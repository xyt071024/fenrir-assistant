import json
import random
import time
import threading
from pathlib import Path
from datetime import datetime

class PetState:
    IDLE = "idle"
    WALKING = "walking"
    RUNNING = "running"
    JUMPING = "jumping"
    SITTING = "sitting"
    SLEEPING = "sleeping"
    PLAYING = "playing"
    INTERACTING = "interacting"
    HIDDEN = "hidden"

class PetAction:
    """所有可用动作定义"""

    # 基础动作
    IDLE_ACTIONS = [
        "stand_still", "blink", "look_around", "yawn", "stretch",
        "scratch_head", "tilt_head", "breathe", "tail_swing",
        "ear_twitch", "smile", "frown", "shrug"
    ]

    # 移动动作
    WALK_ACTIONS = [
        "walk_left", "walk_right", "walk_slow", "walk_fast",
        "walk_tired", "walk_happy", "sneak", "tiptoe"
    ]

    # 奔跑动作
    RUN_ACTIONS = [
        "run_left", "run_right", "run_fast", "sprint",
        "dash", "zoom", "panic_run"
    ]

    # 跳跃动作
    JUMP_ACTIONS = [
        "jump_up", "jump_forward", "jump_high", "jump_twirl",
        "double_jump", "hop", "skip", "leap"
    ]

    # 坐下/休息
    SIT_ACTIONS = [
        "sit_down", "sit_pretty", "sit_lazy", "cross_legs",
        "side_sit", "lean_back", "slouch"
    ]

    # 睡眠动作
    SLEEP_ACTIONS = [
        "sleep_curled", "sleep_spread", "sleep_on_back",
        "sleep_twitching", "dream_run", "snore_soft", "wake_up"
    ]

    # 玩耍动作
    PLAY_ACTIONS = [
        "chase_tail", "pounce", "bat_at_object", "roll_over",
        "play_dead", "fetch", "hide_and_seek", "dance",
        "spin", "bow", "wave", "high_five"
    ]

    # 交互动作（与鼠标/用户）
    INTERACT_ACTIONS = [
        "nuzzle_hand", "rub_against", "lick_finger", "beg_for_treat",
        "follow_cursor", "head_pat_enjoy", "handshake",
        "boop_nose", "hug", "kiss_blow", "climb_lap"
    ]

    # 特殊动作
    SPECIAL_ACTIONS = [
        "magic_trick", "do_backflip", "balance_on_ball",
        "juggle_paws", "pretend_statue", "mirror_user",
        "dance_routine", "sing_note", "draw_heart"
    ]

    @classmethod
    def get_all_actions(cls):
        """获取所有动作（约100种）"""
        return (cls.IDLE_ACTIONS + cls.WALK_ACTIONS + cls.RUN_ACTIONS +
                cls.JUMP_ACTIONS + cls.SIT_ACTIONS + cls.SLEEP_ACTIONS +
                cls.PLAY_ACTIONS + cls.INTERACT_ACTIONS + cls.SPECIAL_ACTIONS)

    @classmethod
    def get_random(cls, state=None):
        """根据状态获取随机动作"""
        if state == PetState.IDLE:
            pool = cls.IDLE_ACTIONS
        elif state == PetState.WALKING:
            pool = cls.WALK_ACTIONS
        elif state == PetState.RUNNING:
            pool = cls.RUN_ACTIONS
        elif state == PetState.JUMPING:
            pool = cls.JUMP_ACTIONS
        elif state == PetState.SITTING:
            pool = cls.SIT_ACTIONS
        elif state == PetState.SLEEPING:
            pool = cls.SLEEP_ACTIONS
        elif state == PetState.PLAYING:
            pool = cls.PLAY_ACTIONS + cls.SPECIAL_ACTIONS
        elif state == PetState.INTERACTING:
            pool = cls.INTERACT_ACTIONS
        else:
            pool = cls.get_all_actions()
        return random.choice(pool)

class PetEmotion:
    """宠物情感系统"""

    EMOTIONS = {
        "happy": {"icon": "😊", "description": "开心"},
        "sad": {"icon": "😢", "description": "难过"},
        "angry": {"icon": "😠", "description": "生气"},
        "surprised": {"icon": "😮", "description": "惊讶"},
        "scared": {"icon": "😨", "description": "害怕"},
        "loved": {"icon": "🥰", "description": "被爱"},
        "hungry": {"icon": "😋", "description": "饿了"},
        "sleepy": {"icon": "😴", "description": "困了"},
        "playful": {"icon": "😜", "description": "想玩"},
        "curious": {"icon": "🤔", "description": "好奇"},
        "bored": {"icon": "😐", "description": "无聊"},
        "excited": {"icon": "🤩", "description": "兴奋"}
    }

    def __init__(self, initial="happy"):
        self.current = initial
        self.history = []
        self.multiplier = 1.0

    def set(self, emotion):
        if emotion in self.EMOTIONS:
            self.current = emotion
            self.history.append({
                "time": datetime.now().isoformat(),
                "emotion": emotion
            })
            if len(self.history) > 100:
                self.history = self.history[-50:]

    def boost(self, emotion, duration=60):
        """在指定时间内提升某种情感倾向"""
        self.current = emotion
        self.multiplier = 1.5
        threading.Timer(duration, self._reset_multiplier).start()

    def _reset_multiplier(self):
        self.multiplier = 1.0

class DeskPet:
    """桌宠主引擎"""

    ACTION_DURATIONS = {
        "blink": 0.3, "yawn": 2.0, "stretch": 2.5,
        "stand_still": 1.0, "look_around": 1.5,
        "walk_left": 0.8, "walk_right": 0.8,
        "jump_up": 0.6, "sit_down": 1.0,
        "sleep_curled": 3.0, "chase_tail": 2.0,
        "dance": 3.0, "wave": 1.0
    }

    def __init__(self, name="芬璃尔", config_path=None):
        self.name = name
        self.state = PetState.IDLE
        self.emotion = PetEmotion()
        self.position = {"x": 100, "y": 100}
        self.screen_size = {"w": 1920, "h": 1080}
        self.size = 128
        self.opacity = 1.0
        self.speed = 1.0
        self.running = False
        self.current_action = None
        self.custom_image = None
        self.auto_behavior = True
        self.interaction_count = 0
        self.last_interaction = time.time()

        if config_path:
            self.load_config(config_path)

    def start(self):
        """启动宠物"""
        self.running = True
        self.change_state(PetState.IDLE)

    def stop(self):
        """停止宠物"""
        self.running = False
        self.change_state(PetState.HIDDEN)

    def change_state(self, new_state, action=None):
        """切换状态和动作"""
        self.state = new_state
        self.current_action = action or PetAction.get_random(new_state)
        duration = self.ACTION_DURATIONS.get(self.current_action, 1.0)
        return {
            "state": new_state,
            "action": self.current_action,
            "duration": duration / self.speed
        }

    def move_to(self, x, y):
        """移动到指定位置"""
        self.position["x"] = x
        self.position["y"] = y
        return self.change_state(PetState.WALKING)

    def interact(self, interaction_type="click"):
        """与用户交互"""
        self.interaction_count += 1
        self.last_interaction = time.time()

        if interaction_type == "click":
            responses = ["nuzzle_hand", "look_at_user", "blink", "wave"]
        elif interaction_type == "drag":
            responses = ["rub_against", "head_pat_enjoy", "beg_for_treat"]
        elif interaction_type == "double_click":
            responses = ["dance", "do_backflip", "high_five"]
        else:
            responses = ["tilt_head", "scratch_head"]

        action = random.choice(responses)
        self.emotion.set("happy")
        return self.change_state(PetState.INTERACTING, action)

    def wander(self):
        """随机走动"""
        import random as rnd
        x = rnd.randint(50, self.screen_size["w"] - self.size - 50)
        y = rnd.randint(50, self.screen_size["h"] - self.size - 50)
        self.position["x"] = x
        self.position["y"] = y

        state = rnd.choice([PetState.WALKING, PetState.RUNNING, PetState.JUMPING])
        return self.change_state(state)

    def get_status(self):
        """获取宠物的完整状态"""
        return {
            "name": self.name,
            "state": self.state,
            "emotion": self.emotion.current,
            "emotion_icon": PetEmotion.EMOTIONS.get(self.emotion.current, {}).get("icon", "😐"),
            "position": self.position,
            "action": self.current_action,
            "opacity": self.opacity,
            "running": self.running,
            "size": self.size,
            "interaction_count": self.interaction_count
        }

    def auto_think(self):
        """自动行为决策"""
        if not self.auto_behavior or not self.running:
            return None

        time_since_interaction = time.time() - self.last_interaction

        if time_since_interaction > 300:
            result = self.change_state(PetState.SLEEPING)
            self.emotion.set("sleepy")
            return result
        elif time_since_interaction > 120:
            result = self.change_state(PetState.SITTING)
            self.emotion.set("bored")
            return result
        elif time_since_interaction > 30:
            result = self.wander()
            return result

        actions = [
            PetState.IDLE, PetState.WALKING, PetState.PLAYING
        ]
        chosen = random.choice(actions)
        result = self.change_state(chosen)

        # 偶尔改变心情
        if random.random() < 0.1:
            self.emotion.set(random.choice(list(PetEmotion.EMOTIONS.keys())))

        return result

    def load_config(self, config_path):
        """加载配置"""
        path = Path(config_path)
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.size = data.get("size", 128)
                self.opacity = data.get("opacity", 1.0)
                self.speed = data.get("speed", 1.0)
                self.name = data.get("name", "芬璃尔")
                self.auto_behavior = data.get("auto_behavior", True)

    def save_config(self, config_path):
        """保存配置"""
        data = {
            "name": self.name,
            "size": self.size,
            "opacity": self.opacity,
            "speed": self.speed,
            "auto_behavior": self.auto_behavior
        }
        path = Path(config_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


class GameDetector:
    """游戏检测器——检测全屏游戏并通知桌宠隐藏"""

    def __init__(self, pet=None, check_interval=5):
        self.pet = pet
        self.check_interval = check_interval
        self.in_game = False
        self._monitoring = False
        self._callbacks = {"enter_game": [], "exit_game": []}

    def on(self, event, callback):
        """注册事件回调：enter_game / exit_game"""
        if event in self._callbacks:
            self._callbacks[event].append(callback)

    def check_fullscreen(self):
        """检查是否有全屏程序在运行"""
        import psutil
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                name = proc.info["name"].lower()
                for kw in ["game", "play", "client", "launcher"]:
                    if kw in name:
                        try:
                            windows = proc.windows() if hasattr(proc, "windows") else []
                            for win in windows:
                                import win32gui
                                _, _, w, h = win32gui.GetWindowRect(win.handle)
                                if w >= self._get_screen_width() and h >= self._get_screen_height():
                                    return True
                        except:
                            pass
            except:
                continue
        return False

    def _get_screen_width(self):
        try:
            import win32api
            return win32api.GetSystemMetrics(0)
        except:
            return 1920

    def _get_screen_height(self):
        try:
            import win32api
            return win32api.GetSystemMetrics(1)
        except:
            return 1080

    def start_monitoring(self):
        """开始监控游戏状态"""
        self._monitoring = True
        thread = threading.Thread(target=self._monitor_loop, daemon=True)
        thread.start()

    def stop_monitoring(self):
        self._monitoring = False

    def _monitor_loop(self):
        while self._monitoring:
            try:
                fullscreen = self.check_fullscreen()
                if fullscreen and not self.in_game:
                    self.in_game = True
                    if self.pet:
                        self.pet.change_state(PetState.HIDDEN)
                    for cb in self._callbacks["enter_game"]:
                        cb()
                elif not fullscreen and self.in_game:
                    self.in_game = False
                    if self.pet:
                        self.pet.change_state(PetState.IDLE)
                    for cb in self._callbacks["exit_game"]:
                        cb()
            except:
                pass
            time.sleep(self.check_interval)


# 预设宠物皮肤配置
PRESET_PETS = {
    "芬璃尔": {
        "name": "芬璃尔",
        "base_color": "#8B5CF6",
        "accent_color": "#C084FC",
        "description": "紫色调的神秘AI桌宠",
        "default_emotion": "happy"
    },
    "小白": {
        "name": "小白",
        "base_color": "#FFFFFF",
        "accent_color": "#F472B6",
        "description": "白色可爱的猫系桌宠",
        "default_emotion": "playful"
    },
    "天选姬": {
        "name": "天选姬",
        "base_color": "#00BFFF",
        "accent_color": "#FFD700",
        "description": "灵感来自华硕天选姬的蓝色系桌宠",
        "default_emotion": "excited"
    },
    "星辰": {
        "name": "星辰",
        "base_color": "#1E1B4B",
        "accent_color": "#818CF8",
        "description": "星空主题的神秘桌宠",
        "default_emotion": "curious"
    }
}
