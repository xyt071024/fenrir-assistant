TOOL_OBSIDIAN = {
    "name": "obsidian-md",
    "display_name": "Obsidian笔记",
    "description": "基于本地Markdown文件的强大知识管理工具，支持双向链接、图谱视图和插件扩展，是个人知识管理(PKM)的首选工具之一。",
    "category": "笔记知识管理",
    "scenarios": ["个人知识管理", "双向链接笔记", "数字花园", "日记与周报", "知识图谱可视化"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["trilium", "logseq"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "建议搭配 Obsidian Sync 或 Git 进行多设备同步；善用 Templater 和 Dataview 插件可大幅提升效率",
    "github_stars": "65k+",
    "open_source": False,
    "download_command": "非Python工具，请从 obsidian.md 下载安装",
    "fallback": ["logseq", "trilium"]
}

TOOL_NOTION = {
    "name": "notion-sdk",
    "display_name": "Notion",
    "description": "一体化工作空间工具，集笔记、数据库、项目管理、Wiki于一体，支持丰富的富文本编辑和灵活的数据组织方式。",
    "category": "笔记知识管理",
    "scenarios": ["团队知识库", "项目管理", "个人笔记", "OKR跟踪", "内容发布"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["outline"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "利用 Database 功能做结构化数据管理；API 有速率限制，注意控制请求频率",
    "github_stars": "4.5k+ (notion-sdk-py)",
    "open_source": True,
    "download_command": "pip install notion-client",
    "fallback": ["outline", "obsidian-md"]
}

TOOL_EVERNOTE = {
    "name": "evernote",
    "display_name": "EverNote",
    "description": "老牌云笔记服务，支持跨平台同步、网页剪藏、OCR图片搜索和丰富的笔记本组织体系。",
    "category": "笔记知识管理",
    "scenarios": ["网页剪藏", "跨平台笔记同步", "文档归档", "扫描文档管理", "团队协作笔记"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["simplenote", "notion-sdk"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "高级账户才有完整API访问权限；同步偶尔会有冲突需手动处理",
    "github_stars": "1.5k+ (evernote-sdk-python)",
    "open_source": True,
    "download_command": "pip install evernote3",
    "fallback": ["notion-sdk", "joplin"]
}

TOOL_JOPLIN = {
    "name": "joplin",
    "display_name": "Joplin开源笔记",
    "description": "开源跨平台笔记应用，支持Markdown编辑、端到端加密和多种同步方式（NextCloud、Dropbox、OneDrive等）。",
    "category": "笔记知识管理",
    "scenarios": ["开源笔记管理", "端到端加密笔记", "待办事项管理", "网页剪藏", "多端同步"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["boostnote", "simplenote"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "Joplin API 可配合 Python 脚本实现自动化操作；插件系统丰富",
    "github_stars": "46k+",
    "open_source": True,
    "download_command": "pip install joplin-api",
    "fallback": ["obsidian-md", "boostnote"]
}

TOOL_LOGSEQ = {
    "name": "logseq",
    "display_name": "Logseq知识图谱",
    "description": "开源的知识管理和协作平台，基于大纲(outline)和双向链接，支持知识图谱直观展示笔记关联。",
    "category": "笔记知识管理",
    "scenarios": ["知识图谱构建", "大纲笔记", "任务管理", "个人知识管理", "学术研究"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["obsidian-md", "dendron"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "充分利用块级引用和页面属性；搭配 Git 进行版本控制效果更佳",
    "github_stars": "34k+",
    "open_source": True,
    "download_command": "非Python工具，请从 logseq.com 下载，或 pip install logseq-client",
    "fallback": ["obsidian-md", "trilium"]
}

TOOL_TRILIUM = {
    "name": "trilium",
    "display_name": "Trilium笔记",
    "description": "自托管的层级笔记应用，支持富文本和Markdown、关系图、脚本自动化和版本历史。",
    "category": "笔记知识管理",
    "scenarios": ["自托管笔记系统", "层级知识管理", "关系图分析", "内容自动化", "家庭知识库"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["obsidian-md", "dendron"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "内置脚本引擎可实现高度自动化；适合技术用户自托管部署",
    "github_stars": "27k+",
    "open_source": True,
    "download_command": "从 GitHub Releases 下载，或 docker 部署",
    "fallback": ["obsidian-md", "logseq"]
}

TOOL_OUTLINE = {
    "name": "outline",
    "display_name": "Outline团队笔记",
    "description": "现代团队知识库平台，支持Markdown编辑、实时协作、与Slack和SSO集成，界面简洁快速。",
    "category": "笔记知识管理",
    "scenarios": ["团队知识库", "内部文档管理", "技术文档", "新人引导", "SOP管理"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["notion-sdk", "foam"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "支持自部署；API 文档完善，适合企业级知识管理",
    "github_stars": "29k+",
    "open_source": True,
    "download_command": "pip install outline-client 或 Docker 部署",
    "fallback": ["notion-sdk", "dendron"]
}

TOOL_FOAM = {
    "name": "foam",
    "display_name": "Foam知识网络",
    "description": "基于VS Code的可扩展个人知识管理框架，利用Markdown和双向链接构建知识网络。",
    "category": "笔记知识管理",
    "scenarios": ["VS Code知识管理", "双向链接网络", "开发者笔记", "数字花园", "知识发现"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["obsidian-md", "dendron"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "作为VS Code扩展使用，适合习惯在编辑器中工作的开发者",
    "github_stars": "15k+",
    "open_source": True,
    "download_command": "VS Code 扩展市场安装，或 npm install -g foam-cli",
    "fallback": ["obsidian-md", "dendron"]
}

TOOL_DENDRON = {
    "name": "dendron",
    "display_name": "Dendron层次笔记",
    "description": "基于VS Code的层次化笔记工具，通过文件系统的树形结构管理知识，适合大规模知识库。",
    "category": "笔记知识管理",
    "scenarios": ["大规模知识库", "层次化笔记", "开发者文档", "API文档管理", "项目管理"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["foam", "obsidian-md"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "利用层次结构命名规则组织笔记；支持发布静态网站",
    "github_stars": "15k+",
    "open_source": True,
    "download_command": "VS Code 扩展市场安装，或 npm install -g @dendronhq/dendron-cli",
    "fallback": ["obsidian-md", "foam"]
}

TOOL_ZETTLR = {
    "name": "zettlr",
    "display_name": "Zettlr学术笔记",
    "description": "面向学术写作的Markdown编辑器，支持Zotero集成、引用管理和学术出版导出。",
    "category": "笔记知识管理",
    "scenarios": ["学术写作", "论文管理", "引用管理", "学术笔记", "文献综述"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 4,
    "conflicts_with": ["obsidian-md"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "与Zotero文献管理深度集成；支持导出为LaTeX和Word格式",
    "github_stars": "10k+",
    "open_source": True,
    "download_command": "非Python工具，请从 zettlr.com 下载",
    "fallback": ["obsidian-md", "logseq"]
}

TOOL_CHERRYTREE = {
    "name": "cherrytree",
    "display_name": "CherryTree",
    "description": "开源层级笔记应用，支持富文本和代码语法高亮，数据存储在单一SQLite数据库中。",
    "category": "笔记知识管理",
    "scenarios": ["层级笔记", "代码笔记管理", "个人知识库", "离线笔记", "数据迁移"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 4,
    "conflicts_with": ["trilium", "joplin"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "单文件数据库方便备份；支持导入源格式包括HTML、TXT和XML",
    "github_stars": "3.5k+",
    "open_source": True,
    "download_command": "apt install cherrytree 或从 giuspen.com/cherrytree 下载",
    "fallback": ["trilium", "joplin"]
}

TOOL_BOOSTNOTE = {
    "name": "boostnote",
    "display_name": "BoostNote",
    "description": "面向软件开发者的笔记应用，支持Markdown和代码片段存储，提供开发工具集成。",
    "category": "笔记知识管理",
    "scenarios": ["代码片段管理", "开发者笔记", "技术文档", "API文档", "Snippet共享"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["joplin", "lepton"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "支持多语言代码高亮；文件夹和标签双重组织方式",
    "github_stars": "17k+",
    "open_source": True,
    "download_command": "非Python工具，请从 boostnote.io 下载",
    "fallback": ["joplin", "obsidian-md"]
}

TOOL_SIMPLENOTE = {
    "name": "simplenote",
    "display_name": "SimpleNote",
    "description": "轻量级跨平台笔记应用，极简设计理念，支持Markdown和标签分类，自动实时同步。",
    "category": "笔记知识管理",
    "scenarios": ["快速笔记", "跨平台同步", "极简笔记", "列表管理", "协作笔记"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["evernote", "notion-sdk"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "适合需要快速记录的场景；API简单易用但功能有限",
    "github_stars": "5k+ (simplenote.py)",
    "open_source": True,
    "download_command": "pip install simplenote.py",
    "fallback": ["evernote", "joplin"]
}

TOOL_TIDDLYWIKI = {
    "name": "tiddlywiki",
    "display_name": "TiddlyWiki",
    "description": "独特的单HTML文件Wiki，所有内容存储在单个页面中，高度可定制和可扩展。",
    "category": "笔记知识管理",
    "scenarios": ["个人Wiki", "单文件知识库", "自建博客", "个人笔记系统", "知识管理系统"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["outline", "dokuwiki"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "支持插件和主题；可部署为Node.js服务器版本提升保存体验",
    "github_stars": "20k+",
    "open_source": True,
    "download_command": "npm install -g tiddlywiki",
    "fallback": ["obsidian-md", "outline"]
}

TOOL_SIYUAN = {
    "name": "siyuan",
    "display_name": "思源笔记",
    "description": "国产开源个人知识管理系统，支持块级引用、双向链接、Markdown和DataView查询。",
    "category": "笔记知识管理",
    "scenarios": ["中文知识管理", "块级笔记", "双向链接", "本地优先笔记", "知识图谱"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["obsidian-md", "logseq"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "中文支持出色；社区主题和插件丰富；支持数据导出标准格式",
    "github_stars": "22k+",
    "open_source": True,
    "download_command": "非Python工具，请从 github.com/siyuan-note/siyuan 下载",
    "fallback": ["obsidian-md", "logseq"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}