TOOL_APScheduler = {
    "name": "APScheduler", "display_name": "APScheduler高级调度", "description": "功能强大的任务调度库，支持定时、间隔、Cron表达式、持久化任务存储、分布式执行",
    "category": "定时任务", "scenarios": ["定时任务调度", "周期性任务", "后台作业管理"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["schedule", "celery-beat"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "推荐使用 BackgroundScheduler 或 AsyncIOScheduler",
    "github_stars": 7100, "open_source": True,
    "download_command": "pip install apscheduler", "fallback": ["schedule", "celery-beat"]
}

TOOL_schedule = {
    "name": "schedule", "display_name": "schedule轻量调度", "description": "极简的轻量级任务调度库，API简洁易用，适合简单的周期性任务",
    "category": "定时任务", "scenarios": ["简单定时任务", "轻量调度", "快速原型"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["APScheduler"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "不适合持久化或分布式场景",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install schedule", "fallback": ["APScheduler", "timer"]
}

TOOL_croniter = {
    "name": "croniter", "display_name": "croniter cron解析", "description": "Cron 表达式解析和迭代工具，支持验证、计算下次/上次执行时间、反向迭代",
    "category": "定时任务", "scenarios": ["Cron表达式解析", "执行时间计算", "调度规则验证"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "常作为其他调度库的底层依赖使用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install croniter", "fallback": ["APScheduler", "schedule"]
}

TOOL_celery = {
    "name": "celery", "display_name": "celery分布式任务", "description": "业界标准分布式任务队列，支持任务调度、异步执行、结果存储、多Broker、工作流编排",
    "category": "定时任务", "scenarios": ["分布式任务", "异步任务队列", "生产级调度"],
    "accuracy": 5, "efficiency": 5, "speed": 3,
    "conflicts_with": ["huey", "rq", "dramatiq"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要 Redis/RabbitMQ 作为消息代理",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install celery", "fallback": ["huey", "rq", "dramatiq"]
}

TOOL_huey = {
    "name": "huey", "display_name": "huey轻量任务", "description": "轻量级任务队列，支持 Redis/SQLite 作为存储，内置定时任务和重试机制",
    "category": "定时任务", "scenarios": ["轻量异步任务", "定时执行", "Redis任务队列"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["celery", "rq", "arq"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "比 Celery 更轻量，适合中小项目",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install huey", "fallback": ["rq", "celery", "dramatiq"]
}

TOOL_rq = {
    "name": "rq", "display_name": "rq Redis队列", "description": "基于 Redis 的简单任务队列，API简洁，支持任务调度、延迟执行、结果查询",
    "category": "定时任务", "scenarios": ["Redis任务队列", "简单异步任务", "后台作业"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["celery", "huey", "arq"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "依赖 Redis，部署简单零配置",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install rq", "fallback": ["huey", "celery", "arq"]
}

TOOL_dramatiq = {
    "name": "dramatiq", "display_name": "dramatiq任务队列", "description": "快速可靠的分布式任务队列库，支持 Redis/RabbitMQ，自动重试、限流、中间件",
    "category": "定时任务", "scenarios": ["分布式任务处理", "消息队列", "异步任务"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["celery", "huey", "rq"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持先进先出和延迟队列",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install dramatiq", "fallback": ["celery", "rq", "huey"]
}

TOOL_arq = {
    "name": "arq", "display_name": "arq Redis异步队列", "description": "基于 Redis 的异步任务队列，专为 asyncio 设计，支持定时任务、重试、超时控制",
    "category": "定时任务", "scenarios": ["异步任务队列", "asyncio集成", "高性能任务"],
    "accuracy": 5, "efficiency": 4, "speed": 5,
    "conflicts_with": ["rq", "huey", "celery"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "纯异步实现，性能优异",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install arq", "fallback": ["rq", "celery", "dramatiq"]
}

TOOL_celery_beat = {
    "name": "celery-beat", "display_name": "celery-beat周期性任务", "description": "Celery 的周期性任务调度器，支持 Cron 表达式、间隔调度、动态添加/移除任务",
    "category": "定时任务", "scenarios": ["周期性任务", "Celery定时调度", "生产级计划任务"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["APScheduler", "schedule"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要搭配 Celery 和 Redis/RabbitMQ 使用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install celery", "fallback": ["APScheduler", "schedule"]
}

TOOL_apscheduler_tornado = {
    "name": "apscheduler-tornado", "display_name": "apscheduler-tornado Web监控", "description": "APScheduler 的 Tornado Web 管理界面，支持可视化任务管理、执行日志查看",
    "category": "定时任务", "scenarios": ["调度监控面板", "Web管理", "任务可视化"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "需配合 APScheduler 使用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install apscheduler-tornado", "fallback": ["APScheduler", "celery-beat"]
}

TOOL_python_jobs = {
    "name": "python-jobs", "display_name": "python-jobs定时任务", "description": "基于文件存储的定时任务管理库，支持任务持久化、错误重试、并行执行",
    "category": "定时任务", "scenarios": ["简单任务持久化", "文件存储调度", "定时作业"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["APScheduler"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "无需外部依赖，内置 SQLite 存储",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install python-jobs", "fallback": ["APScheduler", "schedule"]
}

TOOL_task_scheduler = {
    "name": "task-scheduler", "display_name": "task-scheduler任务调度", "description": "简单实用的任务调度器，支持单次/周期任务、线程池执行、任务依赖管理",
    "category": "定时任务", "scenarios": ["任务编排", "依赖调度", "线程池执行"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["APScheduler", "schedule"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持任务链和依赖关系配置",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install task-scheduler", "fallback": ["APScheduler", "schedule"]
}

TOOL_delayed = {
    "name": "delayed", "display_name": "delayed延迟执行", "description": "简洁的延迟执行库，支持指定延迟时间后执行函数，可取消/暂停/重置延迟任务",
    "category": "定时任务", "scenarios": ["延迟执行", "超时控制", "定时回调"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["timer", "schedule"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合简单的延迟执行需求",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install delayed", "fallback": ["timer", "schedule"]
}

TOOL_timer = {
    "name": "timer", "display_name": "timer定时器", "description": "Python threading.Timer 增强版，支持重复定时、参数传递、取消操作、线程安全",
    "category": "定时任务", "scenarios": ["重复定时", "倒计时", "心跳任务"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["delayed", "schedule"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "基于标准库 threading.Timer 封装",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install timer", "fallback": ["delayed", "schedule"]
}

TOOL_watchdog = {
    "name": "watchdog", "display_name": "watchdog文件监控", "description": "跨平台文件系统事件监控库，支持文件和目录的创建/修改/删除事件监听与触发",
    "category": "定时任务", "scenarios": ["文件变更监控", "目录监听", "自动化触发", "热重载"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "可实现文件变化触发任务调度的模式",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install watchdog", "fallback": ["inotify", "pyinotify"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
