TOOL_horoscope_api = {
    "name": "horoscope-api星座运势",
    "display_name": "星座运势查询",
    "description": "基于出生日期与行星位置，提供每日、每周、每月的十二星座运势分析，涵盖爱情、事业、财运、健康等方面",
    "category": "心理占星",
    "scenarios": ["每日运势查看", "星座匹配分析", "择日决策参考"],
    "accuracy": 3,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["astrology-calc星盘计算"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "结合个人星盘使用可获得更精准的分析结果",
    "github_stars": 4500,
    "open_source": True,
    "download_command": "pip install horoscope-api",
    "fallback": ["astrology-calc星盘计算", "zodiac-signs十二星座"]
}

TOOL_astrology_calc = {
    "name": "astrology-calc星盘计算",
    "display_name": "个人星盘计算",
    "description": "根据出生时间、地点精确计算个人星盘，输出行星位置、宫位分布、相位角度及星盘解读报告",
    "category": "心理占星",
    "scenarios": ["个人命盘生成", "行星相位分析", "出生图解读"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["horoscope-api星座运势"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需要准确的出生时间和地点才能保证计算精度",
    "github_stars": 3200,
    "open_source": True,
    "download_command": "pip install astrology-calc",
    "fallback": ["horoscope-api星座运势", "zodiac-signs十二星座"]
}

TOOL_zodiac_signs = {
    "name": "zodiac-signs十二星座",
    "display_name": "十二星座百科",
    "description": "全面介绍白羊座到双鱼座的十二星座性格特征、日期范围、守护星、元素属性及星座间关系",
    "category": "心理占星",
    "scenarios": ["星座知识学习", "性格分析参考", "星座科普教学"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合作为星座入门和日常参考工具",
    "github_stars": 2800,
    "open_source": True,
    "download_command": "pip install zodiac-signs",
    "fallback": ["horoscope-api星座运势"]
}

TOOL_tarot_api = {
    "name": "tarot-api塔罗牌",
    "display_name": "塔罗牌占卜",
    "description": "提供韦特塔罗、马赛塔罗等多副牌组的在线占卜功能，包含牌义解释、牌阵推荐和占卜记录管理",
    "category": "心理占星",
    "scenarios": ["心灵指引", "决策参考", "自我探索"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "建议保持专注平静的心态进行占卜，结果仅供参考",
    "github_stars": 5100,
    "open_source": True,
    "download_command": "pip install tarot-api",
    "fallback": ["personality-test人格测试", "psychology-test心理测试"]
}

TOOL_personality_test = {
    "name": "personality-test人格测试",
    "display_name": "人格特质测试",
    "description": "基于大五人格、九型人格等经典理论模型，通过科学问卷评估用户的性格特质与行为倾向",
    "category": "心理测评",
    "scenarios": ["自我认知提升", "职业规划参考", "团队建设辅助"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["MBTI-test MBTI"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "认真回答所有问题可获得更准确的人格画像",
    "github_stars": 6800,
    "open_source": True,
    "download_command": "pip install personality-test",
    "fallback": ["MBTI-test MBTI", "psychology-test心理测试"]
}

TOOL_mbti_test = {
    "name": "MBTI-test MBTI",
    "display_name": "MBTI职业人格测试",
    "description": "基于荣格心理类型的MBTI测评工具，从精力来源、认知方式、决策方式、生活方式四个维度分析人格类型",
    "category": "心理测评",
    "scenarios": ["职业规划", "人际关系改善", "自我认知"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["personality-test人格测试"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "建议在安静环境下完整完成93道题目以获得准确结果",
    "github_stars": 9200,
    "open_source": True,
    "download_command": "pip install mbti-test",
    "fallback": ["personality-test人格测试", "psychology-test心理测试"]
}

TOOL_psychology_test = {
    "name": "psychology-test心理测试",
    "display_name": "专业心理测评",
    "description": "整合SDS抑郁自评、SAS焦虑自评、SCL-90症状自评等标准化心理量表，提供心理健康状况评估",
    "category": "心理测评",
    "scenarios": ["心理健康筛查", "情绪状态评估", "心理咨询辅助"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["personality-test人格测试"],
    "safety_level": "caution",
    "requires_network": False,
    "usage_tips": "测评结果不能替代专业心理诊断，如有需要请咨询心理医生",
    "github_stars": 7500,
    "open_source": True,
    "download_command": "pip install psychology-test",
    "fallback": ["personality-test人格测试", "mood-tracker情绪记录"]
}

TOOL_mood_tracker = {
    "name": "mood-tracker情绪记录",
    "display_name": "情绪追踪记录",
    "description": "支持每日情绪打卡、情绪变化趋势图表、触发因素分析，帮助用户了解和管理自身情绪模式",
    "category": "心理健康",
    "scenarios": ["情绪管理", "心理状态监测", "冥想辅助"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "坚持每日记录可获得更有意义的情绪趋势分析",
    "github_stars": 3800,
    "open_source": True,
    "download_command": "pip install mood-tracker",
    "fallback": ["psychology-test心理测试"]
}

TOOL_dream_interpret = {
    "name": "dream-interpret解梦",
    "display_name": "梦境解析",
    "description": "结合弗洛伊德、荣格等心理学派的解梦理论，对梦境元素进行象征意义分析和潜意识解读",
    "category": "心理探索",
    "scenarios": ["梦境含义探索", "潜意识分析", "自我了解"],
    "accuracy": 2,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "记录梦境细节越丰富，解析结果越有参考价值",
    "github_stars": 2100,
    "open_source": True,
    "download_command": "pip install dream-interpret",
    "fallback": ["psychology-test心理测试", "mood-tracker情绪记录"]
}

TOOL_numerology = {
    "name": "numerology生命灵数",
    "display_name": "生命灵数分析",
    "description": "基于出生日期计算生命灵数、天赋数、命运数等，揭示个人天赋、人生课题和流年运势",
    "category": "心理占星",
    "scenarios": ["命运数字计算", "天赋潜能挖掘", "人生周期分析"],
    "accuracy": 3,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["horoscope-api星座运势", "astrology-calc星盘计算"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "生命灵数可与星座分析互补使用，获得更全面的自我认知",
    "github_stars": 1900,
    "open_source": True,
    "download_command": "pip install numerology",
    "fallback": ["zodiac-signs十二星座", "personality-test人格测试"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}