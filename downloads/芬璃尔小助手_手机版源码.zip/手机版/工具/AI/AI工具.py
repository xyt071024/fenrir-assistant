TOOL_langchain = {
    "name": "langchain", "display_name": "LangChain", "description": "最流行的LLM应用开发框架，提供链式调用、Agent、RAG、工具调用等完整生态，支持数百种模型和向量库集成",
    "category": "AI工具", "scenarios": ["LLM应用开发", "RAG知识库", "AI Agent构建", "链式工作流"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["llamaindex", "semantic-kernel"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "LangChain表达式(LCEL)是推荐写法；注意版本兼容性，0.3+有重大API变更",
    "github_stars": 105000, "open_source": True,
    "download_command": "pip install langchain langchain-community", "fallback": ["llamaindex", "semantic-kernel"]
}

TOOL_llamaindex = {
    "name": "llamaindex", "display_name": "LlamaIndex", "description": "专注数据索引与RAG的LLM框架，提供丰富的文档解析器、索引结构和查询引擎，擅长构建知识库检索系统",
    "category": "AI工具", "scenarios": ["RAG检索增强生成", "文档问答", "结构化数据索引", "多模态RAG"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["langchain", "txtai"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "配合LLM使用效果最佳；支持高级检索策略如Hybrid Search和Rerank",
    "github_stars": 40000, "open_source": True,
    "download_command": "pip install llama-index", "fallback": ["langchain", "txtai"]
}

TOOL_openai = {
    "name": "openai", "display_name": "OpenAI Python SDK", "description": "OpenAI官方Python库，支持GPT-4o/o1系列、DALL-E、Whisper、Embeddings等全API调用",
    "category": "AI工具", "scenarios": ["调用GPT模型", "文本Embedding", "图片生成", "语音转文字"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "v1.0+使用client = OpenAI(api_key=...)新写法；支持Azure OpenAI配置",
    "github_stars": 45000, "open_source": True,
    "download_command": "pip install openai", "fallback": ["anthropic", "google-generativeai"]
}

TOOL_anthropic = {
    "name": "anthropic", "display_name": "Anthropic Claude SDK", "description": "Anthropic官方Python SDK，调用Claude 3.5 Sonnet/Haiku/Opus系列模型，支持系统提示词和Tool Use",
    "category": "AI工具", "scenarios": ["调用Claude模型", "Tool Use工具调用", "长文本分析"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["openai"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持100K+超长上下文；system prompt是独立参数；block until complete模式",
    "github_stars": 8000, "open_source": True,
    "download_command": "pip install anthropic", "fallback": ["openai", "google-generativeai"]
}

TOOL_google_generativeai = {
    "name": "google-generativeai", "display_name": "Google Generative AI (Gemini)", "description": "Google Gemini官方Python库，调用Gemini 1.5 Pro/Flash系列模型，支持多模态输入和百万级Token上下文",
    "category": "AI工具", "scenarios": ["调用Gemini模型", "多模态理解", "超长上下文处理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["openai"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持1M Token超长上下文；免费配额充足适合原型开发",
    "github_stars": 6500, "open_source": True,
    "download_command": "pip install google-generativeai", "fallback": ["openai", "anthropic"]
}

TOOL_huggingface_hub = {
    "name": "huggingface-hub", "display_name": "HuggingFace Hub", "description": "HuggingFace官方库，访问模型/数据集/Spaces仓库，支持模型下载、上传、推理API调用",
    "category": "AI工具", "scenarios": ["下载AI模型", "管理数据集", "调用推理API", "模型版本管理"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "设置HF_HUB_ENABLE_HF_TRANSFER=1加速下载；使用snapshot_download下载整个仓库",
    "github_stars": 17000, "open_source": True,
    "download_command": "pip install huggingface-hub", "fallback": ["modelscope", "gitee-ai"]
}

TOOL_transformers = {
    "name": "transformers", "display_name": "Transformers (HuggingFace)", "description": "HuggingFace核心库，支持BERT/GPT/Llama/Whisper等主流模型架构，统一接口加载数千种预训练模型",
    "category": "AI工具", "scenarios": ["加载预训练模型", "文本分类", "文本生成", "命名实体识别", "问答系统"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "pipeline API快速上手；推荐配合accelerate和bitsandbytes使用低精度推理",
    "github_stars": 140000, "open_source": True,
    "download_command": "pip install transformers", "fallback": ["sentence-transformers", "diffusers"]
}

TOOL_ollama = {
    "name": "ollama", "display_name": "Ollama Python", "description": "Ollama的Python客户端，本地运行和管理LLM模型（Llama/Qwen/DeepSeek等），无需GPU也可运行小模型",
    "category": "AI工具", "scenarios": ["本地运行LLM", "离线AI推理", "模型管理", "API接口封装"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["llama.cpp", "vllm"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "使用前需安装ollama服务端并pull模型；支持自定义Modelfile配置模型参数",
    "github_stars": 12000, "open_source": True,
    "download_command": "pip install ollama", "fallback": ["llama-cpp-python", "transformers"]
}

TOOL_vllm = {
    "name": "vllm", "display_name": "vLLM", "description": "高性能LLM推理引擎，使用PagedAttention实现高效显存管理，支持Continuous Batching和量化推理",
    "category": "AI工具", "scenarios": ["高性能模型部署", "生产级推理服务", "多模型并发", "量化推理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["ollama", "llama.cpp"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "需要CUDA GPU；部署为OpenAI兼容API服务：python -m vllm.entrypoints.openai.api_server",
    "github_stars": 50000, "open_source": True,
    "download_command": "pip install vllm", "fallback": ["ollama", "text-generation-inference"]
}

TOOL_gradio = {
    "name": "gradio", "display_name": "Gradio", "description": "快速构建ML模型Web界面的库，几行代码生成交互式Demo，支持多种输入输出类型和分享链接",
    "category": "AI工具", "scenarios": ["AI模型Demo", "模型可视化", "快速原型", "模型分享"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["streamlit", "chainlit"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "gr.Interface快速创建单页Demo；Blocks API构建复杂界面；share=True生成公网链接",
    "github_stars": 38000, "open_source": True,
    "download_command": "pip install gradio", "fallback": ["streamlit", "chainlit"]
}

TOOL_streamlit = {
    "name": "streamlit", "display_name": "Streamlit", "description": "数据应用构建框架，用纯Python快速搭建数据仪表盘和AI交互应用，自带美化主题和部署方案",
    "category": "AI工具", "scenarios": ["数据仪表盘", "AI交互应用", "数据可视化", "模型分析工具"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["gradio", "chainlit"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "st.session_state管理状态；@st.cache_data装饰器缓存数据；支持cloud免费部署",
    "github_stars": 40000, "open_source": True,
    "download_command": "pip install streamlit", "fallback": ["gradio", "chainlit"]
}

TOOL_chainlit = {
    "name": "chainlit", "display_name": "Chainlit", "description": "专注对话式AI应用的开发框架，原生支持LLM对话界面、流式输出、对话历史、人工干预等功能",
    "category": "AI工具", "scenarios": ["AI对话应用", "Chatbot开发", "LLM应用原型", "人工审核流程"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["gradio", "streamlit"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "原生支持LangChain集成；@cl.on_message装饰器处理消息；内置对话管理",
    "github_stars": 7500, "open_source": True,
    "download_command": "pip install chainlit", "fallback": ["gradio", "streamlit"]
}

TOOL_txtai = {
    "name": "txtai", "display_name": "txtai", "description": "AI驱动的语义搜索平台，整合Embedding、向量检索、RAG、工作流于一体，支持本地运行",
    "category": "AI工具", "scenarios": ["语义搜索", "RAG知识库", "AI工作流", "文本摘要"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["llamaindex", "langchain"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "默认使用SentenceTransformer做Embedding；支持SQLite+FAISS索引，轻量级部署",
    "github_stars": 10000, "open_source": True,
    "download_command": "pip install txtai", "fallback": ["llamaindex", "chromadb"]
}

TOOL_semantic_kernel = {
    "name": "semantic-kernel", "display_name": "Semantic Kernel (微软)", "description": "微软出品LLM编排SDK，支持C#/Python/Java，集成Azure OpenAI，提供Planner和Plugin系统",
    "category": "AI工具", "scenarios": ["Azure AI应用", "企业级LLM编排", "自动化工作流"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["langchain", "autogen"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "Kernel是核心对象；Plugin封装技能函数；Planner自动编排多步任务",
    "github_stars": 25000, "open_source": True,
    "download_command": "pip install semantic-kernel", "fallback": ["langchain", "autogen"]
}

TOOL_autogen = {
    "name": "pyautogen", "display_name": "AutoGen (微软)", "description": "微软多智能体对话框架，支持多个AI Agent协同工作，通过对话完成任务编排和代码生成",
    "category": "AI工具", "scenarios": ["多Agent协作", "代码自动生成", "复杂任务分解", "群聊式AI"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["crewai", "semantic-kernel"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "定义AssistantAgent和UserProxyAgent；GroupChat实现多Agent群聊",
    "github_stars": 40000, "open_source": True,
    "download_command": "pip install pyautogen", "fallback": ["crewai", "semantic-kernel"]
}

TOOL_crewai = {
    "name": "crewai", "display_name": "CrewAI", "description": "多智能体协作框架，定义Role-Based Agent和Task，自动编排工作流实现团队协作式任务完成",
    "category": "AI工具", "scenarios": ["多Agent工作流", "角色分工协作", "内容创作管线", "数据分析管线"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["autogen", "langchain"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "Agent定义role/goal/backstory；Crew定义task执行顺序；支持Process.sequential/hierarchical",
    "github_stars": 30000, "open_source": True,
    "download_command": "pip install crewai", "fallback": ["autogen", "langchain"]
}

TOOL_mem0 = {
    "name": "mem0", "display_name": "Mem0", "description": "AI记忆层工具，为LLM应用添加长期记忆能力，自动提取、存储和检索用户偏好和历史对话",
    "category": "AI工具", "scenarios": ["AI记忆管理", "用户偏好学习", "个性化对话", "长期记忆存储"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["memoripy", "zep"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持向量库存储记忆；自动从对话中提取关键信息；API Key从官网获取",
    "github_stars": 28000, "open_source": True,
    "download_command": "pip install mem0ai", "fallback": ["chromadb", "memoripy"]
}

TOOL_chromadb = {
    "name": "chromadb", "display_name": "ChromaDB", "description": "轻量级开源向量数据库，专为AI应用设计，支持Embedding存储和语义检索，可嵌入运行无需独立服务",
    "category": "AI工具", "scenarios": ["向量存储与检索", "RAG知识库", "语义搜索", "Embedding管理"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["pinecone", "weaviate"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "in-memory模式零配置启动；支持持久化到磁盘；ipython中自动显示查询结果",
    "github_stars": 18000, "open_source": True,
    "download_command": "pip install chromadb", "fallback": ["pinecone", "faiss"]
}

TOOL_pinecone = {
    "name": "pinecone", "display_name": "Pinecone", "description": "云端高性能向量数据库服务，提供低延迟语义搜索和向量存储，支持超大规模索引和混合搜索",
    "category": "AI工具", "scenarios": ["生产级向量搜索", "大规模语义检索", "推荐系统", "RAG基础设施"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["chromadb", "weaviate"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "免费额度足够小项目；支持Sparse-Dense混合检索提升准确率",
    "github_stars": 0, "open_source": False,
    "download_command": "pip install pinecone", "fallback": ["chromadb", "weaviate"]
}

TOOL_weaviate = {
    "name": "weaviate", "display_name": "Weaviate", "description": "开源向量搜索引擎，支持向量+标量混合检索、自动Schema推断、多模态搜索和GraphQL查询",
    "category": "AI工具", "scenarios": ["混合搜索", "多模态检索", "知识图谱", "企业级搜索"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pinecone", "chromadb"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持自托管和云服务；自动向量化功能减少代码量；GraphQL接口灵活查询",
    "github_stars": 13000, "open_source": True,
    "download_command": "pip install weaviate-client", "fallback": ["pinecone", "chromadb"]
}

TOOL_cohere = {
    "name": "cohere", "display_name": "Cohere", "description": "Cohere平台官方Python库，提供企业级Embedding/Rerank/文本生成/分类API，支持多种语言",
    "category": "AI工具", "scenarios": ["文本Embedding", "搜索结果Rerank", "文本分类", "语义搜索"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["openai-embedding"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "Embed v3模型支持多种嵌入类型；Rerank提升搜索结果准确率",
    "github_stars": 4000, "open_source": True,
    "download_command": "pip install cohere", "fallback": ["openai", "google-generativeai"]
}

TOOL_nltk = {
    "name": "nltk", "display_name": "NLTK", "description": "经典自然语言处理库，提供分词、词性标注、命名实体识别、情感分析、语料库等完备NLP工具集",
    "category": "AI工具", "scenarios": ["文本预处理", "分词词性标注", "情感分析", "语料库分析"],
    "accuracy": 3, "efficiency": 3, "speed": 3,
    "conflicts_with": ["spacy", "stanza"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "首次使用需下载语料库：nltk.download('popular')；学术研究经典工具",
    "github_stars": 14000, "open_source": True,
    "download_command": "pip install nltk", "fallback": ["spacy", "stanza"]
}

TOOL_spacy = {
    "name": "spacy", "display_name": "spaCy", "description": "工业级NLP库，速度快精度高，支持Tokenization/POS/NER/Dependency Parsing等，内置预训练模型",
    "category": "AI工具", "scenarios": ["工业级NLP", "命名实体识别", "依存句法分析", "信息提取"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["nltk", "stanza"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "使用python -m spacy download <模型名>下载模型；Doc对象是核心数据结构",
    "github_stars": 31000, "open_source": True,
    "download_command": "pip install spacy", "fallback": ["nltk", "stanza"]
}

TOOL_stanza = {
    "name": "stanza", "display_name": "Stanza (Stanford NLP)", "description": "Stanford NLP官方Python库，提供多语言(超100种)高精度NLP Pipeline，包含CoreNLP全部功能",
    "category": "AI工具", "scenarios": ["多语言NLP", "高精度句法分析", "学术NLP研究", "多语种语料处理"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["spacy", "nltk"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持100+语言；首次使用自动下载模型；CPU推理较慢建议使用GPU",
    "github_stars": 8000, "open_source": True,
    "download_command": "pip install stanza", "fallback": ["spacy", "nltk"]
}

TOOL_fasttext = {
    "name": "fasttext", "display_name": "FastText (Meta)", "description": "Meta高效文本分类和词向量训练工具，支持监督分类和无监督词向量学习，速度快且支持大规模数据",
    "category": "AI工具", "scenarios": ["文本分类", "词向量训练", "语言识别", "文本相似度"],
    "accuracy": 3, "efficiency": 5, "speed": 5,
    "conflicts_with": ["gensim", "word2vec"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "pretrained-vectors可从官网下载预训练词向量；量化模型减少内存占用",
    "github_stars": 27000, "open_source": True,
    "download_command": "pip install fasttext", "fallback": ["gensim", "spacy"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
