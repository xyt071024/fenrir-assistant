TOOL_PYPERCLIP = {
    "name": "pyperclip",
    "display_name": "pyperclip",
    "description": "跨平台剪贴板操作库，支持读取和写入文本到系统剪贴板，兼容Windows/macOS/Linux",
    "category": "剪贴板OCR",
    "scenarios": ["剪贴板读写", "自动化粘贴", "文本复制", "命令行剪贴板"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["pyclip", "clipboard"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Linux需安装xclip或xsel作为后端",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pyperclip",
    "fallback": ["pyclip", "clipboard"]
}

TOOL_PYCLIP = {
    "name": "pyclip",
    "display_name": "pyclip",
    "description": "增强型剪贴板库，支持文本和图片的剪贴板操作，基于pyperclip扩展了图片处理能力",
    "category": "剪贴板OCR",
    "scenarios": ["图片剪贴板", "截图粘贴", "图片复制", "剪贴板增强"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pyperclip", "clipboard"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合需要从剪贴板读取图片的场景",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pyclip",
    "fallback": ["pyperclip", "Pillow"]
}

TOOL_CLIPBOARD = {
    "name": "clipboard",
    "display_name": "clipboard",
    "description": "跨平台剪贴板工具，统一不同操作系统剪贴板操作接口，支持文本和二进制数据",
    "category": "剪贴板OCR",
    "scenarios": ["跨平台剪贴板", "二进制数据剪贴", "自动化操作"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pyperclip", "pyclip"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "底层自动适配各系统原生剪贴板API",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install clipboard",
    "fallback": ["pyperclip", "pyclip"]
}

TOOL_PYOCR = {
    "name": "pyocr",
    "display_name": "pyocr",
    "description": "OCR识别工具封装库，整合Tesseract和Cuneiform等OCR引擎，提供统一的Python调用接口",
    "category": "剪贴板OCR",
    "scenarios": ["OCR识别", "文字提取", "文档数字化", "图片转文字"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pytesseract", "tesserocr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需安装Tesseract OCR引擎本体",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pyocr",
    "fallback": ["pytesseract", "easyocr"]
}

TOOL_PYTESSERACT = {
    "name": "pytesseract",
    "display_name": "pytesseract",
    "description": "Google Tesseract OCR引擎的Python封装，支持100+语言的文字识别，开源OCR的事实标准",
    "category": "剪贴板OCR",
    "scenarios": ["通用OCR", "文档扫描", "图片转文字", "批量文字识别"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pyocr", "tesserocr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需安装Tesseract-OCR引擎并配置系统路径",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pytesseract",
    "fallback": ["easyocr", "paddleocr"]
}

TOOL_EASYOCR = {
    "name": "easyocr",
    "display_name": "EasyOCR",
    "description": "基于深度学习的OCR库，支持80+语言包括中文，无需额外安装OCR引擎，开箱即用",
    "category": "剪贴板OCR",
    "scenarios": ["深度学习OCR", "中文识别", "场景文字识别", "自然场景OCR"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["pytesseract", "paddleocr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "GPU加速效果显著，中文识别效果优秀",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install easyocr",
    "fallback": ["paddleocr", "pytesseract"]
}

TOOL_PADDLEOCR = {
    "name": "paddleocr",
    "display_name": "PaddleOCR",
    "description": "百度飞桨OCR工具库，中文识别效果业界领先，支持表格识别、版面分析和文档结构化",
    "category": "剪贴板OCR",
    "scenarios": ["中文OCR", "表格识别", "文档结构化", "版面分析"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["easyocr", "pytesseract"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "中文识别效果最佳，支持端到端文档分析",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install paddleocr",
    "fallback": ["easyocr", "doctr"]
}

TOOL_DOCTR = {
    "name": "doctr",
    "display_name": "docTR",
    "description": "基于深度学习的文档OCR工具，支持端到端的文本检测和识别，可处理复杂文档布局",
    "category": "剪贴板OCR",
    "scenarios": ["文档OCR", "复杂版面", "端到端OCR", "文档数字化"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["paddleocr", "easyocr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "对扫描文档和PDF的识别效果优秀",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install python-doctr",
    "fallback": ["paddleocr", "easyocr"]
}

TOOL_TESSEROCR = {
    "name": "tesserocr",
    "display_name": "tesserocr",
    "description": "Tesseract OCR引擎的Cython封装，比pytesseract性能更好，直接调用Tesseract C++ API",
    "category": "剪贴板OCR",
    "scenarios": ["高性能OCR", "批量识别", "生产环境OCR"],
    "accuracy": 3,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["pytesseract", "pyocr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需编译安装，性能优于pytesseract约2-3倍",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install tesserocr",
    "fallback": ["pytesseract", "easyocr"]
}

TOOL_MUGGLE_OCR = {
    "name": "muggle_ocr",
    "display_name": "muggle-ocr",
    "description": "轻量级OCR工具，集成Tesseract和CNN模型，专注于验证码和简单文字的快速识别",
    "category": "剪贴板OCR",
    "scenarios": ["验证码识别", "简单文字识别", "快速OCR", "轻量OCR"],
    "accuracy": 3,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["easyocr", "pytesseract"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合短文本和验证码场景，对长篇文档效果一般",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install muggle-ocr",
    "fallback": ["pytesseract", "easyocr"]
}

TOOL_CLIPMAN = {
    "name": "clipman",
    "display_name": "clipman",
    "description": "剪贴板管理器，支持剪贴板历史记录、多条目管理和快捷粘贴，可持久化保存剪贴板内容",
    "category": "剪贴板OCR",
    "scenarios": ["剪贴板历史", "多条目管理", "快捷粘贴", "剪贴板持久化"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pyperclip", "pyclip"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持监听到剪贴板变化自动保存历史记录",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install clipman",
    "fallback": ["pyperclip", "clipboard"]
}

TOOL_PASTE_IMAGE = {
    "name": "paste_image",
    "display_name": "paste-image",
    "description": "图片粘贴工具，支持从剪贴板直接读取图片数据，保存为文件或转换为PIL图像对象",
    "category": "剪贴板OCR",
    "scenarios": ["图片粘贴", "截图处理", "剪贴板图片保存"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["pyclip", "Pillow"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配合PIL使用可读取剪贴板图片的像素数据",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install paste-image",
    "fallback": ["pyclip", "Pillow.ImageGrab"]
}

TOOL_SCREENSHOT_OCR = {
    "name": "screenshot_ocr",
    "display_name": "screenshot-ocr",
    "description": "截图OCR工具，支持屏幕截图后直接识别文字，集成截图和OCR功能于一体",
    "category": "剪贴板OCR",
    "scenarios": ["截图识别", "屏幕文字提取", "实时OCR", "图像文字识别"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["easyocr", "pytesseract"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持选区截图后自动识别，适合日常工作流",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install screenshot-ocr",
    "fallback": ["easyocr", "pytesseract"]
}

TOOL_PDF_OCR = {
    "name": "pdf_ocr",
    "display_name": "pdf-ocr",
    "description": "PDF文字提取工具，支持对扫描版PDF进行OCR识别，可提取文本层并保持原始排版",
    "category": "剪贴板OCR",
    "scenarios": ["PDF文字提取", "扫描件识别", "文档数字化", "PDF转文本"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["doctr", "paddleocr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "对扫描版PDF需先转图片再进行OCR识别",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pdfminer.six",
    "fallback": ["doctr", "pytesseract"]
}

TOOL_TABLE_OCR = {
    "name": "table_ocr",
    "display_name": "table-ocr",
    "description": "表格OCR识别工具，专门识别图片或PDF中的表格数据，提取表格结构和单元格内容为结构化数据",
    "category": "剪贴板OCR",
    "scenarios": ["表格识别", "Excel导入", "发票识别", "表单数字化"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["paddleocr", "doctr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持输出为CSV和Excel格式，便于后续数据处理",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install table-ocr",
    "fallback": ["paddleocr", "doctr"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
