TOOL_matplotlib = {
    "name": "matplotlib", "display_name": "Matplotlib基础图表", "description": "Python最经典的2D绘图库，支持折线图、散点图、柱状图、饼图、等高线图等几乎所有图表类型",
    "category": "数据可视化", "scenarios": ["学术论文绘图", "数据分析可视化", "基础图表制作"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "建议配合Seaborn使用美化样式，rcParams可全局定制风格",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install matplotlib", "fallback": ["seaborn", "plotly"]
}

TOOL_plotly = {
    "name": "plotly", "display_name": "Plotly交互图表", "description": "功能强大的交互式可视化库，支持缩放、悬停、动态更新，可导出为HTML或嵌入Web",
    "category": "数据可视化", "scenarios": ["交互式数据探索", "Web可视化", "仪表盘图表"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "使用plotly.express可快速创建美观图表，支持离线模式",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install plotly", "fallback": ["bokeh", "pyecharts"]
}

TOOL_pyecharts = {
    "name": "pyecharts", "display_name": "Pyecharts ECharts封装", "description": "Apache ECharts的Python封装，提供丰富的中国式图表风格，特别适合数据大屏和商业报告",
    "category": "数据可视化", "scenarios": ["数据大屏", "商业报表", "地理图表"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["plotly"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持链式调用，地图可视化需额外安装地图扩展包",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pyecharts", "fallback": ["plotly", "echarts"]
}

TOOL_seaborn = {
    "name": "seaborn", "display_name": "Seaborn统计图表", "description": "基于Matplotlib的高级统计可视化库，内置美观主题，专为统计数据可视化设计",
    "category": "数据可视化", "scenarios": ["统计图表", "数据分布分析", "相关性可视化"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "搭配Pandas DataFrame使用最方便，一行代码即可生成专业统计图",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install seaborn", "fallback": ["matplotlib"]
}

TOOL_bokeh = {
    "name": "bokeh", "display_name": "Bokeh交互可视化", "description": "专注于Web浏览器的交互式可视化库，支持流式数据更新、大数据集渲染和服务器端交互",
    "category": "数据可视化", "scenarios": ["Web交互图表", "流式数据展示", "大数据可视化"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["plotly"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持Bokeh Server实现实时数据推送，适合Dash应用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install bokeh", "fallback": ["plotly", "holoviews"]
}

TOOL_altair = {
    "name": "altair", "display_name": "Altair声明式可视化", "description": "基于Vega-Lite的声明式统计可视化库，语法简洁优雅，自动选择最佳视觉编码",
    "category": "数据可视化", "scenarios": ["统计可视化", "快速数据探索", "声明式绘图"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "基于Grammar of Graphics理论，支持直接输出Vega-Lite JSON",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install altair", "fallback": ["plotnine", "vega"]
}

TOOL_holoviews = {
    "name": "holoviews", "display_name": "HoloViews高层可视化", "description": "高层可视化封装库，用少量代码即可创建复杂交互可视化，支持多种后端(Bokeh/Matplotlib/Plotly)",
    "category": "数据可视化", "scenarios": ["多维数据探索", "科研可视化", "交互式仪表盘"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "配合Panel使用可构建完整仪表盘应用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install holoviews", "fallback": ["bokeh", "altair"]
}

TOOL_plotnine = {
    "name": "plotnine", "display_name": "Plotnine R风格ggplot", "description": "Python实现的R语言ggplot2风格绘图库，遵循Grammar of Graphics语法",
    "category": "数据可视化", "scenarios": ["R用户迁移", "学术统计图表", "语法一致性绘图"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["altair"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "使用+号叠加图层，语法与R的ggplot2几乎一致",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install plotnine", "fallback": ["seaborn", "altair"]
}

TOOL_networkx = {
    "name": "networkx", "display_name": "NetworkX网络图", "description": "图论与复杂网络分析库，支持社交网络图、知识图谱、流程图的可视化与分析",
    "category": "数据可视化", "scenarios": ["社交网络分析", "知识图谱", "图论研究"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "小规模图直接可视化，大规模图建议用graphviz布局引擎",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install networkx", "fallback": ["graphviz"]
}

TOOL_graphviz = {
    "name": "graphviz", "display_name": "Graphviz图可视化", "description": "专业的图可视化工具，支持有向图、无向图、层级图、流程图等自动布局渲染",
    "category": "数据可视化", "scenarios": ["流程图绘制", "树形图", "自动布局"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "需系统安装Graphviz软件，支持DOT语言描述图结构",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install graphviz", "fallback": ["networkx"]
}

TOOL_mayavi = {
    "name": "mayavi", "display_name": "Mayavi 3D可视化", "description": "基于VTK的强大3D科学可视化库，支持体渲染、等值面、流线、三维标量场和矢量场可视化",
    "category": "数据可视化", "scenarios": ["3D科学可视化", "体数据渲染", "流场可视化"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["vispy"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合科研用途，交互式3D探索功能强大，但安装依赖较多",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mayavi", "fallback": ["vispy", "plotly"]
}

TOOL_vispy = {
    "name": "vispy", "display_name": "Vispy GPU可视化", "description": "基于OpenGL的GPU加速可视化库，支持大规模数据的高性能实时渲染和交互",
    "category": "数据可视化", "scenarios": ["大规模数据可视化", "实时渲染", "GPU加速绘图"],
    "accuracy": 4, "efficiency": 4, "speed": 5,
    "conflicts_with": ["mayavi"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "利用GPU进行并行计算渲染，适合百万级数据点实时交互",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install vispy", "fallback": ["mayavi", "bokeh"]
}

TOOL_vega = {
    "name": "vega", "display_name": "Vega可视化语法", "description": "声明式可视化语法格式，以JSON描述图表，是Altair和Vega-Lite的底层基础",
    "category": "数据可视化", "scenarios": ["自定义可视化语法", "Web嵌入", "可视化规范"],
    "accuracy": 5, "efficiency": 3, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "通常不直接使用，而是通过Vega-Lite或Altair间接操作",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install vega", "fallback": ["altair", "vega-lite"]
}

TOOL_leafmap = {
    "name": "leafmap", "display_name": "Leafmap地理可视化", "description": "基于Leaflet的地理空间可视化库，支持交互式地图制作、矢量/栅格数据可视化",
    "category": "数据可视化", "scenarios": ["地理信息可视化", "卫星影像", "交互式地图"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["folium"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持白膜底图切换，可直接加载GeoJSON、Shapefile等格式",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install leafmap", "fallback": ["folium", "kepler-gl"]
}

TOOL_kepler_gl = {
    "name": "kepler_gl", "display_name": "Kepler.gl数据可视化", "description": "Uber开源的大规模地理数据可视化工具，支持百万级数据点的交互式地图渲染",
    "category": "数据可视化", "scenarios": ["大规模地理数据", "轨迹可视化", "地理数据分析"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "基于WebGL渲染，支持时间动画和滤镜，适合轨迹和热力图展示",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install keplergl", "fallback": ["leafmap", "folium"]
}

TOOL_geopandas = {
    "name": "geopandas", "display_name": "GeoPandas地理数据", "description": "扩展Pandas的地理空间数据处理库，支持Shapefile、GeoJSON等格式的读写与可视化",
    "category": "数据可视化", "scenarios": ["地理数据处理", "空间分析", "地理图表"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "结合matplotlib可直接.plot()绘制地理数据，支持空间连接和坐标变换",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install geopandas", "fallback": ["folium", "leafmap"]
}

TOOL_folium = {
    "name": "folium", "display_name": "Folium地图可视化", "description": "基于Leaflet.js的Python地图可视化库，轻松创建交互式地图，支持标记、热力图、聚类等",
    "category": "数据可视化", "scenarios": ["Web地图制作", "GPS轨迹展示", "地理标记"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["leafmap"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "输出为HTML文件，可嵌入到Web页面中，支持多种在线底图",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install folium", "fallback": ["leafmap", "kepler-gl"]
}

TOOL_dash = {
    "name": "dash", "display_name": "Plotly Dash仪表盘", "description": "Plotly出品的仪表盘框架，用纯Python构建交互式数据仪表盘Web应用",
    "category": "数据可视化", "scenarios": ["数据仪表盘", "Web应用", "企业报表"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["streamlit"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "基于React前端，支持回调函数实现复杂交互逻辑",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install dash", "fallback": ["streamlit", "panel"]
}

TOOL_streamlit = {
    "name": "streamlit", "display_name": "Streamlit快速仪表盘", "description": "最简单的Python数据应用框架，无需前端知识即可快速创建交互式仪表盘和可视化应用",
    "category": "数据可视化", "scenarios": ["快速原型", "数据应用", "机器学习演示"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["dash", "gradio"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "脚本热重载，保存即更新UI，适合快速迭代和演示",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install streamlit", "fallback": ["dash", "gradio"]
}

TOOL_gradio = {
    "name": "gradio", "display_name": "Gradio ML展示", "description": "机器学习模型演示库，快速创建模型交互界面，支持图像、文本、音频等多模态输入输出",
    "category": "数据可视化", "scenarios": ["ML模型展示", "Demo原型", "模型测试"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["streamlit"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持Hugging Face Spaces一键部署，内置队列管理",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install gradio", "fallback": ["streamlit", "dash"]
}

TOOL_panel = {
    "name": "panel", "display_name": "Panel高级仪表盘", "description": "HoloViz生态的仪表盘框架，支持Bokeh/Matplotlib/Plotly等多后端混合使用",
    "category": "数据可视化", "scenarios": ["复杂仪表盘", "多图表联动", "数据应用"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["dash"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "与HoloViews配合效果最佳，支持服务端渲染和回调",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install panel", "fallback": ["dash", "streamlit"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
