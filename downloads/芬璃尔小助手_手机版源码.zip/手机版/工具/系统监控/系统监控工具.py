TOOL_psutil = {
    "name": "psutil", "display_name": "psutil", "description": "跨平台系统监控库，提供CPU/内存/磁盘/网络/进程等实时信息，10.9K GitHub Stars",
    "category": "系统监控", "scenarios": ["系统资源监控", "进程管理", "性能分析", "告警触发"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["psutil-wheels"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "cpu_percent(interval=1)获取CPU使用率，virtual_memory()获取内存详情",
    "github_stars": 10900, "open_source": True,
    "download_command": "pip install psutil", "fallback": ["psutil-wheels", "wmi"]
}

TOOL_gputil = {
    "name": "gputil", "display_name": "GPUtil", "description": "GPU监控工具，通过nvidia-smi获取GPU使用率、显存、温度等信息，返回Python对象",
    "category": "系统监控", "scenarios": ["GPU使用监控", "深度学习训练监控", "显存管理"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["nvidia-ml-py"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "GPUtil.getGPUs()返回所有GPU列表，每个GPU包含load/memory/temperature属性",
    "github_stars": 4000, "open_source": True,
    "download_command": "pip install gputil", "fallback": ["nvidia-ml-py", "psutil"]
}

TOOL_mss = {
    "name": "mss", "display_name": "MSS", "description": "跨平台屏幕截图库，速度极快，支持多显示器、区域截图、窗口截图，输出PIL/Pillow兼容格式",
    "category": "系统监控", "scenarios": ["屏幕截图", "区域截图", "多显示器截取", "定时截图"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["pyautogui"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "mss().shot()快速全屏截图，monitors属性枚举所有显示器",
    "github_stars": 3000, "open_source": True,
    "download_command": "pip install mss", "fallback": ["pyautogui", "PIL.ImageGrab"]
}

TOOL_opencv_python = {
    "name": "opencv_python", "display_name": "opencv-python", "description": "计算机视觉库，可用于屏幕录制、视频处理、图像识别、人脸检测等视觉任务",
    "category": "系统监控", "scenarios": ["屏幕录制", "图像识别", "视频分析", "摄像头采集"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Pillow"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "cv2.VideoWriter录制屏幕，cv2.matchTemplate进行图像模板匹配定位",
    "github_stars": 82000, "open_source": True,
    "download_command": "pip install opencv-python", "fallback": ["mss", "Pillow"]
}

TOOL_pyautogui = {
    "name": "pyautogui", "display_name": "PyAutoGUI", "description": "GUI自动化库，模拟鼠标点击/移动/拖拽、键盘输入、截图、弹窗提醒等操作",
    "category": "系统监控", "scenarios": ["RPA自动化", "鼠标键盘模拟", "GUI测试", "自动操作"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["mss"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "FAILSAFE=True时鼠标移到左上角可紧急停止，locateOnScreen定位图像坐标",
    "github_stars": 11000, "open_source": True,
    "download_command": "pip install pyautogui", "fallback": ["mss", "pynput"]
}

TOOL_keyboard = {
    "name": "keyboard", "display_name": "keyboard", "description": "键盘事件监听与模拟库，支持全局热键、键盘录制回放、按键组合发送",
    "category": "系统监控", "scenarios": ["键盘监听", "全局热键", "键盘宏", "输入自动化"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pynput", "mouse"], "safety_level": "medium",
    "requires_network": False, "usage_tips": "hook()注册回调监听按键，add_hotkey()注册全局快捷键，Windows需管理员权限",
    "github_stars": 4200, "open_source": True,
    "download_command": "pip install keyboard", "fallback": ["pynput", "pyautogui"]
}

TOOL_mouse = {
    "name": "mouse", "display_name": "mouse", "description": "鼠标事件监听与模拟库，支持全局鼠标钩子、点击/移动/滚轮事件捕获和回放",
    "category": "系统监控", "scenarios": ["鼠标监听", "鼠标宏", "点击统计", "自动化操作"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pynput", "keyboard"], "safety_level": "medium",
    "requires_network": False, "usage_tips": "hook()全局监听鼠标事件，play()回放录制的鼠标操作序列",
    "github_stars": 1200, "open_source": True,
    "download_command": "pip install mouse", "fallback": ["pynput", "pyautogui"]
}

TOOL_pynput = {
    "name": "pynput", "display_name": "pynput", "description": "输入设备监听与控制库，统一管理鼠标和键盘，支持Listener/Controller双模式",
    "category": "系统监控", "scenarios": ["输入监听", "键盘记录防护", "自动化输入", "输入统计"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["keyboard", "mouse"], "safety_level": "medium",
    "requires_network": False, "usage_tips": "Listener监听事件，Controller模拟输入，支持stop()优雅退出监听循环",
    "github_stars": 9500, "open_source": True,
    "download_command": "pip install pynput", "fallback": ["keyboard", "mouse"]
}

TOOL_cpuinfo = {
    "name": "cpuinfo", "display_name": "py-cpuinfo", "description": "CPU信息检测库，获取处理器型号、架构、核心数、频率、缓存等详细信息",
    "category": "系统监控", "scenarios": ["CPU信息采集", "硬件检测", "系统信息展示"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["psutil", "wmi"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "cpuinfo.get_cpu_info()返回CPU全部信息字典，brand_raw获取品牌型号字符串",
    "github_stars": 1500, "open_source": True,
    "download_command": "pip install py-cpuinfo", "fallback": ["psutil", "wmi"]
}

TOOL_psutil_wheels = {
    "name": "psutil_wheels", "display_name": "psutil-wheels", "description": "psutil预编译wheel包，提供最新版预编译二进制文件，免编译直接安装",
    "category": "系统监控", "scenarios": ["快速安装", "无编译环境部署", "系统进程监控"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["psutil"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "作为psutil的替代安装方式，功能完全一致，适合无C编译环境的机器",
    "github_stars": 200, "open_source": True,
    "download_command": "pip install psutil-wheels", "fallback": ["psutil"]
}

TOOL_nvidia_ml_py = {
    "name": "nvidia_ml_py", "display_name": "nvidia-ml-py", "description": "NVIDIA Management Library Python绑定，直接调用NVML获取GPU详尽状态数据",
    "category": "系统监控", "scenarios": ["GPU深度监控", "显存分析", "GPU性能调优"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["gputil"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "pynvml.nvmlInit()初始化后调用nvmlDeviceGet*系列函数获取各类GPU数据",
    "github_stars": 1500, "open_source": True,
    "download_command": "pip install nvidia-ml-py", "fallback": ["gputil", "gpuinfo"]
}

TOOL_wmi = {
    "name": "wmi", "display_name": "WMI", "description": "Windows Management Instrumentation Python封装，查询Windows系统硬件软件详细信息",
    "category": "系统监控", "scenarios": ["Windows系统管理", "硬件信息查询", "系统配置采集"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["psutil", "winreg"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "wmi.WMI()建立连接后使用Win32_*类查询各种系统信息，仅Windows平台可用",
    "github_stars": 1700, "open_source": True,
    "download_command": "pip install wmi", "fallback": ["psutil", "pypiwin32"]
}

TOOL_winreg = {
    "name": "winreg", "display_name": "winreg", "description": "Python内置Windows注册表操作模块，读取/写入/枚举注册表键值对",
    "category": "系统监控", "scenarios": ["注册表读写", "系统配置查询", "软件信息获取"],
    "accuracy": 5, "efficiency": 4, "speed": 5,
    "conflicts_with": ["wmi"], "safety_level": "medium",
    "requires_network": False, "usage_tips": "OpenKey/HKEY_LOCAL_MACHINE打开根键，EnumValue枚举键值，修改需谨慎",
    "github_stars": 0, "open_source": True,
    "download_command": "不需要安装，Python内置模块", "fallback": ["wmi", "pypiwin32"]
}

TOOL_screeninfo = {
    "name": "screeninfo", "display_name": "screeninfo", "description": "屏幕信息查询库，获取显示器分辨率、位置、主副屏标识、刷新率等参数",
    "category": "系统监控", "scenarios": ["显示器信息获取", "多屏管理", "分辨率检测"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["mss", "pyautogui"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "screeninfo.get_monitors()返回所有显示器信息，is_primary判断主显示器",
    "github_stars": 600, "open_source": True,
    "download_command": "pip install screeninfo", "fallback": ["mss", "pygetwindow"]
}

TOOL_pygetwindow = {
    "name": "pygetwindow", "display_name": "PyGetWindow", "description": "窗口管理库，获取窗口标题/位置/大小，支持窗口激活/最小化/关闭等操作",
    "category": "系统监控", "scenarios": ["窗口管理", "窗口自动化", "窗口信息查询"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pywinctl"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "getWindowsWithTitle()按标题查找窗口，activate()激活窗口至前台",
    "github_stars": 800, "open_source": True,
    "download_command": "pip install pygetwindow", "fallback": ["pywinctl", "pyautogui"]
}

TOOL_pywinctl = {
    "name": "pywinctl", "display_name": "PyWinCtl", "description": "跨平台窗口控制库，功能比PyGetWindow更丰富，支持窗口置顶/透明度/边框操作",
    "category": "系统监控", "scenarios": ["窗口精细化控制", "窗口状态管理", "窗口事件监听"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pygetwindow"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "getActiveWindow()获取当前激活窗口，setAlwaysOnTop()设置窗口置顶",
    "github_stars": 600, "open_source": True,
    "download_command": "pip install pywinctl", "fallback": ["pygetwindow", "pyautogui"]
}

TOOL_windows_toasts = {
    "name": "windows_toasts", "display_name": "windows-toasts", "description": "Windows原生Toast通知库，发送系统通知消息，支持按钮/图片/输入框等交互元素",
    "category": "系统监控", "scenarios": ["系统通知", "告警提醒", "定时提醒", "状态推送"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["plyer"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "WindowsToast()创建通知，add_button()添加交互按钮，仅Windows 10+可用",
    "github_stars": 300, "open_source": True,
    "download_command": "pip install windows-toasts", "fallback": ["plyer", "pypiwin32"]
}

TOOL_pypiwin32 = {
    "name": "pypiwin32", "display_name": "pypiwin32", "description": "Python Win32 API扩展，提供对Windows API的全面访问，COM/注册表/服务管理等",
    "category": "系统监控", "scenarios": ["Windows API调用", "COM组件操作", "系统服务管理"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["comtypes", "wmi"], "safety_level": "medium",
    "requires_network": False, "usage_tips": "win32api/win32gui/win32com等子模块覆盖系统各方面功能，文档量大",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pypiwin32", "fallback": ["comtypes", "wmi"]
}

TOOL_comtypes = {
    "name": "comtypes", "display_name": "comtypes", "description": "纯Python COM接口库，无需额外工具即可调用Windows COM组件和自动化接口",
    "category": "系统监控", "scenarios": ["COM自动化", "Office操作", "Windows Shell扩展"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["pypiwin32"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "CreateObject()创建COM实例，与VBScript的CreateObject用法相似",
    "github_stars": 800, "open_source": True,
    "download_command": "pip install comtypes", "fallback": ["pypiwin32", "wmi"]
}

TOOL_dark_detector = {
    "name": "dark_detector", "display_name": "dark-detector", "description": "Windows深色/浅色模式检测库，检测系统主题模式并监听主题变更事件",
    "category": "系统监控", "scenarios": ["深色模式检测", "主题适配", "UI自适应"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["winreg"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "is_dark_mode()返回当前是否深色模式，支持注册主题变更回调函数",
    "github_stars": 100, "open_source": True,
    "download_command": "pip install dark-detector", "fallback": ["winreg", "pypiwin32"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
