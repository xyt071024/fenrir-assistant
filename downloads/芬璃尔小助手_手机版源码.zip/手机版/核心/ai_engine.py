from __future__ import annotations
import asyncio
import json
import os
import re
import sqlite3
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

try:
    import aiohttp
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


def count_tokens(text: str) -> int:
    if not text:
        return 0
    text = text.strip()
    chinese_chars = len(re.findall(r'[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]', text))
    other_chars = len(re.sub(r'[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]', '', text))
    return chinese_chars + max(1, other_chars // 4)


def format_messages(history: List[Dict[str, str]], new_message: str, system_prompt: Optional[str] = None) -> List[Dict[str, str]]:
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    if history:
        messages.extend(history)
    messages.append({"role": "user", "content": new_message})
    return messages


def parse_tool_call(response: Dict[str, Any]) -> List[Dict[str, Any]]:
    tool_calls = []

    openai_style = response.get("choices", [{}])[0].get("message", {}).get("tool_calls")
    if openai_style:
        for tc in openai_style:
            func = tc.get("function", {})
            raw_args = func.get("arguments", "{}")
            if isinstance(raw_args, str):
                try:
                    parsed_args = json.loads(raw_args)
                except json.JSONDecodeError:
                    parsed_args = {"_raw": raw_args}
            else:
                parsed_args = raw_args
            tool_calls.append({
                "id": tc.get("id", str(uuid.uuid4())),
                "type": "function",
                "function": {
                    "name": func.get("name", ""),
                    "arguments": parsed_args,
                },
            })

    anthropic_style = response.get("content", [])
    if isinstance(anthropic_style, list):
        for block in anthropic_style:
            if isinstance(block, dict) and block.get("type") == "tool_use":
                raw_input = block.get("input", {})
                if isinstance(raw_input, str):
                    try:
                        parsed_input = json.loads(raw_input)
                    except json.JSONDecodeError:
                        parsed_input = {"_raw": raw_input}
                else:
                    parsed_input = raw_input
                tool_calls.append({
                    "id": block.get("id", str(uuid.uuid4())),
                    "type": "tool_use",
                    "name": block.get("name", ""),
                    "input": parsed_input,
                })

    gemini_style = response.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    if isinstance(gemini_style, list):
        for part in gemini_style:
            if isinstance(part, dict) and "functionCall" in part:
                fc = part["functionCall"]
                raw_args = fc.get("args", {})
                if isinstance(raw_args, str):
                    try:
                        parsed_args = json.loads(raw_args)
                    except json.JSONDecodeError:
                        parsed_args = {"_raw": raw_args}
                else:
                    parsed_args = raw_args
                tool_calls.append({
                    "id": str(uuid.uuid4()),
                    "type": "function",
                    "function": {
                        "name": fc.get("name", ""),
                        "arguments": parsed_args,
                    },
                })

    ollama_style = response.get("message", {}).get("tool_calls")
    if ollama_style:
        for tc in ollama_style:
            raw_args = tc.get("function", {}).get("arguments", {})
            if isinstance(raw_args, str):
                try:
                    parsed_args = json.loads(raw_args)
                except json.JSONDecodeError:
                    parsed_args = {"_raw": raw_args}
            else:
                parsed_args = raw_args
            tool_calls.append({
                "id": str(uuid.uuid4()),
                "type": "function",
                "function": {
                    "name": tc.get("function", {}).get("name", ""),
                    "arguments": parsed_args,
                },
            })

    return tool_calls


class AIEngine:
    PROVIDER_OPENAI = "openai"
    PROVIDER_ANTHROPIC = "anthropic"
    PROVIDER_GEMINI = "gemini"
    PROVIDER_OLLAMA = "ollama"

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or os.path.join(os.path.dirname(__file__), "..", "data", "config.json")
        self.config = self._load_config()
        self.models = self.config.get("models", [])
        self.current_model_name = self.config.get("active_model", "")
        self.current_model = self._find_model(self.current_model_name) or (self.models[0] if self.models else None)
        self._session: Optional[aiohttp.ClientSession] = None

    def _load_config(self) -> Dict[str, Any]:
        config_file = Path(self.config_path)
        if config_file.exists():
            try:
                return json.loads(config_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, IOError):
                pass
        default_config = {
            "models": [
                {
                    "name": "gpt-4o",
                    "provider": "openai",
                    "api_key": "",
                    "api_base": "https://api.openai.com/v1",
                    "model": "gpt-4o",
                    "supports_tools": True,
                    "supports_vision": True,
                    "max_tokens": 4096,
                },
                {
                    "name": "deepseek-chat",
                    "provider": "openai",
                    "api_key": "",
                    "api_base": "https://api.deepseek.com/v1",
                    "model": "deepseek-chat",
                    "supports_tools": True,
                    "supports_vision": False,
                    "max_tokens": 8192,
                },
                {
                    "name": "claude-3.5-sonnet",
                    "provider": "anthropic",
                    "api_key": "",
                    "api_base": "https://api.anthropic.com/v1",
                    "model": "claude-3-5-sonnet-20241022",
                    "anthropic_version": "2023-06-01",
                    "supports_tools": True,
                    "supports_vision": True,
                    "max_tokens": 8192,
                },
                {
                    "name": "gemini-2.0-flash",
                    "provider": "gemini",
                    "api_key": "",
                    "api_base": "https://generativelanguage.googleapis.com/v1beta",
                    "model": "gemini-2.0-flash-exp",
                    "supports_tools": True,
                    "supports_vision": True,
                    "max_tokens": 8192,
                },
                {
                    "name": "ollama-llama3",
                    "provider": "ollama",
                    "api_key": "",
                    "api_base": "http://localhost:11434",
                    "model": "llama3",
                    "supports_tools": True,
                    "supports_vision": False,
                    "max_tokens": 4096,
                },
            ],
            "active_model": "gpt-4o",
        }
        return default_config

    def _find_model(self, name: str) -> Optional[Dict[str, Any]]:
        for m in self.models:
            if m.get("name") == name:
                return m
        return None

    def get_available_models(self) -> List[Dict[str, Any]]:
        return list(self.models)

    def set_model(self, model_name: str) -> bool:
        model = self._find_model(model_name)
        if model:
            self.current_model = model
            self.current_model_name = model_name
            self.config["active_model"] = model_name
            self._save_config()
            return True
        return False

    def supports_tools(self) -> bool:
        return bool(self.current_model and self.current_model.get("supports_tools", False))

    def supports_vision(self) -> bool:
        return bool(self.current_model and self.current_model.get("supports_vision", False))

    def _save_config(self) -> None:
        config_file = Path(self.config_path)
        config_file.parent.mkdir(parents=True, exist_ok=True)
        try:
            config_file.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        except IOError:
            pass

    def _get_provider(self) -> str:
        return (self.current_model or {}).get("provider", "openai")

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    async def chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        stream: bool = True,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Union[Dict[str, Any], AsyncGenerator[Dict[str, Any], None]]:
        if model:
            model_config = self._find_model(model)
            if not model_config:
                raise ValueError(f"Model '{model}' not found in configuration")
        else:
            model_config = self.current_model
            if not model_config:
                raise ValueError("No active model configured")

        provider = model_config.get("provider", "openai")

        if provider == self.PROVIDER_OPENAI:
            return await self._chat_openai(model_config, messages, stream, tools)
        elif provider == self.PROVIDER_ANTHROPIC:
            return await self._chat_anthropic(model_config, messages, stream, tools)
        elif provider == self.PROVIDER_GEMINI:
            return await self._chat_gemini(model_config, messages, stream, tools)
        elif provider == self.PROVIDER_OLLAMA:
            return await self._chat_ollama(model_config, messages, stream, tools)
        else:
            raise ValueError(f"Unsupported provider: {provider}")

    async def _chat_openai(
        self,
        model_config: Dict[str, Any],
        messages: List[Dict[str, str]],
        stream: bool,
        tools: Optional[List[Dict[str, Any]]],
    ) -> Union[Dict[str, Any], AsyncGenerator[Dict[str, Any], None]]:
        api_base = model_config.get("api_base", "https://api.openai.com/v1").rstrip("/")
        api_key = model_config.get("api_key", "")
        model_name = model_config.get("model", "gpt-4o")

        url = f"{api_base}/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        }
        payload: Dict[str, Any] = {
            "model": model_name,
            "messages": messages,
            "stream": stream,
        }
        max_tokens = model_config.get("max_tokens")
        if max_tokens:
            payload["max_tokens"] = max_tokens

        if tools and model_config.get("supports_tools", False):
            payload["tools"] = tools
            payload["tool_choice"] = "auto"

        if stream:
            return self._stream_openai(url, headers, payload)
        else:
            return await self._request_openai(url, headers, payload)

    async def _request_openai(self, url: str, headers: Dict[str, str], payload: Dict[str, Any]) -> Dict[str, Any]:
        if HAS_AIOHTTP:
            session = await self._ensure_session()
            async with session.post(url, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=120)) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"OpenAI API error ({resp.status}): {error_text}")
                return await resp.json()
        elif HAS_REQUESTS:
            loop = asyncio.get_event_loop()
            def _sync_request():
                resp = requests.post(url, headers=headers, json=payload, timeout=120)
                if resp.status_code != 200:
                    raise RuntimeError(f"OpenAI API error ({resp.status_code}): {resp.text}")
                return resp.json()
            return await loop.run_in_executor(None, _sync_request)
        else:
            raise ImportError("Either 'aiohttp' or 'requests' is required for HTTP requests")

    async def _stream_openai(self, url: str, headers: Dict[str, str], payload: Dict[str, Any]):
        if HAS_AIOHTTP:
            session = await self._ensure_session()
            async with session.post(url, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=300)) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"OpenAI API error ({resp.status}): {error_text}")
                async for line in resp.content:
                    decoded = line.decode("utf-8", errors="replace").strip()
                    if not decoded or decoded.startswith(":"):
                        continue
                    if decoded.startswith("data: "):
                        data_str = decoded[6:]
                        if data_str == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data_str)
                            delta = chunk.get("choices", [{}])[0].get("delta", {})
                            finish_reason = chunk.get("choices", [{}])[0].get("finish_reason")
                            result = {
                                "type": "delta",
                                "content": delta.get("content", ""),
                                "role": delta.get("role", "assistant"),
                                "finish_reason": finish_reason,
                            }
                            tool_calls_delta = delta.get("tool_calls")
                            if tool_calls_delta:
                                result["tool_calls"] = tool_calls_delta
                            yield result
                            if finish_reason in ("stop", "tool_calls"):
                                break
                        except json.JSONDecodeError:
                            continue
        elif HAS_REQUESTS:
            loop = asyncio.get_event_loop()
            def _sync_stream():
                with requests.post(url, headers=headers, json=payload, stream=True, timeout=300) as resp:
                    if resp.status_code != 200:
                        raise RuntimeError(f"OpenAI API error ({resp.status_code}): {resp.text}")
                    for line in resp.iter_lines(decode_unicode=True):
                        if not line or line.startswith(":"):
                            continue
                        if line.startswith("data: "):
                            data_str = line[6:]
                            if data_str == "[DONE]":
                                break
                            try:
                                chunk = json.loads(data_str)
                                delta = chunk.get("choices", [{}])[0].get("delta", {})
                                finish_reason = chunk.get("choices", [{}])[0].get("finish_reason")
                                result = {
                                    "type": "delta",
                                    "content": delta.get("content", ""),
                                    "role": delta.get("role", "assistant"),
                                    "finish_reason": finish_reason,
                                }
                                tool_calls_delta = delta.get("tool_calls")
                                if tool_calls_delta:
                                    result["tool_calls"] = tool_calls_delta
                                yield result
                                if finish_reason in ("stop", "tool_calls"):
                                    break
                            except json.JSONDecodeError:
                                continue
            gen = _sync_stream()
            for item in gen:
                yield item
        else:
            raise ImportError("Either 'aiohttp' or 'requests' is required for HTTP requests")

    async def _chat_anthropic(
        self,
        model_config: Dict[str, Any],
        messages: List[Dict[str, str]],
        stream: bool,
        tools: Optional[List[Dict[str, Any]]],
    ) -> Union[Dict[str, Any], AsyncGenerator[Dict[str, Any], None]]:
        api_base = model_config.get("api_base", "https://api.anthropic.com/v1").rstrip("/")
        api_key = model_config.get("api_key", "")
        model_name = model_config.get("model", "claude-3-5-sonnet-20241022")
        api_version = model_config.get("anthropic_version", "2023-06-01")

        url = f"{api_base}/messages"
        headers = {
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": api_version,
        }

        system_msg = None
        filtered_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                filtered_messages.append(msg)

        payload: Dict[str, Any] = {
            "model": model_name,
            "messages": filtered_messages,
            "max_tokens": model_config.get("max_tokens", 4096),
            "stream": stream,
        }
        if system_msg:
            payload["system"] = system_msg

        anthropic_tools = None
        if tools and model_config.get("supports_tools", False):
            anthropic_tools = []
            for t in tools:
                func = t.get("function", t)
                anthropic_tools.append({
                    "name": func.get("name", t.get("name", "")),
                    "description": func.get("description", ""),
                    "input_schema": func.get("parameters", {}),
                })
            payload["tools"] = anthropic_tools

        if stream:
            return self._stream_anthropic(url, headers, payload)
        else:
            return await self._request_anthropic(url, headers, payload)

    async def _request_anthropic(self, url: str, headers: Dict[str, str], payload: Dict[str, Any]) -> Dict[str, Any]:
        if HAS_AIOHTTP:
            session = await self._ensure_session()
            async with session.post(url, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=120)) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"Anthropic API error ({resp.status}): {error_text}")
                return await resp.json()
        elif HAS_REQUESTS:
            loop = asyncio.get_event_loop()
            def _sync_request():
                resp = requests.post(url, headers=headers, json=payload, timeout=120)
                if resp.status_code != 200:
                    raise RuntimeError(f"Anthropic API error ({resp.status_code}): {resp.text}")
                return resp.json()
            return await loop.run_in_executor(None, _sync_request)
        else:
            raise ImportError("Either 'aiohttp' or 'requests' is required for HTTP requests")

    async def _stream_anthropic(self, url: str, headers: Dict[str, str], payload: Dict[str, Any]):
        if HAS_AIOHTTP:
            session = await self._ensure_session()
            async with session.post(url, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=300)) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"Anthropic API error ({resp.status}): {error_text}")
                async for line in resp.content:
                    decoded = line.decode("utf-8", errors="replace").strip()
                    if not decoded or not decoded.startswith("event:"):
                        continue
                    event_type = decoded[6:].strip()
                    data_line = await resp.content.readline()
                    data_str = data_line.decode("utf-8", errors="replace").strip()
                    if data_str.startswith("data: "):
                        data_str = data_str[6:]
                    if event_type == "content_block_delta":
                        try:
                            data = json.loads(data_str)
                            delta = data.get("delta", {})
                            if delta.get("type") == "text_delta":
                                yield {
                                    "type": "delta",
                                    "content": delta.get("text", ""),
                                    "role": "assistant",
                                }
                        except json.JSONDecodeError:
                            continue
                    elif event_type == "message_stop":
                        yield {"type": "done", "content": "", "finish_reason": "stop"}
                        break
                    elif event_type == "content_block_start":
                        try:
                            data = json.loads(data_str)
                            block = data.get("content_block", {})
                            if block.get("type") == "tool_use":
                                yield {
                                    "type": "tool_call_start",
                                    "tool_call_id": block.get("id", ""),
                                    "tool_name": block.get("name", ""),
                                }
                        except json.JSONDecodeError:
                            continue
        else:
            yield {"type": "error", "content": "Streaming Anthropic requires aiohttp"}

    async def _chat_gemini(
        self,
        model_config: Dict[str, Any],
        messages: List[Dict[str, str]],
        stream: bool,
        tools: Optional[List[Dict[str, Any]]],
    ) -> Union[Dict[str, Any], AsyncGenerator[Dict[str, Any], None]]:
        api_base = model_config.get("api_base", "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
        api_key = model_config.get("api_key", "")
        model_name = model_config.get("model", "gemini-2.0-flash-exp")

        gemini_contents = self._convert_to_gemini_format(messages)

        payload: Dict[str, Any] = {
            "contents": gemini_contents,
        }

        if tools and model_config.get("supports_tools", False):
            gemini_tools = []
            for t in tools:
                func = t.get("function", t)
                gemini_tools.append({
                    "functionDeclarations": [{
                        "name": func.get("name", ""),
                        "description": func.get("description", ""),
                        "parameters": func.get("parameters", {}),
                    }]
                })
            payload["tools"] = gemini_tools

        if not stream:
            return await self._chat_gemini_nonstream(api_base, api_key, model_name, payload)
        else:
            return self._chat_gemini_stream(api_base, api_key, model_name, payload)

    async def _chat_gemini_nonstream(
        self,
        api_base: str,
        api_key: str,
        model_name: str,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        url = f"{api_base}/models/{model_name}:generateContent?key={api_key}"
        if HAS_AIOHTTP:
            session = await self._ensure_session()
            async with session.post(url, headers={"Content-Type": "application/json"}, json=payload,
                                    timeout=aiohttp.ClientTimeout(total=120)) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"Gemini API error ({resp.status}): {error_text}")
                result = await resp.json()
                return self._convert_gemini_response(result)
        elif HAS_REQUESTS:
            loop = asyncio.get_event_loop()
            def _sync_request():
                resp = requests.post(url, headers={"Content-Type": "application/json"}, json=payload, timeout=120)
                if resp.status_code != 200:
                    raise RuntimeError(f"Gemini API error ({resp.status_code}): {resp.text}")
                return self._convert_gemini_response(resp.json())
            return await loop.run_in_executor(None, _sync_request)
        else:
            raise ImportError("Either 'aiohttp' or 'requests' is required for HTTP requests")

    async def _chat_gemini_stream(
        self,
        api_base: str,
        api_key: str,
        model_name: str,
        payload: Dict[str, Any],
    ):
        stream_url = f"{api_base}/models/{model_name}:streamGenerateContent?key={api_key}&alt=sse"
        if HAS_AIOHTTP:
            session = await self._ensure_session()
            async with session.post(stream_url, headers={"Content-Type": "application/json"}, json=payload,
                                    timeout=aiohttp.ClientTimeout(total=300)) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"Gemini API error ({resp.status}): {error_text}")
                async for line in resp.content:
                    decoded = line.decode("utf-8", errors="replace").strip()
                    if not decoded or not decoded.startswith("data: "):
                        continue
                    data_str = decoded[6:]
                    try:
                        data = json.loads(data_str)
                        candidates = data.get("candidates", [])
                        if candidates:
                            content = candidates[0].get("content", {})
                            parts = content.get("parts", [])
                            for part in parts:
                                if "text" in part:
                                    yield {
                                        "type": "delta",
                                        "content": part["text"],
                                        "role": "assistant",
                                    }
                                if "functionCall" in part:
                                    yield {
                                        "type": "tool_call",
                                        "content": "",
                                        "tool_calls": [{
                                            "id": str(uuid.uuid4()),
                                            "type": "function",
                                            "function": {
                                                "name": part["functionCall"].get("name", ""),
                                                "arguments": part["functionCall"].get("args", {}),
                                            },
                                        }],
                                    }
                        finish = candidates[0].get("finishReason") if candidates else None
                        if finish and finish != "STOP":
                            if finish == "STOP":
                                yield {"type": "done", "content": "", "finish_reason": "stop"}
                            else:
                                yield {"type": "done", "content": "", "finish_reason": finish.lower()}
                    except json.JSONDecodeError:
                        continue
        else:
            yield {"type": "error", "content": "Streaming Gemini requires aiohttp"}

    def _convert_to_gemini_format(self, messages: List[Dict[str, str]]) -> List[Dict[str, Any]]:
        gemini_contents = []
        system_instruction = None

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")

            if role == "system":
                system_instruction = content
                continue

            parts = [{"text": content}]
            gemini_role = "model" if role in ("assistant", "model") else "user"

            if isinstance(content, list):
                parts = []
                for item in content:
                    if isinstance(item, dict):
                        if item.get("type") == "text":
                            parts.append({"text": item.get("text", "")})
                        elif item.get("type") == "image_url":
                            image_data = item.get("image_url", {}).get("url", "")
                            if image_data.startswith("data:image"):
                                mime_match = re.match(r'data:(image/\w+);base64,(.+)', image_data)
                                if mime_match:
                                    parts.append({
                                        "inline_data": {
                                            "mime_type": mime_match.group(1),
                                            "data": mime_match.group(2),
                                        }
                                    })
                            else:
                                parts.append({"text": f"[Image: {image_data}]"})
                    else:
                        parts.append({"text": str(item)})

            gemini_contents.append({
                "role": gemini_role,
                "parts": parts,
            })

            if system_instruction:
                gemini_contents.insert(0, {
                    "role": "user",
                    "parts": [{"text": f"[System Instruction]: {system_instruction}"}],
                })

        return gemini_contents

    def _convert_gemini_response(self, response: Dict[str, Any]) -> Dict[str, Any]:
        candidates = response.get("candidates", [])
        if not candidates:
            return {"choices": [{"message": {"role": "assistant", "content": ""}}]}

        candidate = candidates[0]
        content = candidate.get("content", {})
        parts = content.get("parts", [])

        text_parts = []
        tool_calls = []
        for part in parts:
            if "text" in part:
                text_parts.append(part["text"])
            if "functionCall" in part:
                fc = part["functionCall"]
                tool_calls.append({
                    "id": str(uuid.uuid4()),
                    "type": "function",
                    "function": {
                        "name": fc.get("name", ""),
                        "arguments": fc.get("args", {}),
                    },
                })

        message: Dict[str, Any] = {
            "role": "assistant",
            "content": "".join(text_parts),
        }
        if tool_calls:
            message["tool_calls"] = tool_calls

        finish_reason = candidate.get("finishReason", "STOP").lower()

        return {
            "choices": [{
                "message": message,
                "finish_reason": finish_reason,
                "index": 0,
            }],
        }

    async def _chat_ollama(
        self,
        model_config: Dict[str, Any],
        messages: List[Dict[str, str]],
        stream: bool,
        tools: Optional[List[Dict[str, Any]]],
    ) -> Union[Dict[str, Any], AsyncGenerator[Dict[str, Any], None]]:
        api_base = model_config.get("api_base", "http://localhost:11434").rstrip("/")
        model_name = model_config.get("model", "llama3")

        url = f"{api_base}/api/chat"
        payload: Dict[str, Any] = {
            "model": model_name,
            "messages": messages,
            "stream": stream,
        }

        ollama_tools = None
        if tools and model_config.get("supports_tools", False):
            ollama_tools = []
            for t in tools:
                func = t.get("function", t)
                ollama_tools.append({
                    "type": "function",
                    "function": {
                        "name": func.get("name", ""),
                        "description": func.get("description", ""),
                        "parameters": func.get("parameters", {}),
                    },
                })
            payload["tools"] = ollama_tools

        if stream:
            return self._stream_ollama(url, payload)
        else:
            return await self._request_ollama(url, payload)

    async def _request_ollama(self, url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        if HAS_AIOHTTP:
            session = await self._ensure_session()
            async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=120)) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"Ollama API error ({resp.status}): {error_text}")
                raw = await resp.json()
                return {
                    "choices": [{
                        "message": {
                            "role": "assistant",
                            "content": raw.get("message", {}).get("content", ""),
                        },
                        "finish_reason": "stop",
                    }]
                }
        elif HAS_REQUESTS:
            loop = asyncio.get_event_loop()
            def _sync_request():
                resp = requests.post(url, json=payload, timeout=120)
                if resp.status_code != 200:
                    raise RuntimeError(f"Ollama API error ({resp.status_code}): {resp.text}")
                raw = resp.json()
                return {
                    "choices": [{
                        "message": {
                            "role": "assistant",
                            "content": raw.get("message", {}).get("content", ""),
                        },
                        "finish_reason": "stop",
                    }]
                }
            return await loop.run_in_executor(None, _sync_request)
        else:
            raise ImportError("Either 'aiohttp' or 'requests' is required for HTTP requests")

    async def _stream_ollama(self, url: str, payload: Dict[str, Any]):
        if HAS_AIOHTTP:
            session = await self._ensure_session()
            async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=300)) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"Ollama API error ({resp.status}): {error_text}")
                async for line in resp.content:
                    decoded = line.decode("utf-8", errors="replace").strip()
                    if not decoded:
                        continue
                    try:
                        data = json.loads(decoded)
                        if data.get("done"):
                            yield {
                                "type": "done",
                                "content": "",
                                "finish_reason": "stop",
                            }
                            break
                        content = data.get("message", {}).get("content", "")
                        if content:
                            yield {
                                "type": "delta",
                                "content": content,
                                "role": "assistant",
                            }
                    except json.JSONDecodeError:
                        continue
        elif HAS_REQUESTS:
            loop = asyncio.get_event_loop()
            def _sync_stream():
                with requests.post(url, json=payload, stream=True, timeout=300) as resp:
                    if resp.status_code != 200:
                        raise RuntimeError(f"Ollama API error ({resp.status_code}): {resp.text}")
                    for line in resp.iter_lines(decode_unicode=True):
                        if not line:
                            continue
                        try:
                            data = json.loads(line)
                            if data.get("done"):
                                yield {
                                    "type": "done",
                                    "content": "",
                                    "finish_reason": "stop",
                                }
                                break
                            content = data.get("message", {}).get("content", "")
                            if content:
                                yield {
                                    "type": "delta",
                                    "content": content,
                                    "role": "assistant",
                                }
                        except json.JSONDecodeError:
                            continue
            for item in _sync_stream():
                yield item
        else:
            raise ImportError("Either 'aiohttp' or 'requests' is required for HTTP requests")

    async def analyze_image(self, image_path: str, prompt: str) -> str:
        if not self.supports_vision():
            raise RuntimeError("Current model does not support vision")

        model_config = self.current_model
        if not model_config:
            raise ValueError("No active model configured")

        image_path_obj = Path(image_path)
        if not image_path_obj.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")

        image_data = image_path_obj.read_bytes()
        import base64
        b64_data = base64.b64encode(image_data).decode("utf-8")

        ext = image_path_obj.suffix.lower()
        mime_map = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".webp": "image/webp",
        }
        mime = mime_map.get(ext, "image/png")

        provider = model_config.get("provider", "openai")
        if provider == self.PROVIDER_OPENAI:
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:{mime};base64,{b64_data}"},
                        },
                    ],
                }
            ]
            result = await self.chat(messages, stream=False)
            return result.get("choices", [{}])[0].get("message", {}).get("content", "")

        elif provider == self.PROVIDER_ANTHROPIC:
            messages = [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": mime,
                                "data": b64_data,
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ]
            result = await self.chat(messages, stream=False)
            content_blocks = result.get("content", [])
            text_parts = [b.get("text", "") for b in content_blocks if b.get("type") == "text"]
            return "".join(text_parts)

        elif provider == self.PROVIDER_GEMINI:
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:{mime};base64,{b64_data}"},
                        },
                    ],
                }
            ]
            result = await self.chat(messages, stream=False)
            return result.get("choices", [{}])[0].get("message", {}).get("content", "")

        else:
            raise ValueError(f"Vision not supported for provider: {provider}")

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()


class MemorySystem:
    STORAGE_JSON = "json"
    STORAGE_SQLITE = "sqlite"

    def __init__(self, storage_path: str):
        self.storage_path = Path(storage_path)
        self.storage_dir = self.storage_path.parent
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.storage_dir / "memories.db"
        self.json_path = self.storage_path if self.storage_path.suffix == ".json" else self.storage_dir / "memories.json"
        self._use_sqlite = self._check_sqlite()
        self._init_storage()

    def _check_sqlite(self) -> bool:
        try:
            sqlite3.sqlite_version
            return True
        except Exception:
            return False

    def _init_storage(self) -> None:
        if self._use_sqlite:
            self._init_sqlite()
        else:
            self._init_json()

    def _init_sqlite(self) -> None:
        conn = sqlite3.connect(str(self.db_path))
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS memories (
                    id TEXT PRIMARY KEY,
                    key TEXT NOT NULL,
                    value TEXT NOT NULL,
                    type TEXT NOT NULL DEFAULT 'auto',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_memories_key ON memories(key)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type)")
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
                    key, value, content='memories', content_rowid='rowid'
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def _init_json(self) -> None:
        if not self.json_path.exists():
            self.json_path.write_text(json.dumps([], ensure_ascii=False), encoding="utf-8")

    def _get_json_data(self) -> List[Dict[str, Any]]:
        try:
            return json.loads(self.json_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, IOError):
            return []

    def _save_json_data(self, data: List[Dict[str, Any]]) -> None:
        self.json_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _generate_id(self) -> str:
        return str(uuid.uuid4())

    def _now(self) -> str:
        return datetime.now().isoformat()

    def store(self, key: str, value: Any, type: str = "auto") -> bool:
        if type not in ("auto", "manual", "long_term"):
            type = "auto"

        value_str = json.dumps(value, ensure_ascii=False) if not isinstance(value, str) else value

        if self._use_sqlite:
            return self._store_sqlite(key, value_str, type)
        else:
            return self._store_json(key, value_str, type)

    def _store_sqlite(self, key: str, value: str, type: str) -> bool:
        conn = sqlite3.connect(str(self.db_path))
        try:
            now = self._now()
            cursor = conn.execute("SELECT id FROM memories WHERE key = ?", (key,))
            existing = cursor.fetchone()

            if existing:
                mem_id = existing[0]
                conn.execute(
                    "UPDATE memories SET value = ?, type = ?, updated_at = ? WHERE id = ?",
                    (value, type, now, mem_id),
                )
                conn.execute(
                    "INSERT INTO memories_fts(rowid, key, value) VALUES ((SELECT rowid FROM memories WHERE id = ?), ?, ?) "
                    "ON CONFLICT(rowid) DO UPDATE SET key = excluded.key, value = excluded.value",
                    (mem_id, key, value),
                )
            else:
                mem_id = self._generate_id()
                conn.execute(
                    "INSERT INTO memories (id, key, value, type, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (mem_id, key, value, type, now, now),
                )
                row = conn.execute("SELECT rowid FROM memories WHERE id = ?", (mem_id,)).fetchone()
                if row:
                    conn.execute(
                        "INSERT INTO memories_fts(rowid, key, value) VALUES (?, ?, ?)",
                        (row[0], key, value),
                    )
            conn.commit()
            return True
        except sqlite3.Error:
            conn.rollback()
            return False
        finally:
            conn.close()

    def _store_json(self, key: str, value: str, type: str) -> bool:
        data = self._get_json_data()
        now = self._now()
        for item in data:
            if item["key"] == key:
                item["value"] = value
                item["type"] = type
                item["updated_at"] = now
                self._save_json_data(data)
                return True
        data.append({
            "id": self._generate_id(),
            "key": key,
            "value": value,
            "type": type,
            "created_at": now,
            "updated_at": now,
        })
        self._save_json_data(data)
        return True

    def recall(self, key: str) -> Optional[Any]:
        if self._use_sqlite:
            return self._recall_sqlite(key)
        else:
            return self._recall_json(key)

    def _recall_sqlite(self, key: str) -> Optional[Any]:
        conn = sqlite3.connect(str(self.db_path))
        try:
            cursor = conn.execute("SELECT value FROM memories WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row:
                try:
                    return json.loads(row[0])
                except (json.JSONDecodeError, TypeError):
                    return row[0]
            return None
        finally:
            conn.close()

    def _recall_json(self, key: str) -> Optional[Any]:
        data = self._get_json_data()
        for item in data:
            if item["key"] == key:
                try:
                    return json.loads(item["value"])
                except (json.JSONDecodeError, TypeError):
                    return item["value"]
        return None

    def search(self, query: str) -> List[Dict[str, Any]]:
        if self._use_sqlite:
            return self._search_sqlite(query)
        else:
            return self._search_json(query)

    def _search_sqlite(self, query: str) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(str(self.db_path))
        try:
            escaped_query = query.replace('"', '""')
            sql = """
                SELECT m.id, m.key, m.value, m.type, m.created_at, m.updated_at
                FROM memories m
                JOIN memories_fts fts ON fts.rowid = m.rowid
                WHERE memories_fts MATCH ?
                ORDER BY rank
                LIMIT 50
            """
            try:
                cursor = conn.execute(sql, (f'"{escaped_query}"',))
            except sqlite3.OperationalError:
                cursor = conn.execute(
                    "SELECT id, key, value, type, created_at, updated_at FROM memories WHERE key LIKE ? OR value LIKE ? LIMIT 50",
                    (f"%{query}%", f"%{query}%"),
                )
            results = []
            for row in cursor.fetchall():
                val = row[2]
                try:
                    val = json.loads(val)
                except (json.JSONDecodeError, TypeError):
                    pass
                results.append({
                    "id": row[0],
                    "key": row[1],
                    "value": val,
                    "type": row[3],
                    "created_at": row[4],
                    "updated_at": row[5],
                })
            return results
        finally:
            conn.close()

    def _search_json(self, query: str) -> List[Dict[str, Any]]:
        data = self._get_json_data()
        query_lower = query.lower()
        results = []
        for item in data:
            if query_lower in item["key"].lower() or query_lower in item["value"].lower():
                val = item["value"]
                try:
                    val = json.loads(val)
                except (json.JSONDecodeError, TypeError):
                    pass
                results.append({
                    "id": item["id"],
                    "key": item["key"],
                    "value": val,
                    "type": item["type"],
                    "created_at": item["created_at"],
                    "updated_at": item["updated_at"],
                })
        return results

    def build_context(self, limit: int = 10) -> str:
        if self._use_sqlite:
            return self._build_context_sqlite(limit)
        else:
            return self._build_context_json(limit)

    def _build_context_sqlite(self, limit: int) -> str:
        conn = sqlite3.connect(str(self.db_path))
        try:
            cursor = conn.execute(
                """SELECT key, value, type FROM memories
                   ORDER BY updated_at DESC LIMIT ?""",
                (limit,),
            )
            lines = []
            for row in cursor.fetchall():
                val = row[1]
                try:
                    val = json.loads(val)
                    if isinstance(val, (dict, list)):
                        val = json.dumps(val, ensure_ascii=False)
                except (json.JSONDecodeError, TypeError):
                    pass
                type_tag = {"auto": "自动", "manual": "用户指定", "long_term": "长期"}.get(row[2], row[2])
                lines.append(f"[{type_tag}] {row[0]}: {val}")
            return "\n".join(lines)
        finally:
            conn.close()

    def _build_context_json(self, limit: int) -> str:
        data = self._get_json_data()
        sorted_data = sorted(data, key=lambda x: x.get("updated_at", ""), reverse=True)[:limit]
        lines = []
        for item in sorted_data:
            val = item["value"]
            try:
                val = json.loads(val)
                if isinstance(val, (dict, list)):
                    val = json.dumps(val, ensure_ascii=False)
            except (json.JSONDecodeError, TypeError):
                pass
            type_tag = {"auto": "自动", "manual": "用户指定", "long_term": "长期"}.get(item["type"], item["type"])
            lines.append(f"[{type_tag}] {item['key']}: {val}")
        return "\n".join(lines)

    def export(self, path: str) -> bool:
        if self._use_sqlite:
            return self._export_sqlite(path)
        else:
            return self._export_json(path)

    def _export_sqlite(self, path: str) -> bool:
        conn = sqlite3.connect(str(self.db_path))
        try:
            cursor = conn.execute(
                "SELECT id, key, value, type, created_at, updated_at FROM memories ORDER BY updated_at DESC"
            )
            rows = cursor.fetchall()
            export_data = []
            for row in rows:
                val = row[2]
                try:
                    val = json.loads(val)
                except (json.JSONDecodeError, TypeError):
                    pass
                export_data.append({
                    "id": row[0],
                    "key": row[1],
                    "value": val,
                    "type": row[3],
                    "created_at": row[4],
                    "updated_at": row[5],
                })
            Path(path).write_text(json.dumps(export_data, ensure_ascii=False, indent=2), encoding="utf-8")
            return True
        except (sqlite3.Error, IOError):
            return False
        finally:
            conn.close()

    def _export_json(self, path: str) -> bool:
        try:
            import shutil
            shutil.copy2(str(self.json_path), path)
            return True
        except IOError:
            return False

    def clear(self, type: Optional[str] = None) -> int:
        if self._use_sqlite:
            return self._clear_sqlite(type)
        else:
            return self._clear_json(type)

    def _clear_sqlite(self, type: Optional[str] = None) -> int:
        conn = sqlite3.connect(str(self.db_path))
        try:
            if type:
                cursor = conn.execute("DELETE FROM memories WHERE type = ?", (type,))
            else:
                cursor = conn.execute("DELETE FROM memories")
            count = cursor.rowcount
            conn.execute("DELETE FROM memories_fts")
            conn.commit()
            return count
        except sqlite3.Error:
            conn.rollback()
            return 0
        finally:
            conn.close()

    def _clear_json(self, type: Optional[str] = None) -> int:
        data = self._get_json_data()
        if type:
            filtered = [item for item in data if item["type"] != type]
            count = len(data) - len(filtered)
            self._save_json_data(filtered)
        else:
            count = len(data)
            self._save_json_data([])
        return count

    def get_stats(self) -> Dict[str, Any]:
        if self._use_sqlite:
            conn = sqlite3.connect(str(self.db_path))
            try:
                total = conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
                by_type = {}
                cursor = conn.execute("SELECT type, COUNT(*) FROM memories GROUP BY type")
                for row in cursor.fetchall():
                    by_type[row[0]] = row[1]
                oldest = conn.execute("SELECT MIN(created_at) FROM memories").fetchone()[0]
                newest = conn.execute("SELECT MAX(updated_at) FROM memories").fetchone()[0]
                return {
                    "total": total,
                    "by_type": by_type,
                    "oldest": oldest,
                    "newest": newest,
                    "storage": "sqlite",
                }
            finally:
                conn.close()
        else:
            data = self._get_json_data()
            by_type: Dict[str, int] = {}
            for item in data:
                t = item.get("type", "auto")
                by_type[t] = by_type.get(t, 0) + 1
            dates = [item.get("created_at", "") for item in data if item.get("created_at")]
            return {
                "total": len(data),
                "by_type": by_type,
                "oldest": min(dates) if dates else None,
                "newest": max(dates) if dates else None,
                "storage": "json",
            }


class AgentOrchestrator:
    def __init__(self, ai_engine: AIEngine, tool_manager: Any, memory: MemorySystem):
        self.ai = ai_engine
        self.tool_manager = tool_manager
        self.memory = memory
        self.conversation_history: List[Dict[str, str]] = []
        self.max_history = 50
        self.safety_checks_enabled = True

    def _get_tool_manager_tools(self) -> Optional[List[Dict[str, Any]]]:
        if not self.tool_manager:
            return None
        try:
            if hasattr(self.tool_manager, "get_tools") and callable(self.tool_manager.get_tools):
                return self.tool_manager.get_tools()
            return None
        except Exception:
            return None

    def _execute_tool(self, tool_name: str, tool_args: Dict[str, Any]) -> Dict[str, Any]:
        if not self.tool_manager:
            return {"success": False, "error": "No tool manager configured"}
        try:
            if hasattr(self.tool_manager, "execute") and callable(self.tool_manager.execute):
                result = self.tool_manager.execute(tool_name, **tool_args)
                return {"success": True, "result": result}
            elif hasattr(self.tool_manager, "call_tool") and callable(self.tool_manager.call_tool):
                result = self.tool_manager.call_tool(tool_name, tool_args)
                return {"success": True, "result": result}
            else:
                method = getattr(self.tool_manager, tool_name, None)
                if method and callable(method):
                    result = method(**tool_args)
                    return {"success": True, "result": result}
                return {"success": False, "error": f"Tool '{tool_name}' not found"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def validate_safety(self, action: str) -> Tuple[bool, str]:
        if not self.safety_checks_enabled:
            return True, ""

        dangerous_patterns = [
            (r"rm\s+(-rf|/[\w/]+)", "文件删除操作需要确认"),
            (r"format\s+[\w:/\\]", "格式化操作已禁止"),
            (r"dd\s+if=", "磁盘写入操作已禁止"),
            (r"DROP\s+TABLE", "数据库删除操作需要确认"),
            (r"DROP\s+DATABASE", "数据库删除操作需要确认"),
            (r">\s*/dev/sd", "直接磁盘写入操作已禁止"),
            (r"shutdown|reboot|halt", "系统关机/重启操作需要确认"),
            (r"del\s+/[Ff]\s+/[Ss]", "强制删除操作需要确认"),
            (r"rd\s+/[Ss]\s+/[Qq]", "强制删除目录操作需要确认"),
        ]

        for pattern, message in dangerous_patterns:
            if re.search(pattern, action, re.IGNORECASE):
                return False, message

        return True, ""

    async def process_query(self, query: str, context: Optional[str] = None) -> Dict[str, Any]:
        memory_context = self.memory.build_context(limit=5)

        system_prompt = "你是一个智能助手，名叫芬璃尔。请用中文回应用户。"
        if memory_context:
            system_prompt += f"\n\n已知信息：\n{memory_context}"
        if context:
            system_prompt += f"\n\n上下文：\n{context}"

        messages = []
        messages.append({"role": "system", "content": system_prompt})
        for msg in self.conversation_history[-10:]:
            messages.append(msg)
        messages.append({"role": "user", "content": query})

        tools = None
        if self.ai.supports_tools():
            tools = self._get_tool_manager_tools()

        try:
            response = await self.ai.chat(messages, stream=False, tools=tools)
        except Exception as e:
            return {
                "success": False,
                "response": f"AI 请求失败：{str(e)}",
                "tool_calls": [],
                "tool_results": [],
            }

        content = response.get("choices", [{}])[0].get("message", {}).get("content", "")
        tool_calls = parse_tool_call(response)

        tool_results = []
        if tool_calls:
            for tc in tool_calls:
                func_info = tc.get("function", tc)
                tool_name = func_info.get("name", tc.get("name", ""))
                tool_args = func_info.get("arguments", tc.get("input", {}))

                if not tool_name:
                    continue

                safe, message = self.validate_safety(json.dumps(tool_args, ensure_ascii=False))
                if not safe:
                    tool_results.append({
                        "tool": tool_name,
                        "success": False,
                        "error": f"安全拦截：{message}",
                    })
                    continue

                result = self._execute_tool(tool_name, tool_args)
                tool_results.append({
                    "tool": tool_name,
                    "success": result["success"],
                    "result": result.get("result"),
                    "error": result.get("error"),
                })

            if tool_results:
                follow_up_messages = list(messages)
                follow_up_messages.append({
                    "role": "assistant",
                    "content": content if content else "",
                })
                for tr in tool_results:
                    follow_up_messages.append({
                        "role": "tool",
                        "tool_call_id": tc.get("id", ""),
                        "content": json.dumps(tr, ensure_ascii=False),
                    })

                try:
                    follow_up = await self.ai.chat(follow_up_messages, stream=False)
                    content = follow_up.get("choices", [{}])[0].get("message", {}).get("content", content)
                except Exception:
                    pass

        self.conversation_history.append({"role": "user", "content": query})
        self.conversation_history.append({"role": "assistant", "content": content})
        if len(self.conversation_history) > self.max_history * 2:
            self.conversation_history = self.conversation_history[-self.max_history:]

        return {
            "success": True,
            "response": content,
            "tool_calls": tool_calls,
            "tool_results": tool_results,
        }

    async def plan_task(self, task_description: str) -> List[Dict[str, Any]]:
        messages = [
            {
                "role": "system",
                "content": "你是一个任务规划专家。请将以下任务分解为多个可执行的步骤。"
                           "每个步骤必须包含：step_id（数字）、description（描述）、"
                           "depends_on（依赖的上一步ID列表）、requires_tools（是否需要工具）。"
                           "请以JSON数组格式返回。",
            },
            {"role": "user", "content": task_description},
        ]

        try:
            response = await self.ai.chat(messages, stream=False)
            content = response.get("choices", [{}])[0].get("message", {}).get("content", "")

            json_match = re.search(r'\[[\s\S]*\]', content)
            if json_match:
                steps = json.loads(json_match.group())
            else:
                lines = content.strip().split("\n")
                steps = []
                for i, line in enumerate(lines):
                    line = line.strip()
                    if line and not line.startswith("#") and not line.startswith("//"):
                        steps.append({
                            "step_id": i + 1,
                            "description": line,
                            "depends_on": [],
                            "requires_tools": False,
                        })
            return steps
        except Exception as e:
            return [{
                "step_id": 1,
                "description": task_description,
                "depends_on": [],
                "requires_tools": False,
                "error": str(e),
            }]

    async def execute_step(self, step: Dict[str, Any]) -> Dict[str, Any]:
        description = step.get("description", "")
        requires_tools = step.get("requires_tools", False)

        system_prompt = f"执行以下步骤：{description}\n请给出执行结果。"

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"请执行步骤 {step.get('step_id', '?')}：{description}"},
        ]

        tools = None
        if requires_tools and self.ai.supports_tools():
            tools = self._get_tool_manager_tools()

        try:
            response = await self.ai.chat(messages, stream=False, tools=tools)
        except Exception as e:
            return {
                "step_id": step.get("step_id"),
                "success": False,
                "result": f"执行失败：{str(e)}",
            }

        content = response.get("choices", [{}])[0].get("message", {}).get("content", "")
        tool_calls = parse_tool_call(response)

        tool_results = []
        if tool_calls:
            for tc in tool_calls:
                func_info = tc.get("function", tc)
                tool_name = func_info.get("name", tc.get("name", ""))
                tool_args = func_info.get("arguments", tc.get("input", {}))
                if tool_name:
                    result = self._execute_tool(tool_name, tool_args)
                    tool_results.append({
                        "tool": tool_name,
                        "success": result["success"],
                        "result": result.get("result"),
                        "error": result.get("error"),
                    })

        return {
            "step_id": step.get("step_id"),
            "success": True,
            "result": content,
            "tool_results": tool_results,
        }


class AsyncGenerator:
    """Compatibility shim for Python < 3.7 async generators when using requests library."""
    pass