TOOL_playwright = {
    "name": "playwright", "display_name": "Playwright", "description": "微软出品现代浏览器自动化框架，支持Chromium/Firefox/WebKit，异步架构，自动等待元素，内置Trace Viewer调试",
    "category": "浏览器自动化", "scenarios": ["网页自动化测试", "截图生成", "PDF导出", "爬虫渲染"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["selenium", "pyppeteer"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "推荐使用async模式，安装时需执行playwright install下载浏览器",
    "github_stars": 72000, "open_source": True,
    "download_command": "pip install playwright && playwright install", "fallback": ["selenium", "pyppeteer"]
}

TOOL_selenium = {
    "name": "selenium", "display_name": "Selenium", "description": "经典浏览器自动化工具，支持多浏览器驱动(Chrome/Firefox/Edge等)，WebDriver协议行业标准",
    "category": "浏览器自动化", "scenarios": ["兼容性测试", "跨浏览器测试", "老旧项目维护"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["playwright", "undetected-chromedriver"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "需要额外下载对应浏览器的WebDriver，建议使用webdriver-manager自动管理驱动",
    "github_stars": 31000, "open_source": True,
    "download_command": "pip install selenium webdriver-manager", "fallback": ["playwright", "undetected-chromedriver"]
}

TOOL_drission_page = {
    "name": "drission_page", "display_name": "DrissionPage", "description": "国产浏览器自动化与数据包收发结合的工具，可同时操控浏览器和收发HTTP数据包，无需切换",
    "category": "浏览器自动化", "scenarios": ["数据采集", "自动化操作", "请求拦截与修改"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["selenium-wire"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "中文文档完善，上手简单，适合处理需要浏览器渲染又需要抓包分析的场景",
    "github_stars": 8000, "open_source": True,
    "download_command": "pip install DrissionPage", "fallback": ["selenium-wire", "playwright"]
}

TOOL_crawl4ai = {
    "name": "crawl4ai", "display_name": "crawl4ai", "description": "AI友好的网络爬虫，专为LLM设计，输出结构化Markdown/JSON，支持智能内容提取",
    "category": "浏览器自动化", "scenarios": ["AI数据采集", "LLM训练数据准备", "RAG知识库构建"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["firecrawl"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "搭配LLM使用效果最佳，支持自动去除广告和导航元素",
    "github_stars": 32000, "open_source": True,
    "download_command": "pip install crawl4ai", "fallback": ["firecrawl", "newspaper3k"]
}

TOOL_firecrawl = {
    "name": "firecrawl", "display_name": "Firecrawl", "description": "网页内容转高质量Markdown工具，支持JavaScript渲染，适合LLM上下文 ingestion",
    "category": "浏览器自动化", "scenarios": ["网页转Markdown", "AI内容输入", "文档抓取"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["crawl4ai", "html2text"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "有云服务和自托管两种模式，API Key从官网获取",
    "github_stars": 22000, "open_source": True,
    "download_command": "pip install firecrawl-py", "fallback": ["crawl4ai", "html2text"]
}

TOOL_beautifulsoup4 = {
    "name": "beautifulsoup4", "display_name": "BeautifulSoup4", "description": "最流行的HTML/XML解析库，提供Pythonic的文档遍历搜索方式，容错性强",
    "category": "浏览器自动化", "scenarios": ["HTML解析", "数据提取", "网页结构分析"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["selectolax", "lxml"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "搭配lxml解析器可获得更快的解析速度，find/find_all是最常用方法",
    "github_stars": 48000, "open_source": True,
    "download_command": "pip install beautifulsoup4 lxml", "fallback": ["selectolax", "lxml"]
}

TOOL_scrapy = {
    "name": "scrapy", "display_name": "Scrapy", "description": "强大的爬虫框架，内置请求调度、去重、Pipeline、中间件、分布式支持等完整生态",
    "category": "浏览器自动化", "scenarios": ["大规模爬虫", "数据采集管道", "增量抓取"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["requests+bs4自建"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "用Item定义数据结构，Pipeline处理数据持久化，支持ScrapyRT部署为API服务",
    "github_stars": 54000, "open_source": True,
    "download_command": "pip install scrapy", "fallback": ["requests+bs4", "crawl4ai"]
}

TOOL_requests = {
    "name": "requests", "display_name": "Requests", "description": "最流行的Python HTTP库，API简洁优雅，支持Session、SSL验证、文件上传下载",
    "category": "浏览器自动化", "scenarios": ["HTTP请求", "API调用", "文件下载", "网页抓取"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["httpx", "aiohttp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "使用Session复用连接保持Cookie，timeout参数必须设置防止卡死",
    "github_stars": 53000, "open_source": True,
    "download_command": "pip install requests", "fallback": ["httpx", "urllib3"]
}

TOOL_aiohttp = {
    "name": "aiohttp", "display_name": "aiohttp", "description": "高性能异步HTTP客户端/服务端框架，支持WebSocket，适合高并发网络请求场景",
    "category": "浏览器自动化", "scenarios": ["高并发爬虫", "异步API调用", "WebSocket通信"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["requests", "httpx"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "使用async/await语法，ClientSession需用async with管理生命周期",
    "github_stars": 26000, "open_source": True,
    "download_command": "pip install aiohttp", "fallback": ["httpx", "requests"]
}

TOOL_httpx = {
    "name": "httpx", "display_name": "HTTPX", "description": "新一代HTTP客户端，同时支持同步/异步API，HTTP/2协议，与requests API高度兼容",
    "category": "浏览器自动化", "scenarios": ["HTTP/2请求", "同步异步混合项目", "现代化API调用"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["requests", "aiohttp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "可作为requests的平替迁移，h2=3.0+版本才完全支持HTTP/2",
    "github_stars": 10000, "open_source": True,
    "download_command": "pip install httpx[http2]", "fallback": ["requests", "aiohttp"]
}

TOOL_pyppeteer = {
    "name": "pyppeteer", "display_name": "Pyppeteer", "description": "Puppeteer的Python非官方移植版，通过CDP协议控制Chromium，async异步驱动",
    "category": "浏览器自动化", "scenarios": ["Chrome DevTools Protocol操作", "PDF生成", "渲染截图"],
    "accuracy": 3, "efficiency": 3, "speed": 3,
    "conflicts_with": ["playwright", "selenium"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "项目维护较慢，新项目推荐使用Playwright替代",
    "github_stars": 9000, "open_source": True,
    "download_command": "pip install pyppeteer", "fallback": ["playwright", "selenium"]
}

TOOL_undetected_chromedriver = {
    "name": "undetected_chromedriver", "display_name": "undetected-chromedriver", "description": "反检测ChromeDriver，修改浏览器指纹特征，绕过Cloudflare等反爬检测",
    "category": "浏览器自动化", "scenarios": ["反爬绕过", "Cloudflare突破", "自动化对抗"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["selenium原生"], "safety_level": "medium",
    "requires_network": False, "usage_tips": "自动下载匹配版本的ChromeDriver，需注意使用合规用途",
    "github_stars": 11000, "open_source": True,
    "download_command": "pip install undetected-chromedriver", "fallback": ["selenium-stealth", "playwright stealth"]
}

TOOL_selenium_wire = {
    "name": "selenium_wire", "display_name": "selenium-wire", "description": "增强版Selenium，可捕获/修改请求和响应，支持网络请求拦截和抓包分析",
    "category": "浏览器自动化", "scenarios": ["请求拦截", "网络抓包", "请求修改"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["selenium", "drissionpage"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "与Selenium API兼容，添加了request/response拦截器，可能拖慢速度",
    "github_stars": 4000, "open_source": True,
    "download_command": "pip install selenium-wire", "fallback": ["drissionpage", "selenium"]
}

TOOL_playwright_python = {
    "name": "playwright_python", "display_name": "playwright-python", "description": "Playwright官方Python绑定，微软维护，支持所有现代浏览器和移动设备模拟",
    "category": "浏览器自动化", "scenarios": ["跨浏览器测试", "移动端模拟", "截图对比", "性能测试"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["pyppeteer", "selenium"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Browser.new_context()创建隔离浏览器上下文，codegen可录制操作生成代码",
    "github_stars": 72000, "open_source": True,
    "download_command": "pip install playwright && playwright install-deps", "fallback": ["playwright", "selenium"]
}

TOOL_html2text = {
    "name": "html2text", "display_name": "html2text", "description": "HTML转Markdown文本工具，保留标题/列表/链接/表格等结构，可配置转换规则",
    "category": "浏览器自动化", "scenarios": ["HTML转Markdown", "邮件内容提取", "文档格式转换"],
    "accuracy": 4, "efficiency": 4, "speed": 5,
    "conflicts_with": ["firecrawl", "markdownify"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "bodywidth参数控制每行最大字符数，ignore_links可选忽略链接",
    "github_stars": 9000, "open_source": True,
    "download_command": "pip install html2text", "fallback": ["firecrawl", "markdownify"]
}

TOOL_readability = {
    "name": "readability", "display_name": "readability-lxml", "description": "Mozilla Readability的Python移植，提取文章正文标题，去除广告导航等干扰元素",
    "category": "浏览器自动化", "scenarios": ["文章提取", "阅读模式", "正文内容提取"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["boilerpy3", "newspaper3k"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "输入HTML字符串返回提取结果，适合新闻文章类页面的正文提取",
    "github_stars": 4000, "open_source": True,
    "download_command": "pip install readability-lxml", "fallback": ["boilerpy3", "newspaper3k"]
}

TOOL_newspaper3k = {
    "name": "newspaper3k", "display_name": "newspaper3k", "description": "新闻文章提取库，支持文章正文、作者、发布日期、关键词、摘要等多维度提取",
    "category": "浏览器自动化", "scenarios": ["新闻采集", "文章元数据提取", "自然语言预处理"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["readability", "boilerpy3"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "download()后parse()分段进行，nlp()可提取关键词和摘要",
    "github_stars": 15000, "open_source": True,
    "download_command": "pip install newspaper3k", "fallback": ["readability", "boilerpy3"]
}

TOOL_boilerpy3 = {
    "name": "boilerpy3", "display_name": "boilerpy3", "description": "Boilerpipe算法的Python3实现，基于文本密度算法提取网页正文内容",
    "category": "浏览器自动化", "scenarios": ["正文提取", "网页去噪", "内容抽取"],
    "accuracy": 3, "efficiency": 4, "speed": 5,
    "conflicts_with": ["readability", "newspaper3k"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "提供ArticleExtractor/DefaultExtractor等多种提取策略可选",
    "github_stars": 800, "open_source": True,
    "download_command": "pip install boilerpy3", "fallback": ["readability", "newspaper3k"]
}

TOOL_selectolax = {
    "name": "selectolax", "display_name": "selectolax", "description": "基于Modest的快速HTML/XML解析器，使用CSS选择器，相比lxml和bs4速度更快",
    "category": "浏览器自动化", "scenarios": ["高速HTML解析", "CSS选择器查询", "数据提取"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["beautifulsoup4", "lxml"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "只读解析器不支持修改HTML，纯提取场景比bs4快数倍",
    "github_stars": 1200, "open_source": True,
    "download_command": "pip install selectolax", "fallback": ["lxml", "beautifulsoup4"]
}

TOOL_lxml = {
    "name": "lxml", "display_name": "lxml", "description": "高性能XML/HTML解析库，C语言底层实现，支持XPath/CSS选择器，XML Schema验证",
    "category": "浏览器自动化", "scenarios": ["XML/HTML解析", "XPath查询", "Schema验证", "XSLT转换"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["selectolax", "beautifulsoup4"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "etree.HTML()解析HTML，XPath比CSS选择器更强大灵活",
    "github_stars": 10000, "open_source": True,
    "download_command": "pip install lxml", "fallback": ["selectolax", "beautifulsoup4"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
