TOOL_MoviePy = {
    "name": "moviepy",
    "display_name": "MoviePy",
    "description": "视频编辑合成库，支持剪辑、拼接、标题插入、视频合成、音频处理、特效添加等，基于FFmpeg",
    "category": "视频处理工具",
    "scenarios": ["视频剪辑与合成", "视频特效添加", "音频视频合并", "GIF制作", "批量视频处理"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["ffmpeg-python", "av"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合Python脚本自动化处理视频，CPU密集型操作，大视频建议分段处理",
    "github_stars": 13800,
    "open_source": True,
    "download_command": "pip install moviepy",
    "fallback": ["ffmpeg-python", "ffmpeg"]
}

TOOL_OpenCV = {
    "name": "opencv-python",
    "display_name": "OpenCV",
    "description": "计算机视觉库，提供视频捕捉、图像处理、特征检测、目标跟踪等功能，广泛用于实时视频分析",
    "category": "视频处理工具",
    "scenarios": ["实时视频流处理", "运动检测", "人脸识别", "视频帧分析", "摄像头调用"],
    "accuracy": 5, "efficiency": 4, "speed": 5,
    "conflicts_with": ["scikit-image", "imageio"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "处理视频帧时使用numpy数组操作效率最高，注意BGR与RGB色彩空间转换",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install opencv-python",
    "fallback": ["imageio-ffmpeg", "scikit-image"]
}

TOOL_ffmpeg_python = {
    "name": "ffmpeg-python",
    "display_name": "ffmpeg-python",
    "description": "FFmpeg的Python封装库，通过Python调用FFmpeg进行音视频转码、滤镜、流处理等操作",
    "category": "视频处理工具",
    "scenarios": ["视频格式转换", "音视频流处理", "滤镜应用", "视频压缩", "流媒体处理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["MoviePy", "av"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "依赖系统FFmpeg，先安装FFmpeg再装此包；适合构建复杂滤镜链",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install ffmpeg-python",
    "fallback": ["ffmpeg", "MoviePy"]
}

TOOL_scenedetect = {
    "name": "scenedetect",
    "display_name": "PySceneDetect",
    "description": "视频场景检测库，基于内容感知的镜头切换检测，支持自适应阈值、HSV颜色空间检测等多种算法",
    "category": "视频处理工具",
    "scenarios": ["视频场景分割", "镜头切换检测", "视频摘要生成", "关键帧提取", "自动化剪辑"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pyscenedetect", "keyframes"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "检测阈值需根据视频类型调整，快速运动场景建议用自适应检测模式",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install scenedetect",
    "fallback": ["pyscenedetect", "keyframes"]
}

TOOL_vidgear = {
    "name": "vidgear",
    "display_name": "VidGear",
    "description": "视频流处理库，提供高性能视频捕获、写入、网络流媒体处理，支持多种后端(GStreamer/FFmpeg/OpenCV)",
    "category": "视频处理工具",
    "scenarios": ["实时视频流处理", "网络摄像头流", "视频网络传输", "高性能视频写入", "RTSP/RTMP流处理"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["OpenCV", "ffmpeg-python"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "网络流处理需稳定的网络环境，推荐使用Gear API进行读写分离",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install vidgear",
    "fallback": ["OpenCV", "ffmpeg-python"]
}

TOOL_ytdlp = {
    "name": "yt-dlp",
    "display_name": "yt-dlp",
    "description": "视频下载工具(youtube-dl的活跃分支)，支持数千个网站的视频/音频下载，支持格式选择、字幕下载、播放列表批量下载",
    "category": "视频处理工具",
    "scenarios": ["在线视频下载", "播放列表批量下载", "字幕下载", "音频提取", "视频格式转换"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["youtube-dl"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "更新频繁，定期升级以应对网站接口变更；支持--format参数精细控制画质",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install yt-dlp",
    "fallback": ["youtube-dl", "ffmpeg"]
}

TOOL_ffmpeg = {
    "name": "ffmpeg",
    "display_name": "FFmpeg",
    "description": "业界标准的音视频处理命令行工具，支持格式转换、编码解码、滤镜、流处理、录制等几乎所有音视频操作",
    "category": "视频处理工具",
    "scenarios": ["视频转码压缩", "格式转换", "音视频流处理", "视频裁剪拼接", "录屏推流"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["ffmpeg-python", "MoviePy"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "命令行工具而非Python库，了解常用参数(-c:v/-c:a/-filter_complex)可极大提升效率",
    "github_stars": 0,
    "open_source": True,
    "download_command": "choco install ffmpeg",
    "fallback": ["ffmpeg-python", "MoviePy"]
}

TOOL_imageio_ffmpeg = {
    "name": "imageio-ffmpeg",
    "display_name": "imageio-ffmpeg",
    "description": "基于FFmpeg的图片/视频读写库，提供简洁的API进行视频帧读写，是imageio的视频后端",
    "category": "视频处理工具",
    "scenarios": ["视频帧逐帧读写", "视频作为3D数组处理", "科学计算视频读写", "简单视频生成"],
    "accuracy": 3, "efficiency": 3, "speed": 3,
    "conflicts_with": ["imageio", "OpenCV"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合科学计算场景，处理大视频时内存占用较高可配合批量读取策略",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install imageio-ffmpeg",
    "fallback": ["imageio", "OpenCV"]
}

TOOL_av = {
    "name": "av",
    "display_name": "PyAV",
    "description": "FFmpeg的Python绑定库，提供底层音视频处理能力，支持精确的编码参数控制、容器格式操作",
    "category": "视频处理工具",
    "scenarios": ["精确编码控制", "容器格式操作", "音视频流底层处理", "专业视频编辑", "编解码器参数调优"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["ffmpeg-python", "MoviePy"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "学习曲线较陡，适合需要精细控制FFmpeg底层参数的高级用户",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install av",
    "fallback": ["ffmpeg-python", "ffmpeg"]
}

TOOL_transcoder = {
    "name": "transcoder",
    "display_name": "Transcoder",
    "description": "视频转码工具，提供简洁API进行视频格式转换、编解码器选择、分辨率调整、码率控制",
    "category": "视频处理工具",
    "scenarios": ["视频格式批量转码", "分辨率缩放", "码率压缩", "编解码器转换", "设备适配转码"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["ffmpeg", "video-compressor"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "预设多种设备配置模板，一键转码为移动端/网页端格式",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install transcoder",
    "fallback": ["ffmpeg", "ffmpeg-python"]
}

TOOL_video_compressor = {
    "name": "video-compressor",
    "display_name": "Video-Compressor",
    "description": "视频压缩工具，智能平衡画质与文件大小，支持CRF控制、目标体积压缩、批量处理",
    "category": "视频处理工具",
    "scenarios": ["视频文件压缩", "目标大小压缩", "批量压缩优化", "社交媒体上传优化", "存储空间节省"],
    "accuracy": 4, "efficiency": 5, "speed": 3,
    "conflicts_with": ["transcoder", "ffmpeg"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "CRF值18-28是常用范围，数值越小画质越好文件越大；目标体积模式需先分析内容复杂度",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install video-compressor",
    "fallback": ["ffmpeg", "transcoder"]
}

TOOL_pyscenedetect = {
    "name": "pyscenedetect",
    "display_name": "PySceneDetect(高级版)",
    "description": "高级视频场景检测库，基于深度学习的场景边界检测，支持内容感知分割、自适应阈值、HSV检测",
    "category": "视频处理工具",
    "scenarios": ["深度学习场景检测", "视频自动分割", "内容感知剪辑", "视频结构分析", "广告检测跳过"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["scenedetect", "keyframes"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "深度学习模式需要GPU加速，检测精度高但速度较慢，适合离线批量处理",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pyscenedetect",
    "fallback": ["scenedetect", "keyframes"]
}

TOOL_audiotsm = {
    "name": "audiotsm",
    "display_name": "AudioTSM",
    "description": "音频变速不变调处理库，支持WSOLA、相位声码器等算法，适用于视频音频变速处理",
    "category": "视频处理工具",
    "scenarios": ["音频变速不变调", "视频快放慢放音频同步", "语音调速", "播客加速播放", "音频时间伸缩"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "WSOLA算法适合语音，相位声码器适合音乐；变速倍数不宜超过2倍以保证质量",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install audiotsm",
    "fallback": ["ffmpeg", "MoviePy"]
}

TOOL_vidstab = {
    "name": "vidstab",
    "display_name": "VidStab",
    "description": "视频防抖处理库，通过运动估计和帧变换消除手持拍摄抖动，支持平移和旋转抖动校正",
    "category": "视频处理工具",
    "scenarios": ["手持视频防抖", "运动相机视频稳定", "无人机视频去抖", "晃动视频修复", "延时摄影稳定"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["OpenCV"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "剧烈抖动的视频需要多次迭代处理；平滑参数建议从默认值开始微调",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install vidstab",
    "fallback": ["OpenCV", "ffmpeg"]
}

TOOL_keyframes = {
    "name": "keyframes",
    "display_name": "KeyFrames",
    "description": "视频关键帧提取工具，基于场景变化检测提取代表性帧，支持多种提取策略和格式输出",
    "category": "视频处理工具",
    "scenarios": ["视频关键帧提取", "视频缩略图生成", "视频预览图制作", "视频内容分析", "帧采样"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["scenedetect", "pyscenedetect"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "按时间间隔提取与按场景变化提取策略可组合使用以达到最佳效果",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install keyframes",
    "fallback": ["scenedetect", "ffmpeg"]
}

TOOL_GIF_Movie_Gear = {
    "name": "gif-movie-gear",
    "display_name": "GIF-Movie-Gear",
    "description": "GIF制作工具，支持视频转GIF、GIF编辑优化、调色板优化、帧率控制、尺寸调整",
    "category": "视频处理工具",
    "scenarios": ["视频转GIF", "GIF尺寸压缩", "GIF帧率优化", "调色板优化减少体积", "表情包制作"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["MoviePy"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "减少颜色数和帧率是缩小GIF体积最有效的方法，dither算法可改善画质",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install gif-movie-gear",
    "fallback": ["MoviePy", "ffmpeg"]
}

TOOL_subtitles = {
    "name": "subtitles",
    "display_name": "Subtitles",
    "description": "字幕处理工具，支持SRT/ASS/VTT等格式字幕的解析、编辑、转换、时间轴调整、合并与分割",
    "category": "视频处理工具",
    "scenarios": ["字幕格式转换", "字幕时间轴调整", "字幕翻译辅助", "字幕合并嵌入", "字幕OCR校正"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "ASS格式支持高级特效，SRT兼容性最好；时间轴偏移量支持正负数微调",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install subtitles",
    "fallback": ["ffmpeg", "pysubs2"]
}

TOOL_video_quality = {
    "name": "video-quality",
    "display_name": "Video-Quality",
    "description": "视频质量分析工具，计算PSNR/SSIM/VMAF等质量指标，支持参考视频对比和客观质量评估",
    "category": "视频处理工具",
    "scenarios": ["视频质量评估", "编解码器对比测试", "转码质量监控", "视频压缩效果分析", "画质客观评价"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "VMAF指标最接近人眼感知，PSNR适合传统编码评估；测试建议取多帧平均",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install video-quality",
    "fallback": ["ffmpeg", "OpenCV"]
}

TOOL_accelerate = {
    "name": "accelerate",
    "display_name": "Video-Accelerate",
    "description": "视频加速/慢放处理工具，支持平滑变速、帧插值、音频同步、批量处理视频速度调整",
    "category": "视频处理工具",
    "scenarios": ["视频倍速播放制作", "延时摄影生成", "慢动作视频制作", "帧插值平滑", "音频同步变速"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["audiotsm", "ffmpeg"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "大幅加速建议配合帧采样，慢放建议开启帧插值以获得流畅效果",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install accelerate",
    "fallback": ["ffmpeg", "audiotsm"]
}

TOOL_concat_videos = {
    "name": "concat-videos",
    "display_name": "Concat-Videos",
    "description": "视频拼接工具，支持多种拼接模式(首尾拼接/画中画/并排拼接)，自动处理编码参数一致性问题",
    "category": "视频处理工具",
    "scenarios": ["视频首尾拼接", "视频并排对比", "画中画叠加", "批量合并视频片段", "转场效果添加"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": ["MoviePy", "ffmpeg"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "拼接前建议统一编码参数和分辨率，避免因参数不一致导致失败",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install concat-videos",
    "fallback": ["ffmpeg", "MoviePy"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
