TOOL_BIOPYTHON = {
    "name": "biopython",
    "display_name": "Biopython 生物信息学工具包",
    "description": "生物信息学领域最流行的 Python 库，提供序列分析、BLAST 接口、PDB 结构解析、系统发育分析等功能。",
    "category": "生物信息",
    "scenarios": ["DNA/RNA/蛋白序列分析", "序列比对与搜索", "分子结构解析", "系统发育树构建", "GenBank 数据解析"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "SeqRecord 和 SeqIO 是核心模块；处理大文件时使用 parse() 迭代器而非 read()",
    "github_stars": 4500,
    "open_source": True,
    "download_command": "pip install biopython",
    "fallback": ["biotite", "scikit-bio"]
}

TOOL_PANDAS_BIO = {
    "name": "pandas-bio",
    "display_name": "Pandas-bio 生物数据框架",
    "description": "基于 Pandas 构建的生物数据处理扩展库，提供生物专用数据类型和 IO 接口，支持常见生物数据格式。",
    "category": "生物信息",
    "scenarios": ["生物实验数据清洗", "高通量测序元数据分析", "基因表达矩阵处理", "临床数据分析", "生物统计建模"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "与 Pandas 生态完全兼容；配合 NumPy/SciPy 进行统计分析效果更佳",
    "github_stars": 800,
    "open_source": True,
    "download_command": "pip install pandas-bio",
    "fallback": ["biopython", "numpy"]
}

TOOL_PYENSEMBL = {
    "name": "pyensembl",
    "display_name": "PyEnsembl 基因组数据库",
    "description": "Ensembl 基因组注释数据库的 Python 接口，支持基因、转录本、外显子等注释信息的快速查询和下载。",
    "category": "生物信息",
    "scenarios": ["基因组注释查询", "转录本与基因映射", "变异位点注释", "跨物种基因组比较", "外显子-内含子结构分析"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "首次使用需通过 pyensembl install 下载参考基因组；推荐缓存到 SSD 加速查询",
    "github_stars": 600,
    "open_source": True,
    "download_command": "pip install pyensembl",
    "fallback": ["biopython", "pysam"]
}

TOOL_PYSAM = {
    "name": "pysam",
    "display_name": "Pysam 基因序列对齐",
    "description": "SAM/BAM/CRAM 格式文件的 Python 封装，基于 htslib 的 C 扩展库。提供高效的序列比对读写和操作功能。",
    "category": "生物信息",
    "scenarios": ["SAM/BAM 文件处理", "序列比对分析", "变异检测管道", "RNA-seq 定量分析", "ChIP-seq 峰值调用"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "使用 pileup() 进行碱基堆叠分析；tabix_index() 创建索引加速区域查询",
    "github_stars": 1500,
    "open_source": True,
    "download_command": "pip install pysam",
    "fallback": ["samtools", "biopython"]
}

TOOL_BIOTITE = {
    "name": "biotite",
    "display_name": "Biotite 生物信息综合库",
    "description": "通用的生物信息分析库，覆盖序列分析、结构生物信息、群体遗传学和分子可视化。纯 Python 实现，易于扩展。",
    "category": "生物信息",
    "scenarios": ["分子结构可视化", "序列图谱绘制", "群体遗传学分析", "蛋白质结构比对", "分子动力学预处理"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "可视化功能可生成出版级图片；结构分析模块支持 PDBx/mmCIF 格式",
    "github_stars": 500,
    "open_source": True,
    "download_command": "pip install biotite",
    "fallback": ["biopython", "pymol"]
}

TOOL_SCIKIT_BIO = {
    "name": "scikit-bio",
    "display_name": "scikit-bio 生态信息学",
    "description": "基于 SciPy 生态构建的生物学数据科学库，专注于生态学和微生物组数据的统计分析。",
    "category": "生物信息",
    "scenarios": ["微生物组多样性分析", "生态统计", "16S rRNA 数据分析", "生物距离矩阵计算", "分类学组成分析"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "配合 QIIME 2 工作流使用更高效；ordination 模块提供 PCA/PCoA/NMDS 等排序方法",
    "github_stars": 1600,
    "open_source": True,
    "download_command": "pip install scikit-bio",
    "fallback": ["biopython", "qiime2"]
}

TOOL_DNA_FEATURES = {
    "name": "dna-features",
    "display_name": "DNA Features Viewer",
    "description": "DNA 质粒图谱可视化库，支持绘制质粒图谱、线性 DNA 图谱、注释特征和限制性酶切位点标记。",
    "category": "生物信息",
    "scenarios": ["质粒图谱绘制", "DNA 序列注释可视化", "限制性酶切位点标注", "基因结构示意图", "论文插图制作"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "支持从 GenBank 文件直接导入注释；Matplotlib backend 可嵌入 Jupyter Notebook",
    "github_stars": 1200,
    "open_source": True,
    "download_command": "pip install dna-features-viewer",
    "fallback": ["biopython", "biotite"]
}

TOOL_MNE = {
    "name": "mne",
    "display_name": "MNE-Python 脑电分析",
    "description": "专业的脑电图/脑磁图数据分析库，提供预处理、源定位、时频分析和统计推断等完整工具链。",
    "category": "生物信息",
    "scenarios": ["EEG 脑电信号处理", "MEG 脑磁信号分析", "事件相关电位分析", "脑网络连接分析", "源定位与成像"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "安装 mne-bids 插件支持 BIDS 格式数据；raw.plot() 快速预览信号质量",
    "github_stars": 3000,
    "open_source": True,
    "download_command": "pip install mne",
    "fallback": ["eeglab", "fieldtrip"]
}

TOOL_NILEARN = {
    "name": "nilearn",
    "display_name": "Nilearn 脑成像分析",
    "description": "快速统计学习的人脑神经影像分析库，基于 scikit-learn 构建。提供功能连接、解码和预测分析工具。",
    "category": "生物信息",
    "scenarios": ["fMRI 功能磁共振分析", "脑区功能连接分析", "脑影像解码与编码", "多体素模式分析", "脑图谱可视化"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "NiftiMasker/NiftiLabelsMasker 是其核心掩膜工具；plot_connectome 绘制脑连接组图",
    "github_stars": 2200,
    "open_source": True,
    "download_command": "pip install nilearn",
    "fallback": ["nibabel", "fsl"]
}

TOOL_NIBABEL = {
    "name": "nibabel",
    "display_name": "NiBabel 神经影像格式",
    "description": "神经影像文件格式的底层读写库，支持 NIfTI、AFNI、FreeSurfer、MINC 等多种医学影像格式。",
    "category": "生物信息",
    "scenarios": ["NIfTI 格式读写", "神经影像格式转换", "医学图像数据预处理", "MRI/DTI 数据加载", "多模态影像管理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "使用 nilearn 进行高层次分析时 nibabel 是底层依赖；get_data() 和 get_fdata() 区别是返回类型",
    "github_stars": 1400,
    "open_source": True,
    "download_command": "pip install nibabel",
    "fallback": ["nilearn", "dipy"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}