TOOL_JINJA2 = {
    "name": "jinja2",
    "description": "现代化模板引擎，支持模板继承、过滤器、沙箱执行",
    "category": "办公文档",
    "github_stars": 10000,
    "scenarios": ["报告模板渲染", "批量文档生成", "HTML邮件模板", "代码生成"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "结合python-docx或ReportLab使用可实现模板化文档生成"
}

TOOL_PYMUPDF = {
    "name": "PyMuPDF",
    "description": "高性能PDF处理库，支持提取、合并、注释、OCR",
    "category": "办公文档",
    "github_stars": 5000,
    "scenarios": ["PDF文本提取", "PDF合并拆分", "PDF注释与水印", "OCR预处理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "处理大文件时内存占用低，适合批量PDF处理"
}

TOOL_OPENPYXL = {
    "name": "openpyxl",
    "description": "Excel文件读写库，支持.xlsx格式的数据操作与样式控制",
    "category": "办公文档",
    "github_stars": 6000,
    "scenarios": ["数据分析报表", "Excel数据导入导出", "批量表格处理", "图表生成"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["xlwings"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "写大量单元格时使用write_only模式可大幅提升性能"
}

TOOL_PYTHON_DOCX = {
    "name": "python-docx",
    "description": "Word文档创建与修改库，支持段落、表格、图片、样式",
    "category": "办公文档",
    "github_stars": 5000,
    "scenarios": ["合同文档生成", "简历自动生成", "报告文档创建", "批量文档合并"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "图片和表格操作需要手动定位，建议先设计好模板结构"
}

TOOL_REPORTLAB = {
    "name": "ReportLab",
    "description": "企业级PDF生成库，支持复杂布局、表格、图表与矢量图形",
    "category": "办公文档",
    "github_stars": 3000,
    "scenarios": ["PDF报表生成", "发票批量打印", "复杂PDF布局", "数据可视化PDF"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["FPDF2", "WeasyPrint"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "PLATYPUS框架是创建复杂页面布局的首选方式"
}

TOOL_WEASYPRINT = {
    "name": "WeasyPrint",
    "description": "HTML/CSS排版渲染为PDF，支持现代CSS特性",
    "category": "办公文档",
    "github_stars": 8000,
    "scenarios": ["Web页面转PDF", "CSS排版打印", "HTML报表导出"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["ReportLab", "FPDF2"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "CSS支持优秀但渲染速度较慢，适合对排版质量要求高的场景"
}

TOOL_PYTHON_PPTX = {
    "name": "python-pptx",
    "description": "PowerPoint文件创建与修改库，支持幻灯片、图表、媒体",
    "category": "办公文档",
    "github_stars": 3000,
    "scenarios": ["演示文稿生成", "幻灯片批处理", "图表报告展示"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "模板复制配合占位符替换是最常用的高效方案"
}

TOOL_XLWINGS = {
    "name": "xlwings",
    "description": "Excel应用自动化库，支持VBA替代、实时数据交互",
    "category": "办公文档",
    "github_stars": 3000,
    "scenarios": ["Excel自动化操作", "金融模型交互", "实时数据对接", "VBA脚本替代"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["openpyxl"],
    "safety_level": "warning",
    "requires_network": False,
    "usage_tips": "需要安装Excel桌面应用，适合需要Excel宏能力的场景"
}

TOOL_FPDF2 = {
    "name": "FPDF2",
    "description": "轻量级PDF生成库，无需外部依赖，语法简洁",
    "category": "办公文档",
    "github_stars": 1000,
    "scenarios": ["简单PDF生成", "PDF合并与拆分", "文本型PDF创建"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["ReportLab", "WeasyPrint"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合快速生成简单PDF，复杂排版建议使用ReportLab"
}

TOOLS_LIST = [
    TOOL_JINJA2,
    TOOL_PYMUPDF,
    TOOL_OPENPYXL,
    TOOL_PYTHON_DOCX,
    TOOL_REPORTLAB,
    TOOL_WEASYPRINT,
    TOOL_PYTHON_PPTX,
    TOOL_XLWINGS,
    TOOL_FPDF2,
]