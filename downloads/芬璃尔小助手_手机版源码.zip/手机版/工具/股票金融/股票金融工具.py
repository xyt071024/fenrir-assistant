TOOL_AKShare = {
    "name": "akshare",
    "display_name": "AKShare",
    "description": "A股/港股/美股/期货/基金/债券等全品类金融数据接口，支持实时行情与历史数据",
    "category": "金融数据",
    "scenarios": ["A股数据获取", "期货行情分析", "基金净值查询", "宏观经济数据"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["tushare"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "推荐作为中国金融数据的首选工具，数据源丰富且更新及时",
    "github_stars": 19300,
    "open_source": True,
    "download_command": "pip install akshare",
    "fallback": ["tushare", "pandas-datareader"]
}

TOOL_TuShare = {
    "name": "tushare",
    "display_name": "TuShare",
    "description": "中国股票市场数据接口，提供股票/指数/基金等历史行情和基本面数据",
    "category": "金融数据",
    "scenarios": ["中国股票数据", "基本面分析", "交易数据下载"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["akshare"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需要注册获取token，适合专业量化投资者",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install tushare",
    "fallback": ["akshare"]
}

TOOL_yfinance = {
    "name": "yfinance",
    "display_name": "yfinance",
    "description": "Yahoo Finance金融数据接口，支持美股/港股/全球指数历史数据下载",
    "category": "金融数据",
    "scenarios": ["美股数据获取", "全球指数行情", "历史K线下载"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["pandas-datareader"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "无需注册即可使用，适合快速获取全球金融市场数据",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install yfinance",
    "fallback": ["pandas-datareader", "akshare"]
}

TOOL_backtrader = {
    "name": "backtrader",
    "display_name": "backtrader",
    "description": "量化交易回测框架，支持策略开发/数据加载/绩效分析/可视化",
    "category": "量化回测",
    "scenarios": ["策略回测", "量化交易开发", "绩效评估"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["backtesting.py", "zipline"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "功能全面但学习曲线较陡，适合专业量化开发",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install backtrader",
    "fallback": ["backtesting.py", "zipline"]
}

TOOL_mplfinance = {
    "name": "mplfinance",
    "display_name": "mplfinance",
    "description": "基于Matplotlib的K线图/ohlc图/交易量图等金融图表绘制工具",
    "category": "金融可视化",
    "scenarios": ["K线图绘制", "交易量图表", "金融时间序列可视化"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["plotly"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Matplotlib官方金融扩展，绘制专业K线图的首选",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install mplfinance",
    "fallback": ["plotly", "bokeh"]
}

TOOL_ccxt = {
    "name": "ccxt",
    "display_name": "CCXT",
    "description": "统一接口访问100+加密货币交易所，支持行情/交易/账户管理",
    "category": "加密货币",
    "scenarios": ["加密货币行情", "交易所API对接", "量化交易"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["cryptocompare"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "支持100+交易所统一接口，加密货币交易的首选库",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install ccxt",
    "fallback": ["cryptocompare"]
}

TOOL_TALib = {
    "name": "TA-Lib",
    "display_name": "TA-Lib",
    "description": "技术指标计算库，提供150+种金融技术分析指标（MACD/RSI/布林带等）",
    "category": "技术指标",
    "scenarios": ["技术分析", "指标计算", "交易信号生成"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "C语言底层实现性能优异，Windows下建议用whl安装",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install TA-Lib",
    "fallback": ["stockstats"]
}

TOOL_backtesting_py = {
    "name": "backtesting.py",
    "display_name": "backtesting.py",
    "description": "轻量级量化回测框架，API简洁适合快速策略验证",
    "category": "量化回测",
    "scenarios": ["快速策略验证", "教学演示", "轻量回测"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["backtrader", "zipline"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "入门简单适合快速原型验证，复杂策略建议用backtrader",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install backtesting",
    "fallback": ["backtrader"]
}

TOOL_pandas_datareader = {
    "name": "pandas-datareader",
    "display_name": "pandas-datareader",
    "description": "从多个网络源读取金融数据，支持Yahoo/FRED/World Bank等",
    "category": "金融数据",
    "scenarios": ["多源金融数据读取", "宏观经济数据", "国际金融数据"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["yfinance"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "配合pandas使用，适合多数据源整合场景",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pandas-datareader",
    "fallback": ["yfinance"]
}

TOOL_QuantLib = {
    "name": "QuantLib",
    "display_name": "QuantLib",
    "description": "专业量化金融库，支持衍生品定价/风险管理/固定收益分析",
    "category": "量化金融",
    "scenarios": ["衍生品定价", "风险管理", "固定收益分析", "蒙特卡洛模拟"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "学术界和业界标准量化库，功能强大但学习成本高",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install QuantLib-Python",
    "fallback": []
}

TOOL_zipline = {
    "name": "zipline",
    "display_name": "Zipline",
    "description": "算法交易回测引擎，Quantopian开源，支持事件驱动回测",
    "category": "量化回测",
    "scenarios": ["算法交易回测", "事件驱动策略", "日频数据回测"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["backtrader", "backtesting.py"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "曾是业界标准回测框架，目前维护较少建议用backtrader替代",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install zipline",
    "fallback": ["backtrader"]
}

TOOL_pyfolio = {
    "name": "pyfolio",
    "display_name": "pyfolio",
    "description": "投资组合分析工具，生成专业的绩效报告和风险分析图表",
    "category": "投资分析",
    "scenarios": ["投资组合分析", "绩效报告", "风险归因", "回测分析"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配合zipline/backtrader使用效果最佳",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pyfolio",
    "fallback": ["empyrical"]
}

TOOL_empyrical = {
    "name": "empyrical",
    "display_name": "empyrical",
    "description": "风险与收益指标计算库，提供夏普比率/最大回撤/年化收益等",
    "category": "投资分析",
    "scenarios": ["风险指标计算", "收益分析", "绩效评价"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["pyfolio"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "pyfolio的底层依赖库，轻量级风险指标计算首选",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install empyrical",
    "fallback": ["pyfolio"]
}

TOOL_alphalens = {
    "name": "alphalens",
    "display_name": "alphalens",
    "description": "因子分析库，评估Alpha因子在选股中的预测能力和收益表现",
    "category": "因子分析",
    "scenarios": ["因子分析", "多因子选股", "Alpha策略评估"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "量化因子研究标准工具，常用于多因子模型开发",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install alphalens",
    "fallback": []
}

TOOL_prophet = {
    "name": "prophet",
    "display_name": "Prophet",
    "description": "Facebook开源的时间序列预测工具，适合股票/经济数据趋势预测",
    "category": "时间序列",
    "scenarios": ["时间序列预测", "趋势分析", "季节性分解", "异常检测"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["statsmodels"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "对节假日效应和趋势变化有良好支持，适合业务时间序列预测",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install prophet",
    "fallback": ["statsmodels"]
}

TOOL_stockstats = {
    "name": "stockstats",
    "display_name": "stockstats",
    "description": "股票统计指标库，封装常用技术指标计算和股票数据统计",
    "category": "技术指标",
    "scenarios": ["股票统计", "技术指标快速计算", "数据预处理"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["TA-Lib"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "轻量级技术指标计算，比TA-Lib更容易安装和使用",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install stockstats",
    "fallback": ["TA-Lib"]
}

TOOL_akshare_mcp = {
    "name": "akshare-mcp",
    "display_name": "akshare-mcp",
    "description": "AKShare的MCP(模型上下文协议)接口封装，支持AI大模型调用股票数据",
    "category": "金融数据",
    "scenarios": ["AI调用股票数据", "MCP协议集成", "大模型金融数据"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["tushare-mcp"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "适合AI Agent集成股票数据能力，需配合MCP客户端使用",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install akshare-mcp",
    "fallback": ["akshare"]
}

TOOL_exchange_calendars = {
    "name": "exchange_calendars",
    "display_name": "exchange_calendars",
    "description": "全球交易所交易日历库，支持A股/美股/港股等交易所的开休市查询",
    "category": "金融数据",
    "scenarios": ["交易日历查询", "休市日判断", "交易日计算"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "回测和交易系统中判断交易日期的必备工具",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install exchange_calendars",
    "fallback": []
}

TOOL_tushare_mcp = {
    "name": "tushare-mcp",
    "display_name": "tushare-mcp",
    "description": "TuShare的MCP接口封装，支持AI模型通过MCP协议获取中国股票数据",
    "category": "金融数据",
    "scenarios": ["AI股票数据调用", "MCP协议接口", "大模型金融集成"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["akshare-mcp"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需要TuShare token，配合MCP客户端实现AI金融数据查询",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install tushare-mcp",
    "fallback": ["tushare"]
}

TOOL_cryptocompare = {
    "name": "cryptocompare",
    "display_name": "cryptocompare",
    "description": "加密货币数据接口，提供数字资产行情/历史数据/新闻等信息",
    "category": "加密货币",
    "scenarios": ["加密货币行情", "数字资产数据", "区块链数据分析"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["ccxt"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "适合加密货币数据分析和研究，免费层有调用次数限制",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install cryptocompare",
    "fallback": ["ccxt"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
