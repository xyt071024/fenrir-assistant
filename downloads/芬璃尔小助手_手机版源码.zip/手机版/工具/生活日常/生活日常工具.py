TOOL_psutil = {
    "name": "psutil", "display_name": "系统监控", "description": "跨平台系统监控库，监控CPU、内存、磁盘、网络、进程等系统资源",
    "category": "生活日常", "scenarios": ["系统资源监控", "性能分析", "进程管理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合做系统托盘小部件或健康监控面板",
    "github_stars": 10900, "open_source": True,
    "download_command": "pip install psutil", "fallback": ["wmi", "GPUtil"]
}

TOOL_schedule = {
    "name": "schedule", "display_name": "Python定时任务", "description": "轻量级Python定时任务调度库，支持周期性执行任务",
    "category": "生活日常", "scenarios": ["定时提醒", "周期性任务", "自动化脚本"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合与通知系统结合做每日提醒",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install schedule", "fallback": ["APScheduler", "celery"]
}

TOOL_Planify = {
    "name": "Planify", "display_name": "任务管理器", "description": "跨平台任务管理器，支持GTK4界面、任务分类、优先级管理和提醒",
    "category": "生活日常", "scenarios": ["任务管理", "待办事项", "项目规划"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Todoist", "Microsoft To Do"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "开源替代Todoist的好选择，支持本地存储",
    "github_stars": 5300, "open_source": True,
    "download_command": "pip install planify", "fallback": ["todoist-python", "taskwarrior"]
}

TOOL_WeekToDo = {
    "name": "WeekToDo", "display_name": "每周计划", "description": "开源每周计划应用，以周为维度管理任务和时间块",
    "category": "生活日常", "scenarios": ["周计划", "时间块管理", "日程规划"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Planify", "Notion Calendar"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合习惯按周规划的用户，界面简洁直观",
    "github_stars": 2100, "open_source": True,
    "download_command": "pip install weektodo", "fallback": ["Planify", "taskwarrior"]
}

TOOL_Lifeforge = {
    "name": "Lifeforge", "display_name": "生活管理", "description": "一体化生活管理平台，涵盖任务、习惯、财务、健康等多个模块",
    "category": "生活日常", "scenarios": ["全生活管理", "个人仪表盘", "数据分析"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["Notion", "Life360"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "功能全面但较重，适合想要一站式解决方案的用户",
    "github_stars": 1600, "open_source": True,
    "download_command": "pip install lifeforge", "fallback": ["Notion API", "Obsidian"]
}

TOOL_DeyWeaver = {
    "name": "DeyWeaver", "display_name": "AI日程规划", "description": "AI驱动的智能日程规划助手，自动优化日程安排",
    "category": "生活日常", "scenarios": ["智能日程规划", "AI助手", "时间优化"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": ["Google Calendar AI", "Motion"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "适合日程繁忙需要AI辅助优化的用户",
    "github_stars": 338, "open_source": True,
    "download_command": "pip install deyweaver", "fallback": ["Planify", "WeekToDo"]
}

TOOL_py_notifier = {
    "name": "py-notifier", "display_name": "桌面通知", "description": "跨平台桌面通知库，支持Windows、macOS、Linux原生通知",
    "category": "生活日常", "scenarios": ["桌面提醒", "通知推送", "状态提示"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "配合schedule使用可实现定时提醒",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install py-notifier", "fallback": ["plyer", "win10toast"]
}

TOOL_todoist_python = {
    "name": "todoist-python", "display_name": "Todoist集成", "description": "Todoist任务管理API的Python封装，支持增删改查和项目管理",
    "category": "生活日常", "scenarios": ["Todoist自动化", "任务同步", "GTD工作流"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Planify", "Microsoft To Do"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要Todoist API Token，适合Todoist重度用户",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install todoist-python", "fallback": ["todoist-api-python", "Planify"]
}

TOOL_habitica_api = {
    "name": "habitica-api", "display_name": "习惯养成", "description": "Habitica游戏化习惯养成应用的Python API封装",
    "category": "生活日常", "scenarios": ["游戏化习惯", "RPG任务管理", "习惯追踪"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要Habitica账号和API密钥，适合游戏化激励用户",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install habitica-api", "fallback": ["loopify", "Streaks"]
}

TOOL_pomodoro_timer = {
    "name": "pomodoro-timer", "display_name": "番茄钟", "description": "番茄工作法计时器，支持专注时段、休息时段和统计追踪",
    "category": "生活日常", "scenarios": ["番茄工作法", "专注计时", "效率提升"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "可定时25分钟专注+5分钟休息，提升工作效率",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pomodoro-timer", "fallback": ["pomodoro-cli", "tomato-timer"]
}

TOOL_alarm_clock = {
    "name": "alarm-clock", "display_name": "闹钟", "description": "Python闹钟程序，支持设置多组闹钟、自定义铃声和贪睡功能",
    "category": "生活日常", "scenarios": ["起床闹钟", "事件提醒", "定时播报"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "结合py-notifier和schedule可实现完整闹钟系统",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install alarm-clock", "fallback": ["py-alarm", "windows-scheduler"]
}

TOOL_countdown_timer = {
    "name": "countdown-timer", "display_name": "倒计时", "description": "倒计时器工具，支持自定义倒计时时长、结束时触发通知或动作",
    "category": "生活日常", "scenarios": ["倒计时提醒", "事件倒计时", "定时器"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "可用于烹饪、运动、休息等场景的倒计时",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install countdown-timer", "fallback": ["pomodoro-timer", "alarm-clock"]
}

TOOL_world_clock = {
    "name": "world-clock", "display_name": "世界时钟", "description": "多时区时钟工具，同时显示多个城市/时区的当前时间",
    "category": "生活日常", "scenarios": ["多时区查看", "跨国协作", "旅行规划"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合需要与不同时区协作的远程工作者",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install world-clock", "fallback": ["pytz", "datetime"]
}

TOOL_unit_converter = {
    "name": "unit-converter", "display_name": "单位换算", "description": "全面的单位换算工具，支持长度、重量、温度、面积、体积等多种单位",
    "category": "生活日常", "scenarios": ["单位换算", "学习辅助", "工程计算"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持公制与英制互转，含常用物理单位",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install unit-converter", "fallback": ["pint", "magnum"]
}

TOOL_currency_converter = {
    "name": "currency-converter", "display_name": "货币换算", "description": "实时货币汇率换算工具，支持多种货币之间的汇率转换",
    "category": "生活日常", "scenarios": ["货币兑换", "跨国购物", "旅行预算"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要网络获取实时汇率，支持离线缓存历史汇率",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install currency-converter", "fallback": ["forex-python", "exchangerates"]
}

TOOL_calorie_calculator = {
    "name": "calorie-calculator", "display_name": "卡路里计算", "description": "食物卡路里计算工具，支持食物热量查询和每日摄入统计",
    "category": "生活日常", "scenarios": ["饮食管理", "减肥辅助", "健康追踪"],
    "accuracy": 3, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "数据仅供参考，建议结合专业营养师建议使用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install calorie-calculator", "fallback": ["nutritionix-api", "fdc-api"]
}

TOOL_bmi_calculator = {
    "name": "bmi-calculator", "display_name": "BMI计算", "description": "身体质量指数(BMI)计算工具，根据身高体重计算BMI值并给出健康建议",
    "category": "生活日常", "scenarios": ["健康评估", "体重管理", "健身参考"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "BMI仅作参考，不能完全反映身体健康状况",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install bmi-calculator", "fallback": ["bmi", "health-calc"]
}

TOOL_tip_calculator = {
    "name": "tip-calculator", "display_name": "小费计算", "description": "小费计算工具，根据消费金额和小费比例自动计算小费及分摊金额",
    "category": "生活日常", "scenarios": ["聚餐分摊", "小费计算", "账单管理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持多人分摊，自定义小费比例",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install tip-calculator", "fallback": ["splitwise-api", "bill-splitter"]
}

TOOL_shopping_list = {
    "name": "shopping-list", "display_name": "购物清单", "description": "购物清单管理工具，支持商品分类、数量标记和清单分享",
    "category": "生活日常", "scenarios": ["购物规划", "超市采购", "家庭用品管理"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持按类别分组，适合家庭共享购物清单",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install shopping-list", "fallback": ["grocy", "bring-api"]
}

TOOL_recipe_manager = {
    "name": "recipe-manager", "display_name": "食谱管理", "description": "食谱管理工具，支持食谱收藏、分类、食材清单和步骤记录",
    "category": "生活日常", "scenarios": ["食谱管理", "烹饪规划", "饮食记录"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "可自定义分类标签，支持导入导出食谱",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install recipe-manager", "fallback": ["meal-planner", "cookbook-api"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}