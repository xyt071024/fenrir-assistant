TOOL_KEYRING = {
    "name": "keyring",
    "display_name": "系统密钥环",
    "description": "操作系统中立密钥环管理库，统一访问Windows凭据管理器、macOS钥匙串、Linux Secret Service等系统级凭据存储",
    "category": "密码管理",
    "scenarios": ["安全存储应用程序的API密钥和令牌", "跨平台应用统一管理凭据", "避免硬编码敏感信息到源代码"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "优先使用操作系统原生密钥存储，keyring.get_password/set_password接口简单易用",
    "github_stars": 900,
    "open_source": True,
    "download_command": "pip install keyring",
    "fallback": ["cryptography-fernet"]
}

TOOL_CRYPTOGRAPHY_FERNET = {
    "name": "cryptography-fernet",
    "display_name": "Fernet对称加密",
    "description": "基于cryptography库的Fernet标准加密方案，提供AES-128-CBC加密和HMAC-SHA256认证的对称加密接口",
    "category": "密码管理",
    "scenarios": ["本地配置文件中的敏感数据加密存储", "小文件的安全加密传输", "数据库字段级别的数据加密"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "生成的密钥需安全保存，丢失后将无法解密已加密数据",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install cryptography",
    "fallback": ["keyring", "secrets"]
}

TOOL_BCRYPT = {
    "name": "bcrypt",
    "display_name": "bcrypt密码哈希",
    "description": "专为密码哈希设计的自适应哈希算法，内置加盐机制和可调节的计算复杂度因子",
    "category": "密码管理",
    "scenarios": ["用户注册和登录系统的密码哈希存储", "Web应用的密码安全性验证", "需要自适应慢哈希的安全场景"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["argon2-cffi"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "cost factor建议设为12，根据硬件性能在安全性和速度间取得平衡",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install bcrypt",
    "fallback": ["argon2-cffi", "passlib"]
}

TOOL_ARGON2_CFFI = {
    "name": "argon2-cffi",
    "display_name": "Argon2现代哈希",
    "description": "基于现代Argon2算法的密码哈希库，2015年密码哈希竞赛冠军，提供内存硬性和抗GPU并行攻击能力",
    "category": "密码管理",
    "scenarios": ["高安全性要求的密码存储", "防御GPU/ASIC加速的暴力破解攻击", "新项目的密码哈希首选方案"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["bcrypt"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "Argon2id是推荐使用的变体，time_cost和memory_cost参数需根据运行环境调整",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install argon2-cffi",
    "fallback": ["bcrypt", "passlib"]
}

TOOL_PASSLIB = {
    "name": "passlib",
    "display_name": "Passlib密码库",
    "description": "统一的Python密码哈希库，抽象了bcrypt、argon2、pbkdf2等30多种哈希算法的调用接口",
    "category": "密码管理",
    "scenarios": ["需要兼容多种密码哈希算法的遗留系统", "统一管理不同应用的密码哈希策略", "密码哈希方案的迁移和升级"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "CryptContext可同时管理多个哈希方案，方便哈希算法在线升级",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install passlib",
    "fallback": ["bcrypt", "argon2-cffi"]
}

TOOL_PYTHON_GPG = {
    "name": "python-gnupg",
    "display_name": "GPG加密",
    "description": "GNU Privacy Guard的Python封装库，支持非对称加密、数字签名、密钥生成和管理",
    "category": "密码管理",
    "scenarios": ["文件资料的非对称加密传输", "软件包和文档的数字签名验证", "与第三方进行端到端加密通信"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["cryptography-fernet"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "需要先安装GnuPG本体，使用密钥对管理加解密操作",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install python-gnupg",
    "fallback": ["cryptography-fernet"]
}

TOOL_VAULT = {
    "name": "vault",
    "display_name": "HashiCorp Vault密钥存储",
    "description": "企业级密钥和敏感数据管理工具，提供动态密钥生成、密钥轮换、审计日志和访问控制",
    "category": "密码管理",
    "scenarios": ["微服务架构中API密钥和数据库凭据的统一管理", "企业敏感配置的集中存储和动态分发", "密钥自动轮换和生命周期管理"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["keyring"],
    "safety_level": "安全",
    "requires_network": True,
    "usage_tips": "生产环境建议使用Vault集群部署，开发环境可使用dev模式快速启动",
    "github_stars": 31500,
    "open_source": True,
    "download_command": "winget install HashiCorp.Vault",
    "fallback": ["keyring", "bitwarden-client"]
}

TOOL_KEEPASS = {
    "name": "keepass",
    "display_name": "KeePass密码管理器",
    "description": "开源的本地密码管理工具，使用AES/Twofish加密数据库文件，支持插件扩展和多种导出格式",
    "category": "密码管理",
    "scenarios": ["个人所有密码集中本地化管理", "离线环境下的密码安全存储", "使用KeePass格式跨平台同步密码"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["bitwarden-client"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "数据库文件可放在云盘同步到多设备使用，需保管好主密码",
    "github_stars": 0,
    "open_source": True,
    "download_command": "winget install KeePassX",
    "fallback": ["bitwarden-client", "pass"]
}

TOOL_BITWARDEN_CLIENT = {
    "name": "bitwarden-client",
    "display_name": "Bitwarden客户端",
    "description": "Bitwarden官方命令行客户端，支持全平台密码同步、组织管理和自我托管服务器",
    "category": "密码管理",
    "scenarios": ["跨设备密码实时同步", "团队密码库共享和权限管理", "自建密码服务器的企业场景"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["keepass", "lastpass-cli"],
    "safety_level": "安全",
    "requires_network": True,
    "usage_tips": "支持self-host模式部署到自己的服务器，敏感数据全部端到端加密",
    "github_stars": 0,
    "open_source": True,
    "download_command": "winget install Bitwarden.Bitwarden-CLI",
    "fallback": ["keepass", "vault"]
}

TOOL_ONEPASSWORD_CLIENT = {
    "name": "onepassword-client",
    "display_name": "1Password命令行工具",
    "description": "1Password官方命令行工具，支持密码管理、签名密钥管理和秘密身份认证",
    "category": "密码管理",
    "scenarios": ["在终端中快速检索和使用1Password中的密码", "CI/CD流水线中提取部署密钥", "开发者个人密钥的统一管理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["bitwarden-client", "lastpass-cli"],
    "safety_level": "安全",
    "requires_network": True,
    "usage_tips": "需要先登录1Password账户，支持生物特征解锁和SSH代理功能",
    "github_stars": 0,
    "open_source": False,
    "download_command": "winget install AgileBits.1Password.CLI",
    "fallback": ["bitwarden-client", "keepass"]
}

TOOL_LASTPASS_CLI = {
    "name": "lastpass-cli",
    "display_name": "LastPass命令行工具",
    "description": "LastPass官方命令行工具，支持在终端中直接操作LastPass密码库的增删改查",
    "category": "密码管理",
    "scenarios": ["Linux环境下访问LastPass密码库", "自动化脚本中获取网站登录凭据", "批量导入导出密码数据"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["bitwarden-client", "onepassword-client"],
    "safety_level": "中等",
    "requires_network": True,
    "usage_tips": "登录会话有有效期，长时间使用需要重新认证",
    "github_stars": 5000,
    "open_source": True,
    "download_command": "winget install LastPass.LastPass-CLI",
    "fallback": ["bitwarden-client", "keepass"]
}

TOOL_BROWSERPASS = {
    "name": "browserpass",
    "display_name": "Browserpass浏览器密码",
    "description": "浏览器与pass密码存储的桥接扩展，让浏览器可以读写pass管理的密码库条目",
    "category": "密码管理",
    "scenarios": ["在浏览器表单中自动填充pass中存储的密码", "将pass密码管理集成到浏览器工作流", "需要浏览器和终端统一密码管理"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "需同时安装浏览器扩展和本地原生组件配合使用",
    "github_stars": 0,
    "open_source": True,
    "download_command": "winget install browserpass",
    "fallback": ["pass", "keepass"]
}

TOOL_PASS = {
    "name": "pass",
    "display_name": "pass密码存储",
    "description": "遵循Unix哲学的标准Unix密码管理器，使用GPG加密、简单的文件目录结构存储密码",
    "category": "密码管理",
    "scenarios": ["Linux终端用户的轻量密码管理", "配合Git实现密码版本控制和同步", "使用shell脚本集成到自动化工作流"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["keepass"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "配合Git可轻松同步密码库，pass-otp插件支持两步验证码",
    "github_stars": 0,
    "open_source": True,
    "download_command": "winget install pass",
    "fallback": ["browserpass", "keepass"]
}

TOOL_SECRETS = {
    "name": "secrets",
    "display_name": "secrets安全随机",
    "description": "Python标准库secrets模块，专为密码学安全的随机数生成设计，用于生成安全令牌和密码",
    "category": "密码管理",
    "scenarios": ["生成高强度随机密码和API密钥", "创建安全的会话令牌和CSRF令牌", "密码重置链接的安全令牌生成"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "优先使用secrets.choice生成带特殊字符的复杂密码，长度建议16位以上",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["hashlib"]
}

TOOL_HASHLIB = {
    "name": "hashlib",
    "display_name": "hashlib哈希计算",
    "description": "Python标准库hashlib模块，提供SHA-2、SHA-3、BLAKE2等系列安全哈希算法实现",
    "category": "密码管理",
    "scenarios": ["文件完整性校验的哈希值计算", "密码验证中的哈希摘要运算", "数据指纹和数字摘要的生成"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "密码存储请使用hashlib.pbkdf2_hmac配合加盐多次迭代，而非直接用哈希做摘要",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["secrets"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
