TOOL_librosa = {
    "name": "librosa", "display_name": "LibROSA音频分析", "description": "音频信号分析与特征提取，支持MFCC、色谱图、节奏分析、节拍追踪等",
    "category": "音乐音频", "scenarios": ["音频特征提取", "音乐信息检索", "声音分析"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "处理前建议先将音频重采样到22050Hz",
    "github_stars": 7800, "open_source": True,
    "download_command": "pip install librosa", "fallback": ["pydub", "wave"]
}

TOOL_pydub = {
    "name": "pydub", "display_name": "Pydub音频处理", "description": "简单易用的音频处理库，支持格式转换、裁剪、拼接、音量调整、淡入淡出等",
    "category": "音乐音频", "scenarios": ["音频格式转换", "音频编辑", "批量处理"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "依赖ffmpeg处理非WAV格式，需额外安装",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pydub", "fallback": ["librosa", "wave"]
}

TOOL_pygame_audio = {
    "name": "pygame_audio", "display_name": "Pygame音频播放", "description": "基于pygame的音频播放模块，支持WAV、MP3、OGG等格式的播放与控制",
    "category": "音乐音频", "scenarios": ["音频播放", "游戏音效", "实时回放"],
    "accuracy": 3, "efficiency": 3, "speed": 5,
    "conflicts_with": ["pyaudio"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "多格式支持好，但不适合低延迟场景",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pygame", "fallback": ["pydub", "pyaudio"]
}

TOOL_sounddevice = {
    "name": "sounddevice", "display_name": "SoundDevice录音", "description": "基于PortAudio的音频录制与回放库，支持实时音频流采集和多设备选择",
    "category": "音乐音频", "scenarios": ["音频录制", "实时音频处理", "语音采集"],
    "accuracy": 4, "efficiency": 4, "speed": 5,
    "conflicts_with": ["pyaudio"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "搭配NumPy使用效果最佳，支持回调式流处理",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install sounddevice", "fallback": ["pyaudio", "wave"]
}

TOOL_speech_recognition = {
    "name": "speech_recognition", "display_name": "SpeechRecognition语音识别", "description": "支持多引擎的语音识别库，可接入Google、Sphinx、Whisper、百度等语音识别API",
    "category": "音乐音频", "scenarios": ["语音转文字", "语音命令", "会议记录"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "Google引擎需联网，Sphinx可离线但准确率较低",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install SpeechRecognition", "fallback": ["pyaudio", "wave"]
}

TOOL_gTTS = {
    "name": "gTTS", "display_name": "gTTS文字转语音", "description": "Google Text-to-Speech接口封装，支持多语言、多语速的文字转语音生成",
    "category": "音乐音频", "scenarios": ["语音合成", "文字朗读", "多语言TTS"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pyttsx3"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需联网调用Google API，支持慢速朗读模式",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install gtts", "fallback": ["pyttsx3"]
}

TOOL_noisereduce = {
    "name": "noisereduce", "display_name": "NoiseReduce降噪", "description": "基于频谱门控的音频降噪库，支持稳态噪声和非稳态噪声的智能消除",
    "category": "音乐音频", "scenarios": ["音频降噪", "语音增强", "预处理"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "降噪强度可调参数prop_decrease控制",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install noisereduce", "fallback": ["librosa", "pydub"]
}

TOOL_pedalboard = {
    "name": "pedalboard", "display_name": "Pedalboard音频效果器", "description": "Spotify开源的音频效果器库，支持压缩、混响、延迟、均衡器、失真等专业效果",
    "category": "音乐音频", "scenarios": ["音频效果处理", "音乐制作", "实时效果链"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持效果器链式组合，类似专业DAW的效果器串联",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pedalboard", "fallback": ["pydub", "audiotsm"]
}

TOOL_pyttsx3 = {
    "name": "pyttsx3", "display_name": "pyttsx3离线TTS", "description": "无需联网的文字转语音引擎，支持多语音、语速、音量调节，完全本地运行",
    "category": "音乐音频", "scenarios": ["离线语音合成", "无障碍辅助", "本地朗读"],
    "accuracy": 3, "efficiency": 4, "speed": 5,
    "conflicts_with": ["gTTS"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Windows下使用SAPI5驱动，语音质量取决于系统TTS引擎",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pyttsx3", "fallback": ["gTTS"]
}

TOOL_wave = {
    "name": "wave", "display_name": "Wave模块", "description": "Python标准库提供的WAV音频文件读写模块，支持基本的PCM音频操作",
    "category": "音乐音频", "scenarios": ["WAV读写", "基础音频操作", "标准库依赖"],
    "accuracy": 3, "efficiency": 4, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Python内置无需安装，仅支持未压缩WAV格式",
    "github_stars": 0, "open_source": True,
    "download_command": "无需安装，Python标准库内置", "fallback": ["pydub", "soundfile"]
}

TOOL_pyaudio = {
    "name": "pyaudio", "display_name": "PyAudio音频流", "description": "基于PortAudio的跨平台音频I/O库，支持低延迟音频录制与播放，适合实时音频应用",
    "category": "音乐音频", "scenarios": ["实时音频流", "麦克风输入", "低延迟播放"],
    "accuracy": 4, "efficiency": 4, "speed": 5,
    "conflicts_with": ["sounddevice"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Windows下需安装PortAudio，建议使用pipwin安装",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pyaudio", "fallback": ["sounddevice", "wave"]
}

TOOL_music21 = {
    "name": "music21", "display_name": "Music21音乐分析", "description": "MIT开发的音乐分析工具包，支持乐理分析、和弦识别、调性分析、音符序列处理和MusicXML读写",
    "category": "音乐音频", "scenarios": ["乐理分析", "乐谱处理", "音乐学研究"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合学术研究，支持导出为MIDI、MusicXML、LilyPond格式",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install music21", "fallback": ["midiutil"]
}

TOOL_midiutil = {
    "name": "midiutil", "display_name": "MIDIUtil MIDI生成", "description": "轻量级MIDI文件生成库，支持多轨、多乐器、音符、控制器事件的MIDI序列创建",
    "category": "音乐音频", "scenarios": ["MIDI生成", "自动作曲", "音乐编程"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "纯Python实现，不需要外部依赖，生成标准MIDI文件",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install midiutil", "fallback": ["music21"]
}

TOOL_ffmpeg_python = {
    "name": "ffmpeg_python", "display_name": "ffmpeg-python音频处理", "description": "FFmpeg的Python封装，支持几乎所有音频格式的转换、剪辑、合并、滤镜处理",
    "category": "音乐音频", "scenarios": ["音视频格式转换", "音频转码", "批量处理"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "需要系统中已安装FFmpeg，支持GPU加速编码",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install ffmpeg-python", "fallback": ["pydub"]
}

TOOL_audiotsm = {
    "name": "audiotsm", "display_name": "AudioTSM变速不变调", "description": "音频时间伸缩库，实现变速不变调处理，支持WSOLA、相位声码器等多种算法",
    "category": "音乐音频", "scenarios": ["音频变速", "时间伸缩", "播客编辑"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "WSOLA算法速度快适合实时，相位声码器质量高适合离线处理",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install audiotsm", "fallback": ["librosa", "pydub"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
