"""
芬璃尔小助手 - AI Agent 工具系统

提供文件系统、浏览器、系统控制、办公文档、图像处理、剪贴板等工具的完整实现。
所有工具通过 AIToolManager 统一注册、调度和安全管理。
"""

from __future__ import annotations

import asyncio
import io
import json
import logging
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import time
import traceback
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

# ============================================================================
# 可选依赖导入
# ============================================================================

try:
    import pyautogui
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False

try:
    import pyperclip
    PYPERCLIP_AVAILABLE = True
except ImportError:
    PYPERCLIP_AVAILABLE = False

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    from PIL import Image, ImageFilter, ImageOps
    PILLOW_AVAILABLE = True
except ImportError:
    PILLOW_AVAILABLE = False

try:
    import pytesseract
    PYTESSERACT_AVAILABLE = True
except ImportError:
    PYTESSERACT_AVAILABLE = False

try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False

try:
    from openpyxl import Workbook, load_workbook
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False

try:
    from docx import Document
    from docx.shared import Pt as DocxPt, Inches as DocxInches, RGBColor as DocxRGB
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False


# ============================================================================
# 工具函数 & 辅助
# ============================================================================

def _ensure_path(path: Union[str, Path]) -> Path:
    """将字符串路径转为 Path 对象并展开环境变量。"""
    return Path(os.path.expandvars(str(path))).resolve()


def _safe_path_check(path: Union[str, Path]) -> Tuple[bool, str]:
    """检查路径是否合法且无安全隐患。"""
    try:
        p = _ensure_path(path)
        if not p.exists():
            return False, f"路径不存在: {p}"
        return True, ""
    except Exception as e:
        return False, str(e)


def _format_size(size_bytes: int) -> str:
    """将字节数转为可读字符串。"""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


def _format_time(timestamp: float) -> str:
    """将时间戳转为可读字符串。"""
    return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")


# ============================================================================
# 1. FileSystemTools - 文件系统工具
# ============================================================================

class FileSystemTools:
    """文件系统操作工具集：目录创建、文件读写、搜索、压缩等。"""

    @staticmethod
    def create_dir(path: Union[str, Path]) -> Dict[str, Any]:
        """
        创建目录（支持递归创建）。

        参数:
            path: 要创建的目录路径。

        返回:
            {"success": bool, "path": str, "message": str}
        """
        try:
            p = _ensure_path(path)
            p.mkdir(parents=True, exist_ok=True)
            return {"success": True, "path": str(p), "message": f"目录已创建: {p}"}
        except Exception as e:
            return {"success": False, "path": str(path), "message": f"创建目录失败: {e}"}

    @staticmethod
    def delete_path(path: Union[str, Path], recursive: bool = True) -> Dict[str, Any]:
        """
        删除文件或目录（危险操作，需确认）。

        参数:
            path: 要删除的文件或目录路径。
            recursive: 是否为递归删除（目录时有效）。

        返回:
            {"success": bool, "path": str, "message": str}
        """
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "path": str(p), "message": "路径不存在"}
            if p.is_dir():
                if recursive:
                    shutil.rmtree(p)
                else:
                    os.rmdir(p)
            else:
                p.unlink()
            return {"success": True, "path": str(p), "message": f"已删除: {p}"}
        except Exception as e:
            return {"success": False, "path": str(path), "message": f"删除失败: {e}"}

    @staticmethod
    def move_path(src: Union[str, Path], dst: Union[str, Path]) -> Dict[str, Any]:
        """
        移动文件或目录。

        参数:
            src: 源路径。
            dst: 目标路径。

        返回:
            {"success": bool, "src": str, "dst": str, "message": str}
        """
        try:
            src_p = _ensure_path(src)
            dst_p = _ensure_path(dst)
            if not src_p.exists():
                return {"success": False, "src": str(src_p), "dst": str(dst_p), "message": "源路径不存在"}
            dst_p.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src_p), str(dst_p))
            return {"success": True, "src": str(src_p), "dst": str(dst_p), "message": f"已移动: {src_p} -> {dst_p}"}
        except Exception as e:
            return {"success": False, "src": str(src), "dst": str(dst), "message": f"移动失败: {e}"}

    @staticmethod
    def copy_path(src: Union[str, Path], dst: Union[str, Path]) -> Dict[str, Any]:
        """
        复制文件或目录。

        参数:
            src: 源路径。
            dst: 目标路径。

        返回:
            {"success": bool, "src": str, "dst": str, "message": str}
        """
        try:
            src_p = _ensure_path(src)
            dst_p = _ensure_path(dst)
            if not src_p.exists():
                return {"success": False, "src": str(src_p), "dst": str(dst_p), "message": "源路径不存在"}
            dst_p.parent.mkdir(parents=True, exist_ok=True)
            if src_p.is_dir():
                shutil.copytree(str(src_p), str(dst_p), dirs_exist_ok=True)
            else:
                shutil.copy2(str(src_p), str(dst_p))
            return {"success": True, "src": str(src_p), "dst": str(dst_p), "message": f"已复制: {src_p} -> {dst_p}"}
        except Exception as e:
            return {"success": False, "src": str(src), "dst": str(dst), "message": f"复制失败: {e}"}

    @staticmethod
    def read_file(path: Union[str, Path], encoding: str = "utf-8", mode: str = "text") -> Dict[str, Any]:
        """
        读取文件内容。

        参数:
            path: 文件路径。
            encoding: 文件编码（默认 utf-8）。
            mode: 读取模式，"text" 返回字符串，"binary" 返回 base64 编码。

        返回:
            {"success": bool, "content": str, "path": str, "message": str}
        """
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "content": "", "path": str(p), "message": "文件不存在"}
            if not p.is_file():
                return {"success": False, "content": "", "path": str(p), "message": "路径不是文件"}
            if mode == "binary":
                import base64
                with open(p, "rb") as f:
                    content = base64.b64encode(f.read()).decode("ascii")
                return {"success": True, "content": content, "path": str(p), "message": "以 base64 格式读取", "encoding": "base64"}
            else:
                with open(p, "r", encoding=encoding) as f:
                    content = f.read()
                return {"success": True, "content": content, "path": str(p), "message": f"已读取 {len(content)} 字符"}
        except Exception as e:
            return {"success": False, "content": "", "path": str(path), "message": f"读取失败: {e}"}

    @staticmethod
    def write_file(path: Union[str, Path], content: str, encoding: str = "utf-8", mode: str = "text") -> Dict[str, Any]:
        """
        写入文件（覆盖已有内容）。

        参数:
            path: 文件路径。
            content: 要写入的内容。
            encoding: 文件编码（默认 utf-8）。
            mode: 写入模式，"text" 写字符串，"binary" 写 base64 解码后的内容。

        返回:
            {"success": bool, "path": str, "message": str}
        """
        try:
            p = _ensure_path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            if mode == "binary":
                import base64
                data = base64.b64decode(content)
                with open(p, "wb") as f:
                    f.write(data)
            else:
                with open(p, "w", encoding=encoding) as f:
                    f.write(content)
            return {"success": True, "path": str(p), "message": f"已写入 {len(content)} 字符到 {p}"}
        except Exception as e:
            return {"success": False, "path": str(path), "message": f"写入失败: {e}"}

    @staticmethod
    def append_file(path: Union[str, Path], content: str, encoding: str = "utf-8") -> Dict[str, Any]:
        """
        追加内容到文件末尾。

        参数:
            path: 文件路径。
            content: 要追加的内容。
            encoding: 文件编码（默认 utf-8）。

        返回:
            {"success": bool, "path": str, "message": str}
        """
        try:
            p = _ensure_path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "a", encoding=encoding) as f:
                f.write(content)
            return {"success": True, "path": str(p), "message": f"已追加 {len(content)} 字符到 {p}"}
        except Exception as e:
            return {"success": False, "path": str(path), "message": f"追加失败: {e}"}

    @staticmethod
    def search_files(
        pattern: str,
        root_dir: Union[str, Path] = ".",
        recursive: bool = True,
        max_results: int = 100,
    ) -> Dict[str, Any]:
        """
        搜索文件（使用 glob 模式匹配）。

        参数:
            pattern: 搜索模式，支持 glob 语法（如 "*.txt", "**/*.py"）。
            root_dir: 搜索根目录（默认当前目录）。
            recursive: 是否递归搜索子目录。
            max_results: 最大返回结果数（默认 100）。

        返回:
            {"success": bool, "files": list, "total": int, "message": str}
        """
        try:
            root = _ensure_path(root_dir)
            if not root.is_dir():
                return {"success": False, "files": [], "total": 0, "message": f"目录不存在: {root}"}
            if recursive and not pattern.startswith("**"):
                pattern = f"**/{pattern}"
            matches = list(root.glob(pattern))
            total = len(matches)
            files = [str(m) for m in matches[:max_results]]
            return {
                "success": True,
                "files": files,
                "total": total,
                "message": f"找到 {total} 个文件，返回 {len(files)} 个" if total > max_results else f"找到 {total} 个文件",
            }
        except Exception as e:
            return {"success": False, "files": [], "total": 0, "message": f"搜索失败: {e}"}

    @staticmethod
    def get_file_info(path: Union[str, Path]) -> Dict[str, Any]:
        """
        获取文件或目录的详细信息。

        参数:
            path: 文件或目录路径。

        返回:
            {"success": bool, "info": dict, "message": str}
        """
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "info": {}, "message": "路径不存在"}
            stat = p.stat()
            info = {
                "path": str(p),
                "name": p.name,
                "extension": p.suffix if p.is_file() else "",
                "size": stat.st_size,
                "size_readable": _format_size(stat.st_size),
                "is_file": p.is_file(),
                "is_dir": p.is_dir(),
                "created": _format_time(stat.st_ctime),
                "modified": _format_time(stat.st_mtime),
                "accessed": _format_time(stat.st_atime),
                "permissions": oct(stat.st_mode)[-3:],
            }
            if p.is_dir():
                try:
                    contents = list(p.iterdir())
                    info["contents_count"] = len(contents)
                    info["contents"] = [str(c.name) for c in contents[:50]]
                    if len(contents) > 50:
                        info["contents"].append(f"... 还有 {len(contents) - 50} 项")
                except Exception:
                    info["contents_count"] = -1
            return {"success": True, "info": info, "message": f"已获取信息: {p.name}"}
        except Exception as e:
            return {"success": False, "info": {}, "message": f"获取信息失败: {e}"}

    @staticmethod
    def compress(paths: List[Union[str, Path]], output_path: Union[str, Path], format: str = "zip") -> Dict[str, Any]:
        """
        压缩文件或目录为归档包。

        参数:
            paths: 要压缩的路径列表。
            output_path: 输出归档文件路径。
            format: 归档格式，"zip" 或 "tar"（默认 "zip"）。

        返回:
            {"success": bool, "output": str, "message": str}
        """
        try:
            output = _ensure_path(output_path)
            resolved_paths = [_ensure_path(p) for p in paths]
            for rp in resolved_paths:
                if not rp.exists():
                    return {"success": False, "output": "", "message": f"路径不存在: {rp}"}
            output.parent.mkdir(parents=True, exist_ok=True)

            if format == "zip":
                with zipfile.ZipFile(str(output), "w", zipfile.ZIP_DEFLATED) as zf:
                    for rp in resolved_paths:
                        if rp.is_dir():
                            for file_path in rp.rglob("*"):
                                if file_path.is_file():
                                    arcname = str(file_path.relative_to(rp.parent))
                                    zf.write(str(file_path), arcname)
                        else:
                            zf.write(str(rp), rp.name)
            elif format == "tar":
                import tarfile
                with tarfile.open(str(output), "w:gz") as tf:
                    for rp in resolved_paths:
                        tf.add(str(rp), arcname=rp.name)
            else:
                return {"success": False, "output": "", "message": f"不支持的格式: {format}，支持 zip/tar"}
            return {"success": True, "output": str(output), "message": f"已压缩到 {output}"}
        except Exception as e:
            return {"success": False, "output": "", "message": f"压缩失败: {e}"}

    @staticmethod
    def extract(archive_path: Union[str, Path], output_dir: Union[str, Path]) -> Dict[str, Any]:
        """
        解压归档文件。

        参数:
            archive_path: 归档文件路径。
            output_dir: 解压目标目录。

        返回:
            {"success": bool, "output_dir": str, "files": list, "message": str}
        """
        try:
            archive = _ensure_path(archive_path)
            output = _ensure_path(output_dir)
            if not archive.exists():
                return {"success": False, "output_dir": "", "files": [], "message": "归档文件不存在"}
            output.mkdir(parents=True, exist_ok=True)

            suffix = archive.suffix.lower()
            extracted_files = []

            if suffix == ".zip" or archive_path.endswith(".zip"):
                with zipfile.ZipFile(str(archive), "r") as zf:
                    zf.extractall(str(output))
                    extracted_files = zf.namelist()
            elif suffix in (".tar", ".gz", ".bz2", ".xz") or any(archive_path.endswith(ext) for ext in (".tar.gz", ".tar.bz2", ".tar.xz")):
                import tarfile
                with tarfile.open(str(archive), "r:*") as tf:
                    tf.extractall(str(output))
                    extracted_files = tf.getnames()
            else:
                return {"success": False, "output_dir": "", "files": [], "message": f"不支持的格式: {suffix}"}
            return {
                "success": True,
                "output_dir": str(output),
                "files": extracted_files,
                "message": f"已解压 {len(extracted_files)} 个文件到 {output}",
            }
        except Exception as e:
            return {"success": False, "output_dir": "", "files": [], "message": f"解压失败: {e}"}


# ============================================================================
# 2. BrowserTools - 浏览器自动化工具（基于 Playwright）
# ============================================================================

class BrowserTools:
    """
    浏览器自动化工具集，基于 Playwright 实现异步浏览器控制。
    支持导航、点击、输入、截图、页面内容提取等操作。
    """

    def __init__(self):
        self._playwright = None
        self._browser = None
        self._page = None
        self._context = None
        self._headless = False

    async def _ensure_browser(self):
        """确保浏览器实例已启动。"""
        if self._browser is None or not self._browser.is_connected():
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(headless=self._headless)
            self._context = await self._browser.new_context(
                viewport={"width": 1280, "height": 800},
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                ),
            )
            self._page = await self._context.new_page()

    async def navigate(self, url: str, timeout: int = 30000) -> Dict[str, Any]:
        """
        导航到指定 URL。

        参数:
            url: 目标网址（完整 URL，需包含协议头）。
            timeout: 超时时间（毫秒，默认 30000）。

        返回:
            {"success": bool, "url": str, "title": str, "message": str}
        """
        try:
            await self._ensure_browser()
            await self._page.goto(url, timeout=timeout, wait_until="domcontentloaded")
            return {
                "success": True,
                "url": self._page.url,
                "title": await self._page.title(),
                "message": f"已导航到: {url}",
            }
        except Exception as e:
            return {"success": False, "url": url, "title": "", "message": f"导航失败: {e}"}

    async def click(self, selector: str, timeout: int = 10000) -> Dict[str, Any]:
        """
        点击页面上的元素。

        参数:
            selector: CSS 选择器或 XPath（如 "#button-id", "//button"）。
            timeout: 等待元素出现的超时时间（毫秒，默认 10000）。

        返回:
            {"success": bool, "selector": str, "message": str}
        """
        try:
            await self._ensure_browser()
            await self._page.wait_for_selector(selector, timeout=timeout)
            await self._page.click(selector)
            return {"success": True, "selector": selector, "message": f"已点击元素: {selector}"}
        except Exception as e:
            return {"success": False, "selector": selector, "message": f"点击失败: {e}"}

    async def type(self, selector: str, text: str, delay: int = 50, timeout: int = 10000) -> Dict[str, Any]:
        """
        在页面元素中输入文本。

        参数:
            selector: CSS 选择器或 XPath。
            text: 要输入的文本内容。
            delay: 按键间隔（毫秒，默认 50），模拟真人输入。
            timeout: 等待元素的超时时间（毫秒，默认 10000）。

        返回:
            {"success": bool, "selector": str, "message": str}
        """
        try:
            await self._ensure_browser()
            await self._page.wait_for_selector(selector, timeout=timeout)
            await self._page.fill(selector, "")
            await self._page.type(selector, text, delay=delay)
            return {"success": True, "selector": selector, "message": f"已输入文本到: {selector}"}
        except Exception as e:
            return {"success": False, "selector": selector, "message": f"输入失败: {e}"}

    async def screenshot(self, path: Optional[Union[str, Path]] = None, full_page: bool = False) -> Dict[str, Any]:
        """
        截取页面截图。

        参数:
            path: 截图保存路径（为 None 时返回 base64 编码）。
            full_page: 是否截取完整页面（含滚动区域，默认 False）。

        返回:
            {"success": bool, "path": str|None, "base64": str|None, "message": str}
        """
        try:
            await self._ensure_browser()
            import base64
            if path:
                p = _ensure_path(path)
                p.parent.mkdir(parents=True, exist_ok=True)
                await self._page.screenshot(path=str(p), full_page=full_page)
                return {"success": True, "path": str(p), "base64": None, "message": f"截图已保存: {p}"}
            else:
                screenshot_bytes = await self._page.screenshot(full_page=full_page)
                b64 = base64.b64encode(screenshot_bytes).decode("ascii")
                return {"success": True, "path": None, "base64": b64, "message": "截图已生成（base64）"}
        except Exception as e:
            return {"success": False, "path": None, "base64": None, "message": f"截图失败: {e}"}

    async def get_page_content(self, format: str = "text") -> Dict[str, Any]:
        """
        获取当前页面的内容。

        参数:
            format: 内容格式，"text"（纯文本）或 "html"（原始 HTML）。

        返回:
            {"success": bool, "content": str, "title": str, "url": str, "message": str}
        """
        try:
            await self._ensure_browser()
            title = await self._page.title()
            url = self._page.url
            if format == "html":
                content = await self._page.content()
            else:
                content = await self._page.evaluate("document.body.innerText")
            return {
                "success": True,
                "content": content,
                "title": title,
                "url": url,
                "message": f"已获取页面内容（{len(content)} 字符）",
            }
        except Exception as e:
            return {"success": False, "content": "", "title": "", "url": "", "message": f"获取内容失败: {e}"}

    async def scroll(self, direction: str = "down", amount: int = 500) -> Dict[str, Any]:
        """
        滚动页面。

        参数:
            direction: 滚动方向，"down"、"up"、"left" 或 "right"。
            amount: 滚动距离（像素，默认 500）。

        返回:
            {"success": bool, "direction": str, "amount": int, "message": str}
        """
        try:
            await self._ensure_browser()
            dx, dy = 0, 0
            if direction == "down":
                dy = amount
            elif direction == "up":
                dy = -amount
            elif direction == "right":
                dx = amount
            elif direction == "left":
                dx = -amount
            else:
                return {"success": False, "direction": direction, "amount": amount, "message": f"不支持的滚动方向: {direction}"}
            await self._page.evaluate(f"window.scrollBy({dx}, {dy})")
            return {"success": True, "direction": direction, "amount": amount, "message": f"已滚动 {direction} {amount}px"}
        except Exception as e:
            return {"success": False, "direction": direction, "amount": amount, "message": f"滚动失败: {e}"}

    async def get_element_text(self, selector: str, timeout: int = 10000) -> Dict[str, Any]:
        """
        获取页面元素的文本内容。

        参数:
            selector: CSS 选择器或 XPath。
            timeout: 等待元素出现的超时时间（毫秒，默认 10000）。

        返回:
            {"success": bool, "text": str, "selector": str, "message": str}
        """
        try:
            await self._ensure_browser()
            await self._page.wait_for_selector(selector, timeout=timeout)
            element = await self._page.query_selector(selector)
            if element is None:
                return {"success": False, "text": "", "selector": selector, "message": f"未找到元素: {selector}"}
            text = await element.inner_text()
            return {"success": True, "text": text.strip(), "selector": selector, "message": f"已获取元素文本（{len(text)} 字符）"}
        except Exception as e:
            return {"success": False, "text": "", "selector": selector, "message": f"获取元素文本失败: {e}"}

    async def fill_form(self, fields: Dict[str, str], timeout: int = 10000) -> Dict[str, Any]:
        """
        填写表单（批量输入多个字段）。

        参数:
            fields: 字典，键为选择器，值为要输入的文本。
                    {"#username": "user1", "#password": "pass123"}
            timeout: 等待元素的超时时间（毫秒，默认 10000）。

        返回:
            {"success": bool, "filled": int, "failed": list, "message": str}
        """
        try:
            await self._ensure_browser()
            filled = 0
            failed = []
            for selector, text in fields.items():
                try:
                    await self._page.wait_for_selector(selector, timeout=timeout)
                    await self._page.fill(selector, text)
                    filled += 1
                except Exception as e:
                    failed.append({"selector": selector, "error": str(e)})
            msg = f"已填写 {filled}/{len(fields)} 个字段"
            if failed:
                msg += f"，{len(failed)} 个失败"
            return {"success": len(failed) == 0, "filled": filled, "failed": failed, "message": msg}
        except Exception as e:
            return {"success": False, "filled": 0, "failed": list(fields.keys()), "message": f"填写表单失败: {e}"}

    async def press_key(self, key: str) -> Dict[str, Any]:
        """
        按下键盘按键。

        参数:
            key: 按键名称（如 "Enter", "Tab", "Escape", "ArrowDown" 等）。

        返回:
            {"success": bool, "key": str, "message": str}
        """
        try:
            await self._ensure_browser()
            await self._page.keyboard.press(key)
            return {"success": True, "key": key, "message": f"已按键: {key}"}
        except Exception as e:
            return {"success": False, "key": key, "message": f"按键失败: {e}"}

    async def evaluate_js(self, script: str) -> Dict[str, Any]:
        """
        在页面中执行 JavaScript 代码。

        参数:
            script: 要执行的 JavaScript 代码字符串。

        返回:
            {"success": bool, "result": Any, "message": str}
        """
        try:
            await self._ensure_browser()
            result = await self._page.evaluate(script)
            return {"success": True, "result": result, "message": "JavaScript 执行成功"}
        except Exception as e:
            return {"success": False, "result": None, "message": f"JavaScript 执行失败: {e}"}

    async def close(self) -> Dict[str, Any]:
        """关闭浏览器并释放资源。"""
        try:
            if self._page:
                await self._page.close()
            if self._context:
                await self._context.close()
            if self._browser:
                await self._browser.close()
            if self._playwright:
                await self._playwright.stop()
            self._page = None
            self._context = None
            self._browser = None
            self._playwright = None
            return {"success": True, "message": "浏览器已关闭"}
        except Exception as e:
            return {"success": False, "message": f"关闭浏览器失败: {e}"}


# ============================================================================
# 3. SystemTools - 系统控制工具（基于 psutil + subprocess）
# ============================================================================

class SystemTools:
    """系统操作工具集：命令执行、进程管理、系统信息查询等。"""

    @staticmethod
    def run_command(
        cmd: str,
        timeout: Optional[int] = None,
        cwd: Optional[Union[str, Path]] = None,
        shell: bool = True,
        capture_output: bool = True,
    ) -> Dict[str, Any]:
        """
        运行 Shell 命令并返回输出。

        参数:
            cmd: 要执行的命令字符串。
            timeout: 超时时间（秒）。为 None 表示不超时。
            cwd: 命令执行的工作目录。
            shell: 是否通过 Shell 执行（Windows 下默认 True）。
            capture_output: 是否捕获输出（默认 True）。

        返回:
            {"success": bool, "stdout": str, "stderr": str, "return_code": int, "message": str}
        """
        try:
            if cwd:
                cwd = str(_ensure_path(cwd))
            result = subprocess.run(
                cmd,
                shell=shell,
                capture_output=capture_output,
                timeout=timeout,
                cwd=cwd,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout or "",
                "stderr": result.stderr or "",
                "return_code": result.returncode,
                "message": "命令执行成功" if result.returncode == 0 else f"命令执行失败（返回码: {result.returncode}）",
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": "", "return_code": -1, "message": f"命令执行超时（{timeout}秒）"}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": "", "return_code": -1, "message": f"命令执行异常: {e}"}

    @staticmethod
    def get_process_list() -> Dict[str, Any]:
        """
        获取当前系统进程列表。

        返回:
            {"success": bool, "processes": list, "total": int, "message": str}
        """
        if not PSUTIL_AVAILABLE:
            return {"success": False, "processes": [], "total": 0, "message": "psutil 未安装"}
        try:
            processes = []
            for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status", "create_time"]):
                try:
                    pinfo = proc.info
                    processes.append({
                        "pid": pinfo["pid"],
                        "name": pinfo["name"],
                        "cpu_percent": pinfo["cpu_percent"],
                        "memory_percent": round(pinfo["memory_percent"], 2) if pinfo["memory_percent"] else 0,
                        "status": pinfo["status"],
                        "created": _format_time(pinfo["create_time"]) if pinfo["create_time"] else "",
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            processes.sort(key=lambda p: p["cpu_percent"] or 0, reverse=True)
            return {"success": True, "processes": processes[:200], "total": len(processes), "message": f"获取到 {len(processes)} 个进程"}
        except Exception as e:
            return {"success": False, "processes": [], "total": 0, "message": f"获取进程列表失败: {e}"}

    @staticmethod
    def kill_process(pid: int) -> Dict[str, Any]:
        """
        终止指定 PID 的进程。

        参数:
            pid: 要终止的进程 ID。

        返回:
            {"success": bool, "pid": int, "message": str}
        """
        if not PSUTIL_AVAILABLE:
            return {"success": False, "pid": pid, "message": "psutil 未安装"}
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            proc.terminate()
            proc.wait(timeout=5)
            return {"success": True, "pid": pid, "name": name, "message": f"已终止进程 [{pid}] {name}"}
        except psutil.NoSuchProcess:
            return {"success": False, "pid": pid, "message": f"进程 [{pid}] 不存在"}
        except psutil.AccessDenied:
            return {"success": False, "pid": pid, "message": f"无权限终止进程 [{pid}]"}
        except psutil.TimeoutExpired:
            try:
                proc = psutil.Process(pid)
                proc.kill()
                return {"success": True, "pid": pid, "message": f"已强制终止进程 [{pid}]"}
            except Exception as e:
                return {"success": False, "pid": pid, "message": f"强制终止也失败: {e}"}
        except Exception as e:
            return {"success": False, "pid": pid, "message": f"终止进程失败: {e}"}

    @staticmethod
    def get_system_info() -> Dict[str, Any]:
        """
        获取系统信息（操作系统、CPU、内存等）。

        返回:
            {"success": bool, "info": dict, "message": str}
        """
        info = {
            "platform": platform.platform(),
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "architecture": platform.machine(),
            "processor": platform.processor(),
            "hostname": platform.node(),
            "python_version": sys.version,
        }
        if PSUTIL_AVAILABLE:
            try:
                import psutil
                info["cpu_count"] = {
                    "physical": psutil.cpu_count(logical=False),
                    "logical": psutil.cpu_count(logical=True),
                }
                info["cpu_percent"] = psutil.cpu_percent(interval=0.5)
                mem = psutil.virtual_memory()
                info["memory"] = {
                    "total": mem.total,
                    "total_readable": _format_size(mem.total),
                    "available": mem.available,
                    "available_readable": _format_size(mem.available),
                    "percent": mem.percent,
                }
                swap = psutil.swap_memory()
                info["swap"] = {
                    "total": swap.total,
                    "total_readable": _format_size(swap.total),
                    "used": swap.used,
                    "percent": swap.percent,
                }
                info["boot_time"] = _format_time(psutil.boot_time())
            except Exception:
                pass
        return {"success": True, "info": info, "message": "系统信息获取成功"}

    @staticmethod
    def get_disk_usage(path: Union[str, Path] = "/") -> Dict[str, Any]:
        """
        获取磁盘使用情况。

        参数:
            path: 要检查的路径（默认根目录）。

        返回:
            {"success": bool, "disks": list, "message": str}
        """
        if not PSUTIL_AVAILABLE:
            return {"success": False, "disks": [], "message": "psutil 未安装"}
        try:
            if platform.system() == "Windows":
                disks = [d.device for d in psutil.disk_partitions()]
            else:
                disks = [path]
            result = []
            for disk in disks:
                try:
                    usage = psutil.disk_usage(disk)
                    result.append({
                        "mount": disk,
                        "total": usage.total,
                        "total_readable": _format_size(usage.total),
                        "used": usage.used,
                        "used_readable": _format_size(usage.used),
                        "free": usage.free,
                        "free_readable": _format_size(usage.free),
                        "percent": usage.percent,
                    })
                except Exception:
                    continue
            return {"success": True, "disks": result, "message": f"获取到 {len(result)} 个磁盘信息"}
        except Exception as e:
            return {"success": False, "disks": [], "message": f"获取磁盘信息失败: {e}"}

    @staticmethod
    def open_application(path: Union[str, Path]) -> Dict[str, Any]:
        """
        打开应用程序或文件（使用系统默认关联程序）。

        参数:
            path: 应用程序路径或文件路径。

        返回:
            {"success": bool, "path": str, "message": str}
        """
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "path": str(p), "message": f"路径不存在: {p}"}
            if platform.system() == "Windows":
                os.startfile(str(p))
            elif platform.system() == "Darwin":
                subprocess.run(["open", str(p)], check=True)
            else:
                subprocess.run(["xdg-open", str(p)], check=True)
            return {"success": True, "path": str(p), "message": f"已打开: {p}"}
        except Exception as e:
            return {"success": False, "path": str(path), "message": f"打开失败: {e}"}

    @staticmethod
    def send_notification(title: str, message: str, duration: int = 5) -> Dict[str, Any]:
        """
        发送系统通知。

        参数:
            title: 通知标题。
            message: 通知内容。
            duration: 显示时长（秒，默认 5）。

        返回:
            {"success": bool, "message": str}
        """
        try:
            system = platform.system()
            if system == "Windows":
                try:
                    from plyer import notification
                    notification.notify(title=title, message=message, timeout=duration)
                    return {"success": True, "message": f"通知已发送: {title}"}
                except ImportError:
                    import ctypes
                    ctypes.windll.user32.MessageBoxW(0, message, title, 0)
                    return {"success": True, "message": f"已弹出消息框: {title}"}
            elif system == "Darwin":
                subprocess.run(["osascript", "-e", f'display notification "{message}" with title "{title}"'], check=True)
                return {"success": True, "message": f"通知已发送: {title}"}
            else:
                subprocess.run(["notify-send", title, message], check=True)
                return {"success": True, "message": f"通知已发送: {title}"}
        except Exception as e:
            return {"success": False, "message": f"发送通知失败: {e}"}


# ============================================================================
# 4. ComputerControlTools - 计算机控制工具（基于 pyautogui）
# ============================================================================

class ComputerControlTools:
    """
    计算机控制工具集，基于 PyAutoGUI 实现鼠标键盘自动化。
    注意：请确保在使用前有足够的时间切换到目标窗口。
    """

    @staticmethod
    def mouse_move(x: int, y: int, duration: float = 0.5) -> Dict[str, Any]:
        """
        移动鼠标到指定坐标。

        参数:
            x: 目标 X 坐标。
            y: 目标 Y 坐标。
            duration: 移动持续时间（秒，默认 0.5）。

        返回:
            {"success": bool, "x": int, "y": int, "message": str}
        """
        if not PYAUTOGUI_AVAILABLE:
            return {"success": False, "x": x, "y": y, "message": "pyautogui 未安装"}
        try:
            pyautogui.moveTo(x, y, duration=duration)
            return {"success": True, "x": x, "y": y, "message": f"鼠标已移动到 ({x}, {y})"}
        except Exception as e:
            return {"success": False, "x": x, "y": y, "message": f"移动鼠标失败: {e}"}

    @staticmethod
    def mouse_click(x: int, y: int, button: str = "left") -> Dict[str, Any]:
        """
        在指定坐标点击鼠标。

        参数:
            x: 点击位置的 X 坐标。
            y: 点击位置的 Y 坐标。
            button: 鼠标按键，"left"（左键）、"right"（右键）或 "middle"（中键）。

        返回:
            {"success": bool, "x": int, "y": int, "button": str, "message": str}
        """
        if not PYAUTOGUI_AVAILABLE:
            return {"success": False, "message": "pyautogui 未安装"}
        try:
            pyautogui.click(x=x, y=y, button=button)
            return {"success": True, "x": x, "y": y, "button": button, "message": f"在 ({x}, {y}) 点击 {button} 键"}
        except Exception as e:
            return {"success": False, "x": x, "y": y, "button": button, "message": f"点击失败: {e}"}

    @staticmethod
    def mouse_double_click(x: int, y: int) -> Dict[str, Any]:
        """
        在指定坐标双击鼠标左键。

        参数:
            x: 双击位置的 X 坐标。
            y: 双击位置的 Y 坐标。

        返回:
            {"success": bool, "x": int, "y": int, "message": str}
        """
        if not PYAUTOGUI_AVAILABLE:
            return {"success": False, "message": "pyautogui 未安装"}
        try:
            pyautogui.doubleClick(x=x, y=y)
            return {"success": True, "x": x, "y": y, "message": f"在 ({x}, {y}) 双击"}
        except Exception as e:
            return {"success": False, "x": x, "y": y, "message": f"双击失败: {e}"}

    @staticmethod
    def mouse_drag(start_x: int, start_y: int, end_x: int, end_y: int, duration: float = 0.5, button: str = "left") -> Dict[str, Any]:
        """
        从起始坐标拖拽到结束坐标。

        参数:
            start_x: 起始 X 坐标。
            start_y: 起始 Y 坐标。
            end_x: 结束 X 坐标。
            end_y: 结束 Y 坐标。
            duration: 拖拽持续时间（秒，默认 0.5）。
            button: 拖拽时按下的按键，"left" 或 "right"。

        返回:
            {"success": bool, "message": str}
        """
        if not PYAUTOGUI_AVAILABLE:
            return {"success": False, "message": "pyautogui 未安装"}
        try:
            pyautogui.moveTo(start_x, start_y, duration=0.2)
            pyautogui.drag(end_x - start_x, end_y - start_y, duration=duration, button=button)
            return {
                "success": True,
                "start": (start_x, start_y),
                "end": (end_x, end_y),
                "message": f"从 ({start_x}, {start_y}) 拖拽到 ({end_x}, {end_y})",
            }
        except Exception as e:
            return {"success": False, "message": f"拖拽失败: {e}"}

    @staticmethod
    def keyboard_type(text: str, interval: float = 0.05) -> Dict[str, Any]:
        """
        模拟键盘输入文本。

        参数:
            text: 要输入的文本。
            interval: 按键间隔（秒，默认 0.05）。

        返回:
            {"success": bool, "message": str}
        """
        if not PYAUTOGUI_AVAILABLE:
            return {"success": False, "message": "pyautogui 未安装"}
        try:
            pyautogui.typewrite(text, interval=interval)
            return {"success": True, "message": f"已输入 {len(text)} 个字符"}
        except Exception as e:
            return {"success": False, "message": f"键盘输入失败: {e}"}

    @staticmethod
    def keyboard_hotkey(keys: List[str]) -> Dict[str, Any]:
        """
        按下组合快捷键。

        参数:
            keys: 按键列表，如 ["ctrl", "c"] 表示复制，["alt", "tab"] 表示切换窗口。

        返回:
            {"success": bool, "keys": list, "message": str}
        """
        if not PYAUTOGUI_AVAILABLE:
            return {"success": False, "message": "pyautogui 未安装"}
        try:
            pyautogui.hotkey(*keys)
            return {"success": True, "keys": keys, "message": f"已按下快捷键: {'+'.join(keys)}"}
        except Exception as e:
            return {"success": False, "keys": keys, "message": f"快捷键失败: {e}"}

    @staticmethod
    def keyboard_press(key: str) -> Dict[str, Any]:
        """
        按下并释放单个按键。

        参数:
            key: 按键名称（如 "enter", "tab", "escape", "f5" 等）。

        返回:
            {"success": bool, "key": str, "message": str}
        """
        if not PYAUTOGUI_AVAILABLE:
            return {"success": False, "message": "pyautogui 未安装"}
        try:
            pyautogui.press(key)
            return {"success": True, "key": key, "message": f"已按键: {key}"}
        except Exception as e:
            return {"success": False, "key": key, "message": f"按键失败: {e}"}

    @staticmethod
    def take_screenshot(path: Optional[Union[str, Path]] = None) -> Dict[str, Any]:
        """
        截取屏幕截图。

        参数:
            path: 保存路径。为 None 则返回 PIL Image 对象的 base64 编码。

        返回:
            {"success": bool, "path": str|None, "base64": str|None, "message": str}
        """
        if not PYAUTOGUI_AVAILABLE:
            return {"success": False, "message": "pyautogui 未安装"}
        try:
            import base64
            screenshot = pyautogui.screenshot()
            if path:
                p = _ensure_path(path)
                p.parent.mkdir(parents=True, exist_ok=True)
                screenshot.save(str(p))
                return {"success": True, "path": str(p), "base64": None, "message": f"截图已保存: {p}"}
            else:
                buf = io.BytesIO()
                screenshot.save(buf, format="PNG")
                b64 = base64.b64encode(buf.getvalue()).decode("ascii")
                return {"success": True, "path": None, "base64": b64, "message": "截图已生成（base64）"}
        except Exception as e:
            return {"success": False, "message": f"截图失败: {e}"}

    @staticmethod
    def scroll(direction: str = "down", amount: int = 3) -> Dict[str, Any]:
        """
        滚动鼠标滚轮。

        参数:
            direction: 滚动方向，"up"（向上）或 "down"（向下）。
            amount: 滚动格数（默认 3，正数向上，负数向下）。

        返回:
            {"success": bool, "direction": str, "amount": int, "message": str}
        """
        if not PYAUTOGUI_AVAILABLE:
            return {"success": False, "message": "pyautogui 未安装"}
        try:
            clicks = amount if direction == "up" else -amount
            pyautogui.scroll(clicks)
            return {"success": True, "direction": direction, "amount": amount, "message": f"已滚动 {direction} {amount} 格"}
        except Exception as e:
            return {"success": False, "direction": direction, "amount": amount, "message": f"滚动失败: {e}"}


# ============================================================================
# 5. OfficeTools - 办公文档工具（pptx / xlsx / docx）
# ============================================================================

class OfficeTools:
    """办公文档工具集：创建和编辑 PPT、Excel、Word 文档。"""

    @staticmethod
    def create_pptx(path: Union[str, Path], slides_content: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        创建 PowerPoint 演示文稿。

        参数:
            path: 保存路径（需以 .pptx 结尾）。
            slides_content: 幻灯片内容列表，每项为字典：
                {
                    "title": "幻灯片标题",
                    "subtitle": "副标题（可选）",
                    "body": ["要点1", "要点2"],  # 正文列表（可选）
                }

        返回:
            {"success": bool, "path": str, "slides": int, "message": str}
        """
        if not PPTX_AVAILABLE:
            return {"success": False, "path": "", "slides": 0, "message": "python-pptx 未安装"}
        try:
            p = _ensure_path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            prs = Presentation()
            prs.slide_width = Inches(13.333)
            prs.slide_height = Inches(7.5)

            for slide_data in slides_content:
                slide_layout = prs.slide_layouts[1]
                slide = prs.slides.add_slide(slide_layout)
                title = slide.shapes.title
                title.text = slide_data.get("title", "")

                if "subtitle" in slide_data:
                    from pptx.util import Inches, Pt
                    left = Inches(0.5)
                    top = Inches(1.2)
                    width = Inches(12)
                    height = Inches(0.6)
                    txBox = slide.shapes.add_textbox(left, top, width, height)
                    tf = txBox.text_frame
                    p_para = tf.add_paragraph()
                    p_para.text = slide_data["subtitle"]
                    p_para.font.size = Pt(18)
                    p_para.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

                body = slide_data.get("body", [])
                if body and slide.shapes.placeholders:
                    try:
                        body_shape = slide.placeholders[1]
                        tf = body_shape.text_frame
                        tf.clear()
                        for i, item in enumerate(body):
                            if i == 0:
                                tf.text = item
                            else:
                                p_para = tf.add_paragraph()
                                p_para.text = item
                    except Exception:
                        pass

            prs.save(str(p))
            return {"success": True, "path": str(p), "slides": len(slides_content), "message": f"已创建 {len(slides_content)} 页 PPT: {p.name}"}
        except Exception as e:
            return {"success": False, "path": str(path), "slides": 0, "message": f"创建 PPT 失败: {e}"}

    @staticmethod
    def create_xlsx(path: Union[str, Path], data: List[Dict[str, Any]], sheet_name: str = "Sheet1") -> Dict[str, Any]:
        """
        创建 Excel 工作簿。

        参数:
            path: 保存路径（需以 .xlsx 结尾）。
            data: 数据列表，每项为字典（键为列名，值为单元格值）。
                  例如: [{"姓名": "张三", "年龄": 25}, {"姓名": "李四", "年龄": 30}]
            sheet_name: 工作表名称（默认 "Sheet1"）。

        返回:
            {"success": bool, "path": str, "rows": int, "columns": int, "message": str}
        """
        if not OPENPYXL_AVAILABLE:
            return {"success": False, "path": "", "rows": 0, "columns": 0, "message": "openpyxl 未安装"}
        try:
            p = _ensure_path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            wb = Workbook()
            ws = wb.active
            ws.title = sheet_name

            if not data:
                wb.save(str(p))
                return {"success": True, "path": str(p), "rows": 0, "columns": 0, "message": f"已创建空表格: {p.name}"}

            headers = list(data[0].keys())
            ws.append(headers)
            for row in data:
                ws.append([row.get(h, "") for h in headers])

            for col_idx, header in enumerate(headers, 1):
                cell = ws.cell(row=1, column=col_idx)
                cell.font = cell.font.__class__(bold=True)

            ws.auto_filter.ref = ws.dimensions
            wb.save(str(p))
            return {
                "success": True,
                "path": str(p),
                "rows": len(data),
                "columns": len(headers),
                "message": f"已创建表格: {p.name}（{len(data)} 行 x {len(headers)} 列）",
            }
        except Exception as e:
            return {"success": False, "path": str(path), "rows": 0, "columns": 0, "message": f"创建 Excel 失败: {e}"}

    @staticmethod
    def create_docx(path: Union[str, Path], content: Dict[str, Any]) -> Dict[str, Any]:
        """
        创建 Word 文档。

        参数:
            path: 保存路径（需以 .docx 结尾）。
            content: 文档内容字典：
                {
                    "title": "文档标题",
                    "paragraphs": ["段落1", "段落2"],
                    "headings": [{"level": 1, "text": "章节标题"}, ...],
                }

        返回:
            {"success": bool, "path": str, "paragraphs": int, "message": str}
        """
        if not DOCX_AVAILABLE:
            return {"success": False, "path": "", "paragraphs": 0, "message": "python-docx 未安装"}
        try:
            p = _ensure_path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            doc = Document()

            title = content.get("title", "")
            if title:
                heading = doc.add_heading(title, level=0)

            para_count = 0
            for para_text in content.get("paragraphs", []):
                doc.add_paragraph(para_text)
                para_count += 1

            for heading_data in content.get("headings", []):
                level = heading_data.get("level", 1)
                text = heading_data.get("text", "")
                doc.add_heading(text, level=level)
                para_count += 1

            doc.save(str(p))
            return {"success": True, "path": str(p), "paragraphs": para_count, "message": f"已创建文档: {p.name}"}
        except Exception as e:
            return {"success": False, "path": str(path), "paragraphs": 0, "message": f"创建文档失败: {e}"}

    @staticmethod
    def read_xlsx(path: Union[str, Path], sheet_name: Optional[str] = None) -> Dict[str, Any]:
        """
        读取 Excel 文件内容。

        参数:
            path: Excel 文件路径。
            sheet_name: 要读取的工作表名称。为 None 则读取第一个工作表。

        返回:
            {"success": bool, "headers": list, "rows": list, "sheet_name": str, "total_rows": int, "message": str}
        """
        if not OPENPYXL_AVAILABLE:
            return {"success": False, "headers": [], "rows": [], "sheet_name": "", "total_rows": 0, "message": "openpyxl 未安装"}
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "headers": [], "rows": [], "sheet_name": "", "total_rows": 0, "message": "文件不存在"}
            wb = load_workbook(str(p), read_only=True, data_only=True)
            if sheet_name:
                ws = wb[sheet_name]
            else:
                ws = wb.active
            rows_iter = ws.iter_rows(values_only=True)
            headers = [str(h) if h is not None else "" for h in next(rows_iter, [])]
            rows = []
            for row in rows_iter:
                rows.append([str(c) if c is not None else "" for c in row])
            wb.close()
            return {
                "success": True,
                "headers": headers,
                "rows": rows,
                "sheet_name": ws.title,
                "total_rows": len(rows),
                "message": f"已读取 {ws.title}（{len(rows)} 行数据）",
            }
        except Exception as e:
            return {"success": False, "headers": [], "rows": [], "sheet_name": "", "total_rows": 0, "message": f"读取 Excel 失败: {e}"}

    @staticmethod
    def read_docx(path: Union[str, Path]) -> Dict[str, Any]:
        """
        读取 Word 文档内容。

        参数:
            path: Word 文件路径。

        返回:
            {"success": bool, "content": str, "paragraphs": list, "total_paragraphs": int, "message": str}
        """
        if not DOCX_AVAILABLE:
            return {"success": False, "content": "", "paragraphs": [], "total_paragraphs": 0, "message": "python-docx 未安装"}
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "content": "", "paragraphs": [], "total_paragraphs": 0, "message": "文件不存在"}
            doc = Document(str(p))
            paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]
            content = "\n".join(paragraphs)
            return {
                "success": True,
                "content": content,
                "paragraphs": paragraphs,
                "total_paragraphs": len(paragraphs),
                "message": f"已读取文档（{len(paragraphs)} 段落，{len(content)} 字符）",
            }
        except Exception as e:
            return {"success": False, "content": "", "paragraphs": [], "total_paragraphs": 0, "message": f"读取文档失败: {e}"}

    @staticmethod
    def edit_xlsx(path: Union[str, Path], data: List[Dict[str, Any]], sheet_name: Optional[str] = None) -> Dict[str, Any]:
        """
        编辑 Excel 文件（追加数据到已有工作表）。

        参数:
            path: Excel 文件路径。
            data: 要追加的数据列表（格式同 create_xlsx）。
            sheet_name: 工作表名称。为 None 则使用当前活动工作表。

        返回:
            {"success": bool, "path": str, "rows_added": int, "message": str}
        """
        if not OPENPYXL_AVAILABLE:
            return {"success": False, "path": "", "rows_added": 0, "message": "openpyxl 未安装"}
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "path": str(p), "rows_added": 0, "message": "文件不存在"}
            wb = load_workbook(str(p))
            if sheet_name:
                if sheet_name not in wb.sheetnames:
                    return {"success": False, "path": str(p), "rows_added": 0, "message": f"工作表不存在: {sheet_name}"}
                ws = wb[sheet_name]
            else:
                ws = wb.active

            if not data:
                wb.save(str(p))
                return {"success": True, "path": str(p), "rows_added": 0, "message": "未添加数据"}
            headers = list(data[0].keys())
            for row in data:
                ws.append([row.get(h, "") for h in headers])
            wb.save(str(p))
            wb.close()
            return {"success": True, "path": str(p), "rows_added": len(data), "message": f"已追加 {len(data)} 行数据"}
        except Exception as e:
            return {"success": False, "path": str(path), "rows_added": 0, "message": f"编辑 Excel 失败: {e}"}

    @staticmethod
    def convert_to_pdf(path: Union[str, Path], output_path: Optional[Union[str, Path]] = None) -> Dict[str, Any]:
        """
        将文档转换为 PDF（占位实现，需要系统安装对应办公软件）。

        参数:
            path: 源文件路径（支持 .docx, .pptx, .xlsx）。
            output_path: 输出 PDF 路径。为 None 则自动生成。

        返回:
            {"success": bool, "path": str, "message": str}
        """
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "path": "", "message": "源文件不存在"}
            suffix = p.suffix.lower()
            if suffix not in (".docx", ".pptx", ".xlsx"):
                return {"success": False, "path": "", "message": f"不支持的文件格式: {suffix}，支持 docx/pptx/xlsx"}
            if output_path:
                out = _ensure_path(output_path)
            else:
                out = p.with_suffix(".pdf")
            out.parent.mkdir(parents=True, exist_ok=True)

            if platform.system() == "Windows":
                import subprocess
                try:
                    result = subprocess.run(
                        ["powershell", "-Command", f"""
                            $word = New-Object -ComObject Word.Application
                            $doc = $word.Documents.Open('{p}')
                            $doc.SaveAs('{out}', 17)
                            $doc.Close()
                            $word.Quit()
                        """],
                        capture_output=True, text=True, timeout=30,
                    )
                    if result.returncode == 0:
                        return {"success": True, "path": str(out), "message": f"已转换为 PDF: {out.name}"}
                except Exception:
                    pass
            return {
                "success": False,
                "path": str(out),
                "message": "PDF 转换需要系统安装对应办公软件。请手动转换或使用在线工具。",
            }
        except Exception as e:
            return {"success": False, "path": "", "message": f"转换 PDF 失败: {e}"}


# ============================================================================
# 6. ImageTools - 图片处理工具（基于 Pillow）
# ============================================================================

class ImageTools:
    """图像处理工具集：缩放、格式转换、滤镜、OCR、拼图等。"""

    @staticmethod
    def resize_image(path: Union[str, Path], width: int, height: int, keep_aspect: bool = True, output_path: Optional[Union[str, Path]] = None) -> Dict[str, Any]:
        """
        调整图片尺寸。

        参数:
            path: 图片路径。
            width: 目标宽度（像素）。
            height: 目标高度（像素）。
            keep_aspect: 是否保持宽高比（默认 True，用背景色填充空白）。
            output_path: 输出路径。为 None 则覆盖原文件。

        返回:
            {"success": bool, "path": str, "original_size": tuple, "new_size": tuple, "message": str}
        """
        if not PILLOW_AVAILABLE:
            return {"success": False, "message": "Pillow 未安装"}
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "message": "文件不存在"}
            img = Image.open(str(p))
            original_size = img.size

            if keep_aspect:
                img.thumbnail((width, height), Image.LANCZOS)
                new_img = Image.new("RGB", (width, height), (255, 255, 255))
                new_img.paste(img, ((width - img.width) // 2, (height - img.height) // 2))
                img = new_img
            else:
                img = img.resize((width, height), Image.LANCZOS)

            out_path = _ensure_path(output_path) if output_path else p
            out_path.parent.mkdir(parents=True, exist_ok=True)
            img.save(str(out_path))
            return {
                "success": True,
                "path": str(out_path),
                "original_size": original_size,
                "new_size": (width, height),
                "message": f"已调整尺寸: {original_size} -> ({width}, {height})",
            }
        except Exception as e:
            return {"success": False, "message": f"调整尺寸失败: {e}"}

    @staticmethod
    def convert_format(path: Union[str, Path], new_format: str, output_path: Optional[Union[str, Path]] = None) -> Dict[str, Any]:
        """
        转换图片格式。

        参数:
            path: 图片路径。
            new_format: 目标格式，如 "PNG"、"JPEG"、"GIF"、"WEBP"、"BMP"。
            output_path: 输出路径。为 None 则自动生成（同目录，改扩展名）。

        返回:
            {"success": bool, "path": str, "original_format": str, "new_format": str, "message": str}
        """
        if not PILLOW_AVAILABLE:
            return {"success": False, "message": "Pillow 未安装"}
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "message": "文件不存在"}
            img = Image.open(str(p))
            original_format = img.format or "UNKNOWN"
            fmt = new_format.upper()

            if output_path:
                out_path = _ensure_path(output_path)
            else:
                ext_map = {
                    "PNG": ".png", "JPEG": ".jpg", "JPG": ".jpg",
                    "GIF": ".gif", "WEBP": ".webp", "BMP": ".bmp",
                    "TIFF": ".tiff", "ICO": ".ico",
                }
                ext = ext_map.get(fmt, f".{fmt.lower()}")
                out_path = p.with_suffix(ext)

            out_path.parent.mkdir(parents=True, exist_ok=True)
            save_kwargs = {}
            if fmt == "JPEG":
                save_kwargs["quality"] = 95
            img.save(str(out_path), format=fmt, **save_kwargs)
            return {
                "success": True,
                "path": str(out_path),
                "original_format": original_format,
                "new_format": fmt,
                "message": f"已转换格式: {original_format} -> {fmt}",
            }
        except Exception as e:
            return {"success": False, "message": f"格式转换失败: {e}"}

    @staticmethod
    def add_filter(path: Union[str, Path], filter_type: str, output_path: Optional[Union[str, Path]] = None) -> Dict[str, Any]:
        """
        为图片添加滤镜效果。

        参数:
            path: 图片路径。
            filter_type: 滤镜类型，支持:
                "blur"（模糊）、"contour"（轮廓）、"detail"（细节增强）、
                "edge_enhance"（边缘增强）、"emboss"（浮雕）、
                "sh
arpen"（锐化）、"smooth"（平滑）、"gray"（灰度）。
            output_path: 输出路径。为 None 则覆盖原文件。

        返回:
            {"success": bool, "path": str, "filter": str, "message": str}
        """
        if not PILLOW_AVAILABLE:
            return {"success": False, "message": "Pillow 未安装"}
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "message": "文件不存在"}
            img = Image.open(str(p))

            filter_map = {
                "blur": ImageFilter.BLUR,
                "contour": ImageFilter.CONTOUR,
                "detail": ImageFilter.DETAIL,
                "edge_enhance": ImageFilter.EDGE_ENHANCE,
                "emboss": ImageFilter.EMBOSS,
                "sharpen": ImageFilter.SHARPEN,
                "smooth": ImageFilter.SMOOTH,
            }

            if filter_type == "gray":
                img = ImageOps.grayscale(img)
            else:
                pil_filter = filter_map.get(filter_type)
                if pil_filter is None:
                    return {"success": False, "message": f"不支持的滤镜类型: {filter_type}，支持: {', '.join(filter_map.keys()) + ', gray'}"}
                img = img.filter(pil_filter)

            out_path = _ensure_path(output_path) if output_path else p
            out_path.parent.mkdir(parents=True, exist_ok=True)
            img.save(str(out_path))
            return {"success": True, "path": str(out_path), "filter": filter_type, "message": f"已应用滤镜: {filter_type}"}
        except Exception as e:
            return {"success": False, "message": f"应用滤镜失败: {e}"}

    @staticmethod
    def ocr_image(path: Union[str, Path], lang: str = "chi_sim+eng") -> Dict[str, Any]:
        """
        对图片进行 OCR 文字识别（基于 pytesseract）。

        参数:
            path: 图片路径。
            lang: 识别语言（默认 "chi_sim+eng" 中文简体+英文）。
                  常见：eng（英文）、chi_sim（中文简体）、jpn（日文）。

        返回:
            {"success": bool, "text": str, "confidence": float|None, "message": str}
        """
        if not PYTESSERACT_AVAILABLE:
            return {"success": False, "text": "", "confidence": None, "message": "pytesseract 未安装"}
        if not PILLOW_AVAILABLE:
            return {"success": False, "text": "", "confidence": None, "message": "Pillow 未安装"}
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "text": "", "confidence": None, "message": "文件不存在"}
            img = Image.open(str(p))
            data = pytesseract.image_to_data(img, lang=lang, output_type=pytesseract.Output.DICT)
            text_parts = []
            confidences = []
            for i, text in enumerate(data["text"]):
                if text.strip():
                    try:
                        conf = int(data["conf"][i])
                        if conf > 0:
                            confidences.append(conf)
                    except (ValueError, IndexError):
                        pass
                    text_parts.append(text)
            text = " ".join(text_parts)
            avg_confidence = sum(confidences) / len(confidences) if confidences else None
            return {
                "success": True,
                "text": text,
                "confidence": avg_confidence,
                "message": f"OCR 识别完成，共 {len(text_parts)} 个词" + (f"，平均置信度 {avg_confidence:.1f}%" if avg_confidence else ""),
            }
        except Exception as e:
            return {"success": False, "text": "", "confidence": None, "message": f"OCR 识别失败: {e}"}

    @staticmethod
    def create_collage(images_paths: List[Union[str, Path]], output_path: Union[str, Path], cols: int = 2, spacing: int = 10) -> Dict[str, Any]:
        """
        将多张图片合成为拼图（Collage）。

        参数:
            images_paths: 图片路径列表。
            output_path: 输出拼图路径。
            cols: 每行图片数量（默认 2）。
            spacing: 图片间距（像素，默认 10）。

        返回:
            {"success": bool, "path": str, "images_count": int, "message": str}
        """
        if not PILLOW_AVAILABLE:
            return {"success": False, "path": "", "images_count": 0, "message": "Pillow 未安装"}
        try:
            out = _ensure_path(output_path)
            out.parent.mkdir(parents=True, exist_ok=True)

            images = []
            for img_path in images_paths:
                p = _ensure_path(img_path)
                if p.exists():
                    img = Image.open(str(p)).convert("RGB")
                    max_dim = 800
                    img.thumbnail((max_dim, max_dim), Image.LANCZOS)
                    images.append(img)

            if not images:
                return {"success": False, "path": "", "images_count": 0, "message": "没有有效的图片"}

            rows = (len(images) + cols - 1) // cols
            cell_w = max(img.width for img in images) + spacing
            cell_h = max(img.height for img in images) + spacing
            collage_w = cell_w * cols + spacing
            collage_h = cell_h * rows + spacing

            collage = Image.new("RGB", (collage_w, collage_h), (240, 240, 240))
            for idx, img in enumerate(images):
                row = idx // cols
                col = idx % cols
                x = spacing + col * cell_w + (cell_w - spacing - img.width) // 2
                y = spacing + row * cell_h + (cell_h - spacing - img.height) // 2
                collage.paste(img, (x, y))

            collage.save(str(out))
            return {
                "success": True,
                "path": str(out),
                "images_count": len(images),
                "message": f"已生成拼图，包含 {len(images)} 张图片",
            }
        except Exception as e:
            return {"success": False, "path": "", "images_count": 0, "message": f"创建拼图失败: {e}"}


# ============================================================================
# 7. ClipboardTools - 剪贴板工具（基于 pyperclip）
# ============================================================================

class ClipboardTools:
    """剪贴板操作工具集：文本复制粘贴、文件复制、清空等。"""

    @staticmethod
    def copy_text(text: str) -> Dict[str, Any]:
        """
        复制文本到剪贴板。

        参数:
            text: 要复制到剪贴板的文本内容。

        返回:
            {"success": bool, "length": int, "message": str}
        """
        if not PYPERCLIP_AVAILABLE:
            return {"success": False, "length": 0, "message": "pyperclip 未安装"}
        try:
            pyperclip.copy(text)
            return {"success": True, "length": len(text), "message": f"已复制 {len(text)} 字符到剪贴板"}
        except Exception as e:
            return {"success": False, "length": 0, "message": f"复制失败: {e}"}

    @staticmethod
    def paste_text() -> Dict[str, Any]:
        """
        从剪贴板获取文本内容。

        返回:
            {"success": bool, "text": str, "length": int, "message": str}
        """
        if not PYPERCLIP_AVAILABLE:
            return {"success": False, "text": "", "length": 0, "message": "pyperclip 未安装"}
        try:
            text = pyperclip.paste()
            return {"success": True, "text": text, "length": len(text), "message": f"从剪贴板获取到 {len(text)} 字符"}
        except Exception as e:
            return {"success": False, "text": "", "length": 0, "message": f"粘贴失败: {e}"}

    @staticmethod
    def copy_file(path: Union[str, Path]) -> Dict[str, Any]:
        """
        将文件内容复制到剪贴板（文本文件直接复制内容，二进制文件复制路径）。

        参数:
            path: 要复制的文件路径。

        返回:
            {"success": bool, "path": str, "message": str}
        """
        if not PYPERCLIP_AVAILABLE:
            return {"success": False, "path": "", "message": "pyperclip 未安装"}
        try:
            p = _ensure_path(path)
            if not p.exists():
                return {"success": False, "path": str(p), "message": "文件不存在"}
            ext = p.suffix.lower()
            text_exts = {".txt", ".md", ".py", ".js", ".ts", ".json", ".xml", ".html", ".css", ".csv", ".yml", ".yaml", ".ini", ".cfg", ".conf", ".log", ".bat", ".sh", ".ps1"}
            if ext in text_exts:
                content = p.read_text(encoding="utf-8", errors="replace")
                pyperclip.copy(content)
                return {"success": True, "path": str(p), "message": f"文件内容已复制到剪贴板（{len(content)} 字符）"}
            else:
                pyperclip.copy(str(p))
                return {"success": True, "path": str(p), "message": f"文件路径已复制到剪贴板: {p}"}
        except Exception as e:
            return {"success": False, "path": str(path), "message": f"复制文件失败: {e}"}

    @staticmethod
    def clear() -> Dict[str, Any]:
        """
        清空剪贴板内容。

        返回:
            {"success": bool, "message": str}
        """
        if not PYPERCLIP_AVAILABLE:
            return {"success": False, "message": "pyperclip 未安装"}
        try:
            pyperclip.copy("")
            return {"success": True, "message": "剪贴板已清空"}
        except Exception as e:
            return {"success": False, "message": f"清空剪贴板失败: {e}"}


# ============================================================================
# 8. AIToolManager - AI Agent 工具管理器（统一注册/调度/安全）
# ============================================================================

class AIToolManager:
    def __init__(self):
        self._tools = {}
        self._browser_tools = None
        self._register_all_tools()

    def _register_all_tools(self):
        tools = [
            ("create_dir", FileSystemTools.create_dir, "创建新目录", {"path": "string"}, "filesystem"),
            ("delete_path", FileSystemTools.delete_path, "删除文件或目录（危险）", {"path": "string", "recursive": "boolean"}, "filesystem"),
            ("move_path", FileSystemTools.move_path, "移动文件或目录", {"src": "string", "dst": "string"}, "filesystem"),
            ("copy_path", FileSystemTools.copy_path, "复制文件或目录", {"src": "string", "dst": "string"}, "filesystem"),
            ("read_file", FileSystemTools.read_file, "读取文件内容", {"path": "string", "encoding": "string", "mode": "string"}, "filesystem"),
            ("write_file", FileSystemTools.write_file, "写入文件", {"path": "string", "content": "string", "encoding": "string"}, "filesystem"),
            ("append_file", FileSystemTools.append_file, "追加到文件末尾", {"path": "string", "content": "string"}, "filesystem"),
            ("search_files", FileSystemTools.search_files, "搜索文件", {"pattern": "string", "root_dir": "string", "max_results": "integer"}, "filesystem"),
            ("get_file_info", FileSystemTools.get_file_info, "获取文件信息", {"path": "string"}, "filesystem"),
            ("compress", FileSystemTools.compress, "压缩文件", {"paths": "array", "output_path": "string", "format": "string"}, "filesystem"),
            ("extract", FileSystemTools.extract, "解压文件", {"archive_path": "string", "output_dir": "string"}, "filesystem"),
            ("run_command", SystemTools.run_command, "运行Shell命令（警告）", {"cmd": "string", "timeout": "integer", "cwd": "string"}, "system"),
            ("get_process_list", SystemTools.get_process_list, "获取进程列表", {}, "system"),
            ("kill_process", SystemTools.kill_process, "终止进程（危险）", {"pid": "integer"}, "system"),
            ("get_system_info", SystemTools.get_system_info, "获取系统信息", {}, "system"),
            ("get_disk_usage", SystemTools.get_disk_usage, "获取磁盘使用情况", {"path": "string"}, "system"),
            ("open_application", SystemTools.open_application, "打开应用程序", {"path": "string"}, "system"),
            ("send_notification", SystemTools.send_notification, "发送系统通知", {"title": "string", "message": "string", "duration": "integer"}, "system"),
            ("mouse_move", ComputerControlTools.mouse_move, "移动鼠标", {"x": "integer", "y": "integer", "duration": "number"}, "computer_control"),
            ("mouse_click", ComputerControlTools.mouse_click, "点击鼠标", {"x": "integer", "y": "integer", "button": "string"}, "computer_control"),
            ("mouse_double_click", ComputerControlTools.mouse_double_click, "双击鼠标", {"x": "integer", "y": "integer"}, "computer_control"),
            ("mouse_drag", ComputerControlTools.mouse_drag, "拖拽鼠标", {"start_x": "integer", "start_y": "integer", "end_x": "integer", "end_y": "integer"}, "computer_control"),
            ("keyboard_type", ComputerControlTools.keyboard_type, "键盘输入文本", {"text": "string", "interval": "number"}, "computer_control"),
            ("keyboard_hotkey", ComputerControlTools.keyboard_hotkey, "组合快捷键", {"keys": "array"}, "computer_control"),
            ("keyboard_press", ComputerControlTools.keyboard_press, "按单个键", {"key": "string"}, "computer_control"),
            ("take_screenshot", ComputerControlTools.take_screenshot, "屏幕截图", {"path": "string"}, "computer_control"),
            ("scroll", ComputerControlTools.scroll, "滚动滚轮", {"direction": "string", "amount": "integer"}, "computer_control"),
            ("create_pptx", OfficeTools.create_pptx, "创建PPT", {"path": "string", "slides_content": "array"}, "office"),
            ("create_xlsx", OfficeTools.create_xlsx, "创建Excel", {"path": "string", "data": "array", "sheet_name": "string"}, "office"),
            ("create_docx", OfficeTools.create_docx, "创建Word文档", {"path": "string", "content": "object"}, "office"),
            ("read_xlsx", OfficeTools.read_xlsx, "读取Excel", {"path": "string", "sheet_name": "string"}, "office"),
            ("read_docx", OfficeTools.read_docx, "读取Word文档", {"path": "string"}, "office"),
            ("edit_xlsx", OfficeTools.edit_xlsx, "编辑Excel", {"path": "string", "data": "array", "sheet_name": "string"}, "office"),
            ("convert_to_pdf", OfficeTools.convert_to_pdf, "转换PDF", {"path": "string", "output_path": "string"}, "office"),
            ("resize_image", ImageTools.resize_image, "调整图片尺寸", {"path": "string", "width": "integer", "height": "integer", "keep_aspect": "boolean"}, "image"),
            ("convert_image_format", ImageTools.convert_format, "转换图片格式", {"path": "string", "new_format": "string"}, "image"),
            ("add_image_filter", ImageTools.add_filter, "图片滤镜", {"path": "string", "filter_type": "string"}, "image"),
            ("ocr_image", ImageTools.ocr_image, "OCR识别", {"path": "string", "lang": "string"}, "image"),
            ("create_collage", ImageTools.create_collage, "创建拼图", {"images_paths": "array", "output_path": "string", "cols": "integer"}, "image"),
            ("clipboard_copy_text", ClipboardTools.copy_text, "复制文本到剪贴板", {"text": "string"}, "clipboard"),
            ("clipboard_paste_text", ClipboardTools.paste_text, "从剪贴板粘贴", {}, "clipboard"),
            ("clipboard_copy_file", ClipboardTools.copy_file, "复制文件到剪贴板", {"path": "string"}, "clipboard"),
            ("clipboard_clear", ClipboardTools.clear, "清空剪贴板", {}, "clipboard"),
        ]
        for name, func, desc, params, cat in tools:
            self._tools[name] = {"name": name, "function": func, "description": desc, "parameters": params, "category": cat, "is_async": False}

        browser_tools = [
            ("browser_navigate", "导航到URL", {"url": "string", "timeout": "integer"}),
            ("browser_click", "点击元素", {"selector": "string", "timeout": "integer"}),
            ("browser_type", "输入文本", {"selector": "string", "text": "string", "delay": "integer"}),
            ("browser_screenshot", "页面截图", {"path": "string", "full_page": "boolean"}),
            ("browser_get_page_content", "获取页面内容", {"format": "string"}),
            ("browser_scroll", "滚动页面", {"direction": "string", "amount": "integer"}),
            ("browser_get_element_text", "获取元素文本", {"selector": "string", "timeout": "integer"}),
            ("browser_fill_form", "填写表单", {"fields": "object"}),
            ("browser_press_key", "按键盘键", {"key": "string"}),
            ("browser_evaluate_js", "执行JS", {"script": "string"}),
            ("browser_close", "关闭浏览器", {}),
        ]
        for name, desc, params in browser_tools:
            self._tools[name] = {"name": name, "function": None, "description": desc, "parameters": params, "category": "browser", "is_async": True}

    def register_tool(self, name, func, description, parameters, category="general", is_async=False):
        self._tools[name] = {"name": name, "function": func, "description": description, "parameters": parameters, "category": category, "is_async": is_async}

    def get_tool_descriptions(self):
        result = []
        for name, info in self._tools.items():
            result.append({"name": name, "description": info["description"], "parameters": info["parameters"], "category": info["category"], "is_async": info["is_async"]})
        return result

    def list_available_tools(self):
        cats = {}
        for name, info in self._tools.items():
            c = info["category"]
            if c not in cats:
                cats[c] = []
            cats[c].append({"name": name, "description": info["description"], "is_async": info["is_async"]})
        return {"success": True, "tools": cats, "total": len(self._tools), "message": f"共有 {len(self._tools)} 个工具，分布在 {len(cats)} 个分类"}

    def security_check(self, action_description):
        ad = action_description.lower()
        for kw in ["delete", "remove", "unlink", "kill", "terminate", "shutdown", "format"]:
            if kw in ad:
                return {"action": action_description, "description": "危险操作，涉及删除/终止", "danger_level": "danger", "requires_confirmation": True}
        for kw in ["run_command", "shell", "exec", "cmd", "write_file", "overwrite", "move"]:
            if kw in ad:
                return {"action": action_description, "description": "警告操作，涉及修改数据", "danger_level": "warning", "requires_confirmation": True}
        for kw in ["read", "list", "get_", "search", "info", "paste"]:
            if kw in ad:
                return {"action": action_description, "description": "安全操作，只读查询", "danger_level": "safe", "requires_confirmation": False}
        return {"action": action_description, "description": "未知风险等级", "danger_level": "info", "requires_confirmation": False}

    async def _execute_browser_tool(self, tool_name, params):
        if self._browser_tools is None:
            self._browser_tools = BrowserTools()
        mm = {
            "browser_navigate": self._browser_tools.navigate,
            "browser_click": self._browser_tools.click,
            "browser_type": self._browser_tools.type,
            "browser_screenshot": self._browser_tools.screenshot,
            "browser_get_page_content": self._browser_tools.get_page_content,
            "browser_scroll": self._browser_tools.scroll,
            "browser_get_element_text": self._browser_tools.get_element_text,
            "browser_fill_form": self._browser_tools.fill_form,
            "browser_press_key": self._browser_tools.press_key,
            "browser_evaluate_js": self._browser_tools.evaluate_js,
            "browser_close": self._browser_tools.close,
        }
        m = mm.get(tool_name)
        if m is None:
            return {"success": False, "message": f"未知浏览器工具: {tool_name}"}
        return await m(**params)

    def execute_tool(self, tool_name, params=None):
        if params is None:
            params = {}
        info = self._tools.get(tool_name)
        if info is None:
            return {"success": False, "message": f"未知工具: {tool_name}"}
        if info.get("is_async"):
            return {"success": False, "message": f"工具 {tool_name} 是异步工具，请使用 execute_tool_async"}
        func = info["function"]
        if func is None:
            return {"success": False, "message": f"工具 {tool_name} 未绑定函数"}
        try:
            import traceback
            sec = self.security_check(tool_name)
            result = func(**params)
            if isinstance(result, dict):
                result["_security"] = sec
            return result
        except TypeError as e:
            return {"success": False, "message": f"参数错误: {e}"}
        except Exception as e:
            return {"success": False, "message": f"工具执行失败: {e}", "traceback": traceback.format_exc()}

    async def execute_tool_async(self, tool_name, params=None):
        if params is None:
            params = {}
        info = self._tools.get(tool_name)
        if info is None:
            return {"success": False, "message": f"未知工具: {tool_name}"}
        if info.get("is_async"):
            return await self._execute_browser_tool(tool_name, params)
        func = info["function"]
        if func is None:
            return {"success": False, "message": f"工具 {tool_name} 未绑定函数"}
        try:
            import traceback
            sec = self.security_check(tool_name)
            if asyncio.iscoroutinefunction(func):
                result = await func(**params)
            else:
                result = func(**params)
            if isinstance(result, dict):
                result["_security"] = sec
            return result
        except TypeError as e:
            return {"success": False, "message": f"参数错误: {e}"}
        except Exception as e:
            return {"success": False, "message": f"工具执行失败: {e}", "traceback": traceback.format_exc()}

    def __getitem__(self, name):
        info = self._tools.get(name)
        return info["function"] if info else None

    def __contains__(self, name):
        return name in self._tools

    def __len__(self):
        return len(self._tools)

    def __repr__(self):
        return f"AIToolManager({len(self._tools)} tools)"


_manager = None


def _get_manager():
    global _manager
    if _manager is None:
        _manager = AIToolManager()
    return _manager


all_tools = {
    "create_dir": FileSystemTools.create_dir,
    "delete_path": FileSystemTools.delete_path,
    "move_path": FileSystemTools.move_path,
    "copy_path": FileSystemTools.copy_path,
    "read_file": FileSystemTools.read_file,
    "write_file": FileSystemTools.write_file,
    "append_file": FileSystemTools.append_file,
    "search_files": FileSystemTools.search_files,
    "get_file_info": FileSystemTools.get_file_info,
    "compress": FileSystemTools.compress,
    "extract": FileSystemTools.extract,
    "run_command": SystemTools.run_command,
    "get_process_list": SystemTools.get_process_list,
    "kill_process": SystemTools.kill_process,
    "get_system_info": SystemTools.get_system_info,
    "get_disk_usage": SystemTools.get_disk_usage,
    "open_application": SystemTools.open_application,
    "send_notification": SystemTools.send_notification,
    "mouse_move": ComputerControlTools.mouse_move,
    "mouse_click": ComputerControlTools.mouse_click,
    "mouse_double_click": ComputerControlTools.mouse_double_click,
    "mouse_drag": ComputerControlTools.mouse_drag,
    "keyboard_type": ComputerControlTools.keyboard_type,
    "keyboard_hotkey": ComputerControlTools.keyboard_hotkey,
    "keyboard_press": ComputerControlTools.keyboard_press,
    "take_screenshot": ComputerControlTools.take_screenshot,
    "scroll": ComputerControlTools.scroll,
    "create_pptx": OfficeTools.create_pptx,
    "create_xlsx": OfficeTools.create_xlsx,
    "create_docx": OfficeTools.create_docx,
    "read_xlsx": OfficeTools.read_xlsx,
    "read_docx": OfficeTools.read_docx,
    "edit_xlsx": OfficeTools.edit_xlsx,
    "convert_to_pdf": OfficeTools.convert_to_pdf,
    "resize_image": ImageTools.resize_image,
    "convert_image_format": ImageTools.convert_format,
    "add_image_filter": ImageTools.add_filter,
    "ocr_image": ImageTools.ocr_image,
    "create_collage": ImageTools.create_collage,
    "clipboard_copy_text": ClipboardTools.copy_text,
    "clipboard_paste_text": ClipboardTools.paste_text,
    "clipboard_copy_file": ClipboardTools.copy_file,
    "clipboard_clear": ClipboardTools.clear,
}


def execute_tool(name, params=None):
    return _get_manager().execute_tool(name, params)


def list_tools():
    return _get_manager().list_available_tools()


def get_tool_schemas():
    return _get_manager().get_tool_descriptions()
