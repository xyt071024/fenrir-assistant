from .ai_engine import AIEngine, MemorySystem, AgentOrchestrator
from .tools import AIToolManager, execute_tool, list_tools, get_tool_schemas, all_tools
from .api_manager import APIManager
from .日志管理器 import LogManager, get_logger
from .桌宠引擎 import DeskPet

__all__ = [
    'AIEngine', 'MemorySystem', 'AgentOrchestrator',
    'AIToolManager', 'execute_tool', 'list_tools', 'get_tool_schemas', 'all_tools',
    'APIManager', 'LogManager', 'get_logger', 'DeskPet',
    'create_agent'
]


def create_agent(config_path=None, api_manager=None, logger=None, desk_pet=None):
    import os
    engine = AIEngine(config_path)
    mem_dir = os.path.join(os.path.dirname(config_path or '.'), 'memories')
    os.makedirs(mem_dir, exist_ok=True)
    mem_path = os.path.join(mem_dir, 'memories.json')
    memory = MemorySystem(mem_path)
    tool_mgr = AIToolManager()
    orchestrator = AgentOrchestrator(engine, tool_mgr, memory)
    result = {
        'engine': engine,
        'memory': memory,
        'tools': tool_mgr,
        'orchestrator': orchestrator,
        'api_manager': api_manager or APIManager(),
        'logger': logger or get_logger('agent'),
        'desk_pet': desk_pet,
    }
    result['logger'].info('Agent created, system ready')
    return result
