TOOL_RSYNC = {
    "name": "rsync",
    "display_name": "rsync同步备份",
    "description": "基于rsync的高效文件同步工具，支持增量备份、差异同步和远程备份，广泛用于服务器和本地数据同步",
    "category": "备份恢复",
    "scenarios": ["本地文件夹定时增量备份到外置硬盘", "服务器数据远程同步到备份机", "大规模文件迁移时断点续传"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "中等",
    "requires_network": False,
    "usage_tips": "使用--delete参数可同步删除操作，--link-dest支持硬链接增量备份节省空间",
    "github_stars": 0,
    "open_source": True,
    "download_command": "winget install rsync",
    "fallback": ["rclone"]
}

TOOL_RCLONE = {
    "name": "rclone",
    "display_name": "rclone云端同步",
    "description": "强大的云存储同步工具，支持40多种云存储服务双向同步、加密传输和挂载操作，GitHub 73K星标",
    "category": "备份恢复",
    "scenarios": ["本地文件备份到Google Drive/OneDrive等云端", "不同云盘之间数据迁移", "云存储挂载为本地磁盘使用"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": True,
    "usage_tips": "首次使用需运行rclone config配置云存储，支持crypt远程加密后再上传",
    "github_stars": 73000,
    "open_source": True,
    "download_command": "winget install Rclone.Rclone",
    "fallback": ["rsync", "s3cmd"]
}

TOOL_DUPLICATI = {
    "name": "duplicati",
    "display_name": "Duplicati加密备份",
    "description": "开源的加密增量备份工具，支持AES-256加密备份到本地、网络和云存储，提供Web管理界面",
    "category": "备份恢复",
    "scenarios": ["重要文件加密后备份到云端", "家庭服务器定期自动备份", "需要Web界面管理备份任务的场景"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["duplicity"],
    "safety_level": "安全",
    "requires_network": True,
    "usage_tips": "备份集需保留加密密钥，丢失后将无法恢复数据",
    "github_stars": 11000,
    "open_source": True,
    "download_command": "winget install Duplicati.Duplicati",
    "fallback": ["duplicity", "restic"]
}

TOOL_BORGBACKUP = {
    "name": "borgbackup",
    "display_name": "BorgBackup去重备份",
    "description": "高性能去重备份工具，支持分块级重复数据删除、压缩和加密，备份空间利用率极高",
    "category": "备份恢复",
    "scenarios": ["大量相似数据的备份去重节省空间", "服务器系统定期批量备份", "需要快速增量备份的长期归档"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["attic"],
    "safety_level": "中等",
    "requires_network": False,
    "usage_tips": "使用创建归档功能实现版本管理，prune命令自动清理过期备份",
    "github_stars": 11000,
    "open_source": True,
    "download_command": "winget install BorgBackup",
    "fallback": ["restic", "kopia"]
}

TOOL_RESTIC = {
    "name": "restic",
    "display_name": "Restic加密备份",
    "description": "快速安全的开源备份工具，支持多平台、多存储后端，内置AES-256-GCM加密和重复数据删除",
    "category": "备份恢复",
    "scenarios": ["个人重要文档加密备份", "开发环境配置快照备份", "多平台统一备份方案"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["kopia"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "支持forget策略自动管理备份保留期限，init初始化仓库后即可使用",
    "github_stars": 27000,
    "open_source": True,
    "download_command": "winget install restic",
    "fallback": ["borgbackup", "kopia"]
}

TOOL_KOPIA = {
    "name": "kopia",
    "display_name": "Kopia快照备份",
    "description": "现代快照备份工具，支持内容寻址存储、压缩去重、端到端加密和图形界面操作",
    "category": "备份恢复",
    "scenarios": ["桌面系统快照备份", "Docker容器数据备份", "需要图形界面管理备份的场景"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["restic"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "内置Web UI管理界面，policy设置自动清理规则",
    "github_stars": 20000,
    "open_source": True,
    "download_command": "winget install Kopia.Kopia",
    "fallback": ["restic", "borgbackup"]
}

TOOL_DUPLICITY = {
    "name": "duplicity",
    "display_name": "Duplicity加密备份",
    "description": "传统加密备份工具，支持GPG加密和增量备份，通过librsync实现带宽高效传输",
    "category": "备份恢复",
    "scenarios": ["Linux服务器的GPG加密备份", "带宽受限环境下的远程增量备份", "使用FTP或SSH协议备份到远程主机"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["duplicati", "deja-dup"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "Deja-Dup底层就是Duplicity，使用GPG密钥管理加密",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install duplicity",
    "fallback": ["duplicati", "deja-dup"]
}

TOOL_DEJA_DUP = {
    "name": "deja-dup",
    "display_name": "Deja-Dup简化备份",
    "description": "基于Duplicity的简化备份工具，提供友好的图形界面，一键配置定期自动备份",
    "category": "备份恢复",
    "scenarios": ["Linux桌面用户简化备份操作", "个人文件的定期自动备份", "不需要命令行操作的家庭用户"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["duplicity"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "支持选择备份周期和保留策略，自动处理增量备份",
    "github_stars": 0,
    "open_source": True,
    "download_command": "winget install deja-dup",
    "fallback": ["duplicity", "timeshift"]
}

TOOL_TIMESHIFT = {
    "name": "timeshift",
    "display_name": "Timeshift系统快照",
    "description": "系统快照工具，类似Windows系统还原，使用rsync或Btrfs快照方式备份和恢复系统状态",
    "category": "备份恢复",
    "scenarios": ["系统更新前创建还原点", "系统崩溃后快速恢复到正常状态", "Btrfs文件系统的快照管理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["back-in-time"],
    "safety_level": "中等",
    "requires_network": False,
    "usage_tips": "建议每周创建一次快照，系统大更新前务必手动创建",
    "github_stars": 0,
    "open_source": True,
    "download_command": "winget install timeshift",
    "fallback": ["back-in-time", "deja-dup"]
}

TOOL_BACK_IN_TIME = {
    "name": "back-in-time",
    "display_name": "Back In Time备份",
    "description": "Linux系统下的简单备份工具，基于rsync实现快照式备份，自动管理备份版本",
    "category": "备份恢复",
    "scenarios": ["Linux桌面用户的文件快照备份", "按时间线管理历史版本", "排除特定文件或目录的精确备份"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["timeshift"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "使用快照浏览器可以轻松找到和恢复历史版本文件",
    "github_stars": 0,
    "open_source": True,
    "download_command": "apt install backintime",
    "fallback": ["timeshift", "deja-dup"]
}

TOOL_URBACKUP = {
    "name": "urbackup",
    "display_name": "UrBackup企业备份",
    "description": "企业级客户端-服务器备份系统，支持Windows/Linux的全量和增量备份，提供Web管理控制台",
    "category": "备份恢复",
    "scenarios": ["企业内部多台电脑集中备份管理", "混合操作系统环境的统一备份", "需要文件级和镜像级双模式备份"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["veeam-agent"],
    "safety_level": "安全",
    "requires_network": True,
    "usage_tips": "客户端自动发现内网服务器，支持备份速度限制防止影响正常业务",
    "github_stars": 0,
    "open_source": True,
    "download_command": "winget install UrBackup",
    "fallback": ["veeam-agent"]
}

TOOL_VEEAM_AGENT = {
    "name": "veeam-agent",
    "display_name": "Veeam Agent备份",
    "description": "Veeam推出的免费备份代理工具，支持Windows和Linux系统的整机备份和文件级恢复",
    "category": "备份恢复",
    "scenarios": ["Windows整机系统镜像备份", "物理服务器迁移到虚拟化平台", "需要可靠免费备份方案的个人用户"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["urbackup"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "支持备份到NAS、共享文件夹或Veeam备份仓库",
    "github_stars": 0,
    "open_source": False,
    "download_command": "winget install Veeam.VeeamAgent",
    "fallback": ["urbackup", "timeshift"]
}

TOOL_S3CMD = {
    "name": "s3cmd",
    "display_name": "s3cmd S3备份",
    "description": "Amazon S3兼容的命令行工具，支持S3对象存储的上传、下载、同步和批量管理",
    "category": "备份恢复",
    "scenarios": ["数据备份到AWS S3或兼容存储", "S3存储桶之间数据迁移", "MinIO等私有对象存储管理"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["rclone"],
    "safety_level": "安全",
    "requires_network": True,
    "usage_tips": "配置时需提供Access Key和Secret Key，支持--exclude和--include过滤文件",
    "github_stars": 4700,
    "open_source": True,
    "download_command": "pip install s3cmd",
    "fallback": ["rclone"]
}

TOOL_DUPLICACY = {
    "name": "duplicacy",
    "display_name": "Duplicacy商业备份",
    "description": "跨平台加密去重备份工具，采用独特的分块算法，支持多种云存储和本地备份",
    "category": "备份恢复",
    "scenarios": ["需要商业授权的企业备份场景", "跨多台机器的数据去重备份", "大型项目源代码和资产的版本化备份"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["duplicati"],
    "safety_level": "安全",
    "requires_network": True,
    "usage_tips": "免费版本只能用于个人用途，商业使用需购买授权",
    "github_stars": 0,
    "open_source": False,
    "download_command": "winget install Duplicacy",
    "fallback": ["duplicati", "restic"]
}

TOOL_ATTIC = {
    "name": "attic",
    "display_name": "Attic旧版备份",
    "description": "BorgBackup的前身去重备份工具，支持数据去重、压缩和SSH远程备份，适合旧系统兼容场景",
    "category": "备份恢复",
    "scenarios": ["旧版Linux系统的兼容备份", "需要轻量级去重备份的场景", "从Borg迁移前的过渡备份方案"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["borgbackup"],
    "safety_level": "中等",
    "requires_network": False,
    "usage_tips": "该项目已不再维护，建议升级到BorgBackup获得更好的性能和功能",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install attic",
    "fallback": ["borgbackup", "restic"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
