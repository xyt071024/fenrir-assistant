TOOL_laws_parser = {
    "name": "laws_parser", "display_name": "法规解析", "category": "法律咨询",
    "description": "对中国法律法规条文进行结构化解析，支持章节条款拆分、生效状态标注和跨法规关联引用。",
    "scenarios": ["法规条文检索", "法律条款比对", "新旧法规对比", "法规体系梳理"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "建议优先使用国家法律法规数据库。注意区分法律、行政法规、地方性法规和部门规章的效力层级。",
    "github_stars": 1800, "open_source": True,
    "download_command": "pip install laws-parser",
    "fallback": ["legal_qa"]
}

TOOL_judgment_analyzer = {
    "name": "judgment_analyzer", "display_name": "判决分析", "category": "法律咨询",
    "description": "对中国裁判文书网等公开判决书进行结构化提取和分析，包括案由、当事人、争议焦点、裁判理由和判决结果。",
    "scenarios": ["判决书批量解析", "同案同判分析", "法官裁判倾向研究", "胜诉率统计"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["case_similar"],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "裁判文书网反爬策略严格，建议使用官方 API 或已授权的第三方数据服务。注意隐去当事人敏感信息。",
    "github_stars": 2200, "open_source": True,
    "download_command": "pip install judgment-parser",
    "fallback": ["case_similar", "legal_qa"]
}

TOOL_contract_checker = {
    "name": "contract_checker", "display_name": "合同审核", "category": "法律咨询",
    "description": "基于法律规则库和 NLP 模型对合同文本进行风险条款识别、缺失要素检测和合规性评估。",
    "scenarios": ["劳动合同审核", "商务合同风险排查", "租赁合同检查", "保密协议审查"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "high", "requires_network": False,
    "usage_tips": "合同审核结果仅供参考，重大合同建议由执业律师最终确认。重点关注违约责任、争议解决和免责条款。",
    "github_stars": 3100, "open_source": True,
    "download_command": "pip install contract-checker",
    "fallback": ["legal_doc", "legal_qa"]
}

TOOL_legal_doc = {
    "name": "legal_doc", "display_name": "法律文书", "category": "法律咨询",
    "description": "根据案件信息和诉讼请求自动生成起诉状、答辩状、上诉状、申请书等标准化法律文书模板。",
    "scenarios": ["起诉状自动生成", "律师函起草", "执行申请书制作", "仲裁申请书编写"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "high", "requires_network": False,
    "usage_tips": "文书模板需结合当地法院的具体要求调整。关键事实和诉讼请求务必由使用者核实确认。",
    "github_stars": 1600, "open_source": True,
    "download_command": "pip install legal-doc-generator",
    "fallback": ["contract_checker", "legal_qa"]
}

TOOL_patent_search = {
    "name": "patent_search", "display_name": "专利搜索", "category": "法律咨询",
    "description": "对接中国国家知识产权局（CNIPA）、WIPO 等专利数据库，支持专利全文检索、分类筛选和引用分析。",
    "scenarios": ["专利新颖性检索", "竞争对手专利监控", "专利无效证据查找", "技术领域专利地图"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": [],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "建议使用 IPC 或 CPC 分类号辅助检索以提高查全率。PCT 申请可通过 WIPO Patentscope 查询。",
    "github_stars": 1400, "open_source": True,
    "download_command": "pip install patent-search-tool",
    "fallback": ["trademark_query"]
}

TOOL_trademark_query = {
    "name": "trademark_query", "display_name": "商标查询", "category": "法律咨询",
    "description": "查询中国商标网及马德里国际商标注册信息，支持商标名称近似检索、类别筛选和法律状态跟踪。",
    "scenarios": ["商标注册可行性查询", "近似商标排查", "商标异议证据准备", "商标续展提醒"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "商标查询存在3-6个月盲查期，查询结果不能完全保证注册成功率。建议同时查询文字和图形要素。",
    "github_stars": 900, "open_source": True,
    "download_command": "pip install trademark-query",
    "fallback": ["patent_search"]
}

TOOL_case_similar = {
    "name": "case_similar", "display_name": "案例相似", "category": "法律咨询",
    "description": "基于自然语言处理和案例要素匹配算法，在海量裁判文书中检索与当前案件最相似的历史判例。",
    "scenarios": ["类案检索与推送", "裁判结果预测", "代理策略参考", "上诉可行性评估"],
    "accuracy": 3, "efficiency": 4, "speed": 3,
    "conflicts_with": ["judgment_analyzer"],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "类案检索关键词应覆盖案由、争议焦点和关键事实要素。参考案例优先选择同法院同法官的判决。",
    "github_stars": 1100, "open_source": True,
    "download_command": "pip install case-similarity",
    "fallback": ["judgment_analyzer"]
}

TOOL_regulation_update = {
    "name": "regulation_update", "display_name": "法规更新", "category": "法律咨询",
    "description": "实时监控中国政府各层级法律法规的颁布、修改和废止动态，自动生成法规变更影响分析报告。",
    "scenarios": ["新法速递推送", "行业法规监控", "法规变更合规评估", "立法动态跟踪"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "重点关注全国人大及其常委会的立法动态。行政法规和部门规章可通过司法部官网查询。",
    "github_stars": 700, "open_source": True,
    "download_command": "pip install regulation-watcher",
    "fallback": ["laws_parser", "legal_qa"]
}

TOOL_legal_qa = {
    "name": "legal_qa", "display_name": "法律问答", "category": "法律咨询",
    "description": "基于大语言模型和法律知识图谱，对用户提出的法律问题进行智能解答，覆盖民事、刑事、行政等主要法律领域。",
    "scenarios": ["日常法律咨询", "法律法规解读", "诉讼流程指引", "权利与义务说明"],
    "accuracy": 3, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "AI 法律问答不具备法律约束力，涉及重大权益的问题建议咨询执业律师。回答应注明法律依据。",
    "github_stars": 2500, "open_source": True,
    "download_command": "pip install legal-qa-bot",
    "fallback": ["laws_parser"]
}

TOOL_risk_assessment = {
    "name": "risk_assessment", "display_name": "风险评估", "category": "法律咨询",
    "description": "综合评估企业在合同履行、知识产权、劳动用工、数据合规等领域的法律风险等级，输出风险矩阵和整改建议。",
    "scenarios": ["企业法律风险体检", "投资并购法律尽调", "数据合规风险评估", "劳动用工合规审查"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": [],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "风险评估应覆盖行政、民事和刑事三个维度的法律责任。建议每年至少进行一次全面法律风险体检。",
    "github_stars": 1300, "open_source": True,
    "download_command": "pip install legal-risk-assessment",
    "fallback": ["legal_qa", "contract_checker"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}