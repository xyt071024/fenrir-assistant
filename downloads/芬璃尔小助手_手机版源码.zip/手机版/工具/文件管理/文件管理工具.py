TOOL_LOCAL_FILE_ORGANIZER = {
    "name": "local_file_organizer",
    "display_name": "Local-File-Organizer AI分类",
    "description": "基于AI的文件自动分类整理工具，支持按文件类型、日期、自定义规则自动归类，3.2K Stars，智能识别文件内容",
    "category": "文件管理/自动整理",
    "scenarios": ["下载文件夹整理", "桌面文件清理", "照片按日期归类", "项目文件归档"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["手动文件整理流程"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配置规则文件后一键运行，支持预览模式和实际执行模式，先预览再执行避免误操作",
    "github_stars": 3200,
    "open_source": True,
    "download_command": "pip install local-file-organizer",
    "fallback": ["手动整理", "dupeGuru"]
}

TOOL_WATCHDOG = {
    "name": "watchdog",
    "display_name": "watchdog 文件监控",
    "description": "跨平台文件系统事件监控库，实时监控文件创建、修改、删除、移动等事件，支持递归监控和事件过滤",
    "category": "文件管理/实时监控",
    "scenarios": ["自动同步工具", "文件变更触发任务", "热重载开发", "日志文件监控", "备份触发"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["os.stat轮询方案"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "继承FileSystemEventHandler类重写on_modified等方法，observer.start()启动监控",
    "github_stars": 7000,
    "open_source": True,
    "download_command": "pip install watchdog",
    "fallback": ["os.path.getmtime轮询", "inotify"]
}

TOOL_PATHLIB = {
    "name": "pathlib",
    "display_name": "pathlib 路径操作",
    "description": "Python标准库面向对象文件路径操作模块，Path对象封装路径解析、遍历、读写等操作，替代os.path",
    "category": "文件管理/路径处理",
    "scenarios": ["跨平台路径处理", "文件批量操作", "目录树遍历", "路径匹配与过滤"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["os.path", "os模块"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Path('dir') / 'file.txt' 用/拼接路径，.glob('**/*.py')递归匹配，Python 3.4+内置",
    "github_stars": 0,
    "open_source": True,
    "download_command": "Python标准库，无需安装",
    "fallback": ["os.path", "os模块"]
}

TOOL_SHUTIL = {
    "name": "shutil",
    "display_name": "shutil 文件操作",
    "description": "Python标准库高级文件操作模块，提供文件复制、移动、删除、归档等高级接口，支持目录递归操作",
    "category": "文件管理/基础操作",
    "scenarios": ["文件批量复制移动", "目录递归删除", "文件归档打包", "临时文件操作", "磁盘使用统计"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["os.rename/os.remove", "send2trash"],
    "safety_level": "warning",
    "requires_network": False,
    "usage_tips": "shutil.rmtree()永久删除不可恢复，shutil.move()跨磁盘移动文件，Python标准库内置",
    "github_stars": 0,
    "open_source": True,
    "download_command": "Python标准库，无需安装",
    "fallback": ["os模块", "send2trash"]
}

TOOL_SEND2TRASH = {
    "name": "send2trash",
    "display_name": "send2trash 回收站",
    "description": "安全删除文件到系统回收站而非永久删除，支持Windows/macOS/Linux，可恢复误删文件",
    "category": "文件管理/安全删除",
    "scenarios": ["文件管理器删除功能", "回收站机制集成", "安全删除脚本", "批量文件清理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["shutil.rmtree", "os.remove"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "send2trash.send2trash('file.txt') 替代os.remove()，文件进入回收站而非永久删除",
    "github_stars": 600,
    "open_source": True,
    "download_command": "pip install send2trash",
    "fallback": ["shutil", "trash-cli"]
}

TOOL_FILETYPE = {
    "name": "filetype",
    "display_name": "filetype 文件类型检测",
    "description": "基于文件魔数（magic bytes）检测文件类型，不依赖文件扩展名，支持图片、视频、音频、文档等常见格式",
    "category": "文件管理/类型识别",
    "scenarios": ["文件上传类型校验", "扩展名修复", "批量文件分类", "未知文件识别"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["python-magic", "mimetypes"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "filetype.guess('file.bin')返回类型对象，filetype.is_image()快速判断是否为图片",
    "github_stars": 1500,
    "open_source": True,
    "download_command": "pip install filetype",
    "fallback": ["python-magic", "mimetypes"]
}

TOOL_PATOOL = {
    "name": "patool",
    "display_name": "patool 压缩包管理",
    "description": "通用压缩包管理工具，统一命令行接口操作7z/zip/rar/tar/gz/bz2等20+种压缩格式，自动选择系统压缩工具",
    "category": "文件管理/压缩解压",
    "scenarios": ["多格式压缩解压", "批量压缩处理", "压缩包格式转换", "自动化打包流程"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["py7zr", "zipfile", "rarfile"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "patoolib.extract_archive('file.rar', outdir='./') 自动选择合适解压工具",
    "github_stars": 1200,
    "open_source": True,
    "download_command": "pip install patool",
    "fallback": ["py7zr", "zipfile", "rarfile"]
}

TOOL_PY7ZR = {
    "name": "py7zr",
    "display_name": "py7zr 7zip",
    "description": "纯Python实现的7z压缩解压库，无需外部依赖，支持7z格式的全部特性（分卷压缩、加密、固实压缩）",
    "category": "文件管理/7z压缩",
    "scenarios": ["7z格式压缩解压", "分卷压缩文件处理", "加密压缩包", "高压缩比归档"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["patool", "py7zr命令行"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "with py7zr.SevenZipFile('archive.7z', 'r') as z: z.extractall()",
    "github_stars": 1100,
    "open_source": True,
    "download_command": "pip install py7zr",
    "fallback": ["patool", "zipfile"]
}

TOOL_ZIPFILE_ZIP = {
    "name": "zipfile_zip",
    "display_name": "zipfile ZIP",
    "description": "Python标准库ZIP压缩文件处理模块，支持读写ZIP文件，支持加密、分卷、ZIP64扩展格式",
    "category": "文件管理/ZIP压缩",
    "scenarios": ["ZIP格式打包解包", "ZIP文件内容查看", "内存中压缩数据", "多文件归档"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["py7zr", "patool"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "ZipFile('a.zip', 'w')写入文件，支持with语句自动关闭，Python标准库内置",
    "github_stars": 0,
    "open_source": True,
    "download_command": "Python标准库，无需安装",
    "fallback": ["py7zr", "shutil"]
}

TOOL_TARFILE_TAR = {
    "name": "tarfile_tar",
    "display_name": "tarfile TAR",
    "description": "Python标准库TAR归档文件处理模块，支持tar/gz/bz2/xz等压缩格式，保留Unix文件权限和元数据",
    "category": "文件管理/TAR压缩",
    "scenarios": ["Linux归档文件处理", "备份打包", "源码发布包", "服务器日志归档"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["zipfile", "py7zr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "tarfile.open('archive.tar.gz', 'r:gz')自动检测压缩格式，Python标准库内置",
    "github_stars": 0,
    "open_source": True,
    "download_command": "Python标准库，无需安装",
    "fallback": ["zipfile", "py7zr"]
}

TOOL_RARFILE_RAR = {
    "name": "rarfile_rar",
    "display_name": "rarfile RAR",
    "description": "RAR压缩文件处理库，支持RAR格式的解压、测试和列表查看，需要安装WinRAR或unrar",
    "category": "文件管理/RAR压缩",
    "scenarios": ["RAR文件解压", "RAR压缩包内容查看", "加密RAR文件处理", "RAR分卷解压"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["patool", "py7zr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需安装unrar工具或配置rarfile.UNRAR_TOOL路径，RarFile('file.rar').extractall()",
    "github_stars": 800,
    "open_source": True,
    "download_command": "pip install rarfile",
    "fallback": ["patool", "py7zr"]
}

TOOL_PYUNPACK = {
    "name": "pyunpack",
    "display_name": "pyunpack 解压",
    "description": "通用解压库，自动识别压缩格式并选择合适的后端解压工具，支持zip/tar/rar/7z等多种格式",
    "category": "文件管理/通用解压",
    "scenarios": ["自动格式识别解压", "批量解压工具", "文件上传解压预处理"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["patool", "各格式专用库"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Archive('file.unknown').extractall('output/') 自动识别格式，依赖对应的后端库",
    "github_stars": 400,
    "open_source": True,
    "download_command": "pip install pyunpack",
    "fallback": ["patool", "zipfile"]
}

TOOL_DISKCACHE = {
    "name": "diskcache",
    "display_name": "diskcache 磁盘缓存",
    "description": "高性能磁盘缓存库，支持Django/Flask风格API，比内存缓存更大容量，支持TTL过期、事务和持久化",
    "category": "文件管理/缓存存储",
    "scenarios": ["大数据量缓存", "API响应缓存", "计算结果持久化", "文件元数据缓存"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["redis", "memcached"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Cache('cache_dir')创建缓存，支持decorator方式缓存函数结果，比shelve更高效",
    "github_stars": 900,
    "open_source": True,
    "download_command": "pip install diskcache",
    "fallback": ["shelve", "pickle"]
}

TOOL_DUPEGURU = {
    "name": "dupeguru",
    "display_name": "dupeGuru 重复文件",
    "description": "跨平台重复文件查找工具，支持文件名、大小、内容哈希（MD5/SHA1）多种比对模式，可处理图片相似度",
    "category": "文件管理/重复检测",
    "scenarios": ["磁盘空间清理", "照片重复查找", "音乐重复文件整理", "文档重复检测"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["手动查找重复文件"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "dupeGuru有标准版、音乐版、图片版三个变体，GUI和命令行双模式",
    "github_stars": 6500,
    "open_source": True,
    "download_command": "pip install dupeguru",
    "fallback": ["hashlib手动计算", "fdupes"]
}

TOOL_TRASH_CLI = {
    "name": "trash_cli",
    "display_name": "trash-cli 命令行回收站",
    "description": "命令行回收站工具集，提供trash-put/trash-list/trash-restore/trash-empty等命令，替代rm命令",
    "category": "文件管理/命令行回收站",
    "scenarios": ["命令行安全删除", "回收站查看与恢复", "定时清理回收站", "CI/CD文件清理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["rm命令", "send2trash"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "trash-put file.txt 替代rm删除，trash-list查看回收站，trash-restore交互恢复",
    "github_stars": 3500,
    "open_source": True,
    "download_command": "pip install trash-cli",
    "fallback": ["send2trash", "shutil"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}