TOOL_genanki = {
    "name": "genanki",
    "display_name": "genanki",
    "description": "Anki记忆卡片生成库，支持编程式创建Anki牌组/卡片/模板并导出apkg文件",
    "category": "记忆学习",
    "scenarios": ["Anki卡片批量生成", "间隔重复学习", "自定义牌组创建"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["flashcard-maker"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持自定义卡片模板和媒体资源嵌入，适合批量制作学习卡片",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install genanki",
    "fallback": ["flashcard-maker"]
}

TOOL_py_fsrs = {
    "name": "py-fsrs",
    "display_name": "py-fsrs",
    "description": "FSRS(Free Spaced Repetition Scheduler)间隔重复算法Python实现",
    "category": "记忆学习",
    "scenarios": ["间隔重复算法", "学习排程优化", "记忆曲线模拟"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "下一代间隔重复算法，比传统SM-2算法更高效",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install py-fsrs",
    "fallback": []
}

TOOL_SkillAnything = {
    "name": "Skill-Anything",
    "display_name": "Skill-Anything",
    "description": "AI驱动的学习包生成工具，将任意知识转化为结构化学习内容",
    "category": "学习生成",
    "scenarios": ["学习包生成", "知识结构化工", "AI辅助学习"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "适合将复杂知识转化为系统化的学习材料",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install skill-anything",
    "fallback": ["notebook-generator"]
}

TOOL_LibreLingo = {
    "name": "LibreLingo",
    "display_name": "LibreLingo",
    "description": "开源语言学习平台，支持多语言课程创建和学习",
    "category": "语言学习",
    "scenarios": ["语言学习", "外语教学", "自定义语言课程"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "开源免费的语言学习替代方案，支持创建自定义课程",
    "github_stars": 2600,
    "open_source": True,
    "download_command": "pip install libRElingo",
    "fallback": []
}

TOOL_quiz_generator = {
    "name": "quiz-generator",
    "display_name": "quiz-generator",
    "description": "测验题目自动生成工具，支持选择题/判断题/填空题等多种题型",
    "category": "测验生成",
    "scenarios": ["自动出题", "知识点测试", "考试练习生成"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["quizdown"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "可配合教材内容自动生成测验题目，减轻教师出题负担",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install quiz-generator",
    "fallback": ["quizdown"]
}

TOOL_flashcard_maker = {
    "name": "flashcard-maker",
    "display_name": "flashcard-maker",
    "description": "闪卡制作工具，支持从文本/Markdown/CSV等格式批量生成学习闪卡",
    "category": "记忆学习",
    "scenarios": ["闪卡制作", "知识点记忆", "考试复习"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["genanki"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "轻量级闪卡工具，适合快速从笔记生成复习卡片",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install flashcard-maker",
    "fallback": ["genanki"]
}

TOOL_text_to_speech = {
    "name": "text-to-speech",
    "display_name": "text-to-speech",
    "description": "文字转语音工具，支持多语言朗读，适合语言学习和听力训练",
    "category": "语音学习",
    "scenarios": ["听力训练", "发音学习", "有声内容生成"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "结合间隔重复工具使用，提升语言学习效果",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install text-to-speech",
    "fallback": ["gTTS"]
}

TOOL_py_dictionary = {
    "name": "py-dictionary",
    "display_name": "py-dictionary",
    "description": "Python字典查询工具，支持单词释义/音标/例句/同反义词查询",
    "category": "语言学习",
    "scenarios": ["单词查询", "词典查阅", "词汇学习"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "支持离线词典库，适合集成到学习工具中",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install py-dictionary",
    "fallback": []
}

TOOL_word_cloud = {
    "name": "word-cloud",
    "display_name": "word-cloud",
    "description": "词云生成工具，从文本中提取高频词并生成可视化词云图",
    "category": "可视化学习",
    "scenarios": ["词云生成", "关键词提取", "文本可视化"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持自定义形状和颜色，适合学习材料的可视化总结",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install wordcloud",
    "fallback": []
}

TOOL_math_generator = {
    "name": "math-generator",
    "display_name": "math-generator",
    "description": "数学题目自动生成器，支持四则运算/代数/几何等各类型数学题",
    "category": "数学学习",
    "scenarios": ["数学出题", "练习题生成", "数学教学辅助"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "可设置难度等级和题目类型，适合K12数学教学",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install math-generator",
    "fallback": []
}

TOOL_grammar_check = {
    "name": "grammar-check",
    "display_name": "grammar-check",
    "description": "语法检查工具，支持英语等多语言的拼写/语法/标点错误检测",
    "category": "语言学习",
    "scenarios": ["语法检查", "写作辅助", "语言纠错"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "可集成到写作流程中，提升语言学习者的写作质量",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install grammar-check",
    "fallback": ["language-tool-python"]
}

TOOL_transliterate = {
    "name": "transliterate",
    "display_name": "transliterate",
    "description": "音译转写工具，支持多种文字系统间的音译转换(如中文拼音/日文罗马字)",
    "category": "语言学习",
    "scenarios": ["音译转换", "拼音标注", "跨语言转写"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["pinyin-jyutping"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持多种语言的音译规则，适合语言对比学习",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install transliterate",
    "fallback": ["pinyin-jyutping"]
}

TOOL_pinyin_jyutping = {
    "name": "pinyin-jyutping",
    "display_name": "pinyin-jyutping",
    "description": "中文拼音和粤语拼音注音工具，支持汉字转拼音/粤拼标注",
    "category": "语言学习",
    "scenarios": ["拼音标注", "粤拼转换", "中文发音学习"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["transliterate"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "学习中文发音和粤语的实用工具，支持声调标注",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pinyin-jyutping",
    "fallback": ["transliterate"]
}

TOOL_hanzi_character = {
    "name": "hanzi-character",
    "display_name": "hanzi-character",
    "description": "汉字学习工具，提供汉字笔画/部首/释义/笔顺等学习信息",
    "category": "语言学习",
    "scenarios": ["汉字学习", "笔画查询", "部首检索"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "内置常用汉字数据库，适合汉语教学和自学",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install hanzi-character",
    "fallback": []
}

TOOL_vocabulary_builder = {
    "name": "vocabulary-builder",
    "display_name": "vocabulary-builder",
    "description": "词汇构建工具，通过上下文/词根/联想等方法帮助扩大词汇量",
    "category": "语言学习",
    "scenarios": ["词汇积累", "单词学习", "词汇量扩展"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "结合间隔重复算法使用效果更佳",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install vocabulary-builder",
    "fallback": ["flashcard-maker"]
}

TOOL_quizdown = {
    "name": "quizdown",
    "display_name": "quizdown",
    "description": "Markdown格式的测验生成工具，用Markdown编写题目并渲染为交互式测验",
    "category": "测验生成",
    "scenarios": ["Markdown测验", "交互式题目", "文档嵌入测验"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["quiz-generator"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合在Markdown文档中嵌入测验，技术文档教学的理想选择",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install quizdown",
    "fallback": ["quiz-generator"]
}

TOOL_notebook_generator = {
    "name": "notebook-generator",
    "display_name": "notebook-generator",
    "description": "笔记生成工具，将学习资料自动整理为结构化笔记",
    "category": "笔记整理",
    "scenarios": ["笔记自动生成", "学习资料整理", "知识结构化"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["summary-tool"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持从多种输入格式生成结构化笔记",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install notebook-generator",
    "fallback": ["summary-tool"]
}

TOOL_mindmap = {
    "name": "mindmap",
    "display_name": "mindmap",
    "description": "思维导图生成工具，从文本/大纲/Markdown等自动生成思维导图",
    "category": "思维工具",
    "scenarios": ["思维导图制作", "知识梳理", "头脑风暴可视化"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合学习总结和知识体系梳理，支持多种导图格式导出",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install mindmap",
    "fallback": []
}

TOOL_ocr_flashcard = {
    "name": "ocr-flashcard",
    "display_name": "ocr-flashcard",
    "description": "OCR文字识别转闪卡工具，从图片/扫描件中提取文字并生成学习卡片",
    "category": "记忆学习",
    "scenarios": ["图片转闪卡", "扫描件学习", "OCR学习辅助"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "拍照扫描教材后自动生成复习卡片，提高学习效率",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install ocr-flashcard",
    "fallback": ["flashcard-maker"]
}

TOOL_summary_tool = {
    "name": "summary-tool",
    "display_name": "summary-tool",
    "description": "学习摘要工具，自动提取文本/文章/教材的核心内容和要点",
    "category": "笔记整理",
    "scenarios": ["内容摘要", "知识点提取", "学习笔记精简"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["notebook-generator"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "快速提取长文核心内容，适合考前复习资料精简",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install summary-tool",
    "fallback": ["notebook-generator"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
