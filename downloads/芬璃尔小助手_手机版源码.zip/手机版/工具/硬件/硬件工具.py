TOOL_PSUTIL = {
    "name": "psutil",
    "display_name": "psutil 系统信息",
    "description": "跨平台系统监控库，提供CPU、内存、磁盘、网络和进程信息",
    "category": "硬件工具",
    "scenarios": ["系统监控", "资源利用率采集", "进程管理", "性能分析", "告警系统"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "psutil.cpu_percent(interval=1) 获取实时CPU使用率",
    "github_stars": 11000,
    "open_source": True,
    "download_command": "pip install psutil",
    "fallback": ["wmi"]
}

TOOL_WMI = {
    "name": "wmi",
    "display_name": "WMI Windows WMI",
    "description": "Windows Management Instrumentation接口，查询Windows系统和硬件信息",
    "category": "硬件工具",
    "scenarios": ["Windows系统管理", "硬件信息采集", "远程管理", "事件监控", "配置审计"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "仅Windows平台可用，需要管理员权限查询部分信息",
    "github_stars": 600,
    "open_source": True,
    "download_command": "pip install wmi",
    "fallback": ["psutil"]
}

TOOL_PYADL = {
    "name": "pyadl",
    "display_name": "PyADL AMD显卡",
    "description": "AMD显卡控制库，查询和控制AMD GPU的状态与参数",
    "category": "硬件工具",
    "scenarios": ["AMD显卡监控", "GPU超频", "温度读取", "风扇控制", "显存管理"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 4,
    "conflicts_with": ["nvidia-ml-py"],
    "safety_level": "caution",
    "requires_network": False,
    "usage_tips": "需要安装AMD ADL SDK，仅支持AMD GPU",
    "github_stars": 200,
    "open_source": True,
    "download_command": "pip install pyadl",
    "fallback": ["nvidia-ml-py"]
}

TOOL_NVIDIA_ML = {
    "name": "nvidia-ml-py",
    "display_name": "NVIDIA Management Library",
    "description": "NVIDIA GPU管理库，监控GPU状态、显存使用和进程信息",
    "category": "硬件工具",
    "scenarios": ["NVIDIA GPU监控", "显存分析", "GPU温度采集", "多卡管理", "深度学习监控"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["pyadl"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "pynvml.nvmlInit() 初始化后即可查询所有GPU信息",
    "github_stars": 1200,
    "open_source": True,
    "download_command": "pip install nvidia-ml-py",
    "fallback": ["pyadl"]
}

TOOL_PYUSB = {
    "name": "pyusb",
    "display_name": "PyUSB USB设备",
    "description": "跨平台USB设备操作库，支持设备枚举、控制和数据传输",
    "category": "硬件工具",
    "scenarios": ["USB设备通信", "固件升级", "数据采集", "HID设备控制", "USB测试"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "caution",
    "requires_network": False,
    "usage_tips": "Windows需安装libusb驱动，Linux需root权限",
    "github_stars": 2800,
    "open_source": True,
    "download_command": "pip install pyusb",
    "fallback": ["hid", "pyserial"]
}

TOOL_PYSERIAL = {
    "name": "pyserial",
    "display_name": "pyserial 串口通信",
    "description": "跨平台串口通信库，支持RS232/RS485/USB虚拟串口",
    "category": "硬件工具",
    "scenarios": ["串口调试", "嵌入式通信", "传感器采集", "工业控制", "GPS接收"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "ser = serial.Serial('COM3', 115200, timeout=1) 一行打开串口",
    "github_stars": 6000,
    "open_source": True,
    "download_command": "pip install pyserial",
    "fallback": ["pyusb", "python-periphery"]
}

TOOL_SMBUS2 = {
    "name": "smbus2",
    "display_name": "smbus2 I2C通信",
    "description": "I2C总线通信库，用于连接和控制I2C外设",
    "category": "硬件工具",
    "scenarios": ["I2C传感器读取", "OLED显示屏控制", "ADC/DAC通信", "嵌入式开发", "树莓派外设"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "通常用于树莓派和嵌入式Linux系统",
    "github_stars": 500,
    "open_source": True,
    "download_command": "pip install smbus2",
    "fallback": ["python-periphery"]
}

TOOL_SPIDEV = {
    "name": "spidev",
    "display_name": "spidev SPI通信",
    "description": "SPI总线通信库，实现高速同步串行通信",
    "category": "硬件工具",
    "scenarios": ["SPI设备通信", "高速数据采集", "显示屏驱动", "ADC读取", "RF模块控制"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "通常用于树莓派等Linux单板计算机",
    "github_stars": 400,
    "open_source": True,
    "download_command": "pip install spidev",
    "fallback": ["python-periphery"]
}

TOOL_GPIOZERO = {
    "name": "gpiozero",
    "display_name": "gpiozero GPIO (RPi)",
    "description": "树莓派GPIO控制库，提供简洁易用的设备抽象接口",
    "category": "硬件工具",
    "scenarios": ["LED控制", "按键读取", "电机驱动", "传感器接口", "树莓派项目"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["RPi.GPIO"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "from gpiozero import LED; led = LED(17) 极简GPIO控制",
    "github_stars": 3500,
    "open_source": True,
    "download_command": "pip install gpiozero",
    "fallback": ["RPi.GPIO", "python-periphery"]
}

TOOL_RPI_GPIO = {
    "name": "RPi.GPIO",
    "display_name": "RPi.GPIO 树莓派GPIO",
    "description": "树莓派原生GPIO控制库，支持引脚模式设置和中断",
    "category": "硬件工具",
    "scenarios": ["GPIO引脚控制", "PWM输出", "中断响应", "树莓派HAT驱动", "嵌入式原型"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["gpiozero"],
    "safety_level": "caution",
    "requires_network": False,
    "usage_tips": "使用 GPIO.setmode(GPIO.BCM) 指定引脚编号方式",
    "github_stars": 4200,
    "open_source": True,
    "download_command": "pip install RPi.GPIO",
    "fallback": ["gpiozero", "python-periphery"]
}

TOOL_PYTHON_PERIPHERY = {
    "name": "python-periphery",
    "display_name": "python-periphery 外设",
    "description": "统一外设接口库，支持GPIO、I2C、SPI、MMIO和UART",
    "category": "硬件工具",
    "scenarios": ["嵌入式Linux外设", "GPIO/SPI/I2C/UART统一控制", "工业控制", "物联网设备", "单板计算机"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "跨平台设计，同时支持Linux和Windows",
    "github_stars": 600,
    "open_source": True,
    "download_command": "pip install python-periphery",
    "fallback": ["gpiozero", "smbus2", "spidev"]
}

TOOL_HID = {
    "name": "hid",
    "display_name": "HID HID设备",
    "description": "HID (Human Interface Device) 通信库，用于操作USB HID设备",
    "category": "硬件工具",
    "scenarios": ["USB HID设备通信", "游戏手柄控制", "键盘鼠标模拟", "HID报表解析", "设备固件更新"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "caution",
    "requires_network": False,
    "usage_tips": "Windows需要安装libusb或hidapi驱动",
    "github_stars": 900,
    "open_source": True,
    "download_command": "pip install hidapi",
    "fallback": ["pyusb", "pyserial"]
}

TOOL_PYFTDI = {
    "name": "pyftdi",
    "display_name": "PyFTDI FTDI芯片",
    "description": "FTDI芯片控制库，支持GPIO、SPI、I2C和JTAG功能",
    "category": "硬件工具",
    "scenarios": ["FTDI芯片编程", "USB转SPI/I2C", "JTAG调试", "FPGA配置", "嵌入式调试"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 4,
    "conflicts_with": ["pylibftdi"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需要安装 FTDI D2XX 驱动",
    "github_stars": 500,
    "open_source": True,
    "download_command": "pip install pyftdi",
    "fallback": ["pylibftdi", "pyserial"]
}

TOOL_PYLIBFTDI = {
    "name": "pylibftdi",
    "display_name": "pylibftdi FTDI",
    "description": "FTDI芯片的另一种Python绑定，提供简洁的Bitbang模式接口",
    "category": "硬件工具",
    "scenarios": ["FTDI Bitbang模式", "USB GPIO控制", "简单SPI通信", "LED控制", "逻辑分析仪"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pyftdi"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合简单的FTDI控制场景，比pyftdi更轻量",
    "github_stars": 300,
    "open_source": True,
    "download_command": "pip install pylibftdi",
    "fallback": ["pyftdi", "pyserial"]
}

TOOL_PYVISA = {
    "name": "pyvisa",
    "display_name": "PyVISA 仪器控制",
    "description": "VISA标准仪器控制库，支持GPIB、USB、串口和以太网仪器通信",
    "category": "硬件工具",
    "scenarios": ["示波器控制", "万用表读数", "信号发生器控制", "自动化测试", "实验室数据采集"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需要安装NI-VISA或pyvisa-py后端",
    "github_stars": 1100,
    "open_source": True,
    "download_command": "pip install pyvisa",
    "fallback": ["pyserial", "pyusb"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}