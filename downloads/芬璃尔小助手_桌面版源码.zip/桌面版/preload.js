// ===== 芬璃尔小助手 - Electron 预加载脚本 =====
// 负责：安全暴露 Node.js API 给渲染进程

const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
    platform: process.platform,
    versions: {
        node: process.versions.node,
        chrome: process.versions.chrome,
        electron: process.versions.electron
    }
});