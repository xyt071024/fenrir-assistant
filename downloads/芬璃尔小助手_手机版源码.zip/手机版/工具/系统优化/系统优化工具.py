TOOL_WINDOWS_CLEAN = {
    "name": "clean-windows",
    "display_name": "Windows清理",
    "description": "深度清理Windows系统中的临时文件、缓存、日志文件、回收站等无用数据，释放磁盘空间",
    "category": "系统优化",
    "scenarios": ["磁盘空间不足时快速释放空间", "系统运行缓慢需要清理垃圾文件", "重装系统前进行彻底清理"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["temp-cleaner"],
    "safety_level": "中等",
    "requires_network": False,
    "usage_tips": "建议每月执行一次，首次清理可释放5-20GB空间",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["temp-cleaner", "disk-cleanup"]
}

TOOL_DISK_CLEANUP = {
    "name": "disk-cleanup",
    "display_name": "磁盘清理",
    "description": "调用Windows内置磁盘清理工具，清理系统文件、更新缓存、缩略图等各类磁盘垃圾",
    "category": "系统优化",
    "scenarios": ["C盘爆满需要紧急清理", "Windows更新后清理旧版本文件", "定期维护磁盘健康"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["clean-windows"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "勾选'清理系统文件'按钮可释放更多空间，但速度较慢",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["clean-windows", "temp-cleaner"]
}

TOOL_STARTUP_MANAGER = {
    "name": "startup-manager",
    "display_name": "启动项管理",
    "description": "管理系统开机自启动程序，禁用不必要的启动项以加快系统启动速度",
    "category": "系统优化",
    "scenarios": ["电脑开机速度过慢", "安装了过多自启动软件", "需要禁用恶意或冗余自启动项"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "建议只保留杀毒软件和输入法等必要启动项，其余均可禁用",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["service-manager"]
}

TOOL_SERVICE_MANAGER = {
    "name": "service-manager",
    "display_name": "服务管理",
    "description": "管理Windows后台服务，可启动、停止、禁用不必要的系统服务以释放资源",
    "category": "系统优化",
    "scenarios": ["关闭不必要的后台服务释放内存", "排查系统服务异常导致的故障", "优化游戏或高性能场景的服务配置"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "危险",
    "requires_network": False,
    "usage_tips": "禁用系统服务前务必确认功能影响，错误禁用可能导致系统异常",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["startup-manager"]
}

TOOL_REGISTRY_CLEANER = {
    "name": "registry-cleaner",
    "display_name": "注册表清理",
    "description": "扫描并清理Windows注册表中的无效条目、残留键值和冗余信息",
    "category": "系统优化",
    "scenarios": ["卸载软件后残留注册表项", "系统注册表臃肿导致性能下降", "修复因注册表错误导致的功能异常"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "危险",
    "requires_network": False,
    "usage_tips": "操作前务必备份注册表，误删可能导致系统不稳定或无法启动",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["clean-windows"]
}

TOOL_SYSTEM_BOOSTER = {
    "name": "system-booster",
    "display_name": "系统加速",
    "description": "综合优化系统设置，包括关闭视觉效果、优化网络参数、调整内存分配等多项加速策略",
    "category": "系统优化",
    "scenarios": ["老电脑运行缓慢需要全面提速", "游戏场景下追求最大性能输出", "日常办公希望系统响应更迅速"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["memory-optimizer"],
    "safety_level": "中等",
    "requires_network": False,
    "usage_tips": "加速后建议重启电脑使所有优化生效",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["memory-optimizer", "startup-manager"]
}

TOOL_MEMORY_OPTIMIZER = {
    "name": "memory-optimizer",
    "display_name": "内存优化",
    "description": "实时监控和优化系统内存使用，释放被占用的物理内存，降低内存占用率",
    "category": "系统优化",
    "scenarios": ["内存占用长期居高不下", "运行大型软件前需释放内存", "低内存配置电脑日常优化"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["system-booster"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "效果通常是临时的，持续内存不足建议升级硬件",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["system-booster"]
}

TOOL_TEMP_CLEANER = {
    "name": "temp-cleaner",
    "display_name": "临时文件清理",
    "description": "清理系统临时文件夹、用户临时文件夹、预读取文件等各类临时文件",
    "category": "系统优化",
    "scenarios": ["系统临时文件夹占用过大", "软件安装或更新后清理残留临时文件", "日常定期维护磁盘"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["clean-windows", "disk-cleanup"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "部分临时文件可能被程序占用无法删除，跳过即可",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["clean-windows", "disk-cleanup"]
}

TOOL_BROWSER_CLEANER = {
    "name": "browser-cleaner",
    "display_name": "浏览器缓存清理",
    "description": "清理各主流浏览器的缓存、Cookie、历史记录、下载记录等浏览数据",
    "category": "系统优化",
    "scenarios": ["浏览器运行卡顿需要清理缓存", "隐私保护需要清除浏览痕迹", "释放被浏览器占用的磁盘空间"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "清理后浏览器需要重新登录已保存的网站，建议先导出密码",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["clean-windows"]
}

TOOL_DRIVER_UPDATER = {
    "name": "driver-updater",
    "display_name": "驱动更新",
    "description": "检测并更新系统中过时或有问题的硬件驱动程序，提升硬件兼容性和性能",
    "category": "系统优化",
    "scenarios": ["新硬件无法正常使用", "游戏或专业软件提示驱动版本过低", "系统设备管理器中有黄色感叹号"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 2,
    "conflicts_with": [],
    "safety_level": "中等",
    "requires_network": True,
    "usage_tips": "建议优先从硬件厂商官网下载驱动，第三方工具仅作辅助参考",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": []
}

TOOL_POWER_SCHEME = {
    "name": "power-scheme",
    "display_name": "电源方案",
    "description": "一键切换Windows电源计划，在节能、平衡、高性能之间快速切换并微调参数",
    "category": "系统优化",
    "scenarios": ["笔记本电脑需要延长续航", "玩游戏时需要切换到高性能模式", "办公场景下平衡功耗与性能"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "高性能模式会增加耗电量，笔记本用户注意接通电源",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["system-booster"]
}

TOOL_SYS_INFO = {
    "name": "sys-info",
    "display_name": "系统信息",
    "description": "全面展示操作系统、硬件配置、运行状态等系统详细信息，支持导出为报告",
    "category": "系统优化",
    "scenarios": ["了解电脑硬件配置详情", "排查系统兼容性问题时收集信息", "购买新硬件前确认现有配置"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "可将报告导出分享给技术人员协助诊断问题",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["hardware-monitor"]
}

TOOL_BENCHMARK = {
    "name": "benchmark",
    "display_name": "性能测试",
    "description": "对CPU、GPU、内存、磁盘等硬件进行综合性能基准测试，量化设备性能水平",
    "category": "系统优化",
    "scenarios": ["新电脑验收检测性能是否达标", "超频或升级硬件后验证性能提升", "对比不同配置的性能差异"],
    "accuracy": 4,
    "efficiency": 2,
    "speed": 1,
    "conflicts_with": ["stress-test"],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "测试时关闭其他程序以获得准确结果，测试过程可能需要10-30分钟",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["stress-test"]
}

TOOL_STRESS_TEST = {
    "name": "stress-test",
    "display_name": "压力测试",
    "description": "通过高负载运算对CPU、GPU、内存进行极限压力测试，检测系统稳定性和散热能力",
    "category": "系统优化",
    "scenarios": ["检测超频后的系统稳定性", "验证散热系统是否正常工作", "排查不定时蓝屏或重启的硬件原因"],
    "accuracy": 4,
    "efficiency": 1,
    "speed": 1,
    "conflicts_with": ["benchmark"],
    "safety_level": "危险",
    "requires_network": False,
    "usage_tips": "测试时注意监控温度，温度超过90°C建议停止测试检查散热",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["benchmark"]
}

TOOL_HARDWARE_MONITOR = {
    "name": "hardware-monitor",
    "display_name": "硬件监控",
    "description": "实时监控CPU温度、GPU温度、风扇转速、电压、内存占用等硬件运行状态",
    "category": "系统优化",
    "scenarios": ["长时间高负载运行时监控温度", "排查电脑过热降频问题", "检测硬件是否存在异常状态"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "安全",
    "requires_network": False,
    "usage_tips": "可设置高温警报阈值，超过阈值时自动提醒",
    "github_stars": 0,
    "open_source": True,
    "download_command": "",
    "fallback": ["sys-info"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
