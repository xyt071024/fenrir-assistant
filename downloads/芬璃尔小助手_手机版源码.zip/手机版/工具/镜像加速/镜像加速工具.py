# 镜像加速与代理访问工具
# 解决国内访问国外资源的网络瓶颈问题

TOOL_ghproxy = {
    "name": "ghproxy", "display_name": "GitHub代理加速",
    "description": "GitHub Release/Clone/Raw文件代理加速，通过国内镜像站代理下载GitHub上的资源",
    "category": "镜像加速", "scenarios": ["GitHub Release下载", "git clone加速", "raw文件加速"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["ghfast", "kgithub"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "URL加前缀: https://ghproxy.com/https://github.com/... 或使用 ghfast.top",
    "github_stars": 5000, "open_source": True,
    "download_command": "无需安装，URL前缀方式", "fallback": ["ghfast", "kgithub"]
}

TOOL_ghfast = {
    "name": "ghfast", "display_name": "ghfast.top加速",
    "description": "GitHub快速镜像代理，提供Release文件、git clone、raw文件高速下载加速",
    "category": "镜像加速", "scenarios": ["GitHub文件下载", "git clone加速", "pip安装加速"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["ghproxy", "kgithub"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "URL加前缀: https://ghfast.top/https://github.com/...",
    "github_stars": 3000, "open_source": True,
    "download_command": "无需安装", "fallback": ["ghproxy", "kgithub"]
}

TOOL_kgithub = {
    "name": "kgithub", "display_name": "Kgithub镜像站",
    "description": "Kgithub GitHub镜像站，浏览器可直接访问GitHub页面浏览代码、Issue",
    "category": "镜像加速", "scenarios": ["GitHub网页镜像", "代码浏览", "Issue访问"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["ghproxy", "ghfast"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "直接访问 kgithub.com",
    "github_stars": 2000, "open_source": False,
    "download_command": "浏览器访问", "fallback": ["ghproxy", "ghfast"]
}

TOOL_npmmirror = {
    "name": "npmmirror", "display_name": "npmmirror npm镜像",
    "description": "淘宝NPM镜像站，国内最快最稳定的npm包下载源，同步频率10分钟",
    "category": "镜像加速", "scenarios": ["npm install加速", "yarn安装加速", "pnpm加速"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["cnpmjs", "npm-taobao"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "npm config set registry https://registry.npmmirror.com",
    "github_stars": 10000, "open_source": True,
    "download_command": "npm config set registry https://registry.npmmirror.com", "fallback": ["cnpmjs", "yarn"]
}

TOOL_pypi_mirror = {
    "name": "pypi_mirror", "display_name": "PyPI镜像源",
    "description": "Python包镜像源集合，清华/阿里/中科大镜像加速pip install",
    "category": "镜像加速", "scenarios": ["pip install加速", "Python环境搭建"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["pypi官方源"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "pip install -i https://pypi.tuna.tsinghua.edu.cn/simple 包名",
    "github_stars": 5000, "open_source": True,
    "download_command": "pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple",
    "fallback": ["conda镜像"]
}

TOOL_docker_mirror = {
    "name": "docker_mirror", "display_name": "Docker镜像加速器",
    "description": "Docker镜像加速器配置，阿里云/中科大镜像仓库加速docker pull",
    "category": "镜像加速", "scenarios": ["docker pull加速", "Docker部署", "K8s镜像拉取"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["docker官方仓库"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "配置/etc/docker/daemon.json: {\"registry-mirrors\": [\"https://docker.mirrors.ustc.edu.cn\"]}",
    "github_stars": 3000, "open_source": True,
    "download_command": "修改Docker daemon配置重启", "fallback": ["containerd镜像"]
}

TOOL_conda_mirror = {
    "name": "conda_mirror", "display_name": "Conda镜像源",
    "description": "Anaconda/Miniconda镜像源配置，清华/中科大镜像加速conda install",
    "category": "镜像加速", "scenarios": ["conda install加速", "数据科学环境搭建"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["conda官方源"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main/",
    "github_stars": 3000, "open_source": True,
    "download_command": "conda config命令配置", "fallback": ["pypi镜像"]
}

TOOL_mirror_site = {
    "name": "mirror_site", "display_name": "开源镜像站大全",
    "description": "国内外主要开源软件镜像站集合，清华TUNA/阿里云/中科大/华为云/腾讯云",
    "category": "镜像加速", "scenarios": ["镜像站推荐", "镜像源切换", "系统镜像下载"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["单一镜像源"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "清华: mirrors.tuna.tsinghua.edu.cn; 阿里: mirrors.aliyun.com; 中科大: mirrors.ustc.edu.cn",
    "github_stars": 5000, "open_source": True,
    "download_command": "浏览器访问镜像站", "fallback": ["ghproxy"]
}

TOOL_v2ray = {
    "name": "v2ray", "display_name": "V2Ray代理",
    "description": "Project V代理工具，支持VMess/VLESS/Trojan/Shadowsocks多种协议和路由规则",
    "category": "镜像加速", "scenarios": ["科学上网", "代理配置", "网络转发"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["clash", "shadowsocks"], "safety_level": "warning",
    "requires_network": True,
    "usage_tips": "config.json配置入站出站协议和路由规则",
    "github_stars": 65000, "open_source": True,
    "download_command": "winget install v2ray", "fallback": ["clash", "shadowsocks"]
}

TOOL_clash = {
    "name": "clash", "display_name": "Clash代理",
    "description": "基于规则的跨平台代理客户端，YAML配置规则组/策略组/DNS分流",
    "category": "镜像加速", "scenarios": ["全局代理", "分流代理", "局域网共享代理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["v2ray", "shadowsocks"], "safety_level": "warning",
    "requires_network": True,
    "usage_tips": "config.yaml配置proxies/proxy-groups/rules",
    "github_stars": 30000, "open_source": True,
    "download_command": "winget install ClashForWindows", "fallback": ["v2ray", "shadowsocks"]
}

TOOL_proxy_env = {
    "name": "proxy_env", "display_name": "终端代理环境变量",
    "description": "配置http_proxy/https_proxy环境变量让命令行程序走代理",
    "category": "镜像加速", "scenarios": ["终端代理", "git代理", "curl代理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["proxychains"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "set HTTP_PROXY=http://127.0.0.1:7890; set HTTPS_PROXY=http://127.0.0.1:7890",
    "github_stars": 0, "open_source": False,
    "download_command": "设置环境变量即可", "fallback": ["proxychains"]
}

TOOL_huggingface_mirror = {
    "name": "huggingface_mirror", "display_name": "HuggingFace镜像",
    "description": "HuggingFace模型国内镜像站，加速AI模型下载，解决transformers/diffusers下载慢",
    "category": "镜像加速", "scenarios": ["模型下载加速", "AI模型加载"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["huggingface官方"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "export HF_ENDPOINT=https://hf-mirror.com",
    "github_stars": 5000, "open_source": True,
    "download_command": "export HF_ENDPOINT=https://hf-mirror.com", "fallback": ["modelscope"]
}

TOOL_proxychains = {
    "name": "proxychains", "display_name": "Proxychains代理链",
    "description": "强制任意命令行程序使用代理，支持HTTP/SOCKS5代理链，无需应用支持代理",
    "category": "镜像加速", "scenarios": ["命令行代理", "任意程序强制代理"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["proxy_env"], "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "proxychains4 git clone ...",
    "github_stars": 13000, "open_source": True,
    "download_command": "apt install proxychains4", "fallback": ["proxy_env"]
}
