TOOL_SLACK = {
    "name": "slack-sdk",
    "display_name": "Slack",
    "description": "企业级团队协作平台，支持频道、私信、Bot机器人、文件共享和丰富集成，是远程办公首选沟通工具。",
    "category": "通讯社交",
    "scenarios": ["团队即时通讯", "Bot自动化", "消息通知", "工作流自动化", "DevOps集成"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["mattermost", "discord-py"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "Socket Mode 可避免公网暴露端口；Block Kit Builder 可可视化构建消息布局",
    "github_stars": "12k+ (python-slack-sdk)",
    "open_source": True,
    "download_command": "pip install slack-sdk",
    "fallback": ["mattermost", "discord-py"]
}

TOOL_DISCORD = {
    "name": "discord-py",
    "display_name": "Discord机器人",
    "description": "流行的游戏/社区通讯平台，支持语音频道、Bot机器人和丰富的社区管理功能，API生态成熟。",
    "category": "通讯社交",
    "scenarios": ["社区聊天机器人", "游戏服务器管理", "自动化管理", "语音频道集成", "社区运营"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["slack-sdk", "telegram"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "使用 discord.py 2.x 版本，支持 Slash Command；注意官方API速率限制",
    "github_stars": "15k+ (discord.py)",
    "open_source": True,
    "download_command": "pip install discord.py",
    "fallback": ["slack-sdk", "telegram"]
}

TOOL_TELEGRAM = {
    "name": "telegram",
    "display_name": "Telegram Bot",
    "description": "安全快速的即时通讯平台，Bot API极其强大，支持内联查询、自定义键盘、频道和端到端加密。",
    "category": "通讯社交",
    "scenarios": ["消息通知Bot", "订阅服务", "文件分享", "群组管理", "自动化工作流"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["whatsapp-web", "signal-cli"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "python-telegram-bot 支持 Webook 和 Polling 两种模式；Bot Token 需严格保密",
    "github_stars": "26k+ (python-telegram-bot)",
    "open_source": True,
    "download_command": "pip install python-telegram-bot",
    "fallback": ["discord-py", "signal-cli"]
}

TOOL_TWILIO = {
    "name": "twilio",
    "display_name": "Twilio短信",
    "description": "全球领先的云通讯平台，提供短信、语音、视频和验证服务API，覆盖全球200+国家和地区。",
    "category": "通讯社交",
    "scenarios": ["短信验证码", "电话通知", "语音呼叫", "视频通话", "双因素认证"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["signal-cli"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "价格按用量计费；美国号码需要资质审核；测试模式使用沙箱环境",
    "github_stars": "7k+ (twilio-python)",
    "open_source": True,
    "download_command": "pip install twilio",
    "fallback": ["signal-cli", "telegram"]
}

TOOL_FACEBOOK = {
    "name": "facebook-sdk",
    "display_name": "Facebook",
    "description": "全球最大的社交平台SDK，支持Graph API访问，可用于页面管理、内容发布、广告投放和数据分析。",
    "category": "通讯社交",
    "scenarios": ["社交媒体发布", "广告投放", "页面管理", "数据分析", "Messenger Bot"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["twitter-api", "instagram-api"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需创建Facebook应用获取Access Token；API版本更新频繁需关注变更日志",
    "github_stars": "2.7k+ (facebook-sdk)",
    "open_source": True,
    "download_command": "pip install facebook-sdk",
    "fallback": ["twitter-api", "instagram-api"]
}

TOOL_TWITTER = {
    "name": "twitter-api",
    "display_name": "Twitter/X",
    "description": "Twitter/X平台API，支持推文发布、时间线获取、趋势分析和社交图谱分析。",
    "category": "通讯社交",
    "scenarios": ["社交舆情监控", "自动发布", "趋势分析", "社交网络分析", "内容采集"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["facebook-sdk", "reddit-api"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "v2 API需要使用OAuth 2.0；免费版有请求频率和功能限制",
    "github_stars": "10k+ (tweepy)",
    "open_source": True,
    "download_command": "pip install tweepy",
    "fallback": ["facebook-sdk", "reddit-api"]
}

TOOL_WECHAT = {
    "name": "wechatpy",
    "display_name": "微信",
    "description": "微信公众平台和微信支付的Python SDK，支持公众号管理、模板消息、客服消息和小程序开发。",
    "category": "通讯社交",
    "scenarios": ["微信公众号", "微信支付", "小程序后端", "模板消息", "客服消息"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["dingtalk-sdk", "feishu-lark"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需要微信公众号或小程序AppID和AppSecret；注意微信的Token有效期和刷新机制",
    "github_stars": "4.5k+ (wechatpy)",
    "open_source": True,
    "download_command": "pip install wechatpy",
    "fallback": ["dingtalk-sdk", "feishu-lark"]
}

TOOL_DINGTALK = {
    "name": "dingtalk-sdk",
    "display_name": "钉钉",
    "description": "阿里巴巴旗下企业通讯平台SDK，支持企业内部IM、群机器人、审批流程和考勤打卡。",
    "category": "通讯社交",
    "scenarios": ["企业即时通讯", "群机器人通知", "审批流集成", "考勤打卡", "企业内部应用"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["wechatpy", "feishu-lark"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需注册钉钉开发者账号；企业内部应用免用户授权；API有严格的频率限制",
    "github_stars": "2k+ (dingtalk-sdk)",
    "open_source": True,
    "download_command": "pip install dingtalk-sdk",
    "fallback": ["wechatpy", "feishu-lark"]
}

TOOL_FEISHU = {
    "name": "feishu-lark",
    "display_name": "飞书Lark",
    "description": "字节跳动旗下企业协作平台，集即时通讯、云文档、日历、视频会议和审批于一体。",
    "category": "通讯社交",
    "scenarios": ["企业通讯", "云文档自动化", "审批流程", "机器人通知", "日历管理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["dingtalk-sdk", "slack-sdk"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "使用 lark-cli 工具可快速完成认证；支持自建应用和商店应用两种模式",
    "github_stars": "5k+ (lark-openapi)",
    "open_source": True,
    "download_command": "pip install lark-oapi",
    "fallback": ["dingtalk-sdk", "slack-sdk"]
}

TOOL_MATRIX = {
    "name": "matrix-client",
    "display_name": "Matrix",
    "description": "开放去中心化的实时通讯协议，支持端到端加密、联邦制部署和丰富的集成。",
    "category": "通讯社交",
    "scenarios": ["去中心化通讯", "隐私安全聊天", "自建聊天服务器", "联邦通讯", "IoT通讯"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["mattermost", "slack-sdk"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "选择成熟的Python库 matrix-nio；自建服务器推荐 Synapse 实现",
    "github_stars": "3k+ (matrix-nio)",
    "open_source": True,
    "download_command": "pip install matrix-nio",
    "fallback": ["mattermost", "telegram"]
}

TOOL_MATTERMOST = {
    "name": "mattermost",
    "display_name": "Mattermost",
    "description": "自托管的企业级团队通讯平台，类似Slack的开源替代方案，强调数据安全和控制。",
    "category": "通讯社交",
    "scenarios": ["自托管团队通讯", "企业内部IM", "DevOps集成", "安全通讯", "合规管理"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["slack-sdk", "matrix-client"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "自部署需要维护服务器；支持与GitLab、Jira等DevOps工具深度集成",
    "github_stars": "28k+ (mattermost-server)",
    "open_source": True,
    "download_command": "pip install mattermostdriver",
    "fallback": ["slack-sdk", "matrix-client"]
}

TOOL_SIGNAL = {
    "name": "signal-cli",
    "display_name": "Signal",
    "description": "注重隐私的端到端加密通讯工具，Signal-CLI支持通过命令行或DBus发送接收消息。",
    "category": "通讯社交",
    "scenarios": ["隐私通讯", "端到端加密消息", "安全通知", "自动化消息", "私密通道"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["telegram", "whatsapp-web"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "需要注册Signal账号；CLI模式不支持群组消息的全部功能",
    "github_stars": "6k+ (signal-cli)",
    "open_source": True,
    "download_command": "非Python工具，请从 GitHub Releases 下载 signal-cli",
    "fallback": ["telegram", "whatsapp-web"]
}

TOOL_WHATSAPP = {
    "name": "whatsapp-web",
    "display_name": "WhatsApp",
    "description": "全球最流行的即时通讯应用，通过Web API实现消息发送、接收和媒体文件处理。",
    "category": "通讯社交",
    "scenarios": ["客户沟通", "群发消息", "客服机器人", "业务通知", "媒体分享"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["telegram", "signal-cli"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "使用非官方库有被封号风险；推荐使用 WhatsApp Business API 官方方案",
    "github_stars": "11k+ (pywhatkit)",
    "open_source": True,
    "download_command": "pip install pywhatkit",
    "fallback": ["telegram", "signal-cli"]
}

TOOL_INSTAGRAM = {
    "name": "instagram-api",
    "display_name": "Instagram",
    "description": "Instagram社交平台API，支持图片视频发布、用户数据分析、自动互动和内容管理。",
    "category": "通讯社交",
    "scenarios": ["社交媒体营销", "内容自动发布", "互动自动化", "粉丝分析", "舆情监控"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["facebook-sdk", "twitter-api"],
    "safety_level": "low",
    "requires_network": True,
    "usage_tips": "官方API限制严格；第三方实现有被封禁风险；推荐使用官方 Graph API",
    "github_stars": "3k+ (instagram-private-api)",
    "open_source": True,
    "download_command": "pip install instagram-private-api",
    "fallback": ["facebook-sdk", "twitter-api"]
}

TOOL_REDDIT = {
    "name": "reddit-api",
    "display_name": "Reddit",
    "description": "Reddit社交新闻平台API，支持帖子发布、评论管理、Subreddit分析和舆情数据采集。",
    "category": "通讯社交",
    "scenarios": ["社区舆情分析", "内容自动发布", "Subreddit监控", "数据采集", "社区运营"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["twitter-api"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需创建 Reddit 应用获取 Client ID 和 Secret；注意遵守 API 使用条款和频率限制",
    "github_stars": "17k+ (praw)",
    "open_source": True,
    "download_command": "pip install praw",
    "fallback": ["twitter-api", "facebook-sdk"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}