TOOL_MCP_官方服务器集 = {
    "name": "mcp-servers", "display_name": "MCP官方服务器集", "description": "MCP官方维护的服务器集合，覆盖文件系统、Git、GitHub、数据库、浏览器自动化等常用场景，共72.6K Star，生态最完善",
    "category": "MCP协议", "scenarios": ["MCP服务搭建", "AI工具链集成"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "优先使用官方Server，兼容性和文档最好",
    "github_stars": 72600, "open_source": True,
    "download_command": "pip install mcp", "fallback": ["Awesome MCP Servers"]
}

TOOL_Awesome_MCP_Servers = {
    "name": "awesome-mcp-servers", "display_name": "Awesome MCP Servers精选", "description": "社区精选的MCP服务器列表，收录数千个第三方MCP Server，涵盖股票、天气、地图、AI等多领域",
    "category": "MCP协议", "scenarios": ["发现MCP服务", "第三方MCP选型"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "适合寻找非官方或特定领域的MCP服务",
    "github_stars": 3000, "open_source": True,
    "download_command": "pip install mcp", "fallback": ["MCP官方服务器集"]
}

TOOL_Playwright_MCP_浏览器自动化 = {
    "name": "playwright-mcp", "display_name": "Playwright浏览器自动化", "description": "基于Playwright的MCP浏览器自动化工具，支持无头浏览器操作、页面截图、表单填写、数据抓取等Web自动化任务",
    "category": "MCP协议", "scenarios": ["Web自动化", "网页抓取", "表单填写"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["mcp-server-puppeteer"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "比Puppeteer更快，推荐新项目使用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install playwright-mcp", "fallback": ["mcp-server-puppeteer"]
}

TOOL_Context7_文档查询 = {
    "name": "context7", "display_name": "Context7文档查询", "description": "专为AI设计的文档查询MCP工具，可实时检索技术文档、API参考、框架教程等，让AI获得最新文档上下文",
    "category": "MCP协议", "scenarios": ["技术文档查询", "API文档检索"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "适合需要获取最新框架文档的场景",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install context7-mcp", "fallback": ["MCP官方服务器集"]
}

TOOL_mcp_aktools_股票MCP = {
    "name": "mcp-aktools", "display_name": "mcp-aktools股票MCP", "description": "A股市场MCP工具，支持股票行情查询、K线数据、公司公告、财务数据等，覆盖沪深北交易所数据",
    "category": "MCP协议", "scenarios": ["A股查询", "股票数据获取", "金融分析"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "数据来源为公开市场数据，实时性有保障",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-aktools", "fallback": []
}

TOOL_mcp_server_sqlite_数据库 = {
    "name": "mcp-server-sqlite", "display_name": "SQLite数据库MCP", "description": "SQLite数据库的MCP服务器，支持SQL查询、表结构管理、数据导入导出、数据库分析等操作",
    "category": "MCP协议", "scenarios": ["本地数据库查询", "数据分析", "数据持久化"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合AI Agent存储结构化数据",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-sqlite", "fallback": ["mcp-server-filesystem"]
}

TOOL_mcp_server_filesystem_文件系统 = {
    "name": "mcp-server-filesystem", "display_name": "文件系统MCP", "description": "文件系统操作MCP服务器，支持文件读写、目录浏览、文件搜索、文件元数据获取等本地文件操作",
    "category": "MCP协议", "scenarios": ["文件读写", "目录管理", "文件搜索"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "medium",
    "requires_network": False, "usage_tips": "注意安全配置，建议限定可访问目录范围",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-filesystem", "fallback": []
}

TOOL_mcp_server_github_GitHub操作 = {
    "name": "mcp-server-github", "display_name": "GitHub操作MCP", "description": "GitHub API的MCP封装，支持仓库管理、Issue/PR操作、Code Review、文件操作、工作流触发等GitHub全功能",
    "category": "MCP协议", "scenarios": ["GitHub自动化", "PR管理", "Issue跟踪"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要配置GitHub Token使用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-github", "fallback": ["mcp-server-git"]
}

TOOL_mcp_server_git_Git操作 = {
    "name": "mcp-server-git", "display_name": "Git操作MCP", "description": "Git版本控制MCP服务器，支持commit、branch、log、diff、status等Git常用操作，无需网络即可使用",
    "category": "MCP协议", "scenarios": ["版本控制", "代码管理", "Git操作"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合本地仓库管理，无需GitHub账号",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-git", "fallback": ["mcp-server-github"]
}

TOOL_mcp_server_puppeteer_网页抓取 = {
    "name": "mcp-server-puppeteer", "display_name": "Puppeteer网页抓取", "description": "基于Puppeteer的MCP网页抓取工具，支持页面渲染、JavaScript执行、PDF生成、网络请求拦截等",
    "category": "MCP协议", "scenarios": ["网页抓取", "页面截图", "PDF生成"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Playwright_MCP_浏览器自动化"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要安装Chromium，首次使用较慢",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-puppeteer", "fallback": ["Playwright_MCP_浏览器自动化"]
}

TOOL_mcp_server_brave_search_搜索 = {
    "name": "mcp-server-brave-search", "display_name": "Brave搜索MCP", "description": "Brave搜索引擎的MCP接口，支持Web搜索、新闻搜索、图片搜索，无广告干扰，隐私友好",
    "category": "MCP协议", "scenarios": ["网络搜索", "信息检索", "新闻查询"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要申请Brave Search API Key",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-brave-search", "fallback": ["mcp-server-tavily-search"]
}

TOOL_mcp_server_everart_图像生成 = {
    "name": "mcp-server-everart", "display_name": "EverArt图像生成", "description": "AI图像生成MCP服务器，集成Stable Diffusion、DALL-E等模型，支持文生图、图生图、风格迁移等",
    "category": "MCP协议", "scenarios": ["AI绘图", "图像生成", "风格迁移"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要EverArt API Key，生成速度取决于模型",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-everart", "fallback": []
}

TOOL_mcp_server_memory_记忆系统 = {
    "name": "mcp-server-memory", "display_name": "MCP记忆系统", "description": "AI记忆管理MCP服务器，支持记忆存储、检索、更新、遗忘，让AI Agent具备长期记忆能力，基于知识图谱",
    "category": "MCP协议", "scenarios": ["AI记忆管理", "长期记忆", "知识图谱"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "可配置本地存储路径，数据持久化",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-memory", "fallback": []
}

TOOL_mcp_server_time_时间时区 = {
    "name": "mcp-server-time", "display_name": "时间时区MCP", "description": "时间和时区查询MCP服务器，支持获取当前时间、时区转换、UTC转换、世界各地时间查询等",
    "category": "MCP协议", "scenarios": ["时间查询", "时区转换", "时间计算"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "本地运行，无需网络，精度到秒",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-time", "fallback": []
}

TOOL_mcp_server_weather_天气 = {
    "name": "mcp-server-weather", "display_name": "天气查询MCP", "description": "天气查询MCP服务器，支持获取实时天气、天气预报、空气质量、日出日落等气象数据",
    "category": "MCP协议", "scenarios": ["天气查询", "天气预报", "气象数据"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要配置天气API服务商Key",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mcp-server-weather", "fallback": []
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
