"""
芬璃尔小助手 - 配置管理器

加载/保存 settings.json 配置，管理模型、工具开关、主题、语言等设置。
支持 OpenAI、DeepSeek、Claude、Qwen、Ollama 等多种模型配置。
API Key 优先从环境变量读取，兼容已有 data/config.json。
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional


DEFAULT_CONFIG: Dict[str, Any] = {
    "version": "1.0.0",
    "active_model": "gpt-4o",
    "theme": "dark",
    "language": "zh-CN",
    "tools_enabled": True,
    "tools": {
        "filesystem": True,
        "browser": True,
        "system": True,
        "computer_control": False,
        "office": True,
        "image": True,
        "clipboard": True,
        "web_search": True,
    },
    "models": [
        {
            "name": "gpt-4o",
            "provider": "openai",
            "api_key": "{env:OPENAI_API_KEY}",
            "api_base": "https://api.openai.com/v1",
            "model": "gpt-4o",
            "supports_tools": True,
            "supports_vision": True,
            "max_tokens": 4096,
            "description": "OpenAI GPT-4o，支持工具调用和视觉识别",
        },
        {
            "name": "gpt-4o-mini",
            "provider": "openai",
            "api_key": "{env:OPENAI_API_KEY}",
            "api_base": "https://api.openai.com/v1",
            "model": "gpt-4o-mini",
            "supports_tools": True,
            "supports_vision": True,
            "max_tokens": 16384,
            "description": "OpenAI GPT-4o Mini，轻量快速",
        },
        {
            "name": "deepseek-chat",
            "provider": "openai",
            "api_key": "{env:DEEPSEEK_API_KEY}",
            "api_base": "https://api.deepseek.com/v1",
            "model": "deepseek-chat",
            "supports_tools": True,
            "supports_vision": False,
            "max_tokens": 8192,
            "description": "DeepSeek Chat，高性价比中文模型",
        },
        {
            "name": "claude-3.5-sonnet",
            "provider": "anthropic",
            "api_key": "{env:ANTHROPIC_API_KEY}",
            "api_base": "https://api.anthropic.com/v1",
            "model": "claude-3-5-sonnet-20241022",
            "anthropic_version": "2023-06-01",
            "supports_tools": True,
            "supports_vision": True,
            "max_tokens": 8192,
            "description": "Claude 3.5 Sonnet，擅长深度推理和长文本",
        },
        {
            "name": "claude-3.5-haiku",
            "provider": "anthropic",
            "api_key": "{env:ANTHROPIC_API_KEY}",
            "api_base": "https://api.anthropic.com/v1",
            "model": "claude-3-5-haiku-20241022",
            "anthropic_version": "2023-06-01",
            "supports_tools": True,
            "supports_vision": True,
            "max_tokens": 8192,
            "description": "Claude 3.5 Haiku，快速响应",
        },
        {
            "name": "qwen-max",
            "provider": "openai",
            "api_key": "{env:QWEN_API_KEY}",
            "api_base": "https://dashscope.aliyuncs.com/compatible-mode/v1",
            "model": "qwen-max",
            "supports_tools": True,
            "supports_vision": True,
            "max_tokens": 8192,
            "description": "通义千问 Max，阿里云最强模型",
        },
        {
            "name": "qwen-plus",
            "provider": "openai",
            "api_key": "{env:QWEN_API_KEY}",
            "api_base": "https://dashscope.aliyuncs.com/compatible-mode/v1",
            "model": "qwen-plus",
            "supports_tools": True,
            "supports_vision": True,
            "max_tokens": 8192,
            "description": "通义千问 Plus，性价比之选",
        },
        {
            "name": "ollama-llama3",
            "provider": "ollama",
            "api_key": "",
            "api_base": "http://localhost:11434",
            "model": "llama3",
            "supports_tools": True,
            "supports_vision": False,
            "max_tokens": 4096,
            "description": "本地 Ollama Llama 3，无需 API Key",
        },
        {
            "name": "ollama-qwen2.5",
            "provider": "ollama",
            "api_key": "",
            "api_base": "http://localhost:11434",
            "model": "qwen2.5",
            "supports_tools": True,
            "supports_vision": False,
            "max_tokens": 8192,
            "description": "本地 Ollama Qwen2.5，本地中文模型",
        },
    ],
    "system_prompt": "你是一个智能助手，名叫芬璃尔。请用中文回应用户，简洁准确。",
    "max_history": 50,
    "safety_checks": True,
}


def resolve_env_vars(value: str) -> str:
    if isinstance(value, str) and value.startswith("{env:") and value.endswith("}"):
        env_var = value[5:-1]
        return os.environ.get(env_var, "")
    return value


def resolve_config(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: resolve_config(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [resolve_config(item) for item in obj]
    elif isinstance(obj, str):
        return resolve_env_vars(obj)
    return obj


class ConfigManager:
    def __init__(self, config_dir: Optional[str] = None):
        self.config_dir = Path(config_dir or self._default_config_dir())
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.config_file = self.config_dir / "config.json"
        self.settings_file = self.config_dir / "settings.json"
        self._config: Dict[str, Any] = {}
        self._load()

    def _default_config_dir(self) -> str:
        return os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "data"
        )

    def _load(self) -> None:
        loaded = False

        for fpath in [self.config_file, self.settings_file]:
            if fpath.exists():
                try:
                    data = json.loads(fpath.read_text(encoding="utf-8"))
                    if isinstance(data, dict) and data:
                        self._config = data
                        loaded = True
                        break
                except (json.JSONDecodeError, IOError):
                    continue

        if not loaded:
            self._config = dict(DEFAULT_CONFIG)
            self._save()

    def _save(self) -> None:
        try:
            self.config_file.write_text(
                json.dumps(self._config, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
        except IOError:
            pass

    def get(self, key: str, default: Any = None) -> Any:
        keys = key.split(".")
        value = self._config
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default
        if value is None:
            return default
        return value

    def set(self, key: str, value: Any) -> None:
        keys = key.split(".")
        target = self._config
        for k in keys[:-1]:
            if k not in target:
                target[k] = {}
            target = target[k]
        target[keys[-1]] = value
        self._save()

    def get_model_config(self, model_name: str) -> Optional[Dict[str, Any]]:
        models = self._config.get("models", [])
        for m in models:
            if m.get("name") == model_name:
                resolved = resolve_config(m)
                return resolved
        return None

    def get_active_model(self) -> Dict[str, Any]:
        active_name = self.get("active_model", "gpt-4o")
        model = self.get_model_config(active_name)
        if model:
            return model
        models = self._config.get("models", [])
        if models:
            resolved = resolve_config(models[0])
            return resolved
        return resolve_config(dict(DEFAULT_CONFIG["models"][0]))

    def list_models(self) -> List[Dict[str, Any]]:
        models = self._config.get("models", [])
        return [{
            "name": m.get("name", ""),
            "provider": m.get("provider", ""),
            "model": m.get("model", ""),
            "supports_tools": m.get("supports_tools", False),
            "supports_vision": m.get("supports_vision", False),
            "description": m.get("description", ""),
        } for m in models]

    def set_active_model(self, model_name: str) -> bool:
        models = self._config.get("models", [])
        for m in models:
            if m.get("name") == model_name:
                self.set("active_model", model_name)
                return True
        return False

    def is_tool_enabled(self, tool_category: str) -> bool:
        tools = self._config.get("tools", {})
        return tools.get(tool_category, True)

    def set_tool_enabled(self, tool_category: str, enabled: bool) -> None:
        tools = self._config.get("tools", {})
        tools[tool_category] = enabled
        self.set("tools", tools)

    def get_theme(self) -> str:
        return self.get("theme", "dark")

    def set_theme(self, theme: str) -> None:
        if theme in ("dark", "light", "auto"):
            self.set("theme", theme)

    def get_language(self) -> str:
        return self.get("language", "zh-CN")

    def set_language(self, lang: str) -> None:
        if lang in ("zh-CN", "en-US", "ja-JP"):
            self.set("language", lang)

    def get_system_prompt(self) -> str:
        return self.get("system_prompt", "你是一个智能助手，名叫芬璃尔。请用中文回应用户，简洁准确。")

    def set_system_prompt(self, prompt: str) -> None:
        self.set("system_prompt", prompt)

    def get_max_history(self) -> int:
        return self.get("max_history", 50)

    def is_safety_checks_enabled(self) -> bool:
        return self.get("safety_checks", True)

    def to_dict(self) -> Dict[str, Any]:
        return dict(self._config)

    def export(self) -> str:
        return json.dumps(self._config, ensure_ascii=False, indent=2)

    def import_config(self, json_str: str) -> bool:
        try:
            data = json.loads(json_str)
            if isinstance(data, dict):
                self._config = data
                self._save()
                return True
            return False
        except json.JSONDecodeError:
            return False

    def reset_to_defaults(self) -> None:
        self._config = dict(DEFAULT_CONFIG)
        self._save()