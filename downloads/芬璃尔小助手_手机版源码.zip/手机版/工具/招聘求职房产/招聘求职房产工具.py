TOOL_lagou_sdk = {
    "name": "lagou_sdk", "display_name": "拉勾", "category": "招聘求职",
    "description": "接入拉勾网职位搜索与投递接口，支持按行业、经验、薪资等维度筛选互联网技术类职位。",
    "scenarios": ["互联网职位搜索", "技术岗位薪资查询", "公司评价浏览", "职位投递管理"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": ["boss_sdk"],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "拉勾偏重互联网行业，建议结合其他平台全面搜索。注意遵守反爬协议。",
    "github_stars": 800, "open_source": True,
    "download_command": "pip install lagou-sdk",
    "fallback": ["boss_sdk", "zhaopin_sdk"]
}

TOOL_zhaopin_sdk = {
    "name": "zhaopin_sdk", "display_name": "智联", "category": "招聘求职",
    "description": "连接智联招聘开放平台，实现职位发布、简历搜索和招聘流程管理功能。",
    "scenarios": ["企业招聘职位发布", "简历库批量搜索", "招聘流程管理", "行业薪资报告"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["51job_sdk"],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "智联覆盖全行业全品类岗位，企业用户需先完成资质认证。",
    "github_stars": 600, "open_source": True,
    "download_command": "pip install zhaopin-sdk",
    "fallback": ["51job_sdk", "boss_sdk"]
}

TOOL_51job_sdk = {
    "name": "51job_sdk", "display_name": "前程无忧", "category": "招聘求职",
    "description": "对接前程无忧招聘平台，支持职位搜索、简历投递和招聘数据分析。",
    "scenarios": ["综合岗位搜索", "应届生招聘", "行业薪资对比", "招聘会信息查询"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["zhaopin_sdk"],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "前程无忧传统行业岗位资源丰富，是应届生求职的重要渠道。",
    "github_stars": 500, "open_source": True,
    "download_command": "pip install job51-sdk",
    "fallback": ["zhaopin_sdk", "liepin_sdk"]
}

TOOL_liepin_sdk = {
    "name": "liepin_sdk", "display_name": "猎聘", "category": "招聘求职",
    "description": "集成猎聘网中高端人才招聘服务，支持猎头对接、高端职位搜索和人才简历匹配。",
    "scenarios": ["中高端职位搜索", "猎头服务对接", "职业发展咨询", "行业精英人脉"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["linkedin_api"],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "猎聘偏重中高端职位（年薪15万以上），建议完善个人职业档案以获得精准推荐。",
    "github_stars": 700, "open_source": True,
    "download_command": "pip install liepin-sdk",
    "fallback": ["linkedin_api", "boss_sdk"]
}

TOOL_boss_sdk = {
    "name": "boss_sdk", "display_name": "BOSS直聘", "category": "招聘求职",
    "description": "接入 BOSS 直聘直聊模式，支持职位搜索、即时沟通和面试安排管理。",
    "scenarios": ["互联网岗位搜索", "与HR在线直聊", "面试进度跟踪", "薪资谈判参考"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["lagou_sdk"],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "BOSS 直聘核心优势是直聊模式，建议主动沟通而非被动等待。响应率上午10-11点最高。",
    "github_stars": 1200, "open_source": True,
    "download_command": "pip install boss-sdk",
    "fallback": ["lagou_sdk", "zhaopin_sdk"]
}

TOOL_indeed_sdk = {
    "name": "indeed_sdk", "display_name": "Indeed", "category": "招聘求职",
    "description": "对接 Indeed 全球职位搜索引擎，聚合多平台招聘信息，支持多语言和国家地区的职位检索。",
    "scenarios": ["海外职位搜索", "多平台职位聚合", "薪资对比分析", "公司评价查看"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "Indeed 是全球最大职位搜索引擎，适合海外求职。Sponsored 职位通常回复更快。",
    "github_stars": 900, "open_source": True,
    "download_command": "pip install indeed-sdk",
    "fallback": ["linkedin_api", "boss_sdk"]
}

TOOL_linkedin_api = {
    "name": "linkedin_api", "display_name": "领英", "category": "招聘求职",
    "description": "通过领英 API 获取职业档案、职位信息、企业主页和行业人脉数据，支持 OAuth 2.0 认证。",
    "scenarios": ["职业社交网络分析", "海外人脉拓展", "企业招聘主页管理", "行业动态追踪"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["liepin_sdk"],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "领英中国已更名为领英职场，API 使用需遵守领英开发者协议。建议完善个人档案以提升曝光。",
    "github_stars": 3500, "open_source": True,
    "download_command": "pip install linkedin-api",
    "fallback": ["indeed_sdk", "liepin_sdk"]
}

TOOL_job_analyzer = {
    "name": "job_analyzer", "display_name": "岗位分析", "category": "招聘求职",
    "description": "对职位描述（JD）进行关键词提取、技能需求分析和薪资合理性评估，辅助求职者和招聘方做出更优决策。",
    "scenarios": ["JD 关键词提取", "岗位技能雷达图", "薪资水平评估", "行业需求趋势分析"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "low", "requires_network": False,
    "usage_tips": "建议收集同一岗位至少10份 JD 进行综合对比，分析结果更具代表性。",
    "github_stars": 1000, "open_source": True,
    "download_command": "pip install job-analyzer",
    "fallback": ["recruitment_filter"]
}

TOOL_resume_parser = {
    "name": "resume_parser", "display_name": "简历解析", "category": "招聘求职",
    "description": "利用 OCR 和 NLP 技术对 PDF、Word 等格式简历进行结构化解析，提取个人信息、教育背景、工作经历和技能标签。",
    "scenarios": ["简历批量解析入库", "候选人技能画像", "简历与 JD 匹配", "人才库建设"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "PDF 简历解析准确率高于图片格式。建议使用标准排版模板以提高解析精度。",
    "github_stars": 2800, "open_source": True,
    "download_command": "pip install resume-parser",
    "fallback": ["job_analyzer"]
}

TOOL_recruitment_filter = {
    "name": "recruitment_filter", "display_name": "招聘筛选", "category": "招聘求职",
    "description": "基于多维度条件（学历、经验、技能、薪资、地点等）对候选人或职位进行智能过滤和排序推荐。",
    "scenarios": ["候选人初筛", "职位智能推荐", "简历优先级排序", "招聘漏斗分析"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "medium", "requires_network": False,
    "usage_tips": "筛选条件建议设置合理的宽松度，过于严格的条件可能导致优质候选人被误过滤。",
    "github_stars": 600, "open_source": True,
    "download_command": "pip install recruitment-filter",
    "fallback": ["job_analyzer", "resume_parser"]
}

TOOL_lianjia_sdk = {
    "name": "lianjia_sdk", "display_name": "链家", "category": "房产服务",
    "description": "接入链家房产数据接口，查询二手房、新房和租房房源信息，包括户型、面积、单价和历史成交记录。",
    "scenarios": ["二手房源搜索", "小区房价查询", "历史成交价对比", "学区房筛选"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["beike_sdk"],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "链家数据真实度较高，但挂牌价与成交价可能存在差异。建议参考同小区近期成交均价。",
    "github_stars": 1500, "open_source": True,
    "download_command": "pip install lianjia-sdk",
    "fallback": ["beike_sdk", "anjuke_sdk"]
}

TOOL_beike_sdk = {
    "name": "beike_sdk", "display_name": "贝壳", "category": "房产服务",
    "description": "对接贝壳找房开放平台，获取新房、二手房、租房及商业地产的全面房源数据和经纪人信息。",
    "scenarios": ["新房楼盘查询", "二手房源对比", "租房信息检索", "经纪人服务对接"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["lianjia_sdk"],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "贝壳覆盖链家、德佑等多个品牌，房源信息全但需注意不同品牌服务费差异。",
    "github_stars": 1100, "open_source": True,
    "download_command": "pip install beike-sdk",
    "fallback": ["lianjia_sdk", "anjuke_sdk"]
}

TOOL_anjuke_sdk = {
    "name": "anjuke_sdk", "display_name": "安居客", "category": "房产服务",
    "description": "连接安居客房产信息平台，提供二手房、新房、租房和商铺写字楼等全面的房产信息查询。",
    "scenarios": ["二手房信息搜索", "租房房源检索", "商铺写字楼查询", "房产资讯获取"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "安居客房源信息量大但质量参差不齐，建议结合经纪人认证标识筛选真实房源。",
    "github_stars": 800, "open_source": True,
    "download_command": "pip install anjuke-sdk",
    "fallback": ["lianjia_sdk", "beike_sdk"]
}

TOOL_house_price = {
    "name": "house_price", "display_name": "房价分析", "category": "房产服务",
    "description": "基于多源房产交易数据构建房价分析模型，支持小区均价走势、区域价格热力图和投资回报率计算。",
    "scenarios": ["小区历史均价走势", "城市区域价格对比", "房产投资回报分析", "房价预测模型"],
    "accuracy": 3, "efficiency": 4, "speed": 3,
    "conflicts_with": [],
    "safety_level": "low", "requires_network": True,
    "usage_tips": "房价分析受政策、市场情绪等多因素影响，预测结果仅供参考。建议关注近6个月成交数据。",
    "github_stars": 2000, "open_source": True,
    "download_command": "pip install house-price-analysis",
    "fallback": ["lianjia_sdk", "beike_sdk"]
}

TOOL_rent_comparison = {
    "name": "rent_comparison", "display_name": "租房对比", "category": "房产服务",
    "description": "聚合多个租房平台的房源信息，从价格、位置、户型、配套设施等多维度进行智能对比分析。",
    "scenarios": ["租房价格对比", "通勤时间计算", "周边配套评估", "租房性价比评分"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "low", "requires_network": True,
    "usage_tips": "租房价格受季节性波动影响较大，每年6-8月和12-2月为租赁旺季价格较高。",
    "github_stars": 1300, "open_source": True,
    "download_command": "pip install rent-compare",
    "fallback": ["anjuke_sdk", "lianjia_sdk"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}