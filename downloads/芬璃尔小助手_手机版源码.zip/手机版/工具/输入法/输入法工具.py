TOOL_PYNPT = {
    "name": "pynput",
    "display_name": "Pynput 输入模拟",
    "description": "跨平台的键盘和鼠标输入监控与模拟库。支持全局热键监听、按键记录和精确的输入事件注入。",
    "category": "输入法工具",
    "scenarios": ["自动化测试", "热键监听与响应", "键盘宏录制回放", "游戏外挂防护检测", "无障碍输入辅助"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "Linux 上需要 root 权限或 uinput 组权限；macOS 需在辅助功能中授权",
    "github_stars": 9500,
    "open_source": True,
    "download_command": "pip install pynput",
    "fallback": ["keyboard", "pyautogui"]
}

TOOL_KEYBOARD = {
    "name": "keyboard",
    "display_name": "Keyboard 键盘钩子",
    "description": "纯 Python 的键盘全局钩子库，支持注册热键、录制键盘事件、模拟按键和等待特定按键。",
    "category": "输入法工具",
    "scenarios": ["全局快捷键注册", "键盘宏自动化", "键盘事件录制", "游戏脚本编写", "系统级热键工具"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "Windows 上使用全局钩子需要管理员权限；hook() 回调中不要执行耗时操作",
    "github_stars": 4600,
    "open_source": True,
    "download_command": "pip install keyboard",
    "fallback": ["pynput", "pyautogui"]
}

TOOL_MOUSE = {
    "name": "mouse",
    "display_name": "Mouse 鼠标钩子",
    "description": "键盘库的姐妹库，提供鼠标全局钩子功能。支持鼠标事件监听、点击模拟和鼠标轨迹录制。",
    "category": "输入法工具",
    "scenarios": ["鼠标自动化操作", "点击位置监控", "鼠标宏录制回放", "自动化测试脚本", "UI 交互录制"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "与 keyboard 库配合使用实现完整输入自动化；move() 和 click() 是最常用函数",
    "github_stars": 1500,
    "open_source": True,
    "download_command": "pip install mouse",
    "fallback": ["pynput", "pyautogui"]
}

TOOL_PYAUTOGUI = {
    "name": "pyautogui",
    "display_name": "PyAutoGUI 键盘控制",
    "description": "跨平台的 GUI 自动化库，通过屏幕坐标控制鼠标键盘。支持图像识别定位、屏幕截图和消息弹窗。",
    "category": "输入法工具",
    "scenarios": ["GUI 自动化测试", "重复操作自动化", "批量文件处理自动化", "图像模板匹配点击", "RPA 机器人流程自动化"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "加入 pyautogui.FAILSAFE=True 和 PAUSE=0.5 防止失控；locateOnScreen() 用于图像定位",
    "github_stars": 11000,
    "open_source": True,
    "download_command": "pip install pyautogui",
    "fallback": ["pynput", "keyboard", "mouse"]
}

TOOL_PYTHON_XLIB = {
    "name": "python-xlib",
    "display_name": "python-xlib X11 输入",
    "description": "X Window System 的 Python 客户端库，直接操作 X11 协议。支持底层窗口管理、事件监听和输入模拟。",
    "category": "输入法工具",
    "scenarios": ["Linux 桌面自动化", "X11 窗口管理", "远程 X 服务器控制", "Wayland 兼容场景", "多显示器管理"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "仅适用于 X11 环境，Wayland 下需使用 xdotool 或 wtype 替代",
    "github_stars": 1400,
    "open_source": True,
    "download_command": "pip install python-xlib",
    "fallback": ["xdotool", "pyautogui"]
}

TOOL_UINPUT = {
    "name": "uinput",
    "display_name": "uinput Linux 输入设备",
    "description": "Linux 内核 uinput 模块的 Python 接口，可在用户态创建虚拟输入设备，模拟键盘、鼠标、触摸板等硬件输入。",
    "category": "输入法工具",
    "scenarios": ["Linux 内核级输入模拟", "虚拟输入设备创建", "嵌入设备输入控制", "自动化测试设备模拟", "游戏控制器模拟"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "需要 root 权限或加入 input 用户组；支持模拟游戏手柄、触摸屏等复杂输入设备",
    "github_stars": 600,
    "open_source": True,
    "download_command": "pip install python-uinput",
    "fallback": ["python-xlib", "evdev"]
}

TOOL_SENDKEYS = {
    "name": "sendkeys",
    "display_name": "SendKeys 按键发送",
    "description": "Windows 平台专用的按键发送库，通过 Windows API 模拟键盘输入。支持特殊键、组合键和 Unicode 字符输入。",
    "category": "输入法工具",
    "scenarios": ["Windows 应用自动化", "旧版 GUI 程序控制", "按键序列批量发送", "游戏按键模拟", "系统登录自动填充"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "仅限 Windows 平台；SendKeys.SendWait() 会等待按键处理完成再继续",
    "github_stars": 300,
    "open_source": True,
    "download_command": "pip install SendKeys",
    "fallback": ["pywin32", "pyautogui"]
}

TOOL_CTYPES_INPUT = {
    "name": "ctypes-virtual-input",
    "display_name": "CTypes 虚拟输入",
    "description": "通过 Python 的 ctypes 调用 Windows API (user32.dll) 实现底层虚拟输入，无需任何第三方依赖。",
    "category": "输入法工具",
    "scenarios": ["零依赖输入模拟", "Windows API 直接调用", "嵌入脚本输入控制", "最小环境自动化", "系统级按键注入"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "Windows 标准库即可运行；使用 SendInput API 而非 keybd_event 更可靠",
    "github_stars": 200,
    "open_source": True,
    "download_command": "无需安装，Python 标准库自带",
    "fallback": ["sendkeys", "pywin32", "pyautogui"]
}

TOOL_WIN32EVENT = {
    "name": "win32event",
    "display_name": "win32event Windows 事件",
    "description": "基于 PyWin32 的 Windows 事件驱动输入控制，利用 Windows 消息队列模拟键盘和鼠标事件。",
    "category": "输入法工具",
    "scenarios": ["Windows 消息队列操作", "后台窗口按键发送", "Windows 服务自动化", "无窗口环境输入控制", "企业级 Windows 自动化"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "PostMessage 发送后台消息，SendMessage 同步等待处理；配合 Spy++ 调试消息参数",
    "github_stars": 150,
    "open_source": True,
    "download_command": "pip install pywin32",
    "fallback": ["pywin32", "ctypes-virtual-input", "pyautogui"]
}

TOOL_PYwINAUTO = {
    "name": "pywinauto",
    "display_name": "Pywinauto Windows GUI 自动化",
    "description": "Windows GUI 自动化权威库，基于控件识别而非坐标定位。支持 WinForms/WPF/Qt/MFC 等主流 UI 框架。",
    "category": "输入法工具",
    "scenarios": ["Windows 桌面应用自动化测试", "UI 控件精准操作", "跨进程窗口管理", "安装程序自动交互", "企业软件自动化部署"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "使用 inspect.exe 或 Accessibility Insights 查看控件属性；print_control_identifiers() 调试定位",
    "github_stars": 5000,
    "open_source": True,
    "download_command": "pip install pywinauto",
    "fallback": ["uiautomation", "pyautogui", "win32event"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}