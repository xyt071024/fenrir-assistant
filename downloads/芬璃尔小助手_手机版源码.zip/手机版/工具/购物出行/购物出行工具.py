# ========== 购物 ==========

TOOL_TAOBAO = {
    "name": "taobao-sdk",
    "display_name": "淘宝SDK",
    "description": "淘宝开放平台Python SDK，支持商品搜索、订单管理、优惠券查询和店铺运营等电商全链路功能。",
    "category": "购物",
    "scenarios": ["商品搜索与详情", "订单管理", "优惠券领取", "店铺运营", "电商数据分析"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["jd-sdk", "pdd-sdk"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需要申请淘宝开放平台AppKey；API有严格的调用频率限制",
    "github_stars": "2k+ (taobao-sdk-python)",
    "open_source": True,
    "download_command": "pip install taobao-sdk-python",
    "fallback": ["jd-sdk", "pdd-sdk"]
}

TOOL_JD = {
    "name": "jd-sdk",
    "display_name": "京东SDK",
    "description": "京东开放平台Python SDK，支持商品查询、价格监控、库存管理和京东物流追踪。",
    "category": "购物",
    "scenarios": ["商品检索", "价格监控", "京东物流查询", "订单同步", "店铺数据"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["taobao-sdk", "pdd-sdk"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需申请京东宙斯权限；签名算法较为复杂，注意参数排序",
    "github_stars": "1.5k+ (jd-sdk-python)",
    "open_source": True,
    "download_command": "pip install jd-sdk",
    "fallback": ["taobao-sdk", "pdd-sdk"]
}

TOOL_PDD = {
    "name": "pdd-sdk",
    "display_name": "拼多多SDK",
    "description": "拼多多开放平台Python SDK，支持拼团查询、商品搜索、多多进宝和优惠券推广。",
    "category": "购物",
    "scenarios": ["拼团数据", "多多进宝推广", "商品比价", "优惠券查询", "社交电商"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["taobao-sdk", "jd-sdk"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "多多进寶API适合推广返利场景；注意拼多多API文档更新频率",
    "github_stars": "1k+ (pdd-sdk)",
    "open_source": True,
    "download_command": "pip install pdd-sdk",
    "fallback": ["taobao-sdk", "jd-sdk"]
}

TOOL_1688 = {
    "name": "1688-sdk",
    "display_name": "1688采购",
    "description": "阿里巴巴1688采购批发平台SDK，支持供应商搜索、商品询价、采购订单管理和供应链对接。",
    "category": "购物",
    "scenarios": ["批发采购", "供应商查找", "商品询价比价", "批量采购", "供应链管理"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["taobao-sdk"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需注册1688开发者账号；企业采购场景推荐使用诚信通会员API",
    "github_stars": "800+ (1688-sdk-python)",
    "open_source": True,
    "download_command": "pip install 1688-sdk",
    "fallback": ["taobao-sdk", "jd-sdk"]
}

TOOL_AMAZON = {
    "name": "amazon-sdk",
    "display_name": "亚马逊广告",
    "description": "亚马逊广告平台SDK(Amazon Advertising API)，支持Sponsored Products、Sponsored Brands广告管理和商品推广。",
    "category": "购物",
    "scenarios": ["亚马逊广告管理", "商品推广优化", "关键词分析", "广告报表", "跨境电商运营"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["aliexpress-sdk"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需要亚马逊卖家或广告主账号；API分区按站点区分(NA/EU/FE)",
    "github_stars": "1.2k+ (python-amazon-advertising-api)",
    "open_source": True,
    "download_command": "pip install amazon-advertising-api",
    "fallback": ["aliexpress-sdk", "taobao-sdk"]
}

TOOL_ALIEXPRESS = {
    "name": "aliexpress-sdk",
    "display_name": "速卖通",
    "description": "阿里旗下跨境电商平台SDK，支持国际商品发布、跨境物流追踪和多语言商品管理。",
    "category": "购物",
    "scenarios": ["跨境电商运营", "国际商品发布", "跨境物流追踪", "多语言商品管理", "海外市场分析"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["amazon-sdk"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需速卖通卖家账号；注意不同国家的税率和物流规则差异",
    "github_stars": "600+ (aliexpress-sdk)",
    "open_source": True,
    "download_command": "pip install aliexpress-sdk",
    "fallback": ["amazon-sdk", "taobao-sdk"]
}

TOOL_PRICE_MONITOR = {
    "name": "price-monitor",
    "display_name": "比价工具",
    "description": "多平台商品比价监控工具，自动采集淘宝、京东、拼多多等平台商品价格，支持价格变动提醒。",
    "category": "购物",
    "scenarios": ["商品比价", "价格监控", "降价提醒", "历史价格追踪", "购物攻略"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "low",
    "requires_network": True,
    "usage_tips": "爬虫方式采集数据需遵守Robots协议；部分平台反爬严格需使用代理",
    "github_stars": "10k+ (价格监控开源项目)",
    "open_source": True,
    "download_command": "pip install price-monitor 或参考 GitHub 相关项目",
    "fallback": ["taobao-sdk", "jd-sdk", "pdd-sdk"]
}

TOOL_COUPON = {
    "name": "coupon-finder",
    "display_name": "优惠券工具",
    "description": "跨平台优惠券搜索和聚合工具，自动发现淘宝、京东、拼多多等平台的隐藏优惠券和返利信息。",
    "category": "购物",
    "scenarios": ["优惠券检索", "返利查询", "促销信息聚合", "省钱攻略", "购物决策"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "low",
    "requires_network": True,
    "usage_tips": "注意区分官方券和第三方券；部分返利需要绑定推广位ID",
    "github_stars": "5k+ (优惠券相关开源项目)",
    "open_source": True,
    "download_command": "pip install coupon-finder 或参考 GitHub 相关项目",
    "fallback": ["taobao-sdk", "pdd-sdk", "jd-sdk"]
}

# ========== 出行交通 ==========

TOOL_AMAP = {
    "name": "amap",
    "display_name": "高德地图",
    "description": "高德地图开放平台Python SDK，提供地理编码、路径规划、POI搜索、实时路况等LBS服务。",
    "category": "出行交通",
    "scenarios": ["地理编码/逆编码", "POI兴趣点搜索", "路径规划", "实时路况查询", "行政区划查询"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["baidu-map"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "需申请高德开放平台Key；个人开发者有每日调用次数限制",
    "github_stars": "3k+ (amap-sdk-python)",
    "open_source": True,
    "download_command": "pip install amap-sdk",
    "fallback": ["baidu-map"]
}

TOOL_BAIDU_MAP = {
    "name": "baidu-map",
    "display_name": "百度地图",
    "description": "百度地图开放平台Python SDK，提供位置服务、路线规划、地理围栏和地点检索等能力。",
    "category": "出行交通",
    "scenarios": ["地点检索", "驾车路线规划", "地理编码", "地理围栏", "实时路况"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["amap"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "百度坐标(BD09)与GPS坐标(WGS84)需要转换；服务端API有配额限制",
    "github_stars": "2.5k+ (baidu-map-sdk)",
    "open_source": True,
    "download_command": "pip install baidu-map-sdk",
    "fallback": ["amap"]
}

TOOL_GAODE_NAV = {
    "name": "gaode-navigation",
    "display_name": "导航工具",
    "description": "基于高德地图的导航功能封装，支持驾车、步行、骑行导航路线规划和多方案对比。",
    "category": "出行交通",
    "scenarios": ["驾车导航规划", "骑行路线规划", "步行导航", "多路线对比", "ETA预估"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["gaode-transit"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "导航API会消耗较多配额；建议缓存常用路线结果以减少API调用",
    "github_stars": "1k+ (导航相关开源项目)",
    "open_source": True,
    "download_command": "pip install amap-sdk  # 使用高德SDK的导航功能",
    "fallback": ["amap", "baidu-map"]
}

TOOL_GAODE_TRANSIT = {
    "name": "gaode-transit",
    "display_name": "公交查询",
    "description": "公交出行路线规划工具，支持公交、地铁、轮渡等多种公共交通方式的换乘查询。",
    "category": "出行交通",
    "scenarios": ["公交路线规划", "地铁换乘查询", "实时公交到站", "周边站点查询", "通勤方案"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["gaode-navigation"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "实时公交数据覆盖因城市而异；建议搭配城市交通卡数据使用",
    "github_stars": "800+ (公交查询开源项目)",
    "open_source": True,
    "download_command": "pip install amap-sdk  # 使用高德SDK的公交功能",
    "fallback": ["amap"]
}

TOOL_CTEXPRESS = {
    "name": "ctexpress",
    "display_name": "12306",
    "description": "中国铁路12306购票API封装，支持余票查询、时刻表查询、车次信息获取和票价查询。",
    "category": "出行交通",
    "scenarios": ["火车票余票查询", "列车时刻表", "车次信息", "票价查询", "行程规划"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "12306有反爬机制，请求频率过高会被封IP；建议添加合理延时和代理",
    "github_stars": "15k+ (12306相关开源项目)",
    "open_source": True,
    "download_command": "pip install 12306-api 或参考 GitHub 相关项目",
    "fallback": []
}

TOOL_FLIGHT = {
    "name": "flight-radar",
    "display_name": "航班雷达",
    "description": "航班跟踪和数据查询工具，支持实时航班状态、航线轨迹、航班延误分析和机场动态。",
    "category": "出行交通",
    "scenarios": ["航班实时状态", "航线轨迹追踪", "延误分析", "机场动态", "航班时刻查询"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "免费API有调用次数和数据延迟限制；商业使用需要购买授权",
    "github_stars": "6k+ (flightradar-client)",
    "open_source": True,
    "download_command": "pip install flightradar-client",
    "fallback": []
}

TOOL_DIDI = {
    "name": "didi-sdk",
    "display_name": "滴滴出行",
    "description": "滴滴出行开放平台SDK，支持打车服务集成、订单查询、费用预估和出行数据分析。",
    "category": "出行交通",
    "scenarios": ["打车服务集成", "用车费用预估", "出行订单管理", "企业出行管理", "出行数据分析"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "企业级API需要商务合作申请；个人开发者可体验基础查询服务",
    "github_stars": "500+ (didi-sdk)",
    "open_source": True,
    "download_command": "pip install didi-sdk",
    "fallback": ["amap"]
}

# ========== 美食餐饮 ==========

TOOL_MEITUAN = {
    "name": "meituan-sdk",
    "display_name": "美团SDK",
    "description": "美团开放平台Python SDK，支持团购查询、商家信息获取、外卖配送和评价数据。",
    "category": "美食餐饮",
    "scenarios": ["团购信息查询", "商家详情", "外卖配送追踪", "美食推荐", "餐饮数据分析"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["eleme"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需要申请美团开放平台权限；部分API要求企业认证",
    "github_stars": "1.5k+ (meituan-sdk)",
    "open_source": True,
    "download_command": "pip install meituan-sdk",
    "fallback": ["dianping", "eleme"]
}

TOOL_DIANPING = {
    "name": "dianping",
    "display_name": "大众点评",
    "description": "大众点评数据查询工具，支持商户搜索、排行榜、用户点评和消费信息获取。",
    "category": "美食餐饮",
    "scenarios": ["美食排行榜", "餐厅搜索", "用户点评分析", "商圈美食探索", "消费决策"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["meituan-sdk"],
    "safety_level": "low",
    "requires_network": True,
    "usage_tips": "点评数据反爬严格；建议使用官方合作渠道获取数据",
    "github_stars": "3k+ (dianping开源项目)",
    "open_source": True,
    "download_command": "参考 GitHub 相关开源项目",
    "fallback": ["meituan-sdk", "dianping-reviews"]
}

TOOL_ELEME = {
    "name": "eleme",
    "display_name": "饿了么",
    "description": "饿了么开放平台SDK，支持外卖搜索、店铺信息、配送追踪和营销活动管理。",
    "category": "美食餐饮",
    "scenarios": ["外卖搜索", "店铺详情", "配送轨迹追踪", "营销活动", "餐饮数据分析"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["meituan-sdk"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需注册饿了么开放平台；配送信息接口需要商户授权",
    "github_stars": "1k+ (eleme-sdk)",
    "open_source": True,
    "download_command": "pip install eleme-sdk",
    "fallback": ["meituan-sdk", "dianping"]
}

TOOL_DIANPING_REVIEWS = {
    "name": "dianping-reviews",
    "display_name": "点评分析",
    "description": "大众点评评论分析工具，专注于用户评价采集、情感分析和评分趋势统计。",
    "category": "美食餐饮",
    "scenarios": ["用户评论采集", "情感分析", "评分趋势", "口碑监控", "竞品分析"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 2,
    "conflicts_with": ["dianping"],
    "safety_level": "low",
    "requires_network": True,
    "usage_tips": "评论采集需注意法律合规；建议使用NLP辅助情感分析提升准确度",
    "github_stars": "2k+ (点评分析开源项目)",
    "open_source": True,
    "download_command": "参考 GitHub 相关开源项目",
    "fallback": ["dianping", "meituan-sdk"]
}

TOOL_RECIPE = {
    "name": "recipe-scraper",
    "display_name": "食谱抓取",
    "description": "食谱数据采集和菜谱管理工具，支持从多个美食网站抓取菜谱、食材清单和烹饪步骤。",
    "category": "美食餐饮",
    "scenarios": ["菜谱采集", "食材清单管理", "烹饪步骤提取", "饮食规划", "营养分析"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "注意遵守目标网站的爬虫协议；推荐使用 recipe-scrapers 库",
    "github_stars": "5k+ (recipe-scrapers)",
    "open_source": True,
    "download_command": "pip install recipe-scrapers",
    "fallback": []
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}