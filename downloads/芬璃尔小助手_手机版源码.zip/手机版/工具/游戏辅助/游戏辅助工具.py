TOOL_pyautogui = {
    "name": "pyautogui", "display_name": "PyAutoGUI", "description": "跨平台GUI自动化库，模拟鼠标点击移动、键盘输入、屏幕截图和图像识别定位，适合PC端自动化脚本",
    "category": "游戏辅助工具", "scenarios": ["GUI自动化操作", "鼠标键盘模拟", "截图识别", "游戏脚本"],
    "accuracy": 3, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pydirectinput", "win32api"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "fail-safe功能：鼠标移到左上角紧急停止；locateOnScreen用于图像识别定位",
    "github_stars": 12000, "open_source": True,
    "download_command": "pip install pyautogui", "fallback": ["pydirectinput", "win32api"]
}

TOOL_opencv = {
    "name": "opencv-python", "display_name": "OpenCV", "description": "计算机视觉库，提供图像匹配、颜色检测、屏幕分析、模板匹配等能力，常用于游戏图像识别",
    "category": "游戏辅助工具", "scenarios": ["图像识别", "模板匹配", "颜色检测", "屏幕分析"],
    "accuracy": 5, "efficiency": 4, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "cv2.matchTemplate用于游戏内找图；配合pyautogui实现图像定位点击",
    "github_stars": 82000, "open_source": True,
    "download_command": "pip install opencv-python", "fallback": ["scikit-image", "pillow"]
}

TOOL_mss = {
    "name": "mss", "display_name": "MSS (截屏)", "description": "超高速屏幕捕获库，基于底层API实现每秒数百帧截屏，性能远优于PIL和pyautogui的截图功能",
    "category": "游戏辅助工具", "scenarios": ["高速屏幕捕获", "游戏画面采集", "实时屏幕监控", "帧率敏感场景"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["dxcam", "PIL.ImageGrab"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "使用with mss.mss() as sct上下文管理；monitor参数指定捕获区域",
    "github_stars": 3000, "open_source": True,
    "download_command": "pip install mss", "fallback": ["dxcam", "PIL.ImageGrab"]
}

TOOL_pydirectinput = {
    "name": "pydirectinput", "display_name": "PyDirectInput", "description": "专为游戏设计的鼠标键盘输入库，直接发送DirectInput信号，解决pyautogui在游戏中的输入无效问题",
    "category": "游戏辅助工具", "scenarios": ["游戏内输入模拟", "DirectInput键盘", "游戏鼠标控制"],
    "accuracy": 4, "efficiency": 4, "speed": 5,
    "conflicts_with": ["pyautogui", "win32api"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "按键按下时间需手动管理；部分游戏反作弊可能检测",
    "github_stars": 2000, "open_source": True,
    "download_command": "pip install pydirectinput", "fallback": ["pyautogui", "win32api"]
}

TOOL_keyboard = {
    "name": "keyboard", "display_name": "Keyboard", "description": "全局键盘监听和模拟库，支持热键绑定、键盘录制回放、后台按键检测，无需窗口焦点",
    "category": "游戏辅助工具", "scenarios": ["全局热键", "键盘宏录制", "后台按键监听", "组合快捷键"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pynput", "pyautogui"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "add_hotkey绑定热键回调；record/play实现按键录制回放；需管理员权限",
    "github_stars": 4000, "open_source": True,
    "download_command": "pip install keyboard", "fallback": ["pynput", "pyautogui"]
}

TOOL_mouse = {
    "name": "mouse", "display_name": "Mouse", "description": "全局鼠标监听和控制库，支持鼠标移动点击录制回放、滚轮控制、绝对/相对移动模式",
    "category": "游戏辅助工具", "scenarios": ["鼠标自动化", "鼠标宏", "点击录制回放", "鼠标轨迹模拟"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pynput", "pyautogui"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "hook全局监听鼠标事件；record/play录制回放操作序列",
    "github_stars": 1200, "open_source": True,
    "download_command": "pip install mouse", "fallback": ["pynput", "pyautogui"]
}

TOOL_pynput = {
    "name": "pynput", "display_name": "Pynput", "description": "跨平台输入监听和控制库，同时支持鼠标和键盘的监听与控制，适合需要精确输入的自动化场景",
    "category": "游戏辅助工具", "scenarios": ["输入监听", "鼠标键盘控制", "外挂防御测试", "自动化输入"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["keyboard", "mouse"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Listener线程模型非阻塞监听；支持stop()优雅退出；注意多线程竞争",
    "github_stars": 9000, "open_source": True,
    "download_command": "pip install pynput", "fallback": ["keyboard", "mouse"]
}

TOOL_win32api = {
    "name": "pywin32", "display_name": "Win32 API (pywin32)", "description": "Windows原生API的Python封装，提供窗口管理、进程控制、注册表操作、系统消息等底层能力",
    "category": "游戏辅助工具", "scenarios": ["窗口句柄操作", "进程管理", "系统级控制", "后台鼠标键盘"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["ctypes", "pythonnet"], "safety_level": "caution",
    "requires_network": False, "usage_tips": "win32gui.FindWindow找窗口句柄；win32api.SendMessage发消息；操作不当可能崩溃系统",
    "github_stars": 6000, "open_source": True,
    "download_command": "pip install pywin32", "fallback": ["ctypes", "comtypes"]
}

TOOL_dxcam = {
    "name": "dxcam", "display_name": "DXCAM", "description": "基于DirectX的极速屏幕捕获库，支持多显示器、区域捕获、GPU加速，帧率可达数百FPS",
    "category": "游戏辅助工具", "scenarios": ["游戏画面采集", "超高速屏幕捕获", "实时画面分析", "录屏"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["mss", "PIL.ImageGrab"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "仅Windows+DirectX环境可用；grab(region)指定区域；output参数指定格式",
    "github_stars": 2000, "open_source": True,
    "download_command": "pip install dxcam", "fallback": ["mss", "PIL.ImageGrab"]
}

TOOL_ahk = {
    "name": "ahk", "display_name": "AutoHotkey (AHK)", "description": "AutoHotkey脚本引擎的Python绑定，调用AHK实现热键映射、宏录制、窗口管理和游戏自动化",
    "category": "游戏辅助工具", "scenarios": ["热键映射", "游戏宏", "自动化脚本", "窗口管理"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["keyboard+mouse", "pynput"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "需要系统已安装AutoHotkey；ahk库作为桥接调用AHK脚本",
    "github_stars": 500, "open_source": True,
    "download_command": "pip install ahk", "fallback": ["keyboard+mouse", "pynput"]
}

TOOL_vgamepad = {
    "name": "vgamepad", "display_name": "vGamePad", "description": "虚拟游戏手柄库，模拟Xbox手柄的按钮、摇杆、扳机和震动，无需物理手柄即可控制游戏",
    "category": "游戏辅助工具", "scenarios": ["虚拟手柄", "游戏手柄模拟", "自动化游戏操作", "手柄测试"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["xinput", "ds4windows"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "需要安装ViGEmBus驱动；支持Xbox 360/One/Elite手柄模拟",
    "github_stars": 1500, "open_source": True,
    "download_command": "pip install vgamepad", "fallback": ["xinput", "ds4windows"]
}

TOOL_ds4windows = {
    "name": "ds4windows", "display_name": "DS4Windows", "description": "DS4手柄模拟库，将DualShock/DualSense手柄映射为Xbox手柄，支持蓝牙连接和自定义配置",
    "category": "游戏辅助工具", "scenarios": ["PS手柄映射", "手柄连接管理", "手柄键位配置", "蓝牙手柄适配"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["vgamepad", "xinput"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "独立程序非Python库；需安装对应驱动；支持自定义映射配置",
    "github_stars": 5000, "open_source": True,
    "download_command": "下载安装从官网 https://ds4-windows.com/", "fallback": ["vgamepad", "xinput"]
}

TOOL_discord_rich_presence = {
    "name": "discord-rich-presence", "display_name": "Discord Rich Presence", "description": "Discord游戏状态集成库，在Discord资料卡显示正在玩的游戏、时长、自定义文本和按钮",
    "category": "游戏辅助工具", "scenarios": ["Discord状态同步", "游戏陪玩状态", "直播状态展示", "社区互动"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["custom-rpc"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需在Discord Developer Portal注册应用获取Client ID；支持大图和小图展示",
    "github_stars": 3000, "open_source": True,
    "download_command": "pip install pypresence", "fallback": ["discord.py", "custom-rpc"]
}

TOOL_overwolf = {
    "name": "overwolf", "display_name": "Overwolf API", "description": "游戏插件平台Overwolf的Python接口，用于开发游戏内覆盖UI、录屏、数据统计和直播工具",
    "category": "游戏辅助工具", "scenarios": ["游戏内覆盖UI", "游戏数据统计", "游戏录屏", "电竞辅助工具"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需安装Overwolf桌面客户端；通过HTTP API通信；支持JS+Python混编",
    "github_stars": 500, "open_source": True,
    "download_command": "pip install overwolf", "fallback": []
}

TOOL_xinput = {
    "name": "xinput", "display_name": "XInput (Xbox手柄)", "description": "Xbox手柄输入控制的Python封装，读取手柄状态（摇杆/扳机/按键/震动），支持多手柄连接",
    "category": "游戏辅助工具", "scenarios": ["手柄状态读取", "Xbox手柄控制", "手柄震动反馈", "多手柄管理"],
    "accuracy": 5, "efficiency": 4, "speed": 5,
    "conflicts_with": ["vgamepad", "ds4windows"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "仅支持Windows；使用XInput.get_state()读取手柄状态；最多支持4个手柄",
    "github_stars": 800, "open_source": True,
    "download_command": "pip install xinput", "fallback": ["vgamepad", "ds4windows"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}