TOOL_yt_dlp = {
    "name": "yt_dlp", "display_name": "yt-dlp", "description": "youtube-dl的活跃分支，支持YouTube/B站/Twitter/抖音等上千个网站的音频视频下载",
    "category": "网络下载", "scenarios": ["视频下载", "音频提取", "播放列表批量下载", "字幕下载"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["you-get", "lux"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "-f best[ext=mp4]选择最佳MP4格式，--extract-audio提取音频，--write-subs下载字幕",
    "github_stars": 99000, "open_source": True,
    "download_command": "pip install yt-dlp", "fallback": ["you-get", "lux"]
}

TOOL_aria2p = {
    "name": "aria2p", "display_name": "aria2p", "description": "Aria2下载工具的Python管理接口，支持多连接下载、BT/磁力链、RPC远程控制",
    "category": "网络下载", "scenarios": ["多线程下载加速", "BT下载管理", "批量下载任务管理"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["transmissionrpc", "qbittorrent-api"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需预先安装aria2本体，通过RPC接口连接，支持添加/暂停/移除下载任务",
    "github_stars": 1500, "open_source": True,
    "download_command": "pip install aria2p && winget install aria2", "fallback": ["qbittorrent-api", "transmissionrpc"]
}

TOOL_speedtest_cli = {
    "name": "speedtest_cli", "display_name": "speedtest-cli", "description": "基于Speedtest.net的网速测试工具，测试上下行带宽和延迟，命令行和API双模式",
    "category": "网络下载", "scenarios": ["带宽测试", "网络质量检测", "延迟测量"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["自有测速方案"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "speedtest-cli --share可生成分享结果图，--server筛选特定测速服务器",
    "github_stars": 14000, "open_source": True,
    "download_command": "pip install speedtest-cli", "fallback": ["requests手动测速"]
}

TOOL_requests = {
    "name": "requests", "display_name": "Requests", "description": "最流行的Python HTTP库，支持文件分块下载、断点续传、流式下载、多线程下载",
    "category": "网络下载", "scenarios": ["文件下载", "流式下载", "断点续传", "分块下载"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["httpx", "aiohttp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "stream=True流式下载大文件，headers添加Range头实现断点续传",
    "github_stars": 53000, "open_source": True,
    "download_command": "pip install requests", "fallback": ["httpx", "wget"]
}

TOOL_aiohttp = {
    "name": "aiohttp", "display_name": "aiohttp", "description": "异步HTTP客户端，高并发下载框架，支持连接池复用，适合批量文件下载场景",
    "category": "网络下载", "scenarios": ["批量文件并发下载", "异步下载加速", "下载队列管理"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["requests", "httpx"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "ClientSession配合asyncio.gather实现并发下载，semaphore控制并发数",
    "github_stars": 26000, "open_source": True,
    "download_command": "pip install aiohttp", "fallback": ["httpx", "requests"]
}

TOOL_wget = {
    "name": "wget", "display_name": "wget", "description": "wget的Python移植版，一行代码下载文件，支持断点续传和进度显示，适合简单下载任务",
    "category": "网络下载", "scenarios": ["简单文件下载", "批量URL下载", "快速原型"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["requests", "curl"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "wget.download(url, out=path)一行下载，内置进度条显示下载进度",
    "github_stars": 5000, "open_source": True,
    "download_command": "pip install wget", "fallback": ["requests", "pycurl"]
}

TOOL_pycurl = {
    "name": "pycurl", "display_name": "PycURL", "description": "cURL的Python绑定，性能极高，支持SSL/TLS、代理、FTP、断点续传等丰富协议",
    "category": "网络下载", "scenarios": ["高性能下载", "FTP传输", "自定义协议请求"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["requests", "httpx"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "基于libcurl，API偏底层但功能全面，适合需要精细控制网络传输的场景",
    "github_stars": 1200, "open_source": True,
    "download_command": "pip install pycurl", "fallback": ["requests", "wget"]
}

TOOL_transmissionrpc = {
    "name": "transmissionrpc", "display_name": "transmissionrpc", "description": "Transmission BT客户端的RPC接口库，远程管理种子添加/下载/做种/移除等操作",
    "category": "网络下载", "scenarios": ["BT下载管理", "Transmission远程控制", "种子管理"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["qbittorrent-api", "aria2p"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "连接Transmission daemon的RPC端口，支持添加磁力链/种子文件和管理下载队列",
    "github_stars": 600, "open_source": True,
    "download_command": "pip install transmissionrpc", "fallback": ["qbittorrent-api", "aria2p"]
}

TOOL_qbittorrent_api = {
    "name": "qbittorrent_api", "display_name": "qbittorrent-api", "description": "qBittorrent Web API的Python封装，管理BT下载/做种/分类/RSS等完整功能",
    "category": "网络下载", "scenarios": ["qBittorrent远程管理", "BT自动化下载", "RSS订阅下载"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["transmissionrpc", "aria2p"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "Client连接qBittorrent WebUI，支持添加/暂停/删除/分类管理和RSS自动下载",
    "github_stars": 3000, "open_source": True,
    "download_command": "pip install qbittorrent-api", "fallback": ["transmissionrpc", "aria2p"]
}

TOOL_gallery_dl = {
    "name": "gallery_dl", "display_name": "gallery-dl", "description": "图库/画集下载器，支持Pixiv/DeviantArt/Danbooru/Twitter等数十个图片站点",
    "category": "网络下载", "scenarios": ["图片批量下载", "画集采集", "插画收藏", "漫画下载"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["yt-dlp(图片部分)"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "--range 1-50控制下载范围，--cookies cookies.txt使用登录态下载受限内容",
    "github_stars": 12000, "open_source": True,
    "download_command": "pip install gallery-dl", "fallback": ["yt-dlp", "instagram-downloader"]
}

TOOL_spotdl = {
    "name": "spotdl", "display_name": "spotdl", "description": "Spotify音乐下载器，从Spotify链接下载歌曲/专辑/播放列表为MP3格式",
    "category": "网络下载", "scenarios": ["Spotify音乐下载", "播放列表下载", "专辑下载"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["scdl"], "safety_level": "medium",
    "requires_network": True, "usage_tips": "spotdl [track_url]直接下载，--output-format指定输出格式，受版权限制可能失效",
    "github_stars": 18000, "open_source": True,
    "download_command": "pip install spotdl", "fallback": ["yt-dlp", "scdl"]
}

TOOL_scdl = {
    "name": "scdl", "display_name": "scdl", "description": "SoundCloud音乐下载器，支持下载音轨/播放列表/关注列表等个人内容",
    "category": "网络下载", "scenarios": ["SoundCloud音乐下载", "在线音乐离线", "DJ混音带下载"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["spotdl"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "scdl -l [track_url]下载单曲，scdl -f [favorites]下载喜欢列表",
    "github_stars": 3000, "open_source": True,
    "download_command": "pip install scdl", "fallback": ["yt-dlp", "spotdl"]
}

TOOL_tiktok_downloader = {
    "name": "tiktok_downloader", "display_name": "tiktok-downloader", "description": "TikTok视频/图片无水印下载器，支持用户主页/标签搜索/单个视频下载",
    "category": "网络下载", "scenarios": ["TikTok视频下载", "无水印保存", "批量采集"],
    "accuracy": 3, "efficiency": 3, "speed": 3,
    "conflicts_with": ["yt-dlp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "TikTok反爬频繁更新，工具可能间歇性失效，配合yt-dlp使用效果更好",
    "github_stars": 2000, "open_source": True,
    "download_command": "pip install tiktok-downloader", "fallback": ["yt-dlp", "bilibili-api"]
}

TOOL_bilibili_api = {
    "name": "bilibili_api", "display_name": "bilibili-api", "description": "B站非官方Python API，支持视频/直播/番剧/专栏/弹幕/评论等全面功能",
    "category": "网络下载", "scenarios": ["B站视频下载", "弹幕爬取", "直播监控", "评论分析"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["you-get", "lux"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持清晰度选择和大会员画质，需要SESSDATA登录获取更高画质",
    "github_stars": 15000, "open_source": True,
    "download_command": "pip install bilibili-api-python", "fallback": ["you-get", "lux"]
}

TOOL_you_get = {
    "name": "you_get", "display_name": "you-get", "description": "中国视频网站下载专用，支持优酷/B站/爱奇艺/腾讯视频等国内主流平台",
    "category": "网络下载", "scenarios": ["中国视频网站下载", "国内视频离线", "弹幕下载"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["yt-dlp", "lux"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "you-get [url]直接下载，--info查看可用清晰度格式，-o指定输出目录",
    "github_stars": 54000, "open_source": True,
    "download_command": "pip install you-get", "fallback": ["lux", "yt-dlp"]
}

TOOL_lux = {
    "name": "lux", "display_name": "Lux", "description": "Go语言编写的快速视频下载器，支持B站/优酷/芒果TV等中国视频站，下载速度快",
    "category": "网络下载", "scenarios": ["中国视频站快速下载", "批量下载", "多线程加速"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["you-get", "yt-dlp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "Go语言编写需单独安装二进制，多线程并发下载速度优于you-get",
    "github_stars": 29000, "open_source": True,
    "download_command": "需从GitHub Releases下载二进制文件", "fallback": ["you-get", "yt-dlp"]
}

TOOL_streamlink = {
    "name": "streamlink", "display_name": "Streamlink", "description": "流媒体下载工具，从Twitch/YouTube直播等流媒体服务提取视频流并保存",
    "category": "网络下载", "scenarios": ["直播录制", "流媒体保存", "m3u8流下载"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["m3u8-downloader", "yt-dlp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "streamlink [url] best -o output.ts 直播录制，支持自动重连",
    "github_stars": 12000, "open_source": True,
    "download_command": "pip install streamlink", "fallback": ["m3u8-downloader", "yt-dlp"]
}

TOOL_m3u8_downloader = {
    "name": "m3u8_downloader", "display_name": "m3u8-downloader", "description": "m3u8流视频下载器，支持AES-128解密、多线程下载、合并为MP4文件",
    "category": "网络下载", "scenarios": ["m3u8视频下载", "加密流解密", "分段视频合并"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["streamlink", "yt-dlp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "自动解析m3u8索引文件中的TS分段，支持key解密和并行下载提高速度",
    "github_stars": 6000, "open_source": True,
    "download_command": "pip install m3u8-downloader", "fallback": ["streamlink", "ffmpeg手动合并"]
}

TOOL_pytube = {
    "name": "pytube", "display_name": "pytube", "description": "轻量级YouTube下载库，无需第三方依赖，支持视频/音频流选择和字幕下载",
    "category": "网络下载", "scenarios": ["YouTube视频下载", "YouTube音频提取", "字幕下载"],
    "accuracy": 3, "efficiency": 3, "speed": 3,
    "conflicts_with": ["yt-dlp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "YouTube反爬频繁，pytube可能间歇性失效，推荐使用yt-dlp作为更稳定的替代",
    "github_stars": 13000, "open_source": True,
    "download_command": "pip install pytube", "fallback": ["yt-dlp", "lux"]
}

TOOL_instagram_downloader = {
    "name": "instagram_downloader", "display_name": "instagram-downloader", "description": "Instagram内容下载器，支持帖子/视频/Reels/Stories/IGTV等多元内容下载",
    "category": "网络下载", "scenarios": ["Instagram帖子下载", "Reels保存", "Stories归档"],
    "accuracy": 3, "efficiency": 3, "speed": 3,
    "conflicts_with": ["yt-dlp", "gallery-dl"], "safety_level": "medium",
    "requires_network": True, "usage_tips": "Instagram限制严格，需频繁更新Cookie，建议搭配gallery-dl使用效果更稳定",
    "github_stars": 1500, "open_source": True,
    "download_command": "pip install instagram-downloader", "fallback": ["gallery-dl", "yt-dlp"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
