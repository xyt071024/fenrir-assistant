import json
import requests
from pathlib import Path
from typing import Optional, Dict, List


class APIManager:
    """API管理器：自动识别模型、多Key管理、自定义API"""
    
    # 预设厂商及其API地址和模型列表
    PRESET_PROVIDERS = {
        "DeepSeek": {
            "base_url": "https://api.deepseek.com",
            "models_endpoint": "/models",
            "default_models": ["deepseek-chat", "deepseek-reasoner"]
        },
        "OpenAI": {
            "base_url": "https://api.openai.com",
            "models_endpoint": "/v1/models",
            "default_models": ["gpt-4o", "gpt-4o-mini"]
        },
        "通义千问": {
            "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
            "models_endpoint": "/models",
            "default_models": ["qwen-plus", "qwen-max"]
        },
        "豆包": {
            "base_url": "https://ark.cn-beijing.volces.com/api/v3",
            "models_endpoint": "/models",
            "default_models": ["doubao-pro", "doubao-lite"]
        },
        "Kimi": {
            "base_url": "https://api.moonshot.cn/v1",
            "models_endpoint": "/models",
            "default_models": ["moonshot-v1-8k", "moonshot-v1-32k"]
        },
        "智谱GLM": {
            "base_url": "https://open.bigmodel.cn/api/paas/v4",
            "models_endpoint": "/models",
            "default_models": ["glm-4-plus", "glm-4"]
        },
        "MiniMax": {
            "base_url": "https://api.minimax.chat/v1",
            "models_endpoint": "/models",
            "default_models": ["MiniMax-Text-01"]
        },
        "小米MiMo": {
            "base_url": "https://api.mi.com/v1",
            "models_endpoint": "/models",
            "default_models": ["mimo-pro"]
        },
        "零一万物": {
            "base_url": "https://api.lingyiwanwu.com/v1",
            "models_endpoint": "/models",
            "default_models": ["yi-34b-chat"]
        },
        "讯飞星火": {
            "base_url": "https://spark-api.xf-yun.com/v3.5",
            "models_endpoint": "/models",
            "default_models": ["spark-3.5", "spark-4.0"]
        },
        "百度文心": {
            "base_url": "https://aip.baidubce.com/rpc/2.0/ai_custom/v1",
            "models_endpoint": "/models",
            "default_models": ["ernie-4.0", "ernie-3.5"]
        },
        "百川智能": {
            "base_url": "https://api.baichuan-ai.com/v1",
            "models_endpoint": "/models",
            "default_models": ["Baichuan4", "Baichuan3"]
        },
        "阶跃星辰": {
            "base_url": "https://api.stepfun.com/v1",
            "models_endpoint": "/models",
            "default_models": ["step-2"]
        },
        "Claude": {
            "base_url": "https://api.anthropic.com",
            "models_endpoint": "/v1/models",
            "default_models": ["claude-3-5-sonnet", "claude-3-haiku"]
        },
        "Gemini": {
            "base_url": "https://generativelanguage.googleapis.com/v1beta",
            "models_endpoint": "/models",
            "default_models": ["gemini-2.0-flash", "gemini-2.0-pro"]
        },
        "Mistral": {
            "base_url": "https://api.mistral.ai/v1",
            "models_endpoint": "/models",
            "default_models": ["mistral-large", "mistral-medium"]
        },
        "Groq": {
            "base_url": "https://api.groq.com/openai/v1",
            "models_endpoint": "/models",
            "default_models": ["llama-3.3-70b", "mixtral-8x7b"]
        },
        "OpenRouter": {
            "base_url": "https://openrouter.ai/api/v1",
            "models_endpoint": "/models",
            "default_models": ["openrouter/auto"]
        },
        "Together AI": {
            "base_url": "https://api.together.xyz/v1",
            "models_endpoint": "/models",
            "default_models": ["mistralai/Mixtral-8x7B"]
        },
        "Ollama": {
            "base_url": "http://localhost:11434",
            "models_endpoint": "/api/tags",
            "default_models": []
        },
        "LM Studio": {
            "base_url": "http://localhost:1234/v1",
            "models_endpoint": "/models",
            "default_models": []
        },
        "vLLM": {
            "base_url": "http://localhost:8000/v1",
            "models_endpoint": "/models",
            "default_models": []
        }
    }
    
    def __init__(self, config_path=None):
        self.config_path = config_path or Path("data/api_config.json")
        self.providers = {}  # provider_name -> [key_configs]
        self.load_config()
    
    def load_config(self):
        """加载已有配置"""
        if self.config_path and Path(self.config_path).exists():
            with open(self.config_path, "r", encoding="utf-8") as f:
                self.providers = json.load(f)
    
    def save_config(self):
        """保存配置"""
        if self.config_path:
            self.config_path = Path(self.config_path)
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.providers, f, ensure_ascii=False, indent=2)
    
    def discover_models(self, provider_name, api_key, base_url=None):
        """发现指定API可用的所有模型"""
        provider_info = self.PRESET_PROVIDERS.get(provider_name)
        if not provider_info:
            return None
        
        url = base_url or provider_info["base_url"]
        models_url = url.rstrip("/") + provider_info.get("models_endpoint", "/models")
        
        try:
            headers = {"Authorization": f"Bearer {api_key}"}
            response = requests.get(models_url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                # 解析不同API返回格式的模型列表
                models = []
                if "data" in data:
                    # OpenAI兼容格式: {"data": [{"id": "gpt-4"}, ...]}
                    for item in data["data"]:
                        if isinstance(item, dict) and "id" in item:
                            models.append(item["id"])
                elif "models" in data:
                    # 自定义格式
                    models = data["models"]
                elif isinstance(data, list):
                    models = [m["name"] if isinstance(m, dict) else m for m in data]
                
                return models if models else provider_info.get("default_models", [])
            else:
                # API请求失败，返回默认模型列表
                return provider_info.get("default_models", [])
        except Exception:
            # 网络错误等，返回默认模型列表
            return provider_info.get("default_models", [])
    
    def add_api_key(self, provider_name, api_key, base_url=None, label=None):
        """添加一个API Key配置"""
        if provider_name not in self.providers:
            self.providers[provider_name] = []
        
        # 发现模型
        models = self.discover_models(provider_name, api_key, base_url)
        
        provider_info = self.PRESET_PROVIDERS.get(provider_name, {})
        
        key_config = {
            "api_key": api_key,
            "base_url": base_url or provider_info.get("base_url", ""),
            "label": label or f"{provider_name}{len(self.providers[provider_name]) + 1}",
            "models": models or [],
            "selected_models": models or [],  # 默认全选
            "enabled": True,
            "added_at": __import__('datetime').datetime.now().isoformat()
        }
        
        self.providers[provider_name].append(key_config)
        self.save_config()
        return key_config
    
    def add_custom_provider(self, name, base_url, api_key):
        """添加自定义API厂商"""
        # 先尝试发现模型
        try:
            headers = {"Authorization": f"Bearer {api_key}"}
            response = requests.get(
                base_url.rstrip("/") + "/models", 
                headers=headers, timeout=10
            )
            if response.status_code == 200:
                data = response.json()
                models = []
                if "data" in data:
                    for item in data["data"]:
                        if isinstance(item, dict) and "id" in item:
                            models.append(item["id"])
                else:
                    models = ["custom-model"]
            else:
                models = ["custom-model"]
        except Exception:
            models = ["custom-model"]
        
        # 保存
        key_config = {
            "api_key": api_key,
            "base_url": base_url,
            "label": name,
            "models": models,
            "selected_models": models,
            "enabled": True,
            "is_custom": True,
            "added_at": __import__('datetime').datetime.now().isoformat()
        }
        
        if "自定义" not in self.providers:
            self.providers["自定义"] = []
        self.providers["自定义"].append(key_config)
        self.save_config()
        return key_config
    
    def get_all_models_flat(self):
        """获取所有可用模型的扁平列表（用于模型选择器）"""
        result = []
        for provider_name, keys in self.providers.items():
            for key_config in keys:
                if not key_config.get("enabled", True):
                    continue
                label = key_config.get("label", provider_name)
                for model in key_config.get("selected_models", []):
                    result.append({
                        "provider": provider_name,
                        "label": label,
                        "model": model,
                        "api_key": key_config["api_key"],
                        "base_url": key_config["base_url"],
                    })
        return result
    
    def get_models_grouped(self):
        """按厂商分组获取模型（用于折叠菜单显示）"""
        result = []
        for provider_name, keys in self.providers.items():
            for key_config in keys:
                if not key_config.get("enabled", True):
                    continue
                label = key_config.get("label", provider_name)
                result.append({
                    "provider": provider_name,
                    "label": label,
                    "api_key": key_config["api_key"],
                    "base_url": key_config["base_url"],
                    "models": key_config.get("selected_models", []),
                })
        return result
    
    def update_selected_models(self, provider_name, api_key_prefix, models):
        """更新某个API Key下选中的模型"""
        for key_config in self.providers.get(provider_name, []):
            if key_config["api_key"].startswith(api_key_prefix):
                key_config["selected_models"] = models
                self.save_config()
                return True
        return False
    
    def remove_api_key(self, provider_name, index):
        """删除某个API Key"""
        if provider_name in self.providers and 0 <= index < len(self.providers[provider_name]):
            self.providers[provider_name].pop(index)
            if not self.providers[provider_name]:
                del self.providers[provider_name]
            self.save_config()
            return True
        return False


# 单例
_api_manager = None

def get_api_manager(config_path=None):
    global _api_manager
    if _api_manager is None:
        _api_manager = APIManager(config_path)
    return _api_manager
