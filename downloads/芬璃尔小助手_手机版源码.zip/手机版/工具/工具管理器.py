import ast
import re
from pathlib import Path
from functools import lru_cache


class ToolManager:
    def __init__(self, tools_dir="工具"):
        self.tools_dir = Path(tools_dir)
        self.registry = {}
        self.category_index = {}
        self.used_tools = set()
        self._cache = {}
        self._scanned = False

    def scan_and_register(self):
        if self._scanned:
            return
        if not self.tools_dir.is_dir():
            self._scanned = True
            return
        for cat_dir in sorted(self.tools_dir.iterdir()):
            if not cat_dir.is_dir():
                continue
            category = cat_dir.name
            for py_file in sorted(cat_dir.glob("*.py")):
                self._load_tools_from_file(py_file, category)
        self._scanned = True

    def _load_tools_from_file(self, filepath, default_category):
        try:
            source = filepath.read_text(encoding="utf-8")
            tree = ast.parse(source)
            for node in ast.walk(tree):
                if not isinstance(node, ast.Assign):
                    continue
                for target in node.targets:
                    if not isinstance(target, ast.Name) or not target.id.startswith("TOOL_"):
                        continue
                    if not isinstance(node.value, (ast.Dict,)):
                        continue
                    try:
                        tool_def = ast.literal_eval(node.value)
                    except (ValueError, TypeError):
                        tool_def = self._safe_eval_dict(node.value)
                    if not isinstance(tool_def, dict) or "name" not in tool_def:
                        continue
                    if "category" not in tool_def:
                        tool_def["category"] = default_category
                    name = tool_def["name"]
                    self.registry[name] = tool_def
                    cat = tool_def.get("category", default_category)
                    if cat not in self.category_index:
                        self.category_index[cat] = []
                    if name not in self.category_index[cat]:
                        self.category_index[cat].append(name)
        except Exception:
            pass

    def _safe_eval_dict(self, dict_node):
        result = {}
        for key_node, value_node in zip(dict_node.keys, dict_node.values):
            key = self._safe_eval_literal(key_node)
            if key is None or not isinstance(key, str):
                continue
            val = self._safe_eval_literal(value_node)
            result[key] = val
        return result

    def _safe_eval_literal(self, node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Str):
            return node.s
        if isinstance(node, ast.Num):
            return node.n
        if isinstance(node, ast.List):
            return [self._safe_eval_literal(e) for e in node.elts]
        if isinstance(node, ast.Dict):
            return self._safe_eval_dict(node)
        if isinstance(node, ast.Name):
            if node.id == "True":
                return True
            if node.id == "False":
                return False
            if node.id == "None":
                return None
            return node.id
        if isinstance(node, ast.Tuple):
            return tuple(self._safe_eval_literal(e) for e in node.elts)
        if isinstance(node, ast.Set):
            return {self._safe_eval_literal(e) for e in node.elts}
        return None

    def recommend(self, task_description, top_n=5):
        self.scan_and_register()
        cache_key = f"recommend:{task_description}:{top_n}"
        if cache_key in self._cache:
            return self._cache[cache_key]
        task_lower = task_description.lower()
        task_words = set(re.findall(r'[\w\u4e00-\u9fff]+', task_lower))
        scored = []
        for name, tool in self.registry.items():
            desc = tool.get("description", "").lower()
            scenarios = [s.lower() for s in tool.get("scenarios", [])]
            display = tool.get("display_name", "").lower()
            name_lower = tool.get("name", "").lower()
            scenario_text = " ".join(scenarios)
            score = 0
            for s in scenarios:
                if s in task_lower:
                    score += 3
            for w in task_words:
                if w in desc or w in scenario_text or w in name_lower or w in display:
                    score += 2
            if task_lower in desc or task_lower in name_lower:
                score += 5
            acc = tool.get("accuracy", 1)
            eff = tool.get("efficiency", 1)
            spd = tool.get("speed", 1)
            score += acc * 10 + eff * 5 + spd * 2
            scored.append((score, acc, eff, spd, tool))
        scored.sort(key=lambda x: (-x[0], -x[1], -x[2], -x[3]))
        result = [item[4] for item in scored[:top_n]]
        self._cache[cache_key] = result
        return result

    def 推荐工具(self, task_description, top_n=5):
        return self.recommend(task_description, top_n)

    def get_by_category(self, category):
        self.scan_and_register()
        names = self.category_index.get(category, [])
        return [self.registry[n] for n in names if n in self.registry]

    def check_conflicts(self, tool_name):
        self.scan_and_register()
        tool = self.registry.get(tool_name)
        if not tool:
            return {"has_conflict": False, "conflicts": [], "message": f"工具 {tool_name} 不存在"}
        conflicts = tool.get("conflicts_with", [])
        used_conflicts = [c for c in conflicts if c in self.used_tools]
        return {
            "has_conflict": len(used_conflicts) > 0,
            "conflicts": used_conflicts,
            "message": f"与已用工具冲突: {used_conflicts}" if used_conflicts else "无冲突"
        }

    def 排除冲突工具(self, selected_tools):
        self.scan_and_register()
        selected_set = set(selected_tools) if isinstance(selected_tools, list) else {selected_tools}
        result = []
        for name in selected_set:
            tool = self.registry.get(name)
            if not tool:
                continue
            conflicts = set(tool.get("conflicts_with", []))
            overlap = conflicts & selected_set
            if overlap:
                result.append({"tool": name, "conflicts_with": list(overlap)})
        return result

    def safety_check(self, tool_name):
        self.scan_and_register()
        tool = self.registry.get(tool_name)
        if not tool:
            return {"requires_confirmation": False, "level": "unknown", "message": f"工具 {tool_name} 不存在"}
        level = tool.get("safety_level", "info")
        requires = {"danger": True, "warning": True, "info": False, "safe": False}
        return {
            "requires_confirmation": requires.get(level, False),
            "level": level,
            "message": f"安全等级: {level}"
        }

    def 安全检查(self, tool_name):
        return self.safety_check(tool_name)

    def mark_used(self, tool_name):
        self.used_tools.add(tool_name)

    def get_tool(self, name):
        self.scan_and_register()
        return self.registry.get(name)


tool_manager = ToolManager()
