TOOL_pluggy = {
    "name": "pluggy", "display_name": "pytest插件框架", "description": "pytest使用的插件框架核心库，提供钩子规范和插件管理机制",
    "category": "自定义插件", "scenarios": ["插件框架", "钩子系统", "pytest扩展"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "成熟稳定的框架，pytest同款钩子机制，适合构建插件化应用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pluggy", "fallback": ["stevedore", "yapsy"]
}

TOOL_importlib = {
    "name": "importlib", "display_name": "Python动态加载", "description": "Python标准库动态模块导入工具，支持运行时加载和重载模块",
    "category": "自定义插件", "scenarios": ["动态导入", "模块热加载", "插件发现"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Python内置标准库，无需额外安装，最基础的动态加载方案",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install importlib", "fallback": ["pkgutil", "dynamic-import"]
}

TOOL_astrbot_plugin_arch = {
    "name": "astrbot-plugin-arch", "display_name": "AstrBot插件架构", "description": "AstrBot机器人框架的插件架构，支持热加载、依赖注入和事件驱动",
    "category": "自定义插件", "scenarios": ["机器人插件", "热加载架构", "事件系统"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "基于AstrBot架构，插件之间通过事件通信，支持热插拔",
    "github_stars": 31800, "open_source": True,
    "download_command": "pip install astrbot-plugin-arch", "fallback": ["pluggy", "stevedore"]
}

TOOL_setuptools_entry_points = {
    "name": "setuptools-entry-points", "display_name": "入口点发现", "description": "通过setuptools入口点机制实现插件自动发现和注册",
    "category": "自定义插件", "scenarios": ["插件发现", "包注册", "自动加载"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Python官方推荐的插件发现方式，打包后自动注册",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install setuptools", "fallback": ["pluggy", "stevedore"]
}

TOOL_stevedore = {
    "name": "stevedore", "display_name": "动态插件加载", "description": "基于setuptools入口点的动态插件加载库，支持命名插件和扩展管理",
    "category": "自定义插件", "scenarios": ["动态加载", "扩展管理", "插件编排"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["yapsy", "pluginbase"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "OpenStack使用的插件框架，支持驱动模式和扩展管理器",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install stevedore", "fallback": ["pluggy", "yapsy"]
}

TOOL_yapsy = {
    "name": "yapsy", "display_name": "插件管理系统", "description": "可插拔的Python插件管理系统，支持文件系统插件发现和生命周期管理",
    "category": "自定义插件", "scenarios": ["插件管理", "生命周期控制", "文件发现"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["stevedore", "pluginbase"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "简单易用的插件管理方案，支持按目录组织插件文件",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install yapsy", "fallback": ["stevedore", "pluginbase"]
}

TOOL_pluginbase = {
    "name": "pluginbase", "display_name": "插件基础库", "description": "灵活轻量的插件系统基础库，支持多源加载和隔离环境",
    "category": "自定义插件", "scenarios": ["插件基础架构", "隔离加载", "灵活配置"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["yapsy", "stevedore"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "比yapsy更灵活，支持更多自定义配置",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pluginbase", "fallback": ["yapsy", "stevedore"]
}

TOOL_extensible = {
    "name": "extensible", "display_name": "可扩展框架", "description": "Python可扩展应用框架，支持插件、中间件和钩子系统",
    "category": "自定义插件", "scenarios": ["可扩展应用", "插件化架构", "模块化开发"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合构建需要高度模块化的应用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install extensible", "fallback": ["pluggy", "pluginbase"]
}

TOOL_deferred_loader = {
    "name": "deferred-loader", "display_name": "延迟加载", "description": "插件延迟加载工具，在需要时才加载插件模块，减少启动时间",
    "category": "自定义插件", "scenarios": ["延迟加载", "性能优化", "按需导入"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合插件数量多的应用，可显著缩短启动时间",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install deferred-loader", "fallback": ["importlib", "hot-reload"]
}

TOOL_hot_reload = {
    "name": "hot-reload", "display_name": "热重载", "description": "插件热重载工具，在不重启应用的情况下更新和重新加载插件",
    "category": "自定义插件", "scenarios": ["热更新", "开发调试", "不停机升级"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "medium",
    "requires_network": False, "usage_tips": "开发调试利器，注意热重载可能引发状态不一致",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install hot-reload", "fallback": ["deferred-loader", "importlib"]
}

TOOL_dynamic_import = {
    "name": "dynamic-import", "display_name": "动态导入", "description": "高级动态导入工具，支持通配符导入、条件导入和远程模块加载",
    "category": "自定义插件", "scenarios": ["动态导入", "条件加载", "远程模块"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "medium",
    "requires_network": False, "usage_tips": "比标准importlib更强，支持更多导入模式",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install dynamic-import", "fallback": ["importlib", "deferred-loader"]
}

TOOL_plugin_manager = {
    "name": "plugin-manager", "display_name": "统一插件管理器", "description": "统一插件管理器，整合安装、卸载、启用、禁用、配置等全生命周期管理",
    "category": "自定义插件", "scenarios": ["插件全生命周期", "统一管理", "配置中心"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["yapsy", "stevedore"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "作为上层管理器协调底层多个插件框架",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install plugin-manager", "fallback": ["yapsy", "stevedore"]
}

TOOL_hook_spec = {
    "name": "hook-spec", "display_name": "钩子规范", "description": "插件钩子规范定义工具，支持类型安全的钩子接口和参数校验",
    "category": "自定义插件", "scenarios": ["钩子定义", "接口规范", "类型安全"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "与pluggy搭配使用，明确定义插件接口契约",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install hook-spec", "fallback": ["pluggy", "extensible"]
}

TOOL_event_system = {
    "name": "event-system", "display_name": "事件系统", "description": "插件间事件通信系统，支持同步/异步事件、优先级和事件过滤",
    "category": "自定义插件", "scenarios": ["事件驱动", "插件通信", "异步消息"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "基于事件总线的通信模式，解耦插件之间的依赖",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install event-system", "fallback": ["pluggy", "middleware-chain"]
}

TOOL_middleware_chain = {
    "name": "middleware-chain", "display_name": "中间件链", "description": "插件中间件链框架，支持请求/响应管道的链式处理",
    "category": "自定义插件", "scenarios": ["中间件模式", "管道处理", "请求拦截"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "类似WSGI/ASGI中间件模式，适合构建请求处理管线",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install middleware-chain", "fallback": ["event-system", "extensible"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}