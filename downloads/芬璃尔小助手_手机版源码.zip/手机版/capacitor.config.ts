import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
    appId: 'com.fenrir.assistant',
    appName: '芬璃尔小助手',
    webDir: '../网页版',
    server: {
        url: 'http://localhost:18088',
        cleartext: true
    },
    android: {
        allowMixedContent: true,
        backgroundColor: '#1a1a2e'
    },
    plugins: {
        SplashScreen: {
            launchShowDuration: 2000,
            backgroundColor: '#1a1a2e',
            androidSplashResourceName: 'splash'
        }
    }
};

export default config;