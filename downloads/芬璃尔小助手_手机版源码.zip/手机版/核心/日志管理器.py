import os
from datetime import datetime
from pathlib import Path

class LogManager:
    """统一日志管理器。
    各形态创建自己的实例，写本地日志时自动同步到顶层大日志。
    """
    
    def __init__(self, form_name, log_dir=None, top_level_log_dir=None):
        self.form_name = form_name  # "网页版" / "桌面版" / "命令行" / "手机版"
        
        # 本地日志目录
        if log_dir is None:
            log_dir = Path(__file__).resolve().parent / "日志"
        self.local_dir = Path(log_dir)
        self.local_dir.mkdir(parents=True, exist_ok=True)
        self.local_file = self.local_dir / f"{form_name}日志.txt"
        
        # 顶层大日志目录
        if top_level_log_dir is None:
            # 默认向上找两层（形态目录 -> 芬璃尔小助手根目录）
            top_level_log_dir = Path(__file__).resolve().parent.parent / "日志"
        self.top_dir = Path(top_level_log_dir)
        self.top_dir.mkdir(parents=True, exist_ok=True)
        self.top_file = self.top_dir / "芬璃尔小助手_汇总日志.txt"
    
    def log(self, level, module, message):
        """
        写入一条日志。
        level: "INFO"/"WARNING"/"ERROR"/"UPDATE"/"TOOL"
        module: 模块名，如 "AI引擎"/"工具调度"/"桌面版启动"等
        message: 日志内容
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_line = f"[{timestamp}] [{level}] [{self.form_name}/{module}] {message}"
        
        # 写本地日志
        try:
            with open(self.local_file, "a", encoding="utf-8") as f:
                f.write(log_line + "\n")
        except Exception as e:
            print(f"写入本地日志失败: {e}")
        
        # 同步写顶层大日志
        try:
            with open(self.top_file, "a", encoding="utf-8") as f:
                f.write(log_line + "\n")
        except Exception as e:
            print(f"写入顶层日志失败: {e}")
    
    def info(self, module, message):
        self.log("INFO", module, message)
    
    def warning(self, module, message):
        self.log("WARNING", module, message)
    
    def error(self, module, message):
        self.log("ERROR", module, message)
    
    def update(self, module, message):
        """记录更新事件（工具更新、代码更新等）"""
        self.log("UPDATE", module, message)
    
    def tool_call(self, tool_name, status):
        """记录工具调用
        status: "SUCCESS"/"FAILED"/"BLOCKED"
        """
        self.log("TOOL", "工具调度", f"调用[{tool_name}] - {status}")
    
    def get_local_logs(self, lines=50):
        """读取本地日志"""
        if not self.local_file.exists():
            return []
        with open(self.local_file, "r", encoding="utf-8") as f:
            all_lines = f.readlines()
        return all_lines[-lines:]
    
    def get_top_logs(self, lines=50):
        """读取顶层日志"""
        if not self.top_file.exists():
            return []
        with open(self.top_file, "r", encoding="utf-8") as f:
            all_lines = f.readlines()
        return all_lines[-lines:]


# 单例缓存
_loggers = {}

def get_logger(form_name):
    """获取或创建日志管理器实例"""
    if form_name not in _loggers:
        _loggers[form_name] = LogManager(form_name)
    return _loggers[form_name]