from .ai_engine import AIEngine, MemorySystem, AgentOrchestrator
from .tools import AIToolManager, execute_tool, list_tools, get_tool_schemas, all_tools

__all__ = [
    'AIEngine', 'MemorySystem', 'AgentOrchestrator',
    'AIToolManager', 'execute_tool', 'list_tools', 'get_tool_schemas', 'all_tools',
    'create_agent'
]


def create_agent(config_path=None):
    import os
    engine = AIEngine(config_path)
    mem_dir = os.path.join(os.path.dirname(config_path or '.'), 'memories')
    os.makedirs(mem_dir, exist_ok=True)
    mem_path = os.path.join(mem_dir, 'memories.json')
    memory = MemorySystem(mem_path)
    tool_mgr = AIToolManager()
    orchestrator = AgentOrchestrator(engine, tool_mgr, memory)
    return {
        'engine': engine,
        'memory': memory,
        'tools': tool_mgr,
        'orchestrator': orchestrator
    }
