TOOL_charity_search = {
    "name": "charity-search慈善查询",
    "display_name": "慈善组织查询",
    "description": "查询国内外慈善组织的注册信息、评级报告、财务透明度和项目执行情况，帮助用户选择可信的捐赠对象",
    "category": "公益慈善",
    "scenarios": ["捐赠前尽职调查", "慈善机构评估", "公益信息核实"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "优先查看财务透明度和项目执行率两个核心指标",
    "github_stars": 3100,
    "open_source": True,
    "download_command": "pip install charity-search",
    "fallback": ["donation-track捐款追踪", "ngo-analyzer NGO分析"]
}

TOOL_donation_track = {
    "name": "donation-track捐款追踪",
    "display_name": "捐款流向追踪",
    "description": "追踪捐款从捐出到项目落地的全过程，可视化展示资金流向、使用比例和受助反馈",
    "category": "公益慈善",
    "scenarios": ["捐款记录管理", "善款使用监督", "公益项目跟进"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "选择支持区块链存证的平台可获得不可篡改的追踪记录",
    "github_stars": 2700,
    "open_source": True,
    "download_command": "pip install donation-track",
    "fallback": ["charity-search慈善查询", "community-help社区互助"]
}

TOOL_volunteer_match = {
    "name": "volunteer-match志愿匹配",
    "display_name": "志愿者服务匹配",
    "description": "根据志愿者的技能、兴趣、可用时间和地理位置，智能匹配适合的志愿服务机会和公益项目",
    "category": "公益参与",
    "scenarios": ["志愿者招募", "公益活动报名", "技能志愿服务"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "完善个人技能标签和服务偏好可获得更精准的匹配推荐",
    "github_stars": 4500,
    "open_source": True,
    "download_command": "pip install volunteer-match",
    "fallback": ["community-help社区互助", "charity-search慈善查询"]
}

TOOL_ngo_analyzer = {
    "name": "ngo-analyzer NGO分析",
    "display_name": "NGO运行分析",
    "description": "对非营利组织的治理结构、财务状况、项目成效、社会影响进行多维度数据分析与评估报告生成",
    "category": "公益研究",
    "scenarios": ["NGO绩效评估", "公益行业研究", "资助决策支持"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["charity-search慈善查询"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "结合多年数据对比分析，能更准确判断组织发展趋势",
    "github_stars": 1900,
    "open_source": True,
    "download_command": "pip install ngo-analyzer",
    "fallback": ["charity-search慈善查询", "donation-track捐款追踪"]
}

TOOL_carbon_calc = {
    "name": "carbon-calc碳足迹",
    "display_name": "碳足迹计算器",
    "description": "计算个人或家庭在日常出行、饮食、居住、消费等方面的碳排放量，并提供减排建议和碳中和方案",
    "category": "环境保护",
    "scenarios": ["个人碳排放核算", "绿色生活规划", "环保意识培养"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "输入尽量详细的生活数据可获得更精确的碳足迹结果",
    "github_stars": 5800,
    "open_source": True,
    "download_command": "pip install carbon-calc",
    "fallback": ["green-energy绿色能源", "recycle-finder回收站"]
}

TOOL_recycle_finder = {
    "name": "recycle-finder回收站",
    "display_name": "回收站点查询",
    "description": "基于地理位置查询附近的可回收物、有害垃圾、旧衣物、电子废弃物等回收站点信息和回收方式",
    "category": "环境保护",
    "scenarios": ["垃圾分类投放", "可回收物处理", "闲置物品捐赠"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "开启定位权限可自动获取周边最近的回收站点",
    "github_stars": 2300,
    "open_source": True,
    "download_command": "pip install recycle-finder",
    "fallback": ["carbon-calc碳足迹", "community-help社区互助"]
}

TOOL_green_energy = {
    "name": "green-energy绿色能源",
    "display_name": "绿色能源指南",
    "description": "提供太阳能、风能等可再生能源的利用方案、政策补贴信息、设备选型建议和节能减排效果评估",
    "category": "环境保护",
    "scenarios": ["家庭节能改造", "新能源设备选购", "环保政策查询"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "输入所在地可获取当地最新的补贴政策和安装条件",
    "github_stars": 3600,
    "open_source": True,
    "download_command": "pip install green-energy",
    "fallback": ["carbon-calc碳足迹", "recycle-finder回收站"]
}

TOOL_animal_protect = {
    "name": "animal-protect动物保护",
    "display_name": "动物保护平台",
    "description": "汇集流浪动物救助站信息、野生动物保护项目、领养替代购买倡导和动物权益相关法律法规",
    "category": "动物福利",
    "scenarios": ["流浪动物救助", "野生动物保护", "宠物领养咨询"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "发现受伤野生动物请联系专业救助机构，不要自行处理",
    "github_stars": 4100,
    "open_source": True,
    "download_command": "pip install animal-protect",
    "fallback": ["volunteer-match志愿匹配", "community-help社区互助"]
}

TOOL_blood_donate = {
    "name": "blood-donate献血站",
    "display_name": "献血站点导航",
    "description": "查询全国献血站点位置、营业时间、血型需求情况，提供献血预约、献血条件和注意事项指引",
    "category": "公益医疗",
    "scenarios": ["献血地点查询", "献血预约登记", "献血政策了解"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "献血前请确保充足睡眠和清淡饮食",
    "github_stars": 1800,
    "open_source": True,
    "download_command": "pip install blood-donate",
    "fallback": ["volunteer-match志愿匹配", "community-help社区互助"]
}

TOOL_community_help = {
    "name": "community-help社区互助",
    "display_name": "社区互助平台",
    "description": "搭建邻里互助网络，支持物品共享、技能互助、紧急求助、社区活动组织等本地化互助服务",
    "category": "社区公益",
    "scenarios": ["邻里互助", "闲置物品流转", "社区活动组织"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "完善社区信息可看到周边邻居发布的互助需求",
    "github_stars": 3300,
    "open_source": True,
    "download_command": "pip install community-help",
    "fallback": ["volunteer-match志愿匹配", "donation-track捐款追踪"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}