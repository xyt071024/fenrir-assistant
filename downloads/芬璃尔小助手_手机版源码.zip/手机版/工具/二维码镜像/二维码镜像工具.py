TOOL_PYTHON_QRCODE = {
    "name": "python_qrcode",
    "display_name": "python-qrcode 二维码生成",
    "description": "Python最流行的二维码生成库，4.8K Stars，支持多种纠错级别、版本和掩码模式，纯Python实现",
    "category": "二维码/生成",
    "scenarios": ["支付二维码生成", "扫码登录", "链接转二维码", "电子票务系统"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["segno", "myqr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "qrcode.make('data').save('qr.png') 一行生成，可设置box_size/border/纠错级别",
    "github_stars": 4800,
    "open_source": True,
    "download_command": "pip install qrcode[pil]",
    "fallback": ["segno", "myqr"]
}

TOOL_SEGNO = {
    "name": "segno",
    "display_name": "segno Micro QR",
    "description": "轻量级二维码生成库，731 Stars，支持Micro QR Code、QR Code和rMQR Code标准，无外部依赖",
    "category": "二维码/生成",
    "scenarios": ["空间受限场景小二维码", "嵌入式系统二维码", "Micro QR特殊格式需求"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["python-qrcode", "myqr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "segno.make('data').save('qr.svg') 支持SVG/PNG/PDF/XBM多种输出格式",
    "github_stars": 731,
    "open_source": True,
    "download_command": "pip install segno",
    "fallback": ["python-qrcode", "myqr"]
}

TOOL_QREADER = {
    "name": "qreader",
    "display_name": "QReader YOLOv8二维码检测",
    "description": "基于YOLOv8的二维码检测与解码库，高精度识别模糊、倾斜、畸变的二维码，优于传统ZBar",
    "category": "二维码/检测解码",
    "scenarios": ["低质量二维码识别", "批量二维码扫描", "工业流水线扫码", "老照片二维码恢复"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["zbarlight", "pyzbar"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "QReader().detect_and_decode(image) 自动下载YOLOv8模型，首次使用需联网",
    "github_stars": 2300,
    "open_source": True,
    "download_command": "pip install qreader",
    "fallback": ["zbarlight", "pyzbar"]
}

TOOL_QR_CODE_GENERATOR = {
    "name": "qr_code_generator",
    "display_name": "QR-Code-generator 6K Stars",
    "description": "高性能二维码生成器，6K Stars，支持40种QR版本和4种纠错级别，提供Python/C/Java等多语言实现",
    "category": "二维码/生成",
    "scenarios": ["高性能二维码批量生成", "多语言跨平台二维码", "自定义QR码实现"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["python-qrcode", "segno"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "pip install qrcodegen 后使用qrcodegen.QrCode.encodeText()生成",
    "github_stars": 6000,
    "open_source": True,
    "download_command": "pip install qrcodegen",
    "fallback": ["python-qrcode", "segno"]
}

TOOL_MYQR = {
    "name": "myqr",
    "display_name": "myqr 艺术二维码",
    "description": "艺术二维码生成库，支持在二维码中嵌入图片、GIF动图、自定义颜色，生成个性化艺术二维码",
    "category": "二维码/艺术美化",
    "scenarios": ["社交媒体个性化二维码", "名片艺术二维码", "营销活动二维码", "动态GIF二维码"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["python-qrcode", "styled-qrcode"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "myqr.run('https://example.com', picture='bg.jpg', colorized=True) 嵌入图片背景",
    "github_stars": 4800,
    "open_source": True,
    "download_command": "pip install myqr",
    "fallback": ["styled-qrcode", "python-qrcode"]
}

TOOL_ZBARLIGHT = {
    "name": "zbarlight",
    "display_name": "zbarlight 二维码解码",
    "description": "基于ZBar的二维码/条形码解码库，轻量级Python绑定，支持QR Code、EAN、UPC等多种码制",
    "category": "二维码/解码",
    "scenarios": ["二维码扫码解析", "条形码扫描", "图片码识别"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["QReader", "pyzbar"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "zbarlight.scan_codes('qrcode', image) 返回解码数据列表，支持PIL图像",
    "github_stars": 300,
    "open_source": True,
    "download_command": "pip install zbarlight",
    "fallback": ["QReader", "pyzbar"]
}

TOOL_PYLIBDMTX = {
    "name": "pylibdmtx",
    "display_name": "pylibdmtx DataMatrix",
    "description": "DataMatrix二维码解码库，基于libdmtx的Python绑定，医疗和工业领域广泛使用的二维码标准",
    "category": "二维码/DataMatrix",
    "scenarios": ["医疗器械追溯码", "工业产品标识", "电子元器件标记", "物流仓储管理"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["zbarlight", "QReader"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "from pylibdmtx import pylibdmtx; pylibdmtx.decode(image) 需要预装libdmtx",
    "github_stars": 200,
    "open_source": True,
    "download_command": "pip install pylibdmtx",
    "fallback": ["zbarlight", "QReader"]
}

TOOL_PYTHON_BARCODE = {
    "name": "python_barcode",
    "display_name": "python-barcode 条码",
    "description": "条形码生成库，支持EAN13/EAN8/UPC/Code128/Code39/ISBN等10+种条码格式，无外部依赖",
    "category": "二维码/条形码",
    "scenarios": ["商品条码生成", "图书ISBN条码", "物流面单条码", "库存标签打印"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["zbarlight", "pylibdmtx"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "EAN13('123456789012').save('barcode') 生成条码图片，支持SVG/PNG格式",
    "github_stars": 600,
    "open_source": True,
    "download_command": "pip install python-barcode",
    "fallback": ["zbarlight", "pylibdmtx"]
}

TOOL_CNPIP = {
    "name": "cnpip",
    "display_name": "cnpip 自动换源",
    "description": "pip镜像源自动切换工具，一键测试并切换到最快的国内镜像源，支持阿里云/清华/中科大等主流镜像",
    "category": "镜像源/换源工具",
    "scenarios": ["pip下载加速", "国内网络pip换源", "自动选择最快镜像"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["pip手动换源", "cmirror"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "cnpip 命令自动测速并切换到最快源，也可手动指定 cnpip use tsinghua",
    "github_stars": 800,
    "open_source": True,
    "download_command": "pip install cnpip",
    "fallback": ["cmirror", "手动pip换源"]
}

TOOL_CMIRROR = {
    "name": "cmirror",
    "display_name": "cmirror 一键换源",
    "description": "开发者换源全家桶，一键切换pip/npm/gem/cargo/homebrew等多语言包管理器镜像源，支持阿里云/华为云/腾讯云",
    "category": "镜像源/多语言换源",
    "scenarios": ["多包管理器换源", "新环境快速配置", "build脚本集成"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["cnpip", "手动换源"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "cmirror pip 切换pip源，cmirror npm 切换npm源，cmirror list 查看当前源",
    "github_stars": 400,
    "open_source": True,
    "download_command": "pip install cmirror",
    "fallback": ["cnpip", "手动换源"]
}

TOOL_QRCODE_TERMINAL = {
    "name": "qrcode_terminal",
    "display_name": "qrcode-terminal 终端二维码",
    "description": "在终端中直接生成和显示二维码，使用Unicode字符绘制，无需图形界面即可展示二维码",
    "category": "二维码/终端显示",
    "scenarios": ["SSH远程生成二维码", "无GUI服务器二维码", "CLI工具集成二维码", "WiFi配置分享"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["python-qrcode图片输出"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "qrcode_terminal.draw('data') 直接在终端打印二维码，适合无显示器环境",
    "github_stars": 200,
    "open_source": True,
    "download_command": "pip install qrcode-terminal",
    "fallback": ["python-qrcode", "segno"]
}

TOOL_MIRAKLE = {
    "name": "mirakle",
    "display_name": "mirakle 二维码扫描",
    "description": "轻量级二维码扫描识别库，基于OpenCV的实时二维码检测，适用于摄像头实时扫码场景",
    "category": "二维码/实时扫描",
    "scenarios": ["摄像头实时扫码", "二维码扫描器", "自动化扫码工具"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["QReader", "QRScanner"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配合OpenCV摄像头使用，mirakle.decode(frame) 逐帧检测二维码",
    "github_stars": 150,
    "open_source": True,
    "download_command": "pip install mirakle",
    "fallback": ["QReader", "QRScanner"]
}

TOOL_QRSCANNER = {
    "name": "qrscanner",
    "display_name": "QRScanner 实时扫描",
    "description": "基于OpenCV的实时二维码扫描器，支持多线程视频流处理，可连续扫描并记录结果",
    "category": "二维码/实时扫描",
    "scenarios": ["批量扫码入库", "门禁扫码系统", "活动签到的二维码扫描"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["mirakle", "QReader"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "QRScanner启动摄像头实时扫描，支持扫描结果去重和日志记录",
    "github_stars": 300,
    "open_source": True,
    "download_command": "pip install qrscanner",
    "fallback": ["mirakle", "QReader"]
}

TOOL_BATCH_QRCODE = {
    "name": "batch_qrcode",
    "display_name": "batch-qrcode 批量生成",
    "description": "批量二维码生成工具，支持从CSV/Excel文件导入数据批量生成二维码，自定义命名规则和输出目录",
    "category": "二维码/批量处理",
    "scenarios": ["批量二维码标签", "序列号二维码批量生成", "优惠券二维码生产", "资产标签批量制作"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["python-qrcode循环生成"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "从CSV读取数据列，自动生成对应二维码并命名，支持ZIP打包导出",
    "github_stars": 200,
    "open_source": True,
    "download_command": "pip install batch-qrcode",
    "fallback": ["python-qrcode", "segno"]
}

TOOL_STYLED_QRCODE = {
    "name": "styled_qrcode",
    "display_name": "styled-qrcode 自定义风格",
    "description": "自定义风格二维码生成库，支持渐变配色、自定义码眼形状、嵌入Logo、圆角模块等视觉定制",
    "category": "二维码/美化定制",
    "scenarios": ["品牌定制二维码", "活动宣传二维码", "产品包装二维码", "社交媒体个性化二维码"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["myqr", "python-qrcode"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持圆形码眼、圆角模块、渐变背景等高级样式，适合商业品牌二维码定制",
    "github_stars": 500,
    "open_source": True,
    "download_command": "pip install styled-qrcode",
    "fallback": ["myqr", "python-qrcode"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}