TOOL_Pillow = {
    "name": "pillow",
    "display_name": "Pillow/PIL",
    "description": "Python图片处理标准库，支持图片打开、裁剪、缩放、旋转、滤镜、色彩调整、格式转换等基础操作",
    "category": "图片生成工具",
    "scenarios": ["图片格式转换", "图片缩放裁剪", "滤镜特效", "水印添加", "批量图片处理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["opencv-python", "wand"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "图片处理的基础库，几乎所有图像处理项目都依赖它；内存管理需要注意大图分块处理",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pillow",
    "fallback": ["opencv-python", "imageio"]
}

TOOL_diffusers = {
    "name": "diffusers",
    "display_name": "Diffusers",
    "description": "HuggingFace推出的扩散模型库，支持Stable Diffusion全系列文生图/图生图/图像修复，支持LoRA/ControlNet",
    "category": "图片生成工具",
    "scenarios": ["文生图", "图生图", "图像修复", "ControlNet可控生成", "LoRA微调模型"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "需要GPU才能有较好体验；模型下载需科学上网；pipeline可组合多个组件实现复杂工作流",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install diffusers transformers accelerate",
    "fallback": []
}

TOOL_rembg = {
    "name": "rembg",
    "display_name": "Rembg",
    "description": "AI自动抠图去背景工具，基于深度学习的背景移除，支持图片和视频，支持多种模型(U2Net/ISNet等)",
    "category": "图片生成工具",
    "scenarios": ["商品图片去背景", "人像抠图", "证件照制作", "批量去背景", "视频去背景"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["OpenCV"],
    "safety_level": "safe",
    "requires_network": False,
    "fallback": ["opencv-python", "pytesseract"],
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install rembg",
    "usage_tips": "U2Net模型精度高但速度慢，ISNet速度快适合批量处理；首次使用自动下载模型"
}

TOOL_Real_ESRGAN = {
    "name": "Real-ESRGAN",
    "display_name": "Real-ESRGAN",
    "description": "真实世界图像超分辨率放大工具，基于增强型超分GAN，支持4倍/8倍放大，擅长处理真实噪点图像",
    "category": "图片生成工具",
    "scenarios": ["图片超分辨率放大", "老照片修复", "模糊图片清晰化", "动漫图片放大", "图像降噪增强"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["ESRGAN", "BasicSR"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "GPU加速效果显著；放大前建议先降噪；支持tile分块处理避免显存不足",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install real-esrgan",
    "fallback": ["ESRGAN", "BasicSR"]
}

TOOL_img2txt = {
    "name": "img2txt",
    "display_name": "Img2Txt",
    "description": "图片生成文字描述工具，基于图像描述模型(BLIP/GIT等)，自动生成图片的自然语言描述",
    "category": "图片生成工具",
    "scenarios": ["图片自动打标签", "图片内容描述", "无障碍图片说明", "社交媒体图片描述", "图库自动分类"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "描述详细程度可通过prompt模板控制，中英文模型效果不同需按需选择",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install img2txt",
    "fallback": ["transformers", "pytesseract"]
}

TOOL_opencv_python_img = {
    "name": "opencv-python",
    "display_name": "OpenCV-Python",
    "description": "计算机视觉库图像处理模块，提供滤波、边缘检测、特征匹配、图像变换、颜色空间转换等数百种图像算法",
    "category": "图片生成工具",
    "scenarios": ["图像预处理", "边缘检测", "特征匹配", "图像变换矫正", "颜色空间转换"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["Pillow", "scikit-image"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "功能极其丰富，大部分计算机视觉任务的基础；注意BGR和RGB的转换",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install opencv-python",
    "fallback": ["Pillow", "scikit-image"]
}

TOOL_scikit_image = {
    "name": "scikit-image",
    "display_name": "scikit-image",
    "description": "科学图像处理库，基于numpy的算法集合，包含分割、特征提取、形态学操作、测量分析等科学图像算法",
    "category": "图片生成工具",
    "scenarios": ["医学图像处理", "科学图像分析", "图像分割", "特征提取", "形态学处理"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["opencv-python"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "与numpy/scipy生态完美集成，适合科研场景；文档齐全且有大量示例",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install scikit-image",
    "fallback": ["opencv-python", "Pillow"]
}

TOOL_imageio = {
    "name": "imageio",
    "display_name": "imageio",
    "description": "跨格式图片读写库，支持几十种图片格式(含科学格式)，提供统一的读写接口，可读写视频帧",
    "category": "图片生成工具",
    "scenarios": ["多种图片格式读写", "科学图片格式(如DICOM)", "图片序列读写", "GIF制作", "简单视频读写"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Pillow", "imageio-ffmpeg"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "插件式架构，通过imageio-ffmpeg扩展可读写视频；适合需要支持多种格式的场景",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install imageio",
    "fallback": ["Pillow", "opencv-python"]
}

TOOL_wand = {
    "name": "wand",
    "display_name": "Wand",
    "description": "ImageMagick的Python封装，提供强大的图片处理能力，支持超过200种格式，适合复杂图片合成与转换",
    "category": "图片生成工具",
    "scenarios": ["复杂图片合成", "图片格式深度转换", "PDF图片处理", "批量图片处理", "高级绘图操作"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Pillow", "opencv-python"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需先安装ImageMagick；支持SVG渲染、颜色管理、CMYK处理等高级功能",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install Wand",
    "fallback": ["Pillow", "opencv-python"]
}

TOOL_pyocr = {
    "name": "pyocr",
    "display_name": "PyOCR",
    "description": "OCR文字识别工具封装层，支持Tesseract和Cuneiform后端，提供统一的文字提取接口",
    "category": "图片生成工具",
    "scenarios": ["图片文字提取", "文档数字化", "验证码识别", "扫描件OCR", "票据识别"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pytesseract"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "识别前对图片进行二值化、降噪预处理可大幅提升准确率",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pyocr",
    "fallback": ["pytesseract", "easyocr"]
}

TOOL_pytesseract = {
    "name": "pytesseract",
    "display_name": "pytesseract",
    "description": "Google Tesseract OCR引擎的Python封装，支持100+语言的文字识别，可自定义识别配置和字典",
    "category": "图片生成工具",
    "scenarios": ["通用OCR识别", "多语言文字识别", "身份证号码识别", "车牌识别", "截图文字提取"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["pyocr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需安装Tesseract引擎和对应语言包；--psm参数控制识别模式，--oem选择识别引擎",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pytesseract",
    "fallback": ["pyocr", "easyocr"]
}

TOOL_qrcode = {
    "name": "qrcode",
    "display_name": "QRCode",
    "description": "二维码生成库，支持生成自定义样式的二维码(颜色/logo/形状)，支持多种纠错级别和版本",
    "category": "图片生成工具",
    "scenarios": ["二维码生成", "带Logo二维码", "彩色二维码", "批量二维码生成", "动态二维码"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["segno"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "纠错级别L/M/Q/H从低到高，带Logo时建议使用H级；Pillow配合可自定义样式",
    "github_stars": 4800,
    "open_source": True,
    "download_command": "pip install qrcode[pil]",
    "fallback": ["segno"]
}

TOOL_segno = {
    "name": "segno",
    "display_name": "Segno",
    "description": "二维码生成库(支持Micro QR)，支持QR Code和Micro QR Code两种标准，可输出SVG/PNG/EPS等多种格式",
    "category": "图片生成工具",
    "scenarios": ["标准二维码生成", "Micro QR码(微小二维码)", "SVG格式二维码", "高密度数据编码", "批量生成"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["qrcode"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Micro QR码适合空间受限场景，数据量小；纯Python实现无额外依赖",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install segno",
    "fallback": ["qrcode"]
}

TOOL_stegano = {
    "name": "stegano",
    "display_name": "Stegano",
    "description": "图片隐写工具库，支持LSB(最低有效位)隐写、EXIF隐写等多种算法，可在图片中隐藏文字/文件",
    "category": "图片生成工具",
    "scenarios": ["图片隐写加密", "信息隐藏传输", "数字水印嵌入", "隐写分析", "隐蔽通信"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "LSB隐写容量大但容易被检测；叠加加密算法可提高安全性；尽量使用无损格式(PNG/BMP)",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install stegano",
    "fallback": []
}

TOOL_pillow_heif = {
    "name": "pillow-heif",
    "display_name": "Pillow-HEIF",
    "description": "HEIF/HEIC格式图片支持库，为Pillow添加苹果HEIF格式(高效图像文件格式)的读写能力",
    "category": "图片生成工具",
    "scenarios": ["iPhone HEIC图片读取", "HEIF格式转换JPEG", "苹果生态图片兼容", "高效图片格式处理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需要与Pillow配合使用，安装后Pillow自动获得HEIF读写能力",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pillow-heif",
    "fallback": ["pyheif"]
}

TOOL_piexif = {
    "name": "piexif",
    "display_name": "Piexif",
    "description": "EXIF数据读写库，支持读取/修改/写入图片EXIF信息(拍摄参数/GPS/相机型号/日期等)",
    "category": "图片生成工具",
    "scenarios": ["EXIF信息读取", "GPS地理位置提取", "图片元数据编辑", "批量EXIF清理", "照片信息管理"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持所有标准EXIF标签；删除EXIF可减小文件体积和保护隐私",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install piexif",
    "fallback": ["Pillow"]
}

TOOL_image_match = {
    "name": "image-match",
    "display_name": "Image-Match",
    "description": "图片相似度匹配库，基于特征提取和哈希算法，支持以图搜图、相似图片查找、去重检测",
    "category": "图片生成工具",
    "scenarios": ["以图搜图", "相似图片查找", "图片去重", "图片版权检测", "盗图识别"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持dHash/pHash/WHash等多种哈希算法，适合中等规模图片库查找",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install image-match",
    "fallback": ["opencv-python"]
}

TOOL_watermark = {
    "name": "watermark",
    "display_name": "Watermark",
    "description": "图片水印工具，支持文字水印和图片水印，可控制位置/透明度/旋转/批量添加水印",
    "category": "图片生成工具",
    "scenarios": ["图片批量加水印", "文字水印", "Logo水印嵌入", "版权保护", "图片防盗"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "水印位置可选择九宫格定位；透明水印不易被裁剪；批量处理时建议用多线程",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install watermark",
    "fallback": ["Pillow", "opencv-python"]
}

TOOL_photomosaic = {
    "name": "photomosaic",
    "display_name": "PhotoMosaic",
    "description": "照片马赛克生成工具，将多张小图片拼贴成大图(马赛克效果)，支持自定义图库匹配和颜色优化",
    "category": "图片生成工具",
    "scenarios": ["照片马赛克艺术创作", "海报拼贴画", "活动照片墙", "创意礼物制作", "像素风艺术"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["collage"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "图库图片数量越多效果越好；建议先聚类颜色再匹配以获得更协调的效果",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install photomosaic",
    "fallback": ["collage", "Pillow"]
}

TOOL_collage = {
    "name": "collage",
    "display_name": "Collage",
    "description": "图片拼贴工具，支持多种拼贴布局(网格/自由/不规则)，可添加边框背景，适合制作拼贴画",
    "category": "图片生成工具",
    "scenarios": ["多图拼贴合成", "照片墙制作", "社交媒体拼图", "产品展示图", "回忆相册"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["photomosaic"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "预设多种布局模板；支持自定义间距和背景色；高清输出需要设置高DPI",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install collage",
    "fallback": ["Pillow", "photomosaic"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}