TOOL_DOCKER = {
    "name": "docker",
    "display_name": "Docker 容器引擎",
    "description": "业界标准的容器化平台，支持应用的打包、分发和运行。通过命名空间隔离和联合文件系统实现轻量级虚拟化。",
    "category": "虚拟化容器",
    "scenarios": ["微服务部署", "CI/CD 流水线", "开发环境标准化", "应用沙箱隔离", "云原生迁移"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["podman", "containerd"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "优先使用多阶段构建减小镜像体积；生产环境推荐搭配 Docker Swarm 或 K8s 使用",
    "github_stars": 70000,
    "open_source": True,
    "download_command": "curl -fsSL https://get.docker.com | sh",
    "fallback": ["podman", "containerd"]
}

TOOL_PODMAN = {
    "name": "podman",
    "display_name": "Podman 无根容器引擎",
    "description": "无需守护进程的容器引擎，原生支持无根模式运行。兼容 Docker CLI 命令，安全性更高。",
    "category": "虚拟化容器",
    "scenarios": ["无根容器运行", "Kubernetes Pod 模拟", "安全敏感环境", "CI/CD 无特权场景", "边缘计算"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["docker"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "使用 podman machine 在 macOS/Windows 上运行；alias docker=podman 平滑迁移",
    "github_stars": 25000,
    "open_source": True,
    "download_command": "brew install podman",
    "fallback": ["docker", "containerd"]
}

TOOL_CONTAINERD = {
    "name": "containerd",
    "display_name": "containerd 容器运行时",
    "description": "行业标准的容器运行时，管理容器的完整生命周期（镜像传输、存储、网络、执行）。Kubernetes 默认容器运行时。",
    "category": "虚拟化容器",
    "scenarios": ["Kubernetes 节点运行时", "生产容器生命周期管理", "高性能容器场景", "嵌入式容器", "边缘节点"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["docker"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "通过 ctr 或 nerdctl 命令行工具交互；注意不要与 dockerd 冲突",
    "github_stars": 18000,
    "open_source": True,
    "download_command": "apt-get install containerd",
    "fallback": ["docker", "cri-o"]
}

TOOL_DOCKER_COMPOSE = {
    "name": "docker-compose",
    "display_name": "Docker Compose 多容器编排",
    "description": "通过 YAML 文件定义和运行多容器 Docker 应用。一键启动整个服务栈，简化开发环境搭建。",
    "category": "虚拟化容器",
    "scenarios": ["本地开发环境搭建", "微服务多容器编排", "测试环境快速部署", "CI/CD 集成测试", "演示环境一键启动"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "定义 depends_on 控制启动顺序；使用 profiles 按需启动服务；推荐 Compose V2",
    "github_stars": 35000,
    "open_source": True,
    "download_command": "pip install docker-compose",
    "fallback": ["docker stack deploy", "podman-compose"]
}

TOOL_KUBERNETES = {
    "name": "kubernetes",
    "display_name": "Kubernetes (K8s) 容器编排",
    "description": "生产级的容器编排平台，提供自动部署、扩缩容、服务发现和负载均衡。云原生计算基金会旗舰项目。",
    "category": "虚拟化容器",
    "scenarios": ["生产容器集群管理", "微服务编排与治理", "自动扩缩容", "灰度发布与回滚", "多云混合部署"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "学习曲线较陡，建议先掌握 kubectl 常用命令；使用 Helm 管理 Charts 简化部署",
    "github_stars": 112000,
    "open_source": True,
    "download_command": "curl -LO https://dl.k8s.io/release/$(curl -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl",
    "fallback": ["docker swarm", "nomad"]
}

TOOL_MINIKUBE = {
    "name": "minikube",
    "display_name": "Minikube 本地 K8s 集群",
    "description": "在本地运行单节点 Kubernetes 集群的工具，适合开发和测试。支持多种驱动和插件。",
    "category": "虚拟化容器",
    "scenarios": ["本地 K8s 开发测试", "学习 Kubernetes", "CI/CD 本地验证", "演示 K8s 功能", "插件与扩展测试"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "使用 --driver=docker 避免嵌套虚拟化；minikube addons enable ingress 安装常用插件",
    "github_stars": 30000,
    "open_source": True,
    "download_command": "curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64",
    "fallback": ["kind", "k3s", "microk8s"]
}

TOOL_VAGRANT = {
    "name": "vagrant",
    "display_name": "Vagrant 虚拟机管理",
    "description": "跨平台虚拟机生命周期管理工具，通过 Vagrantfile 实现基础设施即代码。支持 VirtualBox、VMware、Hyper-V 等。",
    "category": "虚拟化容器",
    "scenarios": ["开发环境统一管理", "跨平台测试", "基础设施即代码实践", "团队开发环境分发", "多虚拟机网络拓扑"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "搭配 VirtualBox 免费使用；vagrant box add 预下载镜像可离线使用",
    "github_stars": 26500,
    "open_source": True,
    "download_command": "brew install vagrant",
    "fallback": ["multipass", "docker compose"]
}

TOOL_VIRTUALBOX = {
    "name": "virtualbox",
    "display_name": "VirtualBox 桌面虚拟化",
    "description": "Oracle 出品的开源桌面虚拟化软件，支持在单台机器上运行多个操作系统。功能全面，社区活跃。",
    "category": "虚拟化容器",
    "scenarios": ["桌面虚拟机运行", "多操作系统测试", "虚拟网络实验", "旧系统兼容运行", "教学演示环境"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["vmware", "hyper-v"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "安装增强功能提升性能；注意与 Hyper-V 冲突需关闭 Hyper-V 才能运行",
    "github_stars": 9000,
    "open_source": True,
    "download_command": "apt-get install virtualbox",
    "fallback": ["vmware", "qemu", "hyper-v"]
}

TOOL_QEMU_KVM = {
    "name": "qemu-kvm",
    "display_name": "QEMU/KVM 虚拟化",
    "description": "Linux 内核级虚拟化方案，KVM 提供硬件辅助虚拟化，QEMU 提供设备模拟。性能接近裸机。",
    "category": "虚拟化容器",
    "scenarios": ["高性能虚拟机运行", "云平台底层虚拟化", "内核开发测试", "异构架构模拟", "数据中心虚拟化"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "需要 CPU 支持 VT-x/AMD-V；virsh 命令管理虚拟机；搭配 libvirt 使用更便捷",
    "github_stars": 14000,
    "open_source": True,
    "download_command": "apt-get install qemu-kvm libvirt-daemon-system",
    "fallback": ["virtualbox", "vmware"]
}

TOOL_VMWARE = {
    "name": "vmware",
    "display_name": "VMware 云原生虚拟化",
    "description": "企业级虚拟化平台，提供 vSphere/ESXi 等产品线。支持云原生工作负载、容器与虚拟机混合管理。",
    "category": "虚拟化容器",
    "scenarios": ["企业数据中心虚拟化", "私有云搭建", "混合云管理", "桌面虚拟化(Virtual Desktop)", "灾备与迁移"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["virtualbox", "hyper-v"],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "VMware Workstation Pro 个人免费；ESXi 是裸机 Hypervisor 性能最优",
    "github_stars": 0,
    "open_source": False,
    "download_command": "wget https://softwareupdate.vmware.com/cds/vmw-desktop/ws/",
    "fallback": ["virtualbox", "qemu-kvm", "hyper-v"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
