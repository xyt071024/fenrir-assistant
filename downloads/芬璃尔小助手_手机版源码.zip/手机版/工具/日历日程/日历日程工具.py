TOOL_khal = {
    "name": "khal", "display_name": "khal日历CLI", "description": "基于控制台的日历管理工具，支持查看、添加和同步日历事件，支持CalDAV同步",
    "category": "日历日程", "scenarios": ["终端日历管理", "快速查看日程", "日历事件添加"],
    "accuracy": 5, "efficiency": 4, "speed": 5,
    "conflicts_with": ["caldav"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合习惯终端的用户，支持 vi 键绑定",
    "github_stars": 3000, "open_source": True,
    "download_command": "pip install khal", "fallback": ["caldav", "kalendar"]
}

TOOL_holidays = {
    "name": "holidays", "display_name": "holidays节假日库", "description": "全球各国法定节假日和公休日库，支持160+国家和地区，可自定义扩展",
    "category": "日历日程", "scenarios": ["法定节假日查询", "工作日判断", "放假安排"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["workalendar"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "常用 country_holidays('CN') 获取中国节假日",
    "github_stars": 1900, "open_source": True,
    "download_command": "pip install holidays", "fallback": ["workalendar", "chinese_calendar"]
}

TOOL_workalendar = {
    "name": "workalendar", "display_name": "workalendar工作日历", "description": "各国工作日历库，支持工作日计算、节假日判断、添加工作日天数等功能",
    "category": "日历日程", "scenarios": ["工作日计算", "项目排期", "法定假日"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["holidays"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合需要加减工作日的业务场景",
    "github_stars": 948, "open_source": True,
    "download_command": "pip install workalendar", "fallback": ["holidays", "chinese_calendar"]
}

TOOL_python_o365 = {
    "name": "python-o365", "display_name": "python-o365 Outlook日历", "description": "Microsoft 365/Exchange 日历、邮件、联系人API封装，支持OAuth2认证",
    "category": "日历日程", "scenarios": ["Outlook日历", "Microsoft 365集成", "企业邮箱日程"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["exchangelib", "outlook-calendar"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要注册 Azure AD 应用获取 client_id",
    "github_stars": 1900, "open_source": True,
    "download_command": "pip install O365", "fallback": ["exchangelib", "outlook-calendar"]
}

TOOL_lunar = {
    "name": "lunar", "display_name": "lunar老黄历", "description": "农历、公历、干支、生肖、宜忌、黄历、星座、节气等中国传统文化日期库",
    "category": "日历日程", "scenarios": ["农历转换", "黄历查询", "传统节日", "择吉"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持 1900-2100 年的农历查询",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install lunar-python", "fallback": ["zhdate", "chinese_calendar"]
}

TOOL_icalendar = {
    "name": "icalendar", "display_name": "icalendar iCal解析", "description": "解析和生成 iCalendar (.ics) 格式文件，支持 VEVENT、VTODO、VJOURNAL 等组件",
    "category": "日历日程", "scenarios": ["iCal文件解析", "日历数据交换", ".ics生成"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["recurring-ical-events"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "搭配 recurring-ical-events 处理循环事件",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install icalendar", "fallback": ["caldav", "dateutil"]
}

TOOL_dateutil = {
    "name": "dateutil", "display_name": "dateutil日期处理", "description": "强大的日期时间处理扩展库，支持相对时间解析、时区处理、日期范围生成、模糊解析等",
    "category": "日历日程", "scenarios": ["日期解析", "时区转换", "相对日期计算", "日期迭代"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["pendulum", "arrow"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "parse('2024-01-01') 自动识别格式",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install python-dateutil", "fallback": ["pendulum", "arrow"]
}

TOOL_pendulum = {
    "name": "pendulum", "display_name": "pendulum时间处理", "description": "更人性化的日期时间库，内置时区处理、时间差计算、格式化、人性化文本等",
    "category": "日历日程", "scenarios": ["时间运算", "时区转换", "人性化时间显示"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["dateutil", "arrow"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "dt.diff_for_humans() 可输出'3小时前'等",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pendulum", "fallback": ["arrow", "dateutil"]
}

TOOL_arrow = {
    "name": "arrow", "display_name": "arrow时间库", "description": "简洁直观的日期时间库，提供链式调用、人性化时间差、时区感知等功能",
    "category": "日历日程", "scenarios": ["快速时间操作", "时间格式化", "时区转换"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["pendulum", "dateutil"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "arrow.get('2024-01-01', 'YYYY-MM-DD') 快速解析",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install arrow", "fallback": ["pendulum", "dateutil"]
}

TOOL_recurring_ical_events = {
    "name": "recurring-ical-events", "display_name": "recurring-ical-events循环事件", "description": "解析 iCalendar 中 RRULE 循环规则，展开重复事件为具体日期实例",
    "category": "日历日程", "scenarios": ["循环事件展开", "RRULE解析", "重复日程处理"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["icalendar"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "需配合 icalendar 库使用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install recurring-ical-events", "fallback": ["icalendar", "caldav"]
}

TOOL_caldav = {
    "name": "caldav", "display_name": "caldav CalDAV协议", "description": "CalDAV协议客户端库，支持连接 NextCloud、Baikal、iCloud 等 CalDAV 服务器",
    "category": "日历日程", "scenarios": ["CalDAV同步", "远程日历操作", "服务器日历管理"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["khal"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持创建/查询/更新/删除远程日历事件",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install caldav", "fallback": ["khal", "google-calendar"]
}

TOOL_google_calendar = {
    "name": "google-calendar", "display_name": "google-calendar Google日历", "description": "Google Calendar API 客户端，支持事件CRUD、日历列表、会议创建等",
    "category": "日历日程", "scenarios": ["Google日历同步", "Google Workspace集成", "日历事件管理"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需在 Google Cloud Console 启用 Calendar API",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install google-api-python-client google-auth-httplib2 google-auth-oauthlib",
    "fallback": ["caldav", "outlook-calendar"]
}

TOOL_apple_calendar = {
    "name": "apple-calendar", "display_name": "apple-calendar Apple日历", "description": "通过 CalDAV 协议或 pyobjc 桥接与 Apple iCloud 日历交互",
    "category": "日历日程", "scenarios": ["iCloud日历", "Apple生态集成", "macOS日历操作"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["caldav"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "macOS 上可直接用 pyobjc 调用系统日历框架",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install caldav", "fallback": ["caldav", "google-calendar"]
}

TOOL_outlook_calendar = {
    "name": "outlook-calendar", "display_name": "outlook-calendar Outlook日历", "description": "通过 Microsoft Graph API 操作 Outlook 日历，支持事件管理、共享日历等",
    "category": "日历日程", "scenarios": ["Outlook日历", "Microsoft Graph", "企业日历"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["python-o365", "exchangelib"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "推荐使用 Microsoft Graph API v1.0",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install requests msal", "fallback": ["python-o365", "exchangelib"]
}

TOOL_exchangelib = {
    "name": "exchangelib", "display_name": "exchangelib Exchange日历", "description": "Microsoft Exchange Web Services (EWS) 客户端，支持日历、邮件、联系人、任务",
    "category": "日历日程", "scenarios": ["Exchange日历", "EWS协议", "企业自建邮箱"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["python-o365", "outlook-calendar"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "适合自建 Exchange 服务器场景",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install exchangelib", "fallback": ["python-o365", "outlook-calendar"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
