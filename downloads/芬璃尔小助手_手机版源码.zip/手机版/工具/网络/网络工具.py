TOOL_requests = {
    "name": "requests", "display_name": "Requests", "description": "最流行的Python HTTP库，API简洁优雅，支持Session复用、SSL验证、Cookie持久化、文件上传下载",
    "category": "网络工具", "scenarios": ["HTTP请求", "REST API调用", "网页抓取", "文件下载"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["httpx", "aiohttp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "Session对象复用连接和Cookie；timeout参数必须设置防止卡死；stream=True大文件下载",
    "github_stars": 53000, "open_source": True,
    "download_command": "pip install requests", "fallback": ["httpx", "urllib3"]
}

TOOL_aiohttp = {
    "name": "aiohttp", "display_name": "aiohttp", "description": "异步HTTP客户端/服务端框架，基于asyncio实现高并发请求，适合爬虫和数据采集",
    "category": "网络工具", "scenarios": ["异步HTTP请求", "高并发爬虫", "WebSocket客户端", "异步Web服务"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["requests", "httpx"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "使用async with管理ClientSession；连接池大小影响并发上限；支持限速",
    "github_stars": 16000, "open_source": True,
    "download_command": "pip install aiohttp", "fallback": ["httpx", "requests"]
}

TOOL_httpx = {
    "name": "httpx", "display_name": "HTTPX", "description": "新一代HTTP客户端，同时支持同步/异步、HTTP/1.1/2.0，API兼容Requests，支持超时和连接池",
    "category": "网络工具", "scenarios": ["HTTP/2请求", "异步HTTP", "API客户端", "代理隧道"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["requests", "aiohttp"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "使用httpx.Client()同步或httpx.AsyncClient()异步；http2=True启用HTTP/2",
    "github_stars": 16000, "open_source": True,
    "download_command": "pip install httpx", "fallback": ["requests", "aiohttp"]
}

TOOL_curl_cffi = {
    "name": "curl_cffi", "display_name": "curl_cffi (指纹模拟)", "description": "模拟浏览器TLS指纹的HTTP库，基于curl-impersonate，绕过Cloudflare等反爬检测",
    "category": "网络工具", "scenarios": ["反爬绕过", "TLS指纹模拟", "浏览器伪装请求", "高难度数据采集"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["requests", "cloudscraper"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "from curl_cffi import requests代替标准requests；支持Chrome/Safari等指纹",
    "github_stars": 7000, "open_source": True,
    "download_command": "pip install curl-cffi", "fallback": ["cloudscraper", "requests"]
}

TOOL_urllib3 = {
    "name": "urllib3", "display_name": "urllib3", "description": "底层HTTP客户端库，Requests的核心依赖，提供连接池管理、代理支持和SSL/TLS配置",
    "category": "网络工具", "scenarios": ["底层HTTP操作", "连接池配置", "代理设置", "SSL自定义"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["requests", "httpx"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "PoolManager管理连接池；ProxyManager配置代理；支持retry机制",
    "github_stars": 4000, "open_source": True,
    "download_command": "pip install urllib3", "fallback": ["requests", "httpx"]
}

TOOL_websockets = {
    "name": "websockets", "display_name": "WebSockets", "description": "WebSocket协议库，支持客户端和服务器端，基于asyncio实现双向实时通信",
    "category": "网络工具", "scenarios": ["WebSocket通信", "实时数据推送", "聊天协议", "行情订阅"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["websocket-client", "aiohttp-ws"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "async with websockets.connect()管理连接；支持ping/pong心跳保活",
    "github_stars": 6000, "open_source": True,
    "download_command": "pip install websockets", "fallback": ["websocket-client", "aiohttp"]
}

TOOL_socket = {
    "name": "socket", "display_name": "Socket (标准库)", "description": "Python标准库底层网络编程接口，支持TCP/UDP、原始套接字，是所有网络库的基础",
    "category": "网络工具", "scenarios": ["TCP/UDP通信", "端口扫描", "网络服务开发", "自定义协议"],
    "accuracy": 5, "efficiency": 4, "speed": 5,
    "conflicts_with": [], "safety_level": "caution",
    "requires_network": False, "usage_tips": "settimeout设置超时防止卡死；SO_REUSEADDR选项重用端口；原始套接字需管理员权限",
    "github_stars": 0, "open_source": True,
    "download_command": "内置标准库，无需安装", "fallback": ["asyncio", "selectors"]
}

TOOL_scapy = {
    "name": "scapy", "display_name": "Scapy", "description": "强大的网络包操作库，支持数据包构造/嗅探/注入、协议解析、网络发现和攻击测试",
    "category": "网络工具", "scenarios": ["网络嗅探分析", "数据包构造", "协议模糊测试", "网络安全研究"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["pypcap", "dpkt"], "safety_level": "danger",
    "requires_network": False, "usage_tips": "需要管理员/root权限；sr/sr1发送接收数据包；sniff嗅探网络流量",
    "github_stars": 11500, "open_source": True,
    "download_command": "pip install scapy", "fallback": ["dpkt", "pypcap"]
}

TOOL_nmap = {
    "name": "python-nmap", "display_name": "Nmap (端口扫描)", "description": "Nmap端口扫描器的Python封装，执行主机发现、端口扫描、服务版本检测和操作系统识别",
    "category": "网络工具", "scenarios": ["端口扫描", "主机发现", "服务指纹识别", "网络安全审计"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["masscan", "scapy"], "safety_level": "danger",
    "requires_network": True, "usage_tips": "需先安装Nmap：https://nmap.org/；PortScannerAsync支持异步扫描",
    "github_stars": 3000, "open_source": True,
    "download_command": "pip install python-nmap", "fallback": ["masscan", "scapy"]
}

TOOL_dnspython = {
    "name": "dnspython", "display_name": "dnspython", "description": "DNS协议工具包，支持DNS查询/区域传输/动态更新，可解析A/AAAA/MX/TXT/NS等所有记录类型",
    "category": "网络工具", "scenarios": ["DNS解析", "域名查询", "邮件服务器MX查询", "子域名枚举"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["socket-gethostbyname", "pycares"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "dns.resolver.resolve()执行查询；支持自定义DNS服务器和超时",
    "github_stars": 4000, "open_source": True,
    "download_command": "pip install dnspython", "fallback": ["pycares", "socket"]
}

TOOL_whois = {
    "name": "whois", "display_name": "python-whois", "description": "域名WHOIS查询库，查询域名注册信息（注册商、注册日期、到期日、DNS服务器等）",
    "category": "网络工具", "scenarios": ["域名注册查询", "过期时间监控", "域名归属调查", "Whois数据采集"],
    "accuracy": 3, "efficiency": 4, "speed": 3,
    "conflicts_with": ["whois-api"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "不同TLD返回字段格式不统一需兼容处理；频繁查询可能被限速",
    "github_stars": 1500, "open_source": True,
    "download_command": "pip install python-whois", "fallback": ["whois-api", "rdap"]
}

TOOL_netifaces = {
    "name": "netifaces", "display_name": "netifaces", "description": "网络接口信息获取库，枚举系统所有网络接口的IP地址、MAC地址、网关和子网掩码",
    "category": "网络工具", "scenarios": ["获取本机IP", "网络接口枚举", "MAC地址查询", "网关探测"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["psutil-net", "socket"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "gateways()获取默认网关；ifaddresses()获取接口地址信息；跨平台兼容",
    "github_stars": 500, "open_source": True,
    "download_command": "pip install netifaces", "fallback": ["psutil", "socket"]
}

TOOL_speedtest_cli = {
    "name": "speedtest-cli", "display_name": "speedtest-cli", "description": "Speedtest.net网速测试命令行工具，测下载/上传速度、延迟和丢包率，返回详细测试结果",
    "category": "网络工具", "scenarios": ["网速测试", "带宽检测", "网络质量评估", "延迟测量"],
    "accuracy": 3, "efficiency": 4, "speed": 2,
    "conflicts_with": ["fast-cli", "iPerf3"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "测试过程需数十秒；--secure启用HTTPS测试；--server-id指定测试服务器",
    "github_stars": 5000, "open_source": True,
    "download_command": "pip install speedtest-cli", "fallback": ["fast-cli", "iPerf3"]
}

TOOL_ping3 = {
    "name": "ping3", "display_name": "ping3", "description": "纯净的ICMP Ping库，无需系统ping命令权限，纯Python实现，支持超时和TTL设置",
    "category": "网络工具", "scenarios": ["主机连通性测试", "网络延迟测量", "服务器健康监控", "丢包率检测"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["python-ping", "icmplib"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "ping()返回毫秒延迟或None(超时)；verbose=True输出详细日志；Windows需管理员权限",
    "github_stars": 1500, "open_source": True,
    "download_command": "pip install ping3", "fallback": ["icmplib", "python-ping"]
}

TOOL_traceroute3 = {
    "name": "traceroute3", "display_name": "traceroute3", "description": "路由追踪库，基于ICMP/UDP探测包，追踪数据包到达目标主机经过的每一跳路由节点",
    "category": "网络工具", "scenarios": ["路由追踪", "网络拓扑探测", "延迟路径分析", "ISP网络诊断"],
    "accuracy": 4, "efficiency": 3, "speed": 2,
    "conflicts_with": ["scapy-traceroute"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "管理员/root权限运行；max_hops设置最大跳数；timeout控制超时",
    "github_stars": 200, "open_source": True,
    "download_command": "pip install traceroute3", "fallback": ["scapy", "系统traceroute命令"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}