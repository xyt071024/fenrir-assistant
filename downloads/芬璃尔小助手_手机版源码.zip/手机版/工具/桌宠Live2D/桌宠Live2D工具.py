TOOL_Open_LLM_VTuber = {
    "name": "Open-LLM-VTuber", "display_name": "AI桌宠+Live2D", "description": "AI驱动的Live2D桌宠，集成大语言模型对话和TTS语音合成，支持实时交互",
    "category": "桌宠Live2D", "scenarios": ["AI桌宠", "Live2D交互", "语音对话"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["Shijima-Qt", "Agentic-Desktop-Pet"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要本地LLM或API密钥，支持自定义Live2D模型",
    "github_stars": 10000, "open_source": True,
    "download_command": "pip install open-llm-vtuber", "fallback": ["NyarchAssistant", "Mate-Engine"]
}

TOOL_Mate_Engine = {
    "name": "Mate-Engine", "display_name": "VRM 3D桌宠引擎", "description": "基于VRM标准的3D桌宠引擎，支持3D模型加载、动画和交互",
    "category": "桌宠Live2D", "scenarios": ["3D桌宠", "VRM模型", "角色动画"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["Open-LLM-VTuber"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持VRM 1.0标准模型，可导入VRChat角色",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mate-engine", "fallback": ["VRoid", "three-vrm"]
}

TOOL_DyberPet = {
    "name": "DyberPet", "display_name": "PySide6桌宠", "description": "基于PySide6开发的桌面宠物，支持自定义外观、互动和动画",
    "category": "桌宠Live2D", "scenarios": ["桌面宠物", "PySide6应用", "互动娱乐"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Desktop-Cat", "float-pet"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "纯Python实现，易于二次开发和定制",
    "github_stars": 728, "open_source": True,
    "download_command": "pip install dyberpet", "fallback": ["Desktop-Cat", "float-pet"]
}

TOOL_Agentic_Desktop_Pet = {
    "name": "Agentic-Desktop-Pet", "display_name": "LLM记忆情感RPG桌宠", "description": "具有LLM记忆和情感系统的RPG风格桌宠，支持成长和情感交互",
    "category": "桌宠Live2D", "scenarios": ["AI记忆桌宠", "情感交互", "RPG养成"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["Open-LLM-VTuber", "DyberPet"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需要调用LLM API，宠物拥有长期记忆和情感状态",
    "github_stars": 277, "open_source": True,
    "download_command": "pip install agentic-desktop-pet", "fallback": ["DyberPet", "pet-emotion"]
}

TOOL_Shijima_Qt = {
    "name": "Shijima-Qt", "display_name": "跨平台Shimeji", "description": "跨平台Shimeji桌宠实现，基于Qt框架，支持多种行为模式",
    "category": "桌宠Live2D", "scenarios": ["Shimeji桌宠", "Qt桌面应用", "动画角色"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Shimeji-ee", "Desktop-Cat"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "经典的Shimeji桌宠跨平台移植版",
    "github_stars": 109, "open_source": True,
    "download_command": "pip install shijima-qt", "fallback": ["Shimeji-ee", "Desktop-Cat"]
}

TOOL_Desktop_Cat = {
    "name": "Desktop-Cat", "display_name": "桌面小猫", "description": "可爱的桌面小猫宠物，会在桌面上自由走动和互动",
    "category": "桌宠Live2D", "scenarios": ["桌面猫咪", "宠物互动", "休闲娱乐"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["DyberPet", "float-pet"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "轻量级桌宠，资源占用小，适合日常陪伴",
    "github_stars": 85, "open_source": True,
    "download_command": "pip install desktop-cat", "fallback": ["DyberPet", "float-pet"]
}

TOOL_Shimeji_ee = {
    "name": "Shimeji-ee", "display_name": "经典桌宠", "description": "经典的Shimeji桌宠实现，支持多种角色和拖拽交互",
    "category": "桌宠Live2D", "scenarios": ["经典桌宠", "角色互动", "桌面装饰"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["Shijima-Qt", "Desktop-Cat"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "经典Shimeji桌宠的增强版，添加更多行为模式",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install shimeji-ee", "fallback": ["Shijima-Qt", "Desktop-Cat"]
}

TOOL_NyarchAssistant = {
    "name": "NyarchAssistant", "display_name": "Live2D AI助手", "description": "Live2D AI桌面助手，集成语音交互和系统控制功能",
    "category": "桌宠Live2D", "scenarios": ["AI助手", "Live2D互动", "系统控制"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["Open-LLM-VTuber"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持自定义Live2D模型和语音识别",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install nyarch-assistant", "fallback": ["Open-LLM-VTuber", "Mate-Engine"]
}

TOOL_Live2D_Python = {
    "name": "Live2D-Python", "display_name": "Live2D Python封装", "description": "Live2D Cubism SDK的Python绑定，支持Live2D模型加载和渲染",
    "category": "桌宠Live2D", "scenarios": ["Live2D开发", "模型渲染", "动画控制"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "底层封装库，适合需要在Python中使用Live2D的开发者",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install live2d-python", "fallback": ["cubism-core", "pixiv-live2d"]
}

TOOL_cubism_core = {
    "name": "cubism-core", "display_name": "Live2D Cubism SDK", "description": "Live2D Cubism原生SDK核心库，提供Live2D模型渲染和动画核心功能",
    "category": "桌宠Live2D", "scenarios": ["Live2D渲染", "Cubism开发", "动画引擎"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Live2D官方的C++核心SDK，需通过Python绑定调用",
    "github_stars": 0, "open_source": False,
    "download_command": "pip install cubism-core", "fallback": ["Live2D-Python", "pixiv-live2d"]
}

TOOL_VTubeStudio = {
    "name": "VTubeStudio", "display_name": "VTuber面部追踪", "description": "VTubeStudio面部追踪和Live2D控制工具，支持摄像头面部捕捉",
    "category": "桌宠Live2D", "scenarios": ["VTuber", "面部捕捉", "实时追踪"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "需要摄像头支持，适合VTuber直播和录播",
    "github_stars": 0, "open_source": False,
    "download_command": "pip install vtube-studio", "fallback": ["VRoid", "Live2D-Python"]
}

TOOL_VRoid = {
    "name": "VRoid", "display_name": "3D角色创建", "description": "VRoid 3D角色创建工具，支持自定义角色建模和VRM模型导出",
    "category": "桌宠Live2D", "scenarios": ["3D建模", "角色设计", "VRM模型"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合创作原创3D角色，模型可在多种平台使用",
    "github_stars": 0, "open_source": False,
    "download_command": "pip install vroid", "fallback": ["Mate-Engine", "blender-vrm"]
}

TOOL_pixiv_live2d = {
    "name": "pixiv-live2d", "display_name": "Live2D模型", "description": "Pixiv风格的Live2D模型资源库和加载工具",
    "category": "桌宠Live2D", "scenarios": ["Live2D模型库", "角色资源", "模型导入"],
    "accuracy": 3, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "汇集社区Live2D模型资源，注意遵守模型使用许可",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pixiv-live2d", "fallback": ["Live2D-Python", "cubism-core"]
}

TOOL_pet_simulator = {
    "name": "pet-simulator", "display_name": "宠物模拟器", "description": "桌面宠物模拟器，模拟真实宠物的行为、需求和互动",
    "category": "桌宠Live2D", "scenarios": ["宠物模拟", "虚拟宠物", "养成游戏"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["DyberPet", "Desktop-Cat"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "模拟宠物饥饿、心情、健康等状态，适合喜欢养成类用户的用户",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pet-simulator", "fallback": ["DyberPet", "pet-emotion"]
}

TOOL_desktop_mascot = {
    "name": "desktop-mascot", "display_name": "桌面吉祥物", "description": "可自定义的桌面吉祥物工具，支持图片序列帧动画",
    "category": "桌宠Live2D", "scenarios": ["桌面装饰", "品牌吉祥物", "动画展示"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["float-pet", "Desktop-Cat"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "轻量级实现，支持导入自己的动画序列帧",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install desktop-mascot", "fallback": ["float-pet", "Desktop-Cat"]
}

TOOL_float_pet = {
    "name": "float-pet", "display_name": "浮动宠物", "description": "在桌面自由浮动的宠物角色，支持鼠标拖拽和碰撞交互",
    "category": "桌宠Live2D", "scenarios": ["浮动宠物", "桌面交互", "休闲娱乐"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["DyberPet", "Desktop-Cat"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持穿透点击和置顶显示，不影响正常工作",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install float-pet", "fallback": ["DyberPet", "desktop-mascot"]
}

TOOL_pet_interaction = {
    "name": "pet-interaction", "display_name": "宠物交互", "description": "宠物交互系统，支持触摸、拖拽、说话等多种交互方式",
    "category": "桌宠Live2D", "scenarios": ["宠物互动", "触摸反馈", "语音交互"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "可配合其他桌宠引擎使用，提供丰富的交互反馈",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pet-interaction", "fallback": ["pet-emotion", "pet-games"]
}

TOOL_pet_games = {
    "name": "pet-games", "display_name": "宠物小游戏", "description": "桌面宠物小游戏合集，包含接物、跳跃等休闲游戏",
    "category": "桌宠Live2D", "scenarios": ["休闲游戏", "宠物娱乐", "消遣互动"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "轻量级小游戏，适合工作间隙放松",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pet-games", "fallback": ["pet-interaction", "pet-simulator"]
}

TOOL_pet_skin_custom = {
    "name": "pet-skin-custom", "display_name": "宠物皮肤自定义", "description": "宠物皮肤自定义工具，支持换装、颜色修改和配饰添加",
    "category": "桌宠Live2D", "scenarios": ["皮肤定制", "换装系统", "外观美化"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持导入自定义素材，打造独一无二的宠物外观",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pet-skin-custom", "fallback": ["pet-simulator", "desktop-mascot"]
}

TOOL_pet_emotion = {
    "name": "pet-emotion", "display_name": "宠物情感系统", "description": "宠物情感系统，模拟宠物的心情变化和情感表达",
    "category": "桌宠Live2D", "scenarios": ["情感模拟", "AI行为", "宠物性格"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "可集成到其他桌宠项目中，赋予宠物情感能力",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pet-emotion", "fallback": ["Agentic-Desktop-Pet", "pet-interaction"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}