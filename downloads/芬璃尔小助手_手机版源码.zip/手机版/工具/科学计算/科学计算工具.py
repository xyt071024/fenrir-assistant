TOOL_NUMPY = {
    "name": "numpy",
    "display_name": "NumPy 数组计算",
    "description": "核心科学计算库，提供高性能多维数组对象和数学函数",
    "category": "科学计算",
    "scenarios": ["数值计算", "线性代数", "傅里叶变换", "随机数生成", "数据预处理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "优先使用向量化操作而非Python循环，可获百倍加速",
    "github_stars": 28000,
    "open_source": True,
    "download_command": "pip install numpy",
    "fallback": ["scipy", "math"]
}

TOOL_SCIPY = {
    "name": "scipy",
    "display_name": "SciPy 科学计算",
    "description": "高级科学计算库，涵盖优化、插值、积分、信号处理和统计",
    "category": "科学计算",
    "scenarios": ["数值优化", "信号处理", "图像处理", "稀疏矩阵", "特殊函数"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "求解线性方程组用 scipy.linalg 比 numpy.linalg 更全面",
    "github_stars": 13000,
    "open_source": True,
    "download_command": "pip install scipy",
    "fallback": ["numpy", "sympy"]
}

TOOL_SYMPY = {
    "name": "sympy",
    "display_name": "SymPy 符号计算",
    "description": "符号数学库，支持代数运算、微积分、微分方程和公式推导",
    "category": "科学计算",
    "scenarios": ["符号表达式", "公式推导", "解析求解", "LaTeX输出", "多项式运算"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "sympy.init_printing() 可启用美观的数学公式输出",
    "github_stars": 13000,
    "open_source": True,
    "download_command": "pip install sympy",
    "fallback": ["numpy", "mpmath"]
}

TOOL_PANDAS = {
    "name": "pandas",
    "display_name": "Pandas 数据分析",
    "description": "高性能数据结构和数据分析工具，提供DataFrame和Series对象",
    "category": "科学计算",
    "scenarios": ["表格数据处理", "时间序列分析", "数据清洗", "分组聚合", "文件IO"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "读取大文件时指定 dtype 和 usecols 可大幅降低内存",
    "github_stars": 44000,
    "open_source": True,
    "download_command": "pip install pandas",
    "fallback": ["numpy", "dask"]
}

TOOL_MATPLOTLIB = {
    "name": "matplotlib",
    "display_name": "Matplotlib 绘图",
    "description": "综合2D绘图库，支持线图、散点图、柱状图、等高线等各类图表",
    "category": "科学计算",
    "scenarios": ["数据可视化", "学术论文绘图", "实时图表", "多子图布局", "动画制作"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "plt.style.use('ggplot') 快速切换美观样式",
    "github_stars": 20000,
    "open_source": True,
    "download_command": "pip install matplotlib",
    "fallback": ["pyvista", "plotly"]
}

TOOL_JUPYTER = {
    "name": "jupyter",
    "display_name": "Jupyter 交互式环境",
    "description": "基于Web的交互式计算环境，支持代码、文本、公式和可视化混合编排",
    "category": "科学计算",
    "scenarios": ["探索性分析", "教学演示", "实验记录", "协作研究", "报告生成"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "安装 jupyterlab 获得更现代的界面体验",
    "github_stars": 29000,
    "open_source": True,
    "download_command": "pip install jupyter",
    "fallback": ["ipython"]
}

TOOL_IPYTHON = {
    "name": "ipython",
    "display_name": "IPython 增强终端",
    "description": "增强型Python交互式终端，支持自动补全、魔法命令和富媒体输出",
    "category": "科学计算",
    "scenarios": ["交互编程", "调试测试", "系统命令集成", "并行计算", "性能分析"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "%timeit 魔法命令可精确测量代码执行时间",
    "github_stars": 16500,
    "open_source": True,
    "download_command": "pip install ipython",
    "fallback": ["jupyter"]
}

TOOL_NUMBA = {
    "name": "numba",
    "display_name": "Numba JIT 加速",
    "description": "即时编译器，将Python数值函数编译为机器码获得接近C的性能",
    "category": "科学计算",
    "scenarios": ["数值加速", "循环优化", "GPU计算", "并行计算", "数学运算"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["cython"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "在函数上添加 @njit 装饰器即可自动加速",
    "github_stars": 9800,
    "open_source": True,
    "download_command": "pip install numba",
    "fallback": ["cython", "numpy"]
}

TOOL_CYTHON = {
    "name": "cython",
    "display_name": "Cython Python转C",
    "description": "将Python代码编译为C扩展，大幅提升执行速度",
    "category": "科学计算",
    "scenarios": ["性能优化", "C扩展开发", "包装C库", "数值计算", "类型标注加速"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["numba"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "使用 cdef 声明类型可获得最大加速效果",
    "github_stars": 9200,
    "open_source": True,
    "download_command": "pip install cython",
    "fallback": ["numba", "numpy"]
}

TOOL_DASK = {
    "name": "dask",
    "display_name": "Dask 分布式计算",
    "description": "并行计算库，将NumPy/Pandas/Scikit-learn扩展到集群规模",
    "category": "科学计算",
    "scenarios": ["大数据处理", "分布式数组", "延迟计算", "集群调度", "内存溢出场景"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "dask.array 接口与 numpy 高度兼容，迁移成本低",
    "github_stars": 12500,
    "open_source": True,
    "download_command": "pip install dask",
    "fallback": ["joblib", "numpy"]
}

TOOL_JOBLIB = {
    "name": "joblib",
    "display_name": "Joblib 并行计算",
    "description": "轻量级并行计算和缓存工具，适合循环并行和函数结果缓存",
    "category": "科学计算",
    "scenarios": ["循环并行", "函数缓存", "numpy加速", "内存映射", "任务分发"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Parallel(n_jobs=-1) 自动使用所有CPU核心",
    "github_stars": 3800,
    "open_source": True,
    "download_command": "pip install joblib",
    "fallback": ["dask", "multiprocessing"]
}

TOOL_MPMATH = {
    "name": "mpmath",
    "display_name": "mpmath 高精度计算",
    "description": "高精度浮点和复数运算库，支持任意精度算术和特殊函数",
    "category": "科学计算",
    "scenarios": ["高精度计算", "任意精度算术", "特殊函数求值", "数值积分", "复变函数"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "mp.dps = 100 设置100位十进制精度",
    "github_stars": 1700,
    "open_source": True,
    "download_command": "pip install mpmath",
    "fallback": ["sympy", "numpy"]
}

TOOL_CVXOPT = {
    "name": "cvxopt",
    "display_name": "CVXOPT 凸优化",
    "description": "凸优化求解器，支持线性规划、二次规划和半正定规划",
    "category": "科学计算",
    "scenarios": ["线性规划", "二次规划", "半正定规划", "锥规划", "投资组合优化"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "结合 numpy 矩阵构建优化问题更高效",
    "github_stars": 2100,
    "open_source": True,
    "download_command": "pip install cvxopt",
    "fallback": ["scipy.optimize", "numpy"]
}

TOOL_PYMC3 = {
    "name": "pymc3",
    "display_name": "PyMC3 贝叶斯统计",
    "description": "概率编程库，用于贝叶斯统计建模和马尔可夫链蒙特卡洛采样",
    "category": "科学计算",
    "scenarios": ["贝叶斯推断", "MCMC采样", "层次模型", "贝叶斯回归", "模型比较"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "pm.plot_trace() 快速检查采样收敛情况",
    "github_stars": 8700,
    "open_source": True,
    "download_command": "pip install pymc3",
    "fallback": ["statsmodels", "scipy"]
}

TOOL_STATSMODELS = {
    "name": "statsmodels",
    "display_name": "Statsmodels 统计建模",
    "description": "统计建模和计量经济学库，提供回归分析、时间序列分析和假设检验",
    "category": "科学计算",
    "scenarios": ["线性回归", "时间序列分析", "假设检验", "方差分析", "统计模型诊断"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "sm.OLS(y, X).fit() 即可完成最小二乘回归",
    "github_stars": 10000,
    "open_source": True,
    "download_command": "pip install statsmodels",
    "fallback": ["scipy.stats", "pymc3"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}