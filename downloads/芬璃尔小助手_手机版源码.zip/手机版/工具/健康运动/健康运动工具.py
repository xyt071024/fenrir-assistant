TOOL_fitbit = {
    "name": "fitbit", "display_name": "Fitbit数据", "category": "健康运动",
    "description": "从 Fitbit 官方 API 获取用户的日常活动、睡眠、心率和体重等健康数据，支持 OAuth 2.0 认证和多种时间维度聚合。",
    "scenarios": ["可穿戴设备数据同步", "个人健康仪表盘", "睡眠质量分析", "运动趋势追踪"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": ["google_fit", "apple_health"],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "建议先申请 Fitbit Developer 账号并注册应用获取 client_id 和 client_secret。数据刷新间隔建议不小于15分钟。",
    "github_stars": 2800, "open_source": True,
    "download_command": "pip install fitbit",
    "fallback": ["google_fit", "apple_health"]
}

TOOL_google_fit = {
    "name": "google_fit", "display_name": "Google健身", "category": "健康运动",
    "description": "接入 Google Fit REST API，读取用户的步数、卡路里消耗、心率、活动时长等健身数据，支持跨平台数据聚合。",
    "scenarios": ["Android 健康数据同步", "健身数据汇总分析", "心率趋势监控", "运动目标跟踪"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["fitbit", "apple_health"],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "需要启用 Fitness API 并配置 OAuth 2.0 同意屏幕。推荐使用 google-auth 库进行认证。",
    "github_stars": 3500, "open_source": True,
    "download_command": "pip install google-auth google-auth-oauthlib google-auth-httplib2",
    "fallback": ["fitbit", "apple_health"]
}

TOOL_apple_health = {
    "name": "apple_health", "display_name": "Apple健康", "category": "健康运动",
    "description": "通过 HealthKit 框架或导出 XML 解析 Apple Health 数据，涵盖活动能量、心率、睡眠分析、血氧等健康指标。",
    "scenarios": ["iOS 健康数据导出", "Apple Watch 数据解析", "健康记录备份分析", "心率变异性研究"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["fitbit", "google_fit"],
    "safety_level": "high", "requires_network": False,
    "usage_tips": "数据可通过 iOS 导出 Health Export XML 进行离线解析。HKQuantityTypeIdentifier 枚举需与 Apple 官方文档保持一致。",
    "github_stars": 1200, "open_source": True,
    "download_command": "pip install healthkit-parser",
    "fallback": ["google_fit", "fitbit"]
}

TOOL_garmin_connect = {
    "name": "garmin_connect", "display_name": "Garmin", "category": "健康运动",
    "description": "连接 Garmin Connect 平台，同步户外运动记录（跑步、骑行、游泳）、全天活动数据和身体监测指标。",
    "scenarios": ["户外运动记录导入", "Garmin 设备数据同步", "运动路线分析", "体能状态监控"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["strava"],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "Garmin 官方 API 需要申请合作资质，也可使用 garth 库进行非官方登录。注意限频策略。",
    "github_stars": 1500, "open_source": True,
    "download_command": "pip install garth",
    "fallback": ["fitbit", "strava"]
}

TOOL_strava = {
    "name": "strava", "display_name": "Strava运动", "category": "健康运动",
    "description": "集成 Strava v3 API，读取骑行、跑步等运动活动的 GPX 轨迹、海拔、速度、功率等详细运动指标。",
    "scenarios": ["运动轨迹可视化", "骑行数据分析", "跑步训练记录", "俱乐部活动统计"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["garmin_connect"],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "注册 Strava API 应用获取 client_id，使用 Authorization Code 流获取 access_token。每15分钟限额600次请求。",
    "github_stars": 4200, "open_source": True,
    "download_command": "pip install stravalib",
    "fallback": ["garmin_connect", "fitbit"]
}

TOOL_whoop_api = {
    "name": "whoop_api", "display_name": "Whoop", "category": "健康运动",
    "description": "对接 Whoop 手环 API 获取用户的心率变异性、静息心率、睡眠阶段、恢复评分和训练负荷等深度生理指标。",
    "scenarios": ["运动员状态监控", "恢复评分分析", "睡眠阶段研究", "训练负荷管理"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "high", "requires_network": True,
    "usage_tips": "Whoop API 需通过官方申请开发者访问权限。恢复指标建议结合静息心率和 HRV 综合判断。",
    "github_stars": 800, "open_source": True,
    "download_command": "pip install whoop-api",
    "fallback": ["fitbit", "heart_rate"]
}

TOOL_sleep_analytics = {
    "name": "sleep_analytics", "display_name": "睡眠分析", "category": "健康运动",
    "description": "基于多维度睡眠数据（时长、阶段分布、觉醒次数、环境噪声）进行深度睡眠质量评估与改善建议分析。",
    "scenarios": ["睡眠质量评分", "深睡比例分析", "睡眠规律检测", "失眠辅助诊断"],
    "accuracy": 3, "efficiency": 4, "speed": 5,
    "conflicts_with": [],
    "safety_level": "medium", "requires_network": False,
    "usage_tips": "建议配合至少14天的连续数据进行分析，结果更具参考价值。深睡占比低于15%可能提示睡眠质量不佳。",
    "github_stars": 600, "open_source": True,
    "download_command": "pip install pandas numpy scipy",
    "fallback": ["fitbit", "whoop_api"]
}

TOOL_calorie_tracker = {
    "name": "calorie_tracker", "display_name": "卡路里", "category": "健康运动",
    "description": "根据食物成分、运动消耗和基础代谢率计算每日卡路里盈亏，支持自定义食物库和膳食记录。",
    "scenarios": ["饮食记录与热量统计", "减脂增肌热量规划", "基础代谢计算", "运动消耗估算"],
    "accuracy": 3, "efficiency": 5, "speed": 5,
    "conflicts_with": ["nutrition_analysis"],
    "safety_level": "low", "requires_network": True,
    "usage_tips": "食物热量数据参考中国食物成分表或 USDA 数据库。基础代谢推荐使用 Mifflin-St Jeor 公式。",
    "github_stars": 900, "open_source": True,
    "download_command": "pip install calorie-calculator",
    "fallback": ["nutrition_analysis"]
}

TOOL_heart_rate = {
    "name": "heart_rate", "display_name": "心率", "category": "健康运动",
    "description": "监测和分析实时及历史心率数据，包括静息心率、运动心率区间、心率变异性（HRV）等关键心血管指标。",
    "scenarios": ["实时心率监控", "心率区间训练指导", "HRV 压力评估", "静息心率趋势分析"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "high", "requires_network": False,
    "usage_tips": "HRV 测量建议在早晨起床后静卧5分钟进行。正常成年静息心率范围60-100次/分。",
    "github_stars": 1100, "open_source": True,
    "download_command": "pip install heartpy",
    "fallback": ["fitbit", "whoop_api"]
}

TOOL_steps_counter = {
    "name": "steps_counter", "display_name": "计步", "category": "健康运动",
    "description": "基于加速度计数据的步数统计算法，支持设备端实时计步和云端数据同步汇总。",
    "scenarios": ["每日步数统计", "运动量达标提醒", "步行趋势周报", "久坐提醒"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "low", "requires_network": False,
    "usage_tips": "世界卫生组织建议成年人每日步行8000-10000步。算法对慢走和持物行走可能产生偏差。",
    "github_stars": 700, "open_source": True,
    "download_command": "pip install pedometer",
    "fallback": ["fitbit", "google_fit"]
}

TOOL_nutrition_analysis = {
    "name": "nutrition_analysis", "display_name": "营养分析", "category": "健康运动",
    "description": "对膳食结构进行全面营养评估，涵盖宏量营养素、微量元素、膳食纤维和水分摄入，提供个性化膳食建议。",
    "scenarios": ["膳食结构评估", "微量元素缺乏筛查", "减脂增肌饮食方案", "过敏原识别"],
    "accuracy": 3, "efficiency": 4, "speed": 4,
    "conflicts_with": ["calorie_tracker"],
    "safety_level": "medium", "requires_network": True,
    "usage_tips": "建议记录至少3天的完整饮食数据以获得准确分析。营养素推荐参考《中国居民膳食营养素参考摄入量》。",
    "github_stars": 500, "open_source": True,
    "download_command": "pip install nutrition-calculator",
    "fallback": ["calorie_tracker"]
}

TOOL_workout_plan = {
    "name": "workout_plan", "display_name": "运动计划", "category": "健康运动",
    "description": "根据用户体能水平、运动目标和可用器械生成个性化训练计划，支持渐进式超负荷原则和周期化编排。",
    "scenarios": ["力量训练计划编排", "减脂运动方案", "家庭健身指导", "运动周期规划"],
    "accuracy": 3, "efficiency": 4, "speed": 5,
    "conflicts_with": [],
    "safety_level": "medium", "requires_network": False,
    "usage_tips": "训练计划应遵循 FITT 原则（频率、强度、时间、类型）。建议每4-6周调整一次计划以避免平台期。",
    "github_stars": 1300, "open_source": True,
    "download_command": "pip install workout-generator",
    "fallback": ["strava", "calorie_tracker"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}