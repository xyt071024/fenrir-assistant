TOOL_LANGUAGETOOL = {
    "name": "language_tool",
    "display_name": "LanguageTool",
    "description": "基于 LanguageTool 的语法和风格检查，支持中英文多种语言，可检测拼写错误、语法问题、标点符号和风格建议",
    "category": "文本优化",
    "scenarios": ["文章校对", "语法纠错", "写作辅助", "语言学习"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["gramformer", "pycorrector"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "适合长篇文档校对，支持自定义规则和禁用特定检查项",
    "github_stars": 3100,
    "open_source": True,
    "download_command": "pip install language-tool-python",
    "fallback": ["gramformer", "spacy"]
}

TOOL_GRAMFORMER = {
    "name": "gramformer",
    "display_name": "Gramformer",
    "description": "基于Transformer的语法纠错模型，可检测和纠正语法错误，支持英语句子级别的语法纠正",
    "category": "文本优化",
    "scenarios": ["语法纠错", "英语写作", "语法检测", "句子修正"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["language_tool", "pycorrector"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "对完整句子效果最佳，建议配合拼写检查一起使用",
    "github_stars": 1600,
    "open_source": True,
    "download_command": "pip install gramformer",
    "fallback": ["language_tool", "textblob"]
}

TOOL_TEXTSTAT = {
    "name": "textstat",
    "display_name": "textstat",
    "description": "文本可读性分析工具，计算Flesch Reading Ease、SMOG指数、音节数、难词占比等多项可读性指标",
    "category": "文本优化",
    "scenarios": ["可读性分析", "文本难度评估", "写作质量评估", "教育评估"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合评估文章适合的阅读年龄和难度等级",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install textstat",
    "fallback": ["nltk"]
}

TOOL_SPACY = {
    "name": "spacy",
    "display_name": "spaCy",
    "description": "工业级自然语言处理库，支持命名实体识别、词性标注、依存句法分析、词向量等NLP任务",
    "category": "文本优化",
    "scenarios": ["NLP处理", "实体识别", "句法分析", "词向量", "文本分类"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["stanza", "hanlp"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需下载语言模型 python -m spacy download en_core_web_sm",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install spacy",
    "fallback": ["stanza", "nltk"]
}

TOOL_JIEBA = {
    "name": "jieba",
    "display_name": "结巴分词",
    "description": "优秀的中文分词库，支持精确模式、全模式、搜索引擎模式，可自定义词典和词性标注",
    "category": "文本优化",
    "scenarios": ["中文分词", "关键词提取", "词频统计", "中文NLP预处理"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["hanlp", "pkuseg"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "建议加载自定义词典提高特定领域分词准确性",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install jieba",
    "fallback": ["hanlp", "pynlpir"]
}

TOOL_OPENCC = {
    "name": "opencc",
    "display_name": "OpenCC",
    "description": "中文简繁转换工具，支持简体到繁体、繁体到简体、香港繁体、台湾繁体等多种转换模式",
    "category": "文本优化",
    "scenarios": ["繁简转换", "中文标准化", "跨区域文本处理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持 s2t(简转繁), t2s(繁转简), s2hk(简转香港繁) 等多种配置",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install opencc-python-reimplemented",
    "fallback": ["zhconv"]
}

TOOL_PYPINYIN = {
    "name": "pypinyin",
    "display_name": "pypinyin",
    "description": "汉字拼音转换工具，支持多种拼音风格，可处理多音字、声调标注、首字母提取等功能",
    "category": "文本优化",
    "scenarios": ["拼音转换", "中文注音", "输入法开发", "语音合成预处理"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "多音字可通过上下文参数提高准确率",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pypinyin",
    "fallback": ["python-pinyin"]
}

TOOL_REFORMATTER = {
    "name": "reformatter",
    "display_name": "reformatter",
    "description": "文本格式化工具，支持自动缩进、换行调整、空格规范化、引号统一、标点标准化等格式化操作",
    "category": "文本优化",
    "scenarios": ["文本排版", "格式规范化", "代码注释格式化", "文档美化"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["textcleaner"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "可自定义格式化规则，适合批量处理不规范文本",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install reformatter",
    "fallback": ["textcleaner", "autopep8"]
}

TOOL_TEXTCLEANER = {
    "name": "textcleaner",
    "display_name": "textcleaner",
    "description": "文本清洗工具，去除多余空白、特殊字符、HTML标签、Emoji、控制字符等噪音数据",
    "category": "文本优化",
    "scenarios": ["数据清洗", "文本预处理", "爬虫数据清理", "日志清洗"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["reformatter"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持正则表达式自定义清洗规则，可保留/删除指定模式",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install textcleaner",
    "fallback": ["reformatter", "beautifulsoup4"]
}

TOOL_SPELLCHECKER = {
    "name": "spellchecker",
    "display_name": "spellchecker",
    "description": "拼写检查工具，基于字典的拼写错误检测和纠正，支持多种语言词典和自定义词库",
    "category": "文本优化",
    "scenarios": ["拼写检查", "英文校对", "错别字检测", "写作辅助"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["autocorrect", "language_tool"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "可加载自定义词典提高专业术语识别率",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pyspellchecker",
    "fallback": ["autocorrect", "textblob"]
}

TOOL_AUTOCORRECT = {
    "name": "autocorrect",
    "display_name": "autocorrect",
    "description": "自动拼写纠错工具，基于编辑距离和词频统计，自动检测并纠正拼写错误",
    "category": "文本优化",
    "scenarios": ["自动纠错", "拼写修正", "实时输入校正", "文本预处理"],
    "accuracy": 3,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["spellchecker"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持多种语言，轻量级适合实时处理场景",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install autocorrect",
    "fallback": ["spellchecker", "textblob"]
}

TOOL_TEXTBLOB = {
    "name": "textblob",
    "display_name": "TextBlob",
    "description": "简易文本处理库，提供词性标注、名词短语提取、情感分析、分类、翻译等NLP功能",
    "category": "文本优化",
    "scenarios": ["情感分析", "词性标注", "文本分类", "基础NLP"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["nltk", "spacy"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合快速原型开发，底层基于NLTK",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install textblob",
    "fallback": ["nltk", "spacy"]
}

TOOL_NLTK = {
    "name": "nltk",
    "display_name": "NLTK",
    "description": "自然语言工具包，包含分词、词干提取、标注、句法分析、语义推理等50+语料库和词汇资源",
    "category": "文本优化",
    "scenarios": ["NLP教学", "文本分类", "情感分析", "信息提取", "语言研究"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["spacy", "stanza"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "首次使用需下载数据资源 nltk.download()",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install nltk",
    "fallback": ["spacy", "textblob"]
}

TOOL_STANZA = {
    "name": "stanza",
    "display_name": "Stanza",
    "description": "Stanford NLP官方Python库，支持分词、词性标注、依存句法分析、命名实体识别等，覆盖70+语言",
    "category": "文本优化",
    "scenarios": ["多语言NLP", "句法分析", "实体识别", "学术研究"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["spacy", "hanlp"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "首次需下载语言模型 stanza.download('en')",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install stanza",
    "fallback": ["spacy", "nltk"]
}

TOOL_HANLP = {
    "name": "hanlp",
    "display_name": "HanLP",
    "description": "面向生产环境的中文NLP工具包，支持分词、词性标注、命名实体识别、依存句法分析、语义角色标注等",
    "category": "文本优化",
    "scenarios": ["中文NLP", "中文分词", "实体识别", "句法分析"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["jieba", "stanza"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持多任务联合模型，一次加载可完成多项NLP任务",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install hanlp",
    "fallback": ["jieba", "spacy"]
}

TOOL_SYNONYMS = {
    "name": "synonyms",
    "display_name": "Synonyms",
    "description": "中文同义词工具，基于Word2Vec的词向量相似度计算，支持同义词查找和词语相似度比较",
    "category": "文本优化",
    "scenarios": ["同义词替换", "文本扩写", "词语相似度", "语义分析"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["wordnet"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "首次使用会自动下载预训练词向量模型",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install synonyms",
    "fallback": ["wordnet", "jionlp"]
}

TOOL_TEXTRANK = {
    "name": "textrank",
    "display_name": "TextRank",
    "description": "基于TextRank算法的关键词提取和文本摘要工具，无监督方法，无需训练数据即可抽取关键信息",
    "category": "文本优化",
    "scenarios": ["关键词提取", "文本摘要", "信息检索", "文档标注"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["sumy", "gensim"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "对长文本效果更佳，可通过调整窗口大小控制提取数量",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install textrank",
    "fallback": ["sumy", "jieba.analyse"]
}

TOOL_SUMY = {
    "name": "sumy",
    "display_name": "sumy",
    "description": "文本自动摘要工具，支持LSA、TextRank、LexRank、Luhn、Edmundson等多种摘要算法",
    "category": "文本优化",
    "scenarios": ["自动摘要", "文档压缩", "信息提取", "文章概要"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["textrank", "gensim"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "LSA算法速度较快，TextRank算法质量较高",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install sumy",
    "fallback": ["textrank", "gensim"]
}

TOOL_GENSIM = {
    "name": "gensim",
    "display_name": "Gensim",
    "description": "主题建模和词向量库，支持Word2Vec、Doc2Vec、LDA、LSI等主题模型，适合大规模语料处理",
    "category": "文本优化",
    "scenarios": ["主题建模", "词向量训练", "语义相似度", "文档聚类"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["sumy"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "处理大规模语料时建议使用流式训练以节省内存",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install gensim",
    "fallback": ["scikit-learn", "sumy"]
}

TOOL_PYCORRECTOR = {
    "name": "pycorrector",
    "display_name": "pycorrector",
    "description": "中文文本纠错工具，基于MacBERT和Seq2Seq模型，可检测和纠正中文拼写错误和语法错误",
    "category": "文本优化",
    "scenarios": ["中文纠错", "错别字检测", "中文校对", "文本校正"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["language_tool", "gramformer"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "建议使用MacBERT版本模型，纠错效果最佳",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pycorrector",
    "fallback": ["language_tool", "jieba"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
