TOOL_WordPress_Plugin_Directory = {
    "name": "wordpress-plugins", "display_name": "WordPress插件目录", "description": "全球最大的CMS插件市场，收录63000+免费插件，涵盖SEO、性能、安全、电商、页面构建等所有WordPress功能扩展",
    "category": "插件生态索引", "scenarios": ["WordPress建站", "功能扩展", "CMS开发"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "建议优先选择活跃安装量10000+且近期有更新的插件",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_VS_Code_Marketplace = {
    "name": "vscode-marketplace", "display_name": "VS Code扩展市场", "description": "微软VS Code官方扩展市场，收录60000+扩展，覆盖编程语言支持、主题、调试器、LSP、Git集成等全开发领域",
    "category": "插件生态索引", "scenarios": ["编辑器扩展", "开发效率", "代码美化"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "在VS Code中按Ctrl+Shift+X直接搜索安装",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_Obsidian_Community_Plugins = {
    "name": "obsidian-plugins", "display_name": "Obsidian社区插件", "description": "Obsidian笔记软件社区插件生态，4900+插件，涵盖笔记增强、图谱可视化、发布、任务管理、白板、日历等扩展",
    "category": "插件生态索引", "scenarios": ["笔记增强", "知识管理", "个人效率"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "Obsidian设置中关闭安全模式即可浏览安装社区插件",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_Home_Assistant_Addons = {
    "name": "homeassistant-addons", "display_name": "Home Assistant插件", "description": "Home Assistant智能家居平台官方和社区插件库，2000+插件，覆盖智能设备集成、自动化、仪表盘、语音助手等",
    "category": "插件生态索引", "scenarios": ["智能家居", "设备集成", "自动化控制"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "通过Supervisor面板的Add-on Store直接安装",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_ComfyUI_Custom_Nodes = {
    "name": "comfyui-nodes", "display_name": "ComfyUI自定义节点", "description": "ComfyUI的社区自定义节点生态，数千个节点，扩展Stable Diffusion工作流能力，支持视频生成、ControlNet、IP-Adapter等",
    "category": "插件生态索引", "scenarios": ["AI绘图工作流", "Stable Diffusion", "节点式编程"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "medium",
    "requires_network": True, "usage_tips": "通过ComfyUI-Manager管理节点，一键安装更新",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_AstrBot_Plugin_Store = {
    "name": "astrbot-plugins", "display_name": "AstrBot插件商店", "description": "AstrBot聊天机器人框架插件生态，数百个插件，覆盖AI对话、群管、娱乐、工具、游戏等QQ/微信机器人功能",
    "category": "插件生态索引", "scenarios": ["聊天机器人", "QQ机器人", "自动化回复"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "在AstrBot管理面板中可直接浏览和安装插件",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_npm_packages = {
    "name": "npm", "display_name": "npm包注册表", "description": "Node.js官方包管理器，200万+包，全球最大的JavaScript包生态，覆盖前端、后端、CLI工具、框架等所有JS领域",
    "category": "插件生态索引", "scenarios": ["JavaScript开发", "Node.js", "前端开发"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "使用npm search或访问npmjs.com搜索包",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_Python_PyPI = {
    "name": "pypi", "display_name": "Python PyPI包索引", "description": "Python官方包索引PyPI，50万+包，Python生态核心，覆盖数据科学、Web开发、AI/ML、自动化、网络等所有领域",
    "category": "插件生态索引", "scenarios": ["Python开发", "数据科学", "Web后端"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "使用pip install从PyPI安装，访问pypi.org搜索",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_Docker_Extensions = {
    "name": "docker-extensions", "display_name": "Docker扩展市场", "description": "Docker Desktop扩展市场，100+扩展，集成开发工具、监控、数据库管理、Kubernetes等容器生态工具",
    "category": "插件生态索引", "scenarios": ["容器管理", "Docker工具", "开发环境"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "在Docker Desktop的Extensions面板中浏览安装",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_Chrome_Web_Store = {
    "name": "chrome-extensions", "display_name": "Chrome扩展商店", "description": "Chrome浏览器扩展商店，全球最大的浏览器扩展市场，涵盖广告拦截、密码管理、开发工具、生产力、娱乐等全品类",
    "category": "插件生态索引", "scenarios": ["浏览器扩展", "网页增强", "开发调试"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "通过Chrome网上应用店搜索或直接访问扩展链接",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": ["Firefox Add-ons"]
}

TOOL_Firefox_Addons = {
    "name": "firefox-addons", "display_name": "Firefox附加组件", "description": "Firefox浏览器附加组件市场，与Chrome扩展生态互补，支持WebExtensions标准，注重隐私保护的扩展更受欢迎",
    "category": "插件生态索引", "scenarios": ["Firefox扩展", "隐私保护", "网页增强"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "大多数Chrome扩展可直接移植到Firefox",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": ["Chrome Web Store"]
}

TOOL_Figma_Plugins = {
    "name": "figma-plugins", "display_name": "Figma插件市场", "description": "Figma设计工具插件社区，涵盖图标库、设计系统、自动布局、导出工具、原型动画、协作增强等设计工作流扩展",
    "category": "插件生态索引", "scenarios": ["UI设计", "原型设计", "设计系统"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "在Figma编辑器内通过Menu > Plugins浏览安装",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": ["Sketch Plugins"]
}

TOOL_Sketch_Plugins = {
    "name": "sketch-plugins", "display_name": "Sketch插件生态", "description": "Sketch设计工具插件生态，支持设计自动化、资源管理、导出优化、协作增强，适合Mac平台UI/UX设计师",
    "category": "插件生态索引", "scenarios": ["Mac设计", "UI/UX", "设计自动化"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "Sketch内置Plugin Manager，支持一键安装",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": ["Figma Plugins"]
}

TOOL_Blender_Addons = {
    "name": "blender-addons", "display_name": "Blender插件市场", "description": "Blender 3D创作套件插件生态，涵盖建模、雕刻、材质、渲染、动画、模拟、UV展开等3D全流程工具扩展",
    "category": "插件生态索引", "scenarios": ["3D建模", "动画制作", "游戏资源"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "在Blender Edit > Preferences > Add-ons中安装管理",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_Unity_Asset_Store = {
    "name": "unity-asset-store", "display_name": "Unity资源商店", "description": "Unity引擎官方资源商店，提供模型、材质、脚本、音效、粒子特效、完整项目模板等游戏开发资源",
    "category": "插件生态索引", "scenarios": ["Unity游戏开发", "3D资源", "游戏模板"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["Unreal Marketplace"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "在Unity Editor中通过Window > Asset Store直接访问",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": ["Unreal Marketplace"]
}

TOOL_Unreal_Marketplace = {
    "name": "unreal-marketplace", "display_name": "虚幻引擎商城", "description": "Unreal Engine官方商城，提供高质量3D模型、环境、角色、动画、VFX、蓝图和完整游戏项目，与UE深度集成",
    "category": "插件生态索引", "scenarios": ["UE5开发", "3A资源", "游戏开发"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["Unity Asset Store"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "每月有免费资源，定期领取可节省大量成本",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": ["Unity Asset Store"]
}

TOOL_Godot_Asset_Store = {
    "name": "godot-assets", "display_name": "Godot资源商店", "description": "Godot开源游戏引擎资源商店，提供插件、脚本、材质、模型、音效等资源，社区驱动，完全免费使用",
    "category": "插件生态索引", "scenarios": ["Godot开发", "开源游戏", "2D/3D游戏"],
    "accuracy": 4, "efficiency": 3, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "在Godot Asset Library中直接浏览下载，全部免费",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": ["Unity Asset Store"]
}

TOOL_Photoshop_Plugins = {
    "name": "photoshop-plugins", "display_name": "Photoshop插件生态", "description": "Adobe Photoshop插件生态，涵盖滤镜、抠图、调色、批量处理、文字特效、AI增强等图像处理扩展",
    "category": "插件生态索引", "scenarios": ["图像处理", "照片编辑", "平面设计"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "通过Adobe Exchange或Creative Cloud桌面应用安装",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_DaVinci_Resolve_插件 = {
    "name": "davinci-plugins", "display_name": "DaVinci Resolve插件", "description": "DaVinci Resolve视频调色剪辑软件插件生态，提供特效转场、调色预设、字幕模板、视觉特效等视频制作扩展",
    "category": "插件生态索引", "scenarios": ["视频剪辑", "调色", "视觉特效"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "通过Resolve的Fusion页面或OFX插件接口扩展功能",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

TOOL_OBS_Studio_插件 = {
    "name": "obs-plugins", "display_name": "OBS Studio插件", "description": "OBS Studio直播录制软件插件生态，提供推流优化、滤镜特效、音频增强、源管理、多平台直播等扩展",
    "category": "插件生态索引", "scenarios": ["直播推流", "屏幕录制", "视频制作"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "通过OBS的Tools菜单或社区插件管理器安装",
    "github_stars": 0, "open_source": False,
    "download_command": "网页访问", "fallback": []
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}