TOOL_OPENCV_AR = {
    "name": "opencv_ar",
    "display_name": "OpenCV AR跟踪",
    "description": "基于OpenCV的增强现实跟踪工具，支持摄像头姿态估计、标记点检测和实时AR叠加",
    "category": "AR/VR",
    "scenarios": ["AR标记跟踪", "摄像头姿态估计", "实时AR应用原型开发", "计算机视觉教学"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["aruco", "mediapipe_hands"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "适用于快速AR原型开发，结合OpenCV的图像处理管线效果更佳",
    "github_stars": 79000,
    "open_source": True,
    "download_command": "pip install opencv-python opencv-contrib-python",
    "fallback": ["aruco", "mediapipe_hands"]
}

TOOL_OPEN3D = {
    "name": "open3d_pointcloud",
    "display_name": "Open3D 3D点云",
    "description": "开源3D数据处理库，支持点云、网格、RGB-D图像处理和3D可视化",
    "category": "AR/VR",
    "scenarios": ["3D点云处理", "三维重建", "SLAM可视化", "3D深度学习"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "处理大规模点云时建议先进行体素下采样以提高性能",
    "github_stars": 11500,
    "open_source": True,
    "download_command": "pip install open3d",
    "fallback": ["pyvr"]
}

TOOL_PYVR = {
    "name": "pyvr",
    "display_name": "PyVR VR工具",
    "description": "Python虚拟现实开发框架，支持VR头显交互、3D场景渲染和空间计算",
    "category": "AR/VR",
    "scenarios": ["VR应用开发", "虚拟场景漫游", "VR交互实验", "空间计算"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["openxr"],
    "safety_level": "medium",
    "requires_network": False,
    "usage_tips": "搭配VR头显使用前请确保驱动已正确安装",
    "github_stars": 3200,
    "open_source": True,
    "download_command": "pip install pyvr",
    "fallback": ["openxr"]
}

TOOL_ARCORE = {
    "name": "arcore",
    "display_name": "ARCore",
    "description": "Google的增强现实平台，支持Android设备的运动跟踪、环境理解和光照估计",
    "category": "AR/VR",
    "scenarios": ["Android AR应用开发", "运动跟踪", "环境理解", "光照估计"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["arkit"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "需要支持ARCore的Android设备，建议使用Sceneform SDK简化开发",
    "github_stars": 18500,
    "open_source": True,
    "download_command": "pip install arcore-python",
    "fallback": ["arfoundation", "opencv_ar"]
}

TOOL_ARFOUNDATION = {
    "name": "arfoundation",
    "display_name": "AR Foundation",
    "description": "Unity跨平台AR框架，支持iOS ARKit和Android ARCore的统一开发接口",
    "category": "AR/VR",
    "scenarios": ["跨平台AR开发", "Unity AR应用", "AR游戏开发", "企业AR方案"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "与Unity编辑器紧密集成，建议使用Unity Package Manager安装",
    "github_stars": 8700,
    "open_source": True,
    "download_command": "unity-package-manager add com.unity.xr.arfoundation",
    "fallback": ["arcore", "arkit"]
}

TOOL_OPENXR = {
    "name": "openxr",
    "display_name": "OpenXR",
    "description": "Khronos开放标准，提供跨平台VR/AR应用编程接口，支持多种头显设备",
    "category": "AR/VR",
    "scenarios": ["跨平台XR开发", "VR头显应用", "工业XR模拟", "XR标准兼容测试"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pyvr"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "确保头显驱动支持OpenXR运行时，推荐使用Monado开源运行时",
    "github_stars": 3200,
    "open_source": True,
    "download_command": "pip install openxr",
    "fallback": ["pyvr"]
}

TOOL_VUFORIA = {
    "name": "vuforia",
    "display_name": "Vuforia",
    "description": "PTC公司的商业AR平台，支持图像识别、模型目标跟踪和虚拟按钮交互",
    "category": "AR/VR",
    "scenarios": ["工业AR应用", "品牌营销AR", "产品可视化", "教育培训AR"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "需要注册Vuforia开发者账号获取License Key",
    "github_stars": 4500,
    "open_source": False,
    "download_command": "pip install vuforia",
    "fallback": ["arfoundation", "opencv_ar"]
}

TOOL_HOLOLENS = {
    "name": "hololens",
    "display_name": "HoloLens",
    "description": "微软混合现实头显开发工具包，支持全息影像叠加和空间映射",
    "category": "AR/VR",
    "scenarios": ["混合现实开发", "全息应用", "远程协作MR", "空间映射与定位"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["openxr"],
    "safety_level": "medium",
    "requires_network": True,
    "usage_tips": "开发前需部署HoloLens模拟器或连接实际设备",
    "github_stars": 8900,
    "open_source": True,
    "download_command": "pip install hololens-toolkit",
    "fallback": ["openxr", "arfoundation"]
}

TOOL_MEDIAPIPE_HANDS = {
    "name": "mediapipe_hands",
    "display_name": "MediaPipe手部跟踪",
    "description": "Google MediaPipe高精度手部关键点检测与跟踪，支持21个关键点实时识别",
    "category": "AR/VR",
    "scenarios": ["手势识别控制", "AR交互输入", "手语翻译", "虚拟手部动画"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["opencv_ar"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "支持CPU和GPU加速，GPU模式下延迟可低至5ms",
    "github_stars": 28000,
    "open_source": True,
    "download_command": "pip install mediapipe",
    "fallback": ["opencv_ar"]
}

TOOL_ARUCO = {
    "name": "aruco",
    "display_name": "ARUCO二维码",
    "description": "OpenCV内置的ARUCO标记生成与检测工具，常用于相机标定和AR定位",
    "category": "AR/VR",
    "scenarios": ["相机标定", "AR标记定位", "机器人导航", "3D姿态估计"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["opencv_ar"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "选择合适的字典尺寸平衡检测精度和性能",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install opencv-contrib-python",
    "fallback": ["opencv_ar"]
}

TOOL_PYTHON_AR = {
    "name": "python_ar",
    "display_name": "Python AR工具包",
    "description": "纯Python实现的AR工具集合，包含标记检测、3D渲染和相机标定功能",
    "category": "AR/VR",
    "scenarios": ["AR教育演示", "轻量级AR应用", "Python AR教学", "快速AR原型"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "适合轻量级AR应用和教学演示，生产环境建议使用OpenCV方案",
    "github_stars": 1200,
    "open_source": True,
    "download_command": "pip install python-ar-toolkit",
    "fallback": ["opencv_ar", "aruco"]
}

TOOL_ARKIT = {
    "name": "arkit",
    "display_name": "ARKit苹果AR",
    "description": "Apple的增强现实框架，支持iOS设备的人脸跟踪、场景理解和光线估计",
    "category": "AR/VR",
    "scenarios": ["iOS AR应用开发", "人脸AR效果", "AR测量工具", "ARKit游戏"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["arcore"],
    "safety_level": "high",
    "requires_network": False,
    "usage_tips": "仅支持iOS设备和配备Apple Silicon的Mac，使用Swift或RealityKit开发",
    "github_stars": 12500,
    "open_source": False,
    "download_command": "xcodebuild -downloadPlatform iOS",
    "fallback": ["arfoundation", "arcore"]
}

TOOL_WEBXR = {
    "name": "webxr",
    "display_name": "WebXR",
    "description": "W3C标准的Web端XR API，支持浏览器中的VR和AR体验，无需安装原生应用",
    "category": "AR/VR",
    "scenarios": ["WebAR/VR应用", "跨平台XR体验", "在线3D展示", "WebXR教育"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "high",
    "requires_network": True,
    "usage_tips": "推荐使用Three.js或A-Frame框架简化WebXR开发",
    "github_stars": 6200,
    "open_source": True,
    "download_command": "npm install @webxr-input-profiles/motion-controllers",
    "fallback": ["openxr"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
