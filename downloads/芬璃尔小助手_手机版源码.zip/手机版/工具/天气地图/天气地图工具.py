TOOL_python_weather = {
    "name": "python-weather",
    "display_name": "python-weather",
    "description": "免费异步天气API库，无需API密钥即可获取实时天气和预报数据",
    "category": "天气数据",
    "scenarios": ["实时天气查询", "天气预报获取", "异步天气数据"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["PyOWM"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "完全免费无需API Key，异步设计性能优异",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install python-weather",
    "fallback": ["PyOWM"]
}

TOOL_PyOWM = {
    "name": "PyOWM",
    "display_name": "PyOWM",
    "description": "OpenWeatherMap官方Python SDK，提供全球天气数据/预报/历史天气查询",
    "category": "天气数据",
    "scenarios": ["全球天气查询", "气象数据API", "天气预警获取"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["python-weather"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "数据来源可靠，免费层每日有调用次数限制",
    "github_stars": 812,
    "open_source": True,
    "download_command": "pip install pyowm",
    "fallback": ["python-weather"]
}

TOOL_meteostat = {
    "name": "meteostat",
    "display_name": "Meteostat",
    "description": "历史天气数据分析和可视化工具，提供全球气象站历史观测数据",
    "category": "天气数据",
    "scenarios": ["历史天气分析", "气候研究", "气象数据可视化"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "适合做气候分析和历史天气研究，数据覆盖全球",
    "github_stars": 438,
    "open_source": True,
    "download_command": "pip install meteostat",
    "fallback": []
}

TOOL_wetterdienst = {
    "name": "wetterdienst",
    "display_name": "Wetterdienst",
    "description": "德国气象局(DWD)官方数据接口，提供德国及欧洲高精度气象数据",
    "category": "天气数据",
    "scenarios": ["德国气象数据", "欧洲天气预报", "气象科学研究"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "欧洲气象研究首选，数据质量和精度极高",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install wetterdienst",
    "fallback": []
}

TOOL_PirateWeather = {
    "name": "Pirate-Weather",
    "display_name": "Pirate-Weather",
    "description": "开源海盗天气API，兼容Dark Sky API格式的免费天气数据替代方案",
    "category": "天气数据",
    "scenarios": ["免费天气API", "Dark Sky替代", "天气预报服务"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "Dark Sky API的免费开源替代，需自行部署或使用公共实例",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pirate-weather",
    "fallback": ["python-weather"]
}

TOOL_folium = {
    "name": "folium",
    "display_name": "Folium",
    "description": "基于Leaflet.js的Python交互式地图可视化库，支持多种地图瓦片和标记",
    "category": "地图可视化",
    "scenarios": ["交互式地图", "地理数据可视化", "热力图", "标记地图"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["leafmap"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "Python交互式地图的首选，输出HTML可在浏览器中直接查看",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install folium",
    "fallback": ["leafmap"]
}

TOOL_geopandas = {
    "name": "geopandas",
    "display_name": "GeoPandas",
    "description": "地理空间数据处理库，扩展Pandas支持地理数据结构和空间操作",
    "category": "地理数据处理",
    "scenarios": ["地理数据加载", "空间分析", "地图数据ETL"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "地理数据分析的核心工具，建议配合matplotlib进行可视化",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install geopandas",
    "fallback": []
}

TOOL_geopy = {
    "name": "geopy",
    "display_name": "GeoPy",
    "description": "地理编码库，支持地址转坐标/坐标转地址/距离计算等地理编码服务",
    "category": "地理编码",
    "scenarios": ["地址解析", "逆地理编码", "距离计算", "坐标转换"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "支持多家地理编码服务商，推荐使用Nominatim免费服务",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install geopy",
    "fallback": []
}

TOOL_openstreetmap = {
    "name": "openstreetmap",
    "display_name": "OpenStreetMap",
    "description": "OpenStreetMap数据接口，提供全球免费开源地图数据的读取和查询",
    "category": "地图数据",
    "scenarios": ["OSM数据下载", "地图数据查询", "路网分析"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["google-map"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "全球最全面的开源地图数据源，数据贡献者社区活跃",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install osmium",
    "fallback": []
}

TOOL_mapbox = {
    "name": "mapbox",
    "display_name": "Mapbox",
    "description": "Mapbox地图服务Python SDK，提供高质量自定义地图和导航服务",
    "category": "地图服务",
    "scenarios": ["自定义地图", "导航路线", "地图样式定制"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["google-map", "amap"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需要注册获取Access Token，提供高度可定制的地图样式",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install mapbox",
    "fallback": ["folium"]
}

TOOL_leafmap = {
    "name": "leafmap",
    "display_name": "Leafmap",
    "description": "交互式地图创建工具，基于Leaflet/Mapbox GL，支持低代码地图应用开发",
    "category": "地图可视化",
    "scenarios": ["快速地图创建", "地理空间分析", "地图应用开发"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["folium"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "Jupyter Notebook中做地理数据可视化的优秀选择",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install leafmap",
    "fallback": ["folium"]
}

TOOL_cartopy = {
    "name": "cartopy",
    "display_name": "Cartopy",
    "description": "专业地图绘制库，支持地图投影/海岸线/国界等地图要素渲染",
    "category": "地图绘制",
    "scenarios": ["专业地图绘制", "气象地图", "海洋地图", "投影转换"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["basemap"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Matplotlib生态下的专业地图绘制工具，科学出版级图形",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install cartopy",
    "fallback": ["basemap"]
}

TOOL_shapely = {
    "name": "shapely",
    "display_name": "Shapely",
    "description": "几何对象操作库，提供点/线/面等几何对象的创建/操作和分析",
    "category": "几何处理",
    "scenarios": ["几何操作", "空间关系判断", "缓冲区分析", "交集计算"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "GeoPandas的底层依赖，处理几何运算的首选库",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install shapely",
    "fallback": []
}

TOOL_fiona = {
    "name": "fiona",
    "display_name": "Fiona",
    "description": "地理数据读写工具，支持Shapefile/GeoJSON/GPKG等矢量格式的读写",
    "category": "地理数据IO",
    "scenarios": ["矢量数据读写", "格式转换", "地理数据导入导出"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["geopandas"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "GDAL的Python封装，格式兼容性极强",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install fiona",
    "fallback": ["geopandas"]
}

TOOL_rasterio = {
    "name": "rasterio",
    "display_name": "Rasterio",
    "description": "栅格地理数据读写库，支持GeoTIFF等栅格格式的读取/写入/处理",
    "category": "地理数据IO",
    "scenarios": ["栅格数据分析", "卫星影像处理", "DEM分析", "遥感图像"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "遥感影像和栅格数据处理的标准Python库",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install rasterio",
    "fallback": []
}

TOOL_pyproj = {
    "name": "pyproj",
    "display_name": "PyProj",
    "description": "地图投影和坐标系转换库，支持20000+种坐标参考系统转换",
    "category": "坐标处理",
    "scenarios": ["投影转换", "坐标系变换", "经纬度换算"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "PROJ库的Python接口，坐标系转换的事实标准",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install pyproj",
    "fallback": []
}

TOOL_contextily = {
    "name": "contextily",
    "display_name": "contextily",
    "description": "地图底图添加工具，为地理数据可视化提供在线/离线地图底图",
    "category": "地图可视化",
    "scenarios": ["地图底图叠加", "背景地图", "在线瓦片加载"],
    "accuracy": 4, "efficiency": 5, "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "配合geopandas/cartopy使用，轻松添加专业底图",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install contextily",
    "fallback": []
}

TOOL_here_map = {
    "name": "here-map",
    "display_name": "HERE Map",
    "description": "HERE地图服务Python SDK，提供地图/导航/交通/地理编码等服务",
    "category": "地图服务",
    "scenarios": ["地图渲染", "路线规划", "实时交通", "地理编码"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["google-map", "mapbox"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需要注册获取API Key，欧洲地区地图数据质量优秀",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install here-map",
    "fallback": ["mapbox"]
}

TOOL_google_map = {
    "name": "google-map",
    "display_name": "Google Map",
    "description": "Google Maps服务Python接口，提供地图/路线/地点搜索等完整服务",
    "category": "地图服务",
    "scenarios": ["Google地图集成", "地点搜索", "路线规划", "街景服务"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["mapbox", "amap"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "覆盖全球的地图服务，需要API Key并启用结算",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install googlemaps",
    "fallback": ["mapbox"]
}

TOOL_amap = {
    "name": "amap",
    "display_name": "高德地图",
    "description": "高德地图Python SDK，提供中国区域的地图/导航/POI搜索/实时交通等服务",
    "category": "地图服务",
    "scenarios": ["中国地图服务", "POI搜索", "导航路线", "实时路况"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["google-map", "mapbox"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "中国区域地图服务首选，数据覆盖和更新远超其他服务商",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install amap",
    "fallback": ["google-map"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
