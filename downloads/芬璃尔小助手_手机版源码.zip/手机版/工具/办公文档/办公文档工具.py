TOOL_PYTHON_DOCX = {
    "name": "python-docx",
    "display_name": "Word文档创建编辑",
    "description": "创建和编辑 Microsoft Word .docx 文件，支持文本、表格、图片、页眉页脚、样式等",
    "category": "办公文档工具",
    "scenarios": ["自动生成Word报告", "批量处理文档", "文档模板填充", "合同/简历生成"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["docxtpl"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合自动化生成 docx 格式文档，对复杂排版支持有限，建议结合模板使用",
    "github_stars": 6100,
    "open_source": True,
    "download_command": "pip install python-docx",
    "fallback": ["docxtpl", "pycups"]
}

TOOL_OPENPYXL = {
    "name": "openpyxl",
    "display_name": "Excel读写操作",
    "description": "读写 Excel 2010 xlsx/xlsm/xltx/xltm 文件，支持公式、图表、样式、条件格式等",
    "category": "办公文档工具",
    "scenarios": ["Excel数据处理", "报表生成", "图表创建", "批量Excel操作"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["xlwings", "xlsxwriter"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "读写能力均衡的首选库，大文件建议用只写模式优化性能",
    "github_stars": 5500,
    "open_source": True,
    "download_command": "pip install openpyxl",
    "fallback": ["xlwings", "xlsxwriter"]
}

TOOL_XLWINGS = {
    "name": "xlwings",
    "display_name": "Excel高级操作",
    "description": "通过 COM 接口操作 Excel 应用程序，支持宏、UDF、与 Excel 实时交互",
    "category": "办公文档工具",
    "scenarios": ["Excel自动化", "VBA替代", "实时Excel操作", "Excel插件开发"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["openpyxl", "xlsxwriter"],
    "safety_level": "warning",
    "requires_network": False,
    "usage_tips": "需要安装 Microsoft Excel，适合需要 Excel 引擎计算的场景，速度较慢",
    "github_stars": 2900,
    "open_source": True,
    "download_command": "pip install xlwings",
    "fallback": ["openpyxl", "xlsxwriter"]
}

TOOL_PYTHON_PPTX = {
    "name": "python-pptx",
    "display_name": "PPT创建编辑",
    "description": "创建和修改 PowerPoint .pptx 文件，支持幻灯片、图表、表格、图片、动画等",
    "category": "办公文档工具",
    "scenarios": ["自动生成PPT报告", "批量幻灯片制作", "演示文稿模板填充"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "对动画和复杂排版支持有限，建议保持模板简洁",
    "github_stars": 2400,
    "open_source": True,
    "download_command": "pip install python-pptx",
    "fallback": []
}

TOOL_REPORTLAB = {
    "name": "ReportLab",
    "display_name": "PDF生成引擎",
    "description": "企业级 PDF 生成库，支持复杂布局、矢量图形、表格、中文等",
    "category": "办公文档工具",
    "scenarios": ["PDF报表生成", "发票打印", "标签制作", "企业级PDF输出"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["FPDF2", "WeasyPrint"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "功能最强大的 Python PDF 库，学习曲线较陡，中文需要注册字体",
    "github_stars": 2800,
    "open_source": True,
    "download_command": "pip install reportlab",
    "fallback": ["FPDF2", "WeasyPrint"]
}

TOOL_WEASYPRINT = {
    "name": "WeasyPrint",
    "display_name": "HTML转PDF",
    "description": "将 HTML/CSS 渲染为 PDF，支持现代 CSS 特性，生成高质量文档",
    "category": "办公文档工具",
    "scenarios": ["HTML报告转PDF", "网页打印", "CSS排版PDF", "简历生成"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["pdfkit", "ReportLab"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "CSS 支持最完善的 HTML转PDF 库，适合精美排版，渲染速度较慢",
    "github_stars": 6700,
    "open_source": True,
    "download_command": "pip install weasyprint",
    "fallback": ["pdfkit", "ReportLab"]
}

TOOL_FPDF2 = {
    "name": "FPDF2",
    "display_name": "轻量PDF生成",
    "description": "轻量级 PDF 生成库，FPDF 的 Python 移植版，简单易用，支持基本 PDF 功能",
    "category": "办公文档工具",
    "scenarios": ["简单PDF生成", "PDF原型开发", "嵌入式PDF输出", "学习PDF格式"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["ReportLab", "PyMuPDF"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "简单场景首选，无需额外依赖，对复杂布局支持有限",
    "github_stars": 900,
    "open_source": True,
    "download_command": "pip install fpdf2",
    "fallback": ["ReportLab", "WeasyPrint"]
}

TOOL_PYMUPDF = {
    "name": "PyMuPDF",
    "display_name": "PDF读取编辑",
    "description": "高效的 PDF 读写和编辑库(fitz)，支持提取文本、图片、注释、OCR 等",
    "category": "办公文档工具",
    "scenarios": ["PDF文本提取", "PDF注释编辑", "PDF渲染", "PDF转图片"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["pdfplumber", "pdfminer"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "速度和功能都很出色，推荐作为 PDF 文本提取的首选",
    "github_stars": 3600,
    "open_source": True,
    "download_command": "pip install PyMuPDF",
    "fallback": ["pdfplumber", "pdfminer"]
}

TOOL_JINJA2 = {
    "name": "jinja2",
    "display_name": "模板引擎",
    "description": "功能强大的模板引擎，支持模板继承、过滤器、控制结构，常用于文档生成",
    "category": "办公文档工具",
    "scenarios": ["文档模板渲染", "代码生成", "报告模板", "邮件模板"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "常与 python-docx、WeasyPrint 等组合使用实现模板化文档生成",
    "github_stars": 10300,
    "open_source": True,
    "download_command": "pip install jinja2",
    "fallback": ["markdown"]
}

TOOL_MARKDOWN = {
    "name": "markdown",
    "display_name": "Markdown转HTML",
    "description": "将 Markdown 文本转换为 HTML，支持多种扩展和自定义渲染器",
    "category": "办公文档工具",
    "scenarios": ["Markdown文档发布", "README生成", "博客系统", "文档转换"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["pandoc"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "轻量级转换工具，复杂文档建议使用 pandoc",
    "github_stars": 3700,
    "open_source": True,
    "download_command": "pip install markdown",
    "fallback": ["pandoc"]
}

TOOL_PANDOC = {
    "name": "pandoc",
    "display_name": "文档格式转换",
    "description": "通用文档格式转换器，支持 Markdown、LaTeX、HTML、Word、PDF 等数十种格式互转",
    "category": "办公文档工具",
    "scenarios": ["跨格式文档转换", "学术论文格式转换", "批量文档迁移", "出版流水线"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["markdown", "pylatex"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "功能最全的文档转换工具，PDF输出需要 LaTeX 引擎支持",
    "github_stars": 34000,
    "open_source": True,
    "download_command": "pip install pandoc",
    "fallback": ["markdown", "pylatex"]
}

TOOL_PDFPLUMBER = {
    "name": "pdfplumber",
    "display_name": "PDF数据提取",
    "description": "专注于 PDF 数据提取，支持表格、文本、数字提取，提供可视化的调试功能",
    "category": "办公文档工具",
    "scenarios": ["PDF表格提取", "PDF数据分析", "发票信息提取", "PDF数字提取"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["tabula-py", "PyMuPDF", "camelot"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "文本和表格提取效果优秀，对扫描件无效(需先OCR)",
    "github_stars": 4900,
    "open_source": True,
    "download_command": "pip install pdfplumber",
    "fallback": ["tabula-py", "PyMuPDF"]
}

TOOL_TABULA_PY = {
    "name": "tabula-py",
    "display_name": "PDF表格提取",
    "description": "基于 Tabula 的 PDF 表格提取工具，可将 PDF 表格转换为 DataFrame 或 CSV",
    "category": "办公文档工具",
    "scenarios": ["PDF表格数据提取", "报表数据采集", "PDF转Excel", "数据迁移"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["pdfplumber", "camelot"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需要安装 Java，对复杂表格(合并单元格)提取效果有限",
    "github_stars": 2200,
    "open_source": True,
    "download_command": "pip install tabula-py",
    "fallback": ["pdfplumber", "camelot"]
}

TOOL_XLSXWRITER = {
    "name": "xlsxwriter",
    "display_name": "Excel写入工具",
    "description": "高性能 Excel 文件写入库，支持图表、条件格式、数据验证、合并单元格等",
    "category": "办公文档工具",
    "scenarios": ["大规模Excel导出", "图表生成", "格式化报表输出", "Excel模板创建"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["openpyxl"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "只写不入，写入速度最快的 Excel 库，适合大数据量导出",
    "github_stars": 3600,
    "open_source": True,
    "download_command": "pip install XlsxWriter",
    "fallback": ["openpyxl"]
}

TOOL_DOCTPL = {
    "name": "docxtpl",
    "display_name": "Word模板引擎",
    "description": "基于 python-docx 和 Jinja2 的 Word 模板工具，通过模板变量生成文档",
    "category": "办公文档工具",
    "scenarios": ["合同模板填充", "批量生成通知书", "报告模板化", "证书生成"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["python-docx"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配合 Word 模板文件使用，支持图片和表格模板，效率极高",
    "github_stars": 2000,
    "open_source": True,
    "download_command": "pip install docxtpl",
    "fallback": ["python-docx", "jinja2"]
}

TOOL_PDFKIT = {
    "name": "pdfkit",
    "display_name": "HTML转PDF(wkhtmltopdf)",
    "description": "wkhtmltopdf 的 Python 封装，将 HTML 文件通过 WebKit 引擎转换为 PDF",
    "category": "办公文档工具",
    "scenarios": ["网页转PDF", "HTML报告导出", "PDF打印预览"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["WeasyPrint"],
    "safety_level": "warning",
    "requires_network": False,
    "usage_tips": "需要单独安装 wkhtmltopdf，项目已停止维护，建议迁移到 WeasyPrint",
    "github_stars": 2200,
    "open_source": True,
    "download_command": "pip install pdfkit",
    "fallback": ["WeasyPrint", "ReportLab"]
}

TOOL_MASTIFF = {
    "name": "mastiff",
    "display_name": "Python OCR转文字",
    "description": "Python OCR 库，将图片中的文字提取为可编辑文本",
    "category": "办公文档工具",
    "scenarios": ["图片文字提取", "扫描件转文本", "OCR识别"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["tesserocr", "easyocr"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "轻量级 OCR 选择，中文识别能力有限，建议用 easyocr 替代",
    "github_stars": 500,
    "open_source": True,
    "download_command": "pip install mastiff",
    "fallback": ["easyocr", "tesserocr"]
}

TOOL_PYLATEX = {
    "name": "pylatex",
    "display_name": "LaTeX生成",
    "description": "Python 生成 LaTeX 代码，可自动编译为 PDF，支持公式、表格、图表等",
    "category": "办公文档工具",
    "scenarios": ["自动生成论文", "LaTeX报告生成", "学术文档流水线", "公式排版"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["pandoc", "ReportLab"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需要安装 LaTeX 发行版，适合需要高质量排版的学术文档",
    "github_stars": 1500,
    "open_source": True,
    "download_command": "pip install pylatex",
    "fallback": ["pandoc", "ReportLab"]
}

TOOL_PYCUPS = {
    "name": "pycups",
    "display_name": "打印服务",
    "description": "CUPS(通用Unix打印系统)的 Python 接口，支持打印机管理、文档打印",
    "category": "办公文档工具",
    "scenarios": ["自动打印文档", "打印机管理", "打印队列监控"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "warning",
    "requires_network": False,
    "usage_tips": "仅 Linux/macOS 可用，Windows 需使用 win32print",
    "github_stars": 300,
    "open_source": True,
    "download_command": "pip install pycups",
    "fallback": []
}

TOOL_TESSEROCR = {
    "name": "tesserocr",
    "display_name": "OCR识别引擎",
    "description": "Tesseract OCR 引擎的 Python API 封装，支持多语言文字识别",
    "category": "办公文档工具",
    "scenarios": ["多语言OCR", "文档数字化", "扫描件识别", "批量文字提取"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["easyocr", "mastiff"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需要安装 Tesseract OCR 引擎和语言包，识别速度比 easyocr 快",
    "github_stars": 600,
    "open_source": True,
    "download_command": "pip install tesserocr",
    "fallback": ["easyocr", "mastiff"]
}

TOOL_EASYOCR = {
    "name": "easyocr",
    "display_name": "OCR识别(支持中文)",
    "description": "基于深度学习的 OCR 库，支持 80+ 种语言(含中文)，开箱即用",
    "category": "办公文档工具",
    "scenarios": ["中文OCR识别", "图片文字识别", "证件信息提取", "自然场景文字识别"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 2,
    "conflicts_with": ["tesserocr", "mastiff"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "首次使用需下载模型，GPU 加速效果明显，中文识别效果优秀",
    "github_stars": 24000,
    "open_source": True,
    "download_command": "pip install easyocr",
    "fallback": ["tesserocr", "mastiff"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}