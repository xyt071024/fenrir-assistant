TOOL_python_o365 = {
    "name": "python-o365", "display_name": "python-o365 Outlook邮件", "description": "Microsoft 365/Exchange 邮件API封装，支持收发邮件、附件管理、邮件搜索、文件夹管理",
    "category": "邮件通知", "scenarios": ["Outlook邮件", "Microsoft 365集成", "企业邮件"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["smtplib", "exchangelib"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需注册 Azure AD 应用获取凭据",
    "github_stars": 1900, "open_source": True,
    "download_command": "pip install O365", "fallback": ["exchangelib", "smtplib"]
}

TOOL_yagmail = {
    "name": "yagmail", "display_name": "yagmail简化发信", "description": "极简的 SMTP 邮件发送库，三行代码即可发送带附件的邮件，自动处理编码",
    "category": "邮件通知", "scenarios": ["快速发信", "通知邮件", "脚本告警"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["smtplib", "emails"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持 Gmail OAuth2 自动认证",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install yagmail", "fallback": ["smtplib", "emails"]
}

TOOL_smtplib = {
    "name": "smtplib", "display_name": "smtplib标准SMTP", "description": "Python 标准库 SMTP 协议客户端，支持 SSL/TLS 加密、认证、多种邮件格式",
    "category": "邮件通知", "scenarios": ["标准邮件发送", "SMTP协议", "基础邮件功能"],
    "accuracy": 5, "efficiency": 3, "speed": 5,
    "conflicts_with": ["yagmail", "MailPilot"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "搭配 email 标准库使用构造邮件内容",
    "github_stars": 0, "open_source": True,
    "download_command": "无需安装，Python标准库自带", "fallback": ["yagmail", "emails"]
}

TOOL_MailPilot = {
    "name": "MailPilot", "display_name": "MailPilot邮件管理", "description": "一站式 Python 邮件管理工具，支持SMTP发信、IMAP收信、模板渲染、邮件队列",
    "category": "邮件通知", "scenarios": ["邮件全流程管理", "邮件模板", "批量发信"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": ["yagmail", "smtplib"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "内置 Jinja2 模板引擎支持",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mailpilot", "fallback": ["yagmail", "smtplib", "emails"]
}

TOOL_email_validator = {
    "name": "email-validator", "display_name": "email-validator邮箱验证", "description": "邮箱地址格式验证库，支持语法检查、域名验证、MX记录查询、一次性邮箱检测",
    "category": "邮件通知", "scenarios": ["邮箱格式校验", "地址验证", "垃圾邮箱过滤"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "validate_email('test@example.com') 一步校验",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install email-validator", "fallback": ["pyIsEmail", "validate_email"]
}

TOOL_imaplib = {
    "name": "imaplib", "display_name": "imaplib IMAP收信", "description": "Python 标准库 IMAP4 协议客户端，支持读取、搜索、删除邮件，管理邮件文件夹",
    "category": "邮件通知", "scenarios": ["IMAP收信", "邮件读取", "邮件搜索"],
    "accuracy": 5, "efficiency": 3, "speed": 4,
    "conflicts_with": ["poplib"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持 IMAP4_SSL 加密连接",
    "github_stars": 0, "open_source": True,
    "download_command": "无需安装，Python标准库自带", "fallback": ["poplib", "python-o365"]
}

TOOL_poplib = {
    "name": "poplib", "display_name": "poplib POP3收信", "description": "Python 标准库 POP3 协议客户端，支持收信、删信、邮件数量统计",
    "category": "邮件通知", "scenarios": ["POP3收信", "简单邮件下载", "邮件备份"],
    "accuracy": 5, "efficiency": 3, "speed": 4,
    "conflicts_with": ["imaplib"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "POP3 协议相对 IMAP 功能更有限",
    "github_stars": 0, "open_source": True,
    "download_command": "无需安装，Python标准库自带", "fallback": ["imaplib", "python-o365"]
}

TOOL_emails = {
    "name": "emails", "display_name": "emails HTML邮件", "description": "现代化的邮件发送库，完美支持 HTML 模板、内联图片、附件、自定义头信息",
    "category": "邮件通知", "scenarios": ["HTML邮件", "富文本邮件", "模板邮件"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["yagmail", "MailPilot"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持 Jinja2 模板渲染 HTML 内容",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install emails", "fallback": ["yagmail", "smtplib", "MailPilot"]
}

TOOL_premailer = {
    "name": "premailer", "display_name": "premailer邮件内联CSS", "description": "将 HTML 中的 CSS 样式自动内联为行内样式，保证邮件在各客户端的兼容性",
    "category": "邮件通知", "scenarios": ["邮件CSS内联", "邮件兼容性", "样式处理"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "邮件发送前执行 CSS 内联可大幅提升兼容性",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install premailer", "fallback": ["css_inline", "inky"]
}

TOOL_mailmerge = {
    "name": "mailmerge", "display_name": "mailmerge邮件合并", "description": "批量邮件合并工具，支持 CSV/Excel 数据源、个性化模板、批量发送、发送记录追踪",
    "category": "邮件通知", "scenarios": ["批量发信", "邮件合并", "个性化群发", "邮件营销"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "适合发送个性化批量通知",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mailmerge", "fallback": ["yagmail", "MailPilot"]
}

TOOL_sendgrid = {
    "name": "sendgrid", "display_name": "sendgrid SendGrid", "description": "SendGrid 邮件发送服务 SDK，支持事务邮件、营销邮件、模板引擎、统计分析",
    "category": "邮件通知", "scenarios": ["云邮件服务", "大规模发信", "邮件API"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["mailgun", "postmark", "amazon-ses"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "每天免费 100 封邮件",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install sendgrid", "fallback": ["mailgun", "postmark", "amazon-ses"]
}

TOOL_mailgun = {
    "name": "mailgun", "display_name": "mailgun Mailgun", "description": "Mailgun 邮件 API SDK，支持收发邮件、邮件验证、追踪分析、批量发送",
    "category": "邮件通知", "scenarios": ["云邮件API", "邮件路由", "开发邮件服务"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["sendgrid", "postmark", "amazon-ses"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "每月免费 5000 封邮件",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install mailgun", "fallback": ["sendgrid", "postmark", "amazon-ses"]
}

TOOL_postmark = {
    "name": "postmark", "display_name": "postmark Postmark", "description": "Postmark 邮件发送服务 SDK，专注事务邮件高送达率，支持模板、追踪、分析",
    "category": "邮件通知", "scenarios": ["事务邮件", "高送达率邮件", "邮件追踪"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["sendgrid", "mailgun", "amazon-ses"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "事务邮件送达率表现优异",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install postmarker", "fallback": ["sendgrid", "mailgun", "amazon-ses"]
}

TOOL_amazon_ses = {
    "name": "amazon-ses", "display_name": "amazon-ses AWS SES", "description": "Amazon Simple Email Service SDK，支持大规模邮件发送、配置集、模板、批处理",
    "category": "邮件通知", "scenarios": ["AWS SES", "云邮件服务", "大规模邮件"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["sendgrid", "mailgun", "postmark"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "需配置 AWS 凭证，从沙箱环境开始",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install boto3", "fallback": ["sendgrid", "mailgun", "postmark"]
}

TOOL_slack_sdk = {
    "name": "slack-sdk", "display_name": "slack-sdk Slack通知", "description": "Slack SDK，支持发送消息通知、Webhook集成、文件上传、频道管理、消息格式化",
    "category": "邮件通知", "scenarios": ["Slack通知", "即时消息告警", "团队协作"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "推荐使用 Webhook 方式最简单",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install slack-sdk", "fallback": ["slackclient", "webhook"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}