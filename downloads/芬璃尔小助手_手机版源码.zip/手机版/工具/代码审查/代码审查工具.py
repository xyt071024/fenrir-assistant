TOOL_RUFF = {
    "name": "Ruff",
    "display_name": "Python代码检查",
    "description": "极速 Python linter 和格式化工具，兼容 Flake8/isort/pycodestyle，40K+ ⭐",
    "category": "代码审查工具",
    "scenarios": ["Python代码风格检查", "快速lint", "CI集成", "代码格式化"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["flake8", "pycodestyle", "isort"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Rust 编写，速度极快，推荐作为 Python 项目的首要 linter 选择",
    "github_stars": 42000,
    "open_source": True,
    "download_command": "pip install ruff",
    "fallback": ["flake8", "pylint"]
}

TOOL_ESLINT = {
    "name": "ESLint",
    "display_name": "JS/TS代码检查",
    "description": "JavaScript 和 TypeScript 的可配置 linter，支持插件扩展和自动修复，25K+ ⭐",
    "category": "代码审查工具",
    "scenarios": ["JS代码检查", "TypeScript代码检查", "代码风格统一", "CI质量门禁"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "前端项目标配，配合 Prettier 使用效果最佳",
    "github_stars": 25000,
    "open_source": True,
    "download_command": "npm install eslint",
    "fallback": []
}

TOOL_BLACK = {
    "name": "black",
    "display_name": "Python格式化",
    "description": "不可妥协的 Python 代码格式化工具，自动格式化代码为统一风格",
    "category": "代码审查工具",
    "scenarios": ["Python代码自动格式化", "团队代码风格统一", "CI格式化检查"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["autopep8"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配置项极少，开箱即用，建议作为团队格式化标准工具",
    "github_stars": 39000,
    "open_source": True,
    "download_command": "pip install black",
    "fallback": ["autopep8", "ruff"]
}

TOOL_MYPY = {
    "name": "mypy",
    "display_name": "Python类型检查",
    "description": "Python 静态类型检查器，验证类型注解的正确性，支持渐进式类型检查",
    "category": "代码审查工具",
    "scenarios": ["Python类型注解验证", "类型错误检测", "代码可靠性提升", "大型项目类型安全"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["pyright"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配合 PEP 484 类型注解使用，严格模式下能发现大量潜在错误",
    "github_stars": 19000,
    "open_source": True,
    "download_command": "pip install mypy",
    "fallback": ["pyright"]
}

TOOL_BANDIT = {
    "name": "bandit",
    "display_name": "安全漏洞扫描",
    "description": "Python 代码安全审计工具，检测常见安全漏洞如 SQL注入、命令注入等",
    "category": "代码审查工具",
    "scenarios": ["安全漏洞扫描", "代码安全审计", "CI安全门禁", "OWASP合规检查"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["Semgrep"],
    "safety_level": "warning",
    "requires_network": False,
    "usage_tips": "能检测常见安全问题但可能有误报，建议配合人工审查",
    "github_stars": 6400,
    "open_source": True,
    "download_command": "pip install bandit",
    "fallback": ["Semgrep"]
}

TOOL_SEMGREP = {
    "name": "Semgrep",
    "display_name": "静态代码分析",
    "description": "多语言静态分析工具，支持自定义规则和模式匹配，可发现代码漏洞和质量问题，11K+ ⭐",
    "category": "代码审查工具",
    "scenarios": ["多语言静态分析", "自定义规则检查", "漏洞模式匹配", "代码质量扫描"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["bandit"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "规则灵活强大，支持编写自定义模式匹配规则，适合安全团队使用",
    "github_stars": 11000,
    "open_source": True,
    "download_command": "pip install semgrep",
    "fallback": ["bandit", "pylint"]
}

TOOL_PR_AGENT = {
    "name": "PR-Agent",
    "display_name": "AI代码审查",
    "description": "基于 AI 的代码审查助手，自动生成 PR 描述、代码审查、修复建议等，7K+ ⭐",
    "category": "代码审查工具",
    "scenarios": ["自动PR审查", "代码变更分析", "PR描述生成", "AI代码改进建议"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 3,
    "conflicts_with": ["sourcery"],
    "safety_level": "info",
    "requires_network": True,
    "usage_tips": "需要配置 OpenAI API 密钥，GitHub Actions 集成最方便",
    "github_stars": 7000,
    "open_source": True,
    "download_command": "pip install pr-agent",
    "fallback": ["sourcery"]
}

TOOL_PYLINT = {
    "name": "pylint",
    "display_name": "Python代码检查",
    "description": "老牌 Python 代码检查工具，提供详细的代码质量报告和评分机制",
    "category": "代码审查工具",
    "scenarios": ["Python代码质量评分", "详细代码分析", "编码规范检查", "代码重构辅助"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["ruff", "flake8"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配置灵活但速度较慢，建议在 CI 中使用而非本地开发",
    "github_stars": 5200,
    "open_source": True,
    "download_command": "pip install pylint",
    "fallback": ["ruff", "flake8"]
}

TOOL_FLAKE8 = {
    "name": "flake8",
    "display_name": "Python代码风格",
    "description": "代码风格检查工具，整合 pycodestyle、pyflakes 和 mccabe，检查风格和逻辑错误",
    "category": "代码审查工具",
    "scenarios": ["代码风格检查", "逻辑错误检测", "复杂度控制", "CI检查"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["ruff", "pylint"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配置简单，速度较快，Ruff 已逐渐成为其替代品",
    "github_stars": 2800,
    "open_source": True,
    "download_command": "pip install flake8",
    "fallback": ["ruff", "pycodestyle"]
}

TOOL_ISORT = {
    "name": "isort",
    "display_name": "import排序",
    "description": "Python import 语句排序工具，自动按 PEP8 规范组织导入顺序",
    "category": "代码审查工具",
    "scenarios": ["import语句整理", "导入规范化", "代码清理"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["ruff"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "可与 Black 配合使用，推荐同时配置到 pre-commit 钩子",
    "github_stars": 6600,
    "open_source": True,
    "download_command": "pip install isort",
    "fallback": ["ruff"]
}

TOOL_PRE_COMMIT = {
    "name": "pre-commit",
    "display_name": "Git钩子管理",
    "description": "Git 预提交钩子管理框架，在提交前自动运行代码检查工具",
    "category": "代码审查工具",
    "scenarios": ["Git钩子自动化", "提交前检查", "代码质量门禁", "团队规范执行"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "项目标配工具，推荐集成 Ruff、Black、mypy 等检查工具",
    "github_stars": 13000,
    "open_source": True,
    "download_command": "pip install pre-commit",
    "fallback": []
}

TOOL_SOURCERY = {
    "name": "sourcery",
    "display_name": "AI代码重构",
    "description": "AI 驱动的代码重构助手，实时建议代码改进和简化方案",
    "category": "代码审查工具",
    "scenarios": ["AI代码重构建议", "代码简化", "性能优化建议", "代码可读性提升"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["PR-Agent"],
    "safety_level": "info",
    "requires_network": True,
    "network": True,
    "usage_tips": "支持 VS Code 等 IDE 插件，实时给出重构建议",
    "github_stars": 1200,
    "open_source": True,
    "download_command": "pip install sourcery",
    "fallback": ["PR-Agent"]
}

TOOL_PYRIGHT = {
    "name": "pyright",
    "display_name": "TypeScript式类型检查",
    "description": "微软出品的 Python 类型检查器，TypeScript 风格，速度快，与 Pylance 集成",
    "category": "代码审查工具",
    "scenarios": ["Python类型检查", "渐进式类型验证", "IDE集成类型检查", "大型项目类型安全"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["mypy"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "VS Code Pylance 内置，可作为 mypy 的高性能替代",
    "github_stars": 14000,
    "open_source": True,
    "download_command": "npm install -g pyright",
    "fallback": ["mypy"]
}

TOOL_PYDOCSTYLE = {
    "name": "pydocstyle",
    "display_name": "文档风格检查",
    "description": "Python 文档字符串(docstring)风格检查器，遵循 PEP 257 规范",
    "category": "代码审查工具",
    "scenarios": ["文档字符串规范检查", "API文档质量", "文档风格统一"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "检查 Google/NumPy/Sphinx 等主流 docstring 格式",
    "github_stars": 1300,
    "open_source": True,
    "download_command": "pip install pydocstyle",
    "fallback": []
}

TOOL_VULTURE = {
    "name": "vulture",
    "display_name": "死代码检测",
    "description": "Python 死代码(未使用代码)检测工具，帮助清理项目中的无用代码",
    "category": "代码审查工具",
    "scenarios": ["死代码清理", "代码库瘦身", "代码维护", "重构辅助"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "可能产生误报(如动态调用的函数)，建议人工确认后再删除",
    "github_stars": 3200,
    "open_source": True,
    "download_command": "pip install vulture",
    "fallback": []
}

TOOL_MCCABE = {
    "name": "mccabe",
    "display_name": "圈复杂度检测",
    "description": "McCabe 圈复杂度检测工具，衡量代码复杂度和可维护性",
    "category": "代码审查工具",
    "scenarios": ["代码复杂度评估", "重构优先级排序", "代码可维护性检查"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "通常通过 flake8 或 pylint 间接使用，也可单独运行",
    "github_stars": 400,
    "open_source": True,
    "download_command": "pip install mccabe",
    "fallback": ["pylint", "flake8"]
}

TOOL_PYCODESTYLE = {
    "name": "pycodestyle",
    "display_name": "PEP8风格检查",
    "description": "PEP 8 代码风格检查工具(原 pep8)，检查代码是否符合 Python 官方风格指南",
    "category": "代码审查工具",
    "scenarios": ["PEP8规范检查", "代码风格统一", "Python新手指导"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["ruff", "flake8"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "已被 flake8 和 ruff 整合，一般不单独使用",
    "github_stars": 2600,
    "open_source": True,
    "download_command": "pip install pycodestyle",
    "fallback": ["ruff", "flake8"]
}

TOOL_PYDOCSTRING = {
    "name": "pydocstring",
    "display_name": "docstring生成",
    "description": "Python 文档字符串自动生成工具，基于代码签名推断文档内容",
    "category": "代码审查工具",
    "scenarios": ["自动生成代码文档", "API文档补全", "代码注释完善"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "生成结果需要人工校验和补充，适合快速搭建文档框架",
    "github_stars": 300,
    "open_source": True,
    "download_command": "pip install pydocstring",
    "fallback": []
}

TOOL_AUTOPEP8 = {
    "name": "autopep8",
    "display_name": "PEP8自动修复",
    "description": "自动修复 PEP 8 风格问题的工具，基于 pycodestyle 的检测结果进行修复",
    "category": "代码审查工具",
    "scenarios": ["自动修复代码风格", "PEP8合规", "遗留代码格式化"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["black", "ruff"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "效果不如 Black 彻底，建议直接使用 Black 替代",
    "github_stars": 5100,
    "open_source": True,
    "download_command": "pip install autopep8",
    "fallback": ["black", "ruff"]
}

TOOL_PYUPGRADE = {
    "name": "pyupgrade",
    "display_name": "Python语法升级",
    "description": "自动将 Python 代码升级到新版本语法特性，如 f-string、海象运算符等",
    "category": "代码审查工具",
    "scenarios": ["Python版本迁移", "语法现代化", "代码风格更新", "旧项目升级"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "建议在迁移 Python 版本后运行，配合 pre-commit 使用效果最佳",
    "github_stars": 3700,
    "open_source": True,
    "download_command": "pip install pyupgrade",
    "fallback": []
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}