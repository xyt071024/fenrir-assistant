Add-Content -Path "D:\芬璃尔小助手\core\tools.py" -Value @"

    def register_tool(self, name: str, func: Optional[Callable], description: str, parameters: Dict[str, Any], category: str = "general", is_async: bool = False):
        """注册一个工具到管理器。"""
        self._tools[name] = {
            "name": name,
            "function": func,
            "description": description,
            "parameters": parameters,
            "category": category,
            "is_async": is_async,
        }

    def get_tool_descriptions(self) -> List[Dict[str, Any]]:
        """
        获取所有工具的描述信息（供 LLM 使用）。

        返回工具架构列表，每个工具包含名称、描述、参数等信息。
        """
        descriptions = []
        for name, info in self._tools.items():
            desc = {
                "name": name,
                "description": info["description"],
                "parameters": info["parameters"],
                "category": info["category"],
                "is_async": info["is_async"],
            }
            descriptions.append(desc)
        return descriptions

    def list_available_tools(self) -> Dict[str, Any]:
        """
        列出所有可用工具，按分类组织。

        返回:
            {"success": bool, "tools": dict, "total": int, "message": str}
        """
        categories = {}
        for name, info in self._tools.items():
            cat = info["category"]
            if cat not in categories:
                categories[cat] = []
            categories[cat].append({
                "name": name,
                "description": info["description"],
                "is_async": info["is_async"],
            })
        total = len(self._tools)
        return {
            "success": True,
            "tools": categories,
            "total": total,
            "message": f"共有 {total} 个工具，分布在 {len(categories)} 个分类",
        }

    def security_check(self, action_description: str) -> Dict[str, Any]:
        """
        对操作进行安全检查，评估风险等级。

        参数:
            action_description: 操作描述文本（LLM 自动生成或来自工具名）。

        返回:
            {"action": str, "description": str, "danger_level": str, "requires_confirmation": bool}
            danger_level: 'safe'（安全）, 'info'（信息）, 'warning'（警告）, 'danger'（危险）
        """
        action_lower = action_description.lower()

        danger_keywords = ["delete", "rmdir", "rm -rf", "remove", "unlink", "kill", "terminate", "shutdown", "format"]
        warning_keywords = ["run_command", "shell", "exec", "execute", "cmd", "powershell", "write_file", "overwrite", "move", "compress"]
        info_keywords = ["read", "list", "get_", "search", "info", "paste", "copy_text"]

        for kw in danger_keywords:
            if kw in action_lower:
                return {
                    "action": action_description,
                    "description": f"操作 '{action_description}' 涉及删除/终止等危险行为",
                    "danger_level": "danger",
                    "requires_confirmation": True,
                }

        for kw in warning_keywords:
            if kw in action_lower:
                return {
                    "action": action_description,
                    "description": f"操作 '{action_description}' 涉及执行命令或修改数据",
                    "danger_level": "warning",
                    "requires_confirmation": True,
                }

        for kw in info_keywords:
            if kw in action_lower:
                return {
                    "action": action_description,
                    "description": f"操作 '{action_description}' 为只读查询操作",
                    "danger_level": "safe",
                    "requires_confirmation": False,
                }

        return {
            "action": action_description,
            "description": f"操作 '{action_description}' 风险等级未知，请谨慎",
            "danger_level": "info",
            "requires_confirmation": False,
        }

    async def _execute_browser_tool(self, tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """执行浏览器异步工具。"""
        if self._browser_tools is None:
            self._browser_tools = BrowserTools()

        method_map = {
            "browser_navigate": self._browser_tools.navigate,
            "browser_click": self._browser_tools.click,
            "browser_type": self._browser_tools.type,
            "browser_screenshot": self._browser_tools.screenshot,
            "browser_get_page_content": self._browser_tools.get_page_content,
            "browser_scroll": self._browser_tools.scroll,
            "browser_get_element_text": self._browser_tools.get_element_text,
            "browser_fill_form": self._browser_tools.fill_form,
            "browser_press_key": self._browser_tools.press_key,
            "browser_evaluate_js": self._browser_tools.evaluate_js,
            "browser_close": self._browser_tools.close,
        }

        method = method_map.get(tool_name)
        if method is None:
            return {"success": False, "message": f"未知的浏览器工具: {tool_name}"}
        return await method(**params)

    def execute_tool(self, tool_name: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        执行指定的工具。

        参数:
            tool_name: 工具名称（见 list_available_tools 或 get_tool_descriptions）。
            params: 工具参数字典。

        返回:
            {"success": bool, ...工具特定返回字段..., "message": str}
        """
        if params is None:
            params = {}

        tool_info = self._tools.get(tool_name)
        if tool_info is None:
            return {"success": False, "message": f"未知工具: {tool_name}，可用工具: {', '.join(self._tools.keys())}"}

        if tool_info.get("is_async"):
            return {"success": False, "message": f"工具 {tool_name} 是异步工具，请使用 execute_tool_async 方法"}

        func = tool_info["function"]
        if func is None:
            return {"success": False, "message": f"工具 {tool_name} 未绑定同步函数"}

        try:
            security = self.security_check(tool_name)
            result = func(**params)
            if isinstance(result, dict):
                result["_security"] = security
            return result
        except TypeError as e:
            return {"success": False, "message": f"参数错误: {e}"}
        except Exception as e:
            return {"success": False, "message": f"工具执行失败: {e}", "traceback": traceback.format_exc()}

    async def execute_tool_async(self, tool_name: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        异步执行工具（用于浏览器等异步操作）。

        参数:
            tool_name: 工具名称。
            params: 工具参数字典。

        返回:
            Dict[str, Any]
        """
        if params is None:
            params = {}

        tool_info = self._tools.get(tool_name)
        if tool_info is None:
            return {"success": False, "message": f"未知工具: {tool_name}"}

        if tool_info.get("is_async"):
            return await self._execute_browser_tool(tool_name, params)

        func = tool_info["function"]
        if func is None:
            return {"success": False, "message": f"工具 {tool_name} 未绑定函数"}

        try:
            security = self.security_check(tool_name)
            if asyncio.iscoroutinefunction(func):
                result = await func(**params)
            else:
                result = func(**params)
            if isinstance(result, dict):
                result["_security"] = security
            return result
        except TypeError as e:
            return {"success": False, "message": f"参数错误: {e}"}
        except Exception as e:
            return {"success": False, "message": f"工具执行失败: {e}", "traceback": traceback.format_exc()}

    def __getitem__(self, name: str) -> Optional[Callable]:
        """通过索引访问工具函数。"""
        info = self._tools.get(name)
        return info["function"] if info else None

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __len__(self) -> int:
        return len(self._tools)

    def __repr__(self) -> str:
        return f"AIToolManager({len(self._tools)} tools)"


# ============================================================================
# 模块级接口
# ============================================================================

_manager: Optional[AIToolManager] = None


def _get_manager() -> AIToolManager:
    """获取全局工具管理器实例（单例）。"""
    global _manager
    if _manager is None:
        _manager = AIToolManager()
    return _manager


# 所有工具函数映射（供直接调用）
all_tools: Dict[str, Callable] = {
    # FileSystem
    "create_dir": FileSystemTools.create_dir,
    "delete_path": FileSystemTools.delete_path,
    "move_path": FileSystemTools.move_path,
    "copy_path": FileSystemTools.copy_path,
    "read_file": FileSystemTools.read_file,
    "write_file": FileSystemTools.write_file,
    "append_file": FileSystemTools.append_file,
    "search_files": FileSystemTools.search_files,
    "get_file_info": FileSystemTools.get_file_info,
    "compress": FileSystemTools.compress,
    "extract": FileSystemTools.extract,
    # System
    "run_command": SystemTools.run_command,
    "get_process_list": SystemTools.get_process_list,
    "kill_process": SystemTools.kill_process,
    "get_system_info": SystemTools.get_system_info,
    "get_disk_usage": SystemTools.get_disk_usage,
    "open_application": SystemTools.open_application,
    "send_notification": SystemTools.send_notification,
    # Computer Control
    "mouse_move": ComputerControlTools.mouse_move,
    "mouse_click": ComputerControlTools.mouse_click,
    "mouse_double_click": ComputerControlTools.mouse_double_click,
    "mouse_drag": ComputerControlTools.mouse_drag,
    "keyboard_type": ComputerControlTools.keyboard_type,
    "keyboard_hotkey": ComputerControlTools.keyboard_hotkey,
    "keyboard_press": ComputerControlTools.keyboard_press,
    "take_screenshot": ComputerControlTools.take_screenshot,
    "scroll": ComputerControlTools.scroll,
    # Office
    "create_pptx": OfficeTools.create_pptx,
    "create_xlsx": OfficeTools.create_xlsx,
    "create_docx": OfficeTools.create_docx,
    "read_xlsx": OfficeTools.read_xlsx,
    "read_docx": OfficeTools.read_docx,
    "edit_xlsx": OfficeTools.edit_xlsx,
    "convert_to_pdf": OfficeTools.convert_to_pdf,
    # Image
    "resize_image": ImageTools.resize_image,
    "convert_image_format": ImageTools.convert_format,
    "add_image_filter": ImageTools.add_filter,
    "ocr_image": ImageTools.ocr_image,
    "create_collage": ImageTools.create_collage,
    # Clipboard
    "clipboard_copy_text": ClipboardTools.copy_text,
    "clipboard_paste_text": ClipboardTools.paste_text,
    "clipboard_copy_file": ClipboardTools.copy_file,
    "clipboard_clear": ClipboardTools.clear,
}


def execute_tool(name: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    执行指定名称的工具（模块级快捷函数）。

    参数:
        name: 工具名称。
        params: 工具参数。

    返回:
        Dict[str, Any]
    """
    manager = _get_manager()
    return manager.execute_tool(name, params)


def list_tools() -> Dict[str, Any]:
    """
    列出所有可用工具（模块级快捷函数）。

    返回:
        {"success": bool, "tools": dict, "total": int}
    """
    manager = _get_manager()
    return manager.list_available_tools()


def get_tool_schemas() -> List[Dict[str, Any]]:
    """
    获取所有工具的描述架构（供 LLM 使用）。

    返回:
        List[Dict[str, Any]] — 工具描述列表
    """
    manager = _get_manager()
    return manager.get_tool_descriptions()
"@
