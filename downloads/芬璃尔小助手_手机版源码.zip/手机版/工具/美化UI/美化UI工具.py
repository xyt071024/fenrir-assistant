TOOL_CUSTOMTKINTER = {
    "name": "customtkinter",
    "display_name": "CustomTkinter 现代控件",
    "description": "基于tkinter的现代化UI组件库，提供圆角按钮、卡片、进度条等丰富控件，支持亮暗主题切换，无需额外依赖即可打造现代桌面应用",
    "category": "UI美化/桌面GUI",
    "scenarios": ["桌面应用开发", "数据录入工具", "系统管理面板", "轻量级客户端"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["tkinter原生样式"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "pip install customtkinter 后可直接替代tkinter使用，CTk()替代Tk()，CTkButton替代Button",
    "github_stars": 26700,
    "open_source": True,
    "download_command": "pip install customtkinter",
    "fallback": ["tkinter", "PyQt6"]
}

TOOL_TTKBOOTSTRAP = {
    "name": "ttkbootstrap",
    "display_name": "ttkbootstrap 20+主题",
    "description": "为tkinter.ttk提供20余种Bootstrap风格主题，包含扁平化配色、圆角样式和响应式布局，一行代码切换主题",
    "category": "UI美化/主题库",
    "scenarios": ["桌面应用快速美化", "原型开发", "内部工具界面", "Bootstrap风格应用"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["tkinter原生主题", "CustomTkinter"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "import ttkbootstrap as tb; root = tb.Window(themename='cosmo') 即可启用",
    "github_stars": 5100,
    "open_source": True,
    "download_command": "pip install ttkbootstrap",
    "fallback": ["tkinter.ttk", "CustomTkinter"]
}

TOOL_PYQT6 = {
    "name": "pyqt6",
    "display_name": "PyQt6",
    "description": "Qt6框架的Python绑定，完整的桌面应用开发框架，支持信号槽、QML、WebEngine、Charts等高级特性",
    "category": "UI美化/桌面框架",
    "scenarios": ["跨平台桌面应用", "专业IDE开发", "多媒体应用", "CAD/设计工具"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 3,
    "conflicts_with": ["PySide6", "PyQt5"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "商业授权需购买PyQt6商用许可，开源项目可使用GPL协议",
    "github_stars": 5300,
    "open_source": True,
    "download_command": "pip install PyQt6",
    "fallback": ["PySide6", "PyQt5"]
}

TOOL_PYSIDE6 = {
    "name": "pyside6",
    "display_name": "PySide6",
    "description": "Qt6官方Python绑定（Qt for Python），LGPL协议更友好，API与PyQt6高度兼容，是Qt官方推荐的Python方案",
    "category": "UI美化/桌面框架",
    "scenarios": ["商业桌面应用", "跨平台工具", "Qt Quick/QML项目", "嵌入式GUI"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 3,
    "conflicts_with": ["PyQt6", "PyQt5"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "pip install pyside6 即可，LGPL许可适合商业闭源应用",
    "github_stars": 3100,
    "open_source": True,
    "download_command": "pip install pyside6",
    "fallback": ["PyQt6", "PyQt5"]
}

TOOL_QSS_STYLESHEET = {
    "name": "qss_stylesheet",
    "display_name": "QSS样式表",
    "description": "Qt样式表引擎，类似CSS的语法为Qt控件定制外观，支持渐变、阴影、动画等视觉效果",
    "category": "UI美化/样式引擎",
    "scenarios": ["Qt应用深度美化", "自定义控件皮肤", "暗色/亮色主题切换", "品牌定制UI"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": ["qt-material", "qdarkstyle"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "widget.setStyleSheet('QPushButton { background: #3498db; }') 即可应用样式",
    "github_stars": 0,
    "open_source": True,
    "download_command": "内置在PyQt6/PySide6中，无需额外安装",
    "fallback": ["qt-material", "qdarkstyle"]
}

TOOL_QT_MATERIAL = {
    "name": "qt_material",
    "display_name": "qt-material Material主题",
    "description": "为PyQt5/PySide2/6提供Material Design 2.0风格主题，内置亮暗色、10余种配色方案，一键切换",
    "category": "UI美化/主题库",
    "scenarios": ["Qt应用Material风格化", "Android风格桌面应用", "现代化工具界面"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["qdarkstyle", "QSS样式表自定义"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "from qt_material import apply_stylesheet; apply_stylesheet(app, 'dark_teal.xml')",
    "github_stars": 2000,
    "open_source": True,
    "download_command": "pip install qt-material",
    "fallback": ["qdarkstyle", "QSS样式表"]
}

TOOL_QDARKSTYLE = {
    "name": "qdarkstyle",
    "display_name": "qdarkstyle 暗色主题",
    "description": "跨Qt版本的暗色主题库，支持PyQt4/5/6和PySide/2/6，精心调配的暗色调配色方案，保护视力",
    "category": "UI美化/暗色主题",
    "scenarios": ["代码编辑器暗色模式", "开发者工具", "夜间使用应用", "专业监控面板"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["qt-material", "qtmodern"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "import qdarkstyle; app.setStyleSheet(qdarkstyle.load_stylesheet())",
    "github_stars": 4800,
    "open_source": True,
    "download_command": "pip install qdarkstyle",
    "fallback": ["qt-material", "QSS样式表"]
}

TOOL_PYQT_DARK_NOTIFICATION = {
    "name": "pyqtdark_notification",
    "display_name": "pyqtdark-notification 通知美化",
    "description": "Qt桌面通知美化组件，支持暗色风格的系统通知、弹窗提醒、Toast消息，可自定义位置和动画",
    "category": "UI美化/通知组件",
    "scenarios": ["桌面应用通知系统", "消息提醒", "后台任务完成提示", "即时通讯消息"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["QSystemTrayIcon原生通知"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配合qdarkstyle使用效果更佳，支持队列管理和点击回调",
    "github_stars": 300,
    "open_source": True,
    "download_command": "pip install pyqtdark-notification",
    "fallback": ["QSystemTrayIcon", "qt-material"]
}

TOOL_QTMODERN = {
    "name": "qtmodern",
    "display_name": "qtmodern 扁平风格",
    "description": "为Qt应用提供现代化扁平设计风格，模仿Windows 10/11和macOS的设计语言，无边框窗口方案",
    "category": "UI美化/扁平风格",
    "scenarios": ["现代风格桌面应用", "无边框窗口设计", "跨平台统一外观"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["qdarkstyle", "qt-material"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "import qtmodern.styles; qtmodern.styles.dark(app)",
    "github_stars": 700,
    "open_source": True,
    "download_command": "pip install qtmodern",
    "fallback": ["qdarkstyle", "QSS样式表"]
}

TOOL_PYQTGRAPH = {
    "name": "pyqtgraph",
    "display_name": "PyQtGraph 专业图表",
    "description": "基于Qt的高性能科学图表库，专为实时数据可视化优化，支持2D/3D绘图、图像处理和科学计算可视化",
    "category": "UI美化/数据可视化",
    "scenarios": ["实时数据监控", "科学计算可视化", "信号分析仪", "医学影像显示", "传感器数据展示"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["matplotlib", "matplotlib Qt后端"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "搭配PyQt6/PySide6使用，性能远超matplotlib，适合百万级数据点实时刷新",
    "github_stars": 4000,
    "open_source": True,
    "download_command": "pip install pyqtgraph",
    "fallback": ["matplotlib", "plotly"]
}

TOOL_QTPY = {
    "name": "qtpy",
    "display_name": "qtpy Qt抽象层",
    "description": "Qt Python绑定的抽象层，一套代码同时兼容PyQt5/6和PySide2/6，简化Qt框架选择和迁移",
    "category": "UI美化/兼容层",
    "scenarios": ["跨Qt框架兼容", "库开发需支持多Qt绑定", "减少框架依赖耦合"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["直接使用PyQt6或PySide6"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "from qtpy import QtWidgets, QtCore 统一导入，底层自动选择可用Qt绑定",
    "github_stars": 2600,
    "open_source": True,
    "download_command": "pip install qtpy",
    "fallback": ["PyQt6", "PySide6"]
}

TOOL_FLEXX = {
    "name": "flexx",
    "display_name": "flexx 交互式UI",
    "description": "纯Python交互式UI框架，使用Pyscript技术将Python编译为WebAssembly在浏览器运行，支持实时双向绑定",
    "category": "UI美化/WebGUI",
    "scenarios": ["数据仪表盘", "交互式教学工具", "远程控制面板", "轻量级Web应用"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["eel", "nicegui"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "ui = flexx.app.serve(MyApp); 运行后通过浏览器访问，适合快速原型",
    "github_stars": 3200,
    "open_source": True,
    "download_command": "pip install flexx",
    "fallback": ["eel", "nicegui"]
}

TOOL_EEL = {
    "name": "eel",
    "display_name": "eel HTML-GUI",
    "description": "用HTML/CSS/JS做前端，Python做后端的轻量桌面GUI框架，内置Chrome/Edge应用模式，打包体积小",
    "category": "UI美化/混合GUI",
    "scenarios": ["Web技术做桌面应用", "快速原型GUI", "企业内部工具", "数据展示面板"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pywebview", "electron"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "前端用eel.expose暴露Python函数，后端用eel.start()启动窗口，支持--onefile打包",
    "github_stars": 7500,
    "open_source": True,
    "download_command": "pip install eel",
    "fallback": ["pywebview", "nicegui"]
}

TOOL_PYWEBVIEW = {
    "name": "pywebview",
    "display_name": "pywebview Webview",
    "description": "轻量级原生WebView窗口库，使用系统级WebView渲染HTML，无额外捆绑体积，支持Windows/macOS/Linux",
    "category": "UI美化/WebView",
    "scenarios": ["Web应用桌面壳", "混合应用开发", "内嵌仪表盘", "系统设置界面"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["eel", "electron"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "webview.create_window()即可创建窗口，支持JS-Python双向桥接，打包体积极小",
    "github_stars": 4900,
    "open_source": True,
    "download_command": "pip install pywebview",
    "fallback": ["eel", "CefPython"]
}

TOOL_NICEGUI = {
    "name": "nicegui",
    "display_name": "nicegui WebUI",
    "description": "基于Vue.js的Python Web UI框架，用Python编写前端界面，自带响应式组件库，支持实时更新和事件绑定",
    "category": "UI美化/WebUI框架",
    "scenarios": ["数据仪表盘", "IoT控制面板", "管理后台", "交互式原型", "AI演示界面"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["streamlit", "gradio"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "ui.button('Click', on_click=lambda: ui.notify('Hi')) 链式调用构建界面",
    "github_stars": 10000,
    "open_source": True,
    "download_command": "pip install nicegui",
    "fallback": ["streamlit", "gradio"]
}

TOOL_GRADIO = {
    "name": "gradio",
    "display_name": "gradio ML界面",
    "description": "HuggingFace出品的机器学习Demo界面库，数行代码生成交互式Web演示，内置大量ML组件和预置模板",
    "category": "UI美化/ML演示",
    "scenarios": ["模型Demo展示", "数据集标注工具", "API快速封装界面", "团队协作测试"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["streamlit", "nicegui"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "gr.Interface(fn=my_func, inputs='text', outputs='label').launch() 即可创建界面",
    "github_stars": 37000,
    "open_source": True,
    "download_command": "pip install gradio",
    "fallback": ["streamlit", "nicegui"]
}

TOOL_STREAMLIT = {
    "name": "streamlit",
    "display_name": "streamlit 数据应用",
    "description": "数据科学领域的Web应用框架，纯Python脚本驱动，热重载、缓存、会话状态开箱即用，数据展示首选",
    "category": "UI美化/数据应用",
    "scenarios": ["数据分析面板", "报表展示", "数据探索工具", "A/B测试看板", "实时数据监控"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["gradio", "dash"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "st.write()/st.dataframe()/st.plotly_chart() 等命令式API构建页面",
    "github_stars": 38000,
    "open_source": True,
    "download_command": "pip install streamlit",
    "fallback": ["gradio", "dash"]
}

TOOL_FLET = {
    "name": "flet",
    "display_name": "flet Flutter应用",
    "description": "基于Google Flutter的Python UI框架，用Python编写Flutter应用，真正的原生跨平台（Windows/macOS/Linux/Web/移动端）",
    "category": "UI美化/跨平台框架",
    "scenarios": ["移动端应用", "跨平台桌面应用", "响应式Web应用", "Flutter原型快速开发"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["kivy", "flutter原生开发"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "ft.app(target=main) 启动应用，控件API类似Flutter的Widget树结构",
    "github_stars": 12000,
    "open_source": True,
    "download_command": "pip install flet",
    "fallback": ["kivy", "nicegui"]
}

TOOL_KIVY = {
    "name": "kivy",
    "display_name": "kivy 跨平台UI",
    "description": "开源跨平台Python UI框架，独特的Kv语言描述界面，支持多点触控和GPU加速，一套代码覆盖桌面和移动端",
    "category": "UI美化/跨平台框架",
    "scenarios": ["移动应用开发", "多点触控应用", "嵌入式设备界面", "教育类应用", "游戏界面"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["flet", "PyQt6"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "使用.kv文件分离UI布局和逻辑，pip install kivy[full] 安装完整依赖",
    "github_stars": 18000,
    "open_source": True,
    "download_command": "pip install kivy",
    "fallback": ["flet", "PyQt6"]
}

TOOL_KIVYMD = {
    "name": "kivymd",
    "display_name": "kivymd Material Design",
    "description": "为Kivy框架提供Material Design 3风格组件库，包含FAB按钮、卡片、底部导航等120+个MD控件",
    "category": "UI美化/Material主题",
    "scenarios": ["Material风格移动应用", "现代Android风格界面", "Kivy应用美化"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["kivy原生控件样式"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "from kivymd.app import MDApp 替代Kivy的App类，主题色一行切换",
    "github_stars": 6300,
    "open_source": True,
    "download_command": "pip install kivymd",
    "fallback": ["kivy", "flet"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
