TOOL_child_development = {
    "name": "child-development儿童发展",
    "display_name": "儿童发展评估",
    "description": "基于皮亚杰认知发展理论等国际标准，评估0-12岁儿童在大运动、精细动作、语言、社交等维度的发展水平",
    "category": "育儿教育",
    "scenarios": ["发育里程碑对照", "早期干预参考", "家长育儿指导"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "定期评估并记录变化，比单次结果更有参考价值",
    "github_stars": 5600,
    "open_source": True,
    "download_command": "pip install child-development",
    "fallback": ["growth-chart生长曲线", "parent-tips育儿知识"]
}

TOOL_parent_tips = {
    "name": "parent-tips育儿知识",
    "display_name": "育儿知识百科",
    "description": "覆盖孕期到青春期的科学育儿知识库，包含喂养指南、睡眠训练、行为引导、情绪管理等实用内容",
    "category": "育儿教育",
    "scenarios": ["新手父母学习", "育儿问题解决", "科学喂养指导"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "根据孩子年龄筛选内容，获取针对性建议",
    "github_stars": 8300,
    "open_source": True,
    "download_command": "pip install parent-tips",
    "fallback": ["child-development儿童发展", "kid-safety安全提醒"]
}

TOOL_baby_tracker = {
    "name": "baby-tracker婴儿记录",
    "display_name": "婴儿日常记录",
    "description": "记录新生儿喂奶、换尿布、睡眠、体温等日常数据，生成作息报表并给出喂养和睡眠改善建议",
    "category": "婴儿护理",
    "scenarios": ["新生儿护理记录", "喂养规律分析", "作息调整参考"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "每次喂奶和睡眠后及时记录，数据越完整分析越准确",
    "github_stars": 4200,
    "open_source": True,
    "download_command": "pip install baby-tracker",
    "fallback": ["child-development儿童发展", "growth-chart生长曲线"]
}

TOOL_growth_chart = {
    "name": "growth-chart生长曲线",
    "display_name": "生长发育曲线",
    "description": "参照WHO儿童生长标准，绘制身高、体重、头围等生长曲线，评估儿童生长发育是否在正常范围内",
    "category": "儿童健康",
    "scenarios": ["定期体格监测", "生长偏离筛查", "儿童保健评估"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "至少每三个月测量一次并记录，持续追踪更有意义",
    "github_stars": 6100,
    "open_source": True,
    "download_command": "pip install growth-chart",
    "fallback": ["child-development儿童发展", "vaccination疫苗提醒"]
}

TOOL_vaccination = {
    "name": "vaccination疫苗提醒",
    "display_name": "疫苗接种提醒",
    "description": "根据国家免疫规划程序，管理儿童疫苗接种计划，提供接种时间提醒、疫苗说明和接种记录追踪",
    "category": "儿童健康",
    "scenarios": ["疫苗接种规划", "接种记录管理", "疫苗知识科普"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "输入出生日期后自动生成个性化疫苗接种时间表",
    "github_stars": 3400,
    "open_source": True,
    "download_command": "pip install vaccination",
    "fallback": ["growth-chart生长曲线", "kid-safety安全提醒"]
}

TOOL_kid_safety = {
    "name": "kid-safety安全提醒",
    "display_name": "儿童安全防护",
    "description": "提供居家安全、交通安全、防拐防骗、网络安全等全方位的儿童安全知识和应急处理指南",
    "category": "儿童安全",
    "scenarios": ["居家安全隐患排查", "安全教育素材", "紧急情况应对"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "定期与孩子一起学习安全知识，培养安全意识",
    "github_stars": 2900,
    "open_source": True,
    "download_command": "pip install kid-safety",
    "fallback": ["parent-tips育儿知识", "child-development儿童发展"]
}

TOOL_children_book = {
    "name": "children-book儿童图书",
    "display_name": "儿童图书推荐",
    "description": "按年龄分级推荐优质儿童绘本、桥梁书和章节书，包含内容简介、适读年龄、教育价值和教育主题标签",
    "category": "亲子阅读",
    "scenarios": ["选书参考", "亲子共读", "阅读能力培养"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "根据孩子当前阅读水平和兴趣偏好筛选推荐",
    "github_stars": 4700,
    "open_source": True,
    "download_command": "pip install children-book",
    "fallback": ["story-generator故事生成", "education-game教育游戏"]
}

TOOL_story_generator = {
    "name": "story-generator故事生成",
    "display_name": "儿童故事生成",
    "description": "根据年龄、主题、角色等参数自动生成原创儿童故事，支持寓言、童话、科普故事等多种体裁",
    "category": "亲子创意",
    "scenarios": ["睡前故事", "教学辅助", "创意写作启蒙"],
    "accuracy": 3,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "提供孩子喜欢的角色和场景，能生成更有吸引力的故事",
    "github_stars": 5200,
    "open_source": True,
    "download_command": "pip install story-generator",
    "fallback": ["children-book儿童图书", "game-selection适龄游戏"]
}

TOOL_game_selection = {
    "name": "game-selection适龄游戏",
    "display_name": "适龄游戏推荐",
    "description": "根据儿童年龄段推荐合适的玩具和游戏，涵盖感官游戏、建构游戏、角色扮演、桌游等类型",
    "category": "亲子玩乐",
    "scenarios": ["玩具选购参考", "亲子活动策划", "感统训练辅助"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["education-game教育游戏"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "结合孩子的发展水平而非仅按年龄选择游戏",
    "github_stars": 2500,
    "open_source": True,
    "download_command": "pip install game-selection",
    "fallback": ["education-game教育游戏", "child-development儿童发展"]
}

TOOL_education_game = {
    "name": "education-game教育游戏",
    "display_name": "教育游戏工具",
    "description": "提供数学启蒙、拼音识字、英语学习、逻辑思维等学科启蒙游戏，在玩中学提升学习兴趣",
    "category": "亲子教育",
    "scenarios": ["寓教于乐", "学科启蒙", "学习兴趣培养"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["game-selection适龄游戏"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "每次使用控制在15-20分钟，保护视力的同时保持学习效果",
    "github_stars": 6800,
    "open_source": True,
    "download_command": "pip install education-game",
    "fallback": ["game-selection适龄游戏", "children-book儿童图书"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}