TOOL_BLENDER = {
    "name": "blender-python",
    "display_name": "Blender Python API",
    "description": "Blender内置Python API，可编程控制建模、动画、渲染和合成",
    "category": "3D建模",
    "scenarios": ["程序化建模", "自动化渲染", "插件开发", "批处理", "动画管线"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "在Blender内置控制台直接运行，或通过 blender -P script.py 执行",
    "github_stars": 12000,
    "open_source": True,
    "download_command": "内置在Blender中，无需额外安装",
    "fallback": ["panda3d", "pyrender"]
}

TOOL_TRIMESH = {
    "name": "trimesh",
    "display_name": "Trimesh 3D网格",
    "description": "纯Python的3D三角网格处理库，支持加载/导出、分析和操作",
    "category": "3D建模",
    "scenarios": ["网格加载导出", "碰撞检测", "网格布尔运算", "截面生成", "模型简化"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "trimesh.load() 支持超过20种3D格式",
    "github_stars": 3200,
    "open_source": True,
    "download_command": "pip install trimesh",
    "fallback": ["open3d", "pymeshlab"]
}

TOOL_OPEN3D = {
    "name": "open3d",
    "display_name": "Open3D 3D点云",
    "description": "3D数据处理库，专注于点云、网格处理和3D几何深度学习",
    "category": "3D建模",
    "scenarios": ["点云处理", "3D配准", "表面重建", "3D可视化", "几何深度学习"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "o3d.io.read_point_cloud() 快速载入点云数据",
    "github_stars": 11000,
    "open_source": True,
    "download_command": "pip install open3d",
    "fallback": ["pyvista", "trimesh"]
}

TOOL_PYVISTA = {
    "name": "pyvista",
    "display_name": "PyVista 3D可视化",
    "description": "基于VTK的高级3D可视化库，提供简洁的Pythonic接口",
    "category": "3D建模",
    "scenarios": ["3D网格可视化", "科学数据渲染", "等值面提取", "地形建模", "有限元后处理"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "plotter = pv.Plotter(); plotter.show() 即可创建交互窗口",
    "github_stars": 2800,
    "open_source": True,
    "download_command": "pip install pyvista",
    "fallback": ["mayavi", "vedo"]
}

TOOL_VTK = {
    "name": "vtk",
    "display_name": "VTK 可视化工具包",
    "description": "专业级3D可视化工具包，支持体渲染、等值面和流线可视化",
    "category": "3D建模",
    "scenarios": ["体数据可视化", "医学图像处理", "计算流体力学", "科学可视化", "等值面提取"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "vtk 管线采用 数据流-过滤器-映射器 架构，学习曲线较陡",
    "github_stars": 6500,
    "open_source": True,
    "download_command": "pip install vtk",
    "fallback": ["pyvista", "mayavi"]
}

TOOL_MAYAVI = {
    "name": "mayavi",
    "display_name": "Mayavi 3D科学可视化",
    "description": "基于VTK的3D科学可视化工具，支持交互式体渲染和等值面",
    "category": "3D建模",
    "scenarios": ["标量场可视化", "矢量场可视化", "体渲染", "流线追踪", "分子可视化"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "mlab.contour3d() 快速绘制三维等值面",
    "github_stars": 1200,
    "open_source": True,
    "download_command": "pip install mayavi",
    "fallback": ["pyvista", "vtk"]
}

TOOL_PYRENDER = {
    "name": "pyrender",
    "display_name": "PyRender 3D渲染",
    "description": "轻量级3D渲染库，支持PBR材质、光照和基于物理的渲染",
    "category": "3D建模",
    "scenarios": ["离线渲染", "深度图生成", "3D场景预览", "材质测试", "姿态可视化"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "配合 trimesh 使用可实现完整的网格加载+渲染管线",
    "github_stars": 2800,
    "open_source": True,
    "download_command": "pip install pyrender",
    "fallback": ["trimesh", "vedo"]
}

TOOL_PYBULLET = {
    "name": "pybullet",
    "display_name": "PyBullet 物理模拟",
    "description": "物理引擎模拟库，支持刚体动力学、碰撞检测和机器人仿真",
    "category": "3D建模",
    "scenarios": ["物理仿真", "机器人控制", "碰撞检测", "强化学习环境", "运动规划"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "p.connect(p.GUI) 打开可视化调试界面",
    "github_stars": 4100,
    "open_source": True,
    "download_command": "pip install pybullet",
    "fallback": ["panda3d"]
}

TOOL_PANDA3D = {
    "name": "panda3d",
    "display_name": "Panda3D 3D引擎",
    "description": "完整3D游戏引擎，提供渲染、音频、物理和网络功能",
    "category": "3D建模",
    "scenarios": ["3D游戏开发", "实时渲染", "虚拟现实", "模拟器开发", "交互式3D应用"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "迪士尼开发，渲染管线成熟，适合大型3D项目",
    "github_stars": 4700,
    "open_source": True,
    "download_command": "pip install panda3d",
    "fallback": ["pybullet", "blender-python"]
}

TOOL_PYGLTFLIB = {
    "name": "pygltflib",
    "display_name": "PyGLTFLib glTF处理",
    "description": "glTF 2.0文件读写库，用于处理3D资产的导入导出",
    "category": "3D建模",
    "scenarios": ["glTF格式解析", "3D资产转换", "Web3D导出", "模型优化", "PBR材质处理"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "glTF是Web和游戏引擎的标准3D传输格式",
    "github_stars": 600,
    "open_source": True,
    "download_command": "pip install pygltflib",
    "fallback": ["trimesh", "assimp"]
}

TOOL_ASSIMP = {
    "name": "assimp",
    "display_name": "Assimp 模型导入",
    "description": "Open Asset Import Library，支持40+种3D格式的导入",
    "category": "3D建模",
    "scenarios": ["多格式模型导入", "格式转换批处理", "场景图解析", "材质提取", "动画数据加载"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "pyassimp 是 Assimp 的 Python 绑定",
    "github_stars": 11000,
    "open_source": True,
    "download_command": "pip install pyassimp",
    "fallback": ["trimesh", "pygltflib"]
}

TOOL_PYMESHLAB = {
    "name": "pymeshlab",
    "display_name": "PyMeshLab 网格处理",
    "description": "MeshLab的Python接口，提供丰富的网格清理、修复和简化功能",
    "category": "3D建模",
    "scenarios": ["网格修复", "模型简化", "曲面重建", "网格平滑", "孔洞填充"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "ms = pymeshlab.MeshSet(); ms.load_new_mesh('model.stl') 开始处理",
    "github_stars": 700,
    "open_source": True,
    "download_command": "pip install pymeshlab",
    "fallback": ["trimesh", "open3d"]
}

TOOL_VEDO = {
    "name": "vedo",
    "display_name": "Vedo 3D科学",
    "description": "轻量3D科学可视化库，基于VTK但接口更加简洁现代",
    "category": "3D建模",
    "scenarios": ["3D科学可视化", "网格分析", "体数据渲染", "交互式演示", "医学图像"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "vedo 的 show() 函数一行即可完成3D渲染",
    "github_stars": 2200,
    "open_source": True,
    "download_command": "pip install vedo",
    "fallback": ["pyvista", "mayavi"]
}

TOOL_FURY = {
    "name": "fury",
    "display_name": "FURY 3D可视化",
    "description": "面向科研的3D可视化库，专注于医学影像和神经科学",
    "category": "3D建模",
    "scenarios": ["医学影像可视化", "纤维追踪", "DTI/DSI渲染", "科学动画", "交互式标注"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "FURY 由神经科学社区维护，适合脑成像数据可视化",
    "github_stars": 1000,
    "open_source": True,
    "download_command": "pip install fury",
    "fallback": ["vedo", "pyvista"]
}

TOOL_POLYSCOPE = {
    "name": "polyscope",
    "display_name": "Polyscope 3D几何",
    "description": "3D几何处理和可视化库，专注于网格和点云的快速可视化",
    "category": "3D建模",
    "scenarios": ["几何处理可视化", "点云展示", "曲面参数化", "算法调试", "数值几何验证"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "ps.init(); ps.register_surface_mesh('mesh', verts, faces) 一行显示网格",
    "github_stars": 2100,
    "open_source": True,
    "download_command": "pip install polyscope",
    "fallback": ["pyvista", "open3d"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}