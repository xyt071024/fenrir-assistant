// ===== 芬璃尔小助手 - Electron 主进程 =====
// 负责：启动 Python 后端服务器、创建桌面窗口、管理应用生命周期、桌宠覆盖层

const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const http = require('http');

const PORT = 18088;
const ROOT = path.resolve(__dirname, '..');
let mainWindow = null;
let petWindow = null;
let serverProcess = null;
let tray = null;
let isQuitting = false;

function startPythonServer() {
    const pythonPaths = [
        path.join('D:', 'python', 'python.exe'),
        path.join('D:', 'python', 'python3.exe'),
        'python',
        'python3',
        'pythonw'
    ];

    let pythonExe = null;
    const fs = require('fs');
    for (const p of pythonPaths) {
        if (fs.existsSync(p)) {
            pythonExe = p;
            break;
        }
    }

    if (!pythonExe) {
        pythonExe = 'python';
    }

    let serverPath = path.join(__dirname, 'server.py');
    if (!fs.existsSync(serverPath)) {
        serverPath = path.join(__dirname, '..', 'server.py');
    }
    console.log('[Electron] Starting Python server:', pythonExe, serverPath);

    serverProcess = spawn(pythonExe, [serverPath], {
        cwd: __dirname,
        stdio: ['pipe', 'pipe', 'pipe'],
        windowsHide: true
    });

    serverProcess.stdout.on('data', (data) => {
        console.log('[Python]', data.toString().trim());
    });

    serverProcess.stderr.on('data', (data) => {
        console.error('[Python Error]', data.toString().trim());
    });

    serverProcess.on('close', (code) => {
        console.log('[Electron] Python server exited with code', code);
    });
}

function waitForServer(retries = 30) {
    return new Promise((resolve, reject) => {
        function check() {
            const req = http.get(`http://127.0.0.1:${PORT}`, (res) => {
                if (res.statusCode === 200) {
                    resolve();
                } else {
                    retry();
                }
            });
            req.on('error', () => retry());
            req.setTimeout(1000, () => {
                req.destroy();
                retry();
            });
        }

        function retry() {
            retries--;
            if (retries <= 0) {
                reject(new Error('Server did not start in time'));
                return;
            }
            setTimeout(check, 500);
        }

        check();
    });
}

function createMainWindow() {
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        minWidth: 900,
        minHeight: 600,
        title: '芬璃尔小助手',
        icon: path.join(ROOT, 'app_icon.ico'),
        frame: true,
        autoHideMenuBar: true,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false
        },
        show: false
    });

    mainWindow.setTitle('芬璃尔小助手');
    mainWindow.setMenuBarVisibility(false);
    mainWindow.removeMenu();

    mainWindow.loadURL(`http://127.0.0.1:${PORT}`);

    mainWindow.once('ready-to-show', () => {
        mainWindow.show();
    });

    mainWindow.on('close', (event) => {
        if (!isQuitting) {
            event.preventDefault();
            mainWindow.hide();
            return false;
        }
    });

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

function createPetOverlay() {
    const { screen } = require('electron');
    const displays = screen.getPrimaryDisplay();
    const { width, height } = displays.workAreaSize;

    petWindow = new BrowserWindow({
        width: width,
        height: height,
        x: 0,
        y: 0,
        transparent: true,
        frame: false,
        resizable: false,
        skipTaskbar: true,
        alwaysOnTop: true,
        hasShadow: false,
        focusable: false,
        webPreferences: {
            contextIsolation: false,
            nodeIntegration: true,
            enableRemoteModule: false
        },
        show: false
    });

    petWindow.setIgnoreMouseEvents(true, { forward: true });
    petWindow.loadFile(path.join(__dirname, '核心', '桌宠覆盖窗口.html'));

    petWindow.once('ready-to-show', () => {
        petWindow.show();
    });

    petWindow.on('closed', () => {
        petWindow = null;
    });

    ipcMain.on('pet-event', (event, payload) => {
        if (payload.type === 'drag') {
            petWindow.setIgnoreMouseEvents(false);
            setTimeout(() => {
                petWindow.setIgnoreMouseEvents(true, { forward: true });
            }, 500);
        }
    });
}

function createTray() {
    const iconPath = path.join(ROOT, 'app_icon.ico');
    const fs = require('fs');
    let trayIcon;
    if (fs.existsSync(iconPath)) {
        trayIcon = nativeImage.createFromPath(iconPath);
    } else {
        trayIcon = nativeImage.createEmpty();
    }

    tray = new Tray(trayIcon);
    tray.setToolTip('芬璃尔小助手');

    const contextMenu = Menu.buildFromTemplate([
        {
            label: '显示主窗口',
            click: () => {
                if (mainWindow) {
                    mainWindow.show();
                    mainWindow.focus();
                } else {
                    createMainWindow();
                }
            }
        },
        {
            label: '显示/隐藏桌宠',
            click: () => {
                if (petWindow) {
                    if (petWindow.isVisible()) {
                        petWindow.hide();
                    } else {
                        petWindow.show();
                    }
                }
            }
        },
        { type: 'separator' },
        {
            label: '退出',
            click: () => {
                isQuitting = true;
                if (tray) {
                    tray.destroy();
                    tray = null;
                }
                app.quit();
            }
        }
    ]);

    tray.setContextMenu(contextMenu);

    tray.on('double-click', () => {
        if (mainWindow) {
            mainWindow.show();
            mainWindow.focus();
        } else {
            createMainWindow();
        }
    });
}

function killServer() {
    if (serverProcess) {
        try {
            if (process.platform === 'win32') {
                spawn('taskkill', ['/pid', String(serverProcess.pid), '/f', '/t']);
            } else {
                serverProcess.kill('SIGTERM');
            }
        } catch (e) {
            console.error('[Electron] Failed to kill server:', e.message);
        }
        serverProcess = null;
    }
}

app.whenReady().then(async () => {
    startPythonServer();
    try {
        await waitForServer(60);
        console.log('[Electron] Server ready');
    } catch (err) {
        console.error('[Electron]', err.message);
    }
    createMainWindow();
    createPetOverlay();
    createTray();
});

app.on('window-all-closed', () => {
    if (!isQuitting) {
        return;
    }
    killServer();
    app.quit();
});

app.on('before-quit', () => {
    isQuitting = true;
    killServer();
    if (tray) {
        tray.destroy();
        tray = null;
    }
});

app.on('will-quit', () => {
    killServer();
});

app.on('activate', () => {
    if (mainWindow === null) {
        createMainWindow();
    } else {
        mainWindow.show();
    }
});