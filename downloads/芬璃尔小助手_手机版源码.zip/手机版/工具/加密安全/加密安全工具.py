TOOL_cryptography = {
    "name": "cryptography", "display_name": "Cryptography加密库", "description": "Python最专业的密码学库，提供对称加密、非对称加密、数字签名、证书管理等全套加密功能",
    "category": "加密安全", "scenarios": ["数据加密", "数字签名", "证书管理"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["pycryptodome"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "高安全级别，推荐优先使用，Fernet模块适合快速对称加密",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install cryptography", "fallback": ["pycryptodome", "cryptography-fernet"]
}

TOOL_hashlib = {
    "name": "hashlib", "display_name": "Hashlib哈希库", "description": "Python标准库哈希模块，支持MD5、SHA1、SHA256、SHA512、BLAKE2等哈希算法",
    "category": "加密安全", "scenarios": ["数据完整性校验", "密码哈希", "文件校验"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Python内置无需安装，对大文件使用update()分块计算哈希",
    "github_stars": 0, "open_source": True,
    "download_command": "无需安装，Python标准库内置", "fallback": ["hmac", "pbkdf2"]
}

TOOL_jwt = {
    "name": "jwt", "display_name": "PyJWT JWT令牌", "description": "JSON Web Token生成与验证库，支持HS256、RS256等多种签名算法和令牌解析",
    "category": "加密安全", "scenarios": ["用户认证", "API鉴权", "单点登录"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "生产环境建议使用RS256非对称签名，密钥妥善保管",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pyjwt", "fallback": ["cryptography"]
}

TOOL_bandit = {
    "name": "bandit", "display_name": "Bandit安全扫描", "description": "Python代码安全漏洞静态分析工具，自动检测常见安全问题和危险函数调用",
    "category": "加密安全", "scenarios": ["代码审计", "安全扫描", "CI/CD安全检查"],
    "accuracy": 4, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "集成到CI流程中定期扫描，支持自定义规则配置",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install bandit", "fallback": ["safety"]
}

TOOL_argon2 = {
    "name": "argon2", "display_name": "Argon2密码哈希", "description": "Argon2密码哈希算法实现，2015年密码哈希大赛冠军，抗GPU和ASIC攻击",
    "category": "加密安全", "scenarios": ["密码存储", "密钥派生", "安全认证"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["bcrypt"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "当前最安全的密码哈希算法，推荐新项目使用，可调时间/内存/并行度参数",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install argon2-cffi", "fallback": ["bcrypt", "passlib"]
}

TOOL_bcrypt = {
    "name": "bcrypt", "display_name": "Bcrypt密码哈希", "description": "成熟的密码哈希算法实现，内置salt机制，广泛应用的生产级密码保护方案",
    "category": "加密安全", "scenarios": ["密码存储", "用户认证", "账户安全"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": ["argon2"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "成本因子(rounds)建议12以上，平衡安全性和性能",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install bcrypt", "fallback": ["argon2", "passlib"]
}

TOOL_passlib = {
    "name": "passlib", "display_name": "Passlib密码库", "description": "统一密码哈希库，支持bcrypt、argon2、pbkdf2等20+种密码哈希算法，提供统一接口",
    "category": "加密安全", "scenarios": ["密码管理", "多算法兼容", "遗留系统迁移"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "支持密码哈希自动升级，适合新旧系统过渡期使用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install passlib", "fallback": ["bcrypt", "argon2"]
}

TOOL_pycryptodome = {
    "name": "pycryptodome", "display_name": "PyCryptodome加密", "description": "自包含的低级密码学库，支持AES、DES、RSA、ECC等大量加密算法和加密模式",
    "category": "加密安全", "scenarios": ["低级加密操作", "自定义加密方案", "加解密算法实验"],
    "accuracy": 5, "efficiency": 4, "speed": 5,
    "conflicts_with": ["cryptography"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "PyCrypto的活跃分支，无需外部依赖，适合嵌入式加密场景",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pycryptodome", "fallback": ["cryptography"]
}

TOOL_rsa = {
    "name": "rsa", "display_name": "RSA加密库", "description": "纯Python实现的RSA加密算法库，支持密钥生成、加密解密、签名验签等操作",
    "category": "加密安全", "scenarios": ["RSA加解密", "数字签名", "密钥生成"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "纯Python实现性能一般，大数据加密建议配合AES混合加密",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install rsa", "fallback": ["pycryptodome", "cryptography"]
}

TOOL_pyopenssl = {
    "name": "pyopenssl", "display_name": "PyOpenSSL SSL/TLS", "description": "OpenSSL的Python封装，提供SSL/TLS协议操作、证书生成、CRL管理等底层网络加密功能",
    "category": "加密安全", "scenarios": ["SSL/TLS通信", "证书生成", "HTTPS安全"],
    "accuracy": 5, "efficiency": 3, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "底层接口较复杂，注意版本兼容性，推荐配合cryptography使用",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install pyopenssl", "fallback": ["cryptography", "certifi"]
}

TOOL_certifi = {
    "name": "certifi", "display_name": "Certifi证书包", "description": "Mozilla CA证书包Python封装，提供最新的根证书集合用于SSL/TLS验证",
    "category": "加密安全", "scenarios": ["HTTPS请求", "SSL证书验证", "网络安全通信"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "自动跟随Mozilla CA证书更新，定期升级即可保持最新",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install certifi", "fallback": ["truststore"]
}

TOOL_scapy = {
    "name": "scapy", "display_name": "Scapy网络嗅探", "description": "功能强大的网络包操作库，支持抓包、封包构造、协议解析、网络扫描和渗透测试",
    "category": "加密安全", "scenarios": ["网络分析", "协议研究", "安全审计"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "danger",
    "requires_network": True, "usage_tips": "仅限授权环境使用，Windows下需安装Npcap驱动，注意法律法规",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install scapy", "fallback": ["pyshark"]
}

TOOL_paramiko = {
    "name": "paramiko", "display_name": "Paramiko SSH", "description": "SSH2协议的Python实现，支持SSH远程连接、SFTP文件传输、密钥管理和端口转发",
    "category": "加密安全", "scenarios": ["远程服务器管理", "SFTP文件传输", "自动化运维"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持SSH密钥认证和密码认证，建议优先使用密钥认证",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install paramiko", "fallback": ["asyncssh"]
}

TOOL_fernet = {
    "name": "fernet", "display_name": "Cryptography Fernet对称加密", "description": "基于AES-128-CBC和HMAC-SHA256的对称加密方案，提供简单安全的加密解密接口",
    "category": "加密安全", "scenarios": ["文件加密", "数据脱敏", "配置加密"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "来自cryptography库，使用简单，一行代码加密，适合快速数据加密需求",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install cryptography", "fallback": ["pycryptodome"]
}

TOOL_keyring = {
    "name": "keyring", "display_name": "Keyring密钥管理", "description": "系统密钥环管理库，安全存储密码和密钥到操作系统密钥管理器(Windows凭据管理器/macOS钥匙串等)",
    "category": "加密安全", "scenarios": ["凭据管理", "密钥存储", "密码安全保存"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "利用操作系统原生加密存储，比配置文件更安全",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install keyring", "fallback": ["加密文件存储"]
}

TOOL_secrets = {
    "name": "secrets", "display_name": "Secrets安全随机", "description": "Python 3.6+标准库安全随机数模块，专为密码学安全场景设计，替代random模块",
    "category": "加密安全", "scenarios": ["令牌生成", "密码生成", "安全随机数"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Python内置，使用系统安全随机源，适合生成API密钥、重置令牌等",
    "github_stars": 0, "open_source": True,
    "download_command": "无需安装，Python标准库内置", "fallback": ["random"]
}

TOOL_hmac = {
    "name": "hmac", "display_name": "HMAC消息认证", "description": "Python标准库HMAC模块，基于哈希算法的消息认证码计算，验证数据完整性和真实性",
    "category": "加密安全", "scenarios": ["消息认证", "API签名", "数据完整性"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Python内置，常与hashlib配合使用，适合API请求签名验证",
    "github_stars": 0, "open_source": True,
    "download_command": "无需安装，Python标准库内置", "fallback": ["hashlib", "pbkdf2"]
}

TOOL_pbkdf2 = {
    "name": "pbkdf2", "display_name": "PBKDF2密钥派生", "description": "基于密码的密钥派生函数，通过可调迭代次数增强密码强度，抵抗暴力破解攻击",
    "category": "加密安全", "scenarios": ["密钥派生", "密码加固", "安全存储"],
    "accuracy": 5, "efficiency": 4, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "Python内置(hashlib.pbkdf2_hmac)，迭代次数建议10万次以上",
    "github_stars": 0, "open_source": True,
    "download_command": "无需安装，Python标准库内置", "fallback": ["argon2", "bcrypt"]
}

TOOL_truststore = {
    "name": "truststore", "display_name": "Truststore证书信任", "description": "使用系统原生证书存储而非Mozilla捆绑证书，支持Windows/macOS/Linux各平台证书管理",
    "category": "加密安全", "scenarios": ["SSL证书验证", "系统证书集成", "HTTPS安全"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["certifi"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "PEP 543实现，自动利用操作系统CA证书，无需手动更新证书包",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install truststore", "fallback": ["certifi"]
}

TOOL_tlstrust = {
    "name": "tlstrust", "display_name": "TLSTrust TLS安全", "description": "TLS连接安全检测工具，验证证书链、检查SSL配置、检测已知安全漏洞和不安全协议",
    "category": "加密安全", "scenarios": ["TLS安全审计", "证书检测", "SSL配置检查"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "用于服务器TLS安全评估，检测是否支持TLS 1.0/1.1等不安全协议",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install tlstrust", "fallback": ["pyopenssl", "certifi"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
