TOOL_TYPST = {
    "name": "typst",
    "display_name": "新式排版系统",
    "description": "基于 Markdown 语法的现代排版系统，可作为 LaTeX 的替代方案，编译极快",
    "category": "排版PDF工具",
    "scenarios": ["学术论文排版", "简历制作", "演示文稿", "技术文档排版"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["LaTeX", "pylatex"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "语法简洁，编译速度远快于 LaTeX，推荐新项目优先考虑",
    "github_stars": 38000,
    "open_source": True,
    "download_command": "winget install typst",
    "fallback": ["LaTeX", "pylatex"]
}

TOOL_LATEX = {
    "name": "LaTeX",
    "display_name": "学术排版系统",
    "description": "最专业的学术排版系统，通过 TeX 语言生成高质量 PDF 文档，适合论文和书籍",
    "category": "排版PDF工具",
    "scenarios": ["学术论文排版", "书籍出版", "数学公式排版", "学位论文模板"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 2,
    "conflicts_with": ["typst", "pylatex"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "学习曲线陡峭但功能最强大，数学公式排版无可替代",
    "github_stars": 1000,
    "open_source": True,
    "download_command": "choco install miktex",
    "fallback": ["typst", "pylatex"]
}

TOOL_SPHINX = {
    "name": "Sphinx",
    "display_name": "文档生成系统",
    "description": "Python 文档生成工具，支持 reStructuredText 和 Markdown，可输出 HTML/PDF/EPUB",
    "category": "排版PDF工具",
    "scenarios": ["项目文档生成", "API文档", "技术手册", "在线文档网站"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["mkdocs"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Python 生态标准文档工具，配合 Read the Docs 使用最佳",
    "github_stars": 6400,
    "open_source": True,
    "download_command": "pip install sphinx",
    "fallback": ["mkdocs"]
}

TOOL_MKDOCS = {
    "name": "mkdocs",
    "display_name": "文档网站生成",
    "description": "基于 Markdown 的文档网站生成器，配置简单，主题美观，适合项目文档",
    "category": "排版PDF工具",
    "scenarios": ["项目文档网站", "知识库搭建", "技术博客", "产品文档"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["Sphinx"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "Markdown 友好，Material 主题效果出众，推荐给非 Python 项目使用",
    "github_stars": 20000,
    "open_source": True,
    "download_command": "pip install mkdocs",
    "fallback": ["Sphinx"]
}

TOOL_PWEAVE = {
    "name": "pweave",
    "display_name": "文学编程工具",
    "description": "Python 文学编程工具，类似 Jupyter 但基于 Markdown/LaTeX 源文件",
    "category": "排版PDF工具",
    "scenarios": ["可重复研究报告", "文学编程", "数据科学文档", "教学材料生成"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["jupyter-book"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合需要版本控制的文学编程项目，输出格式丰富",
    "github_stars": 500,
    "open_source": True,
    "download_command": "pip install pweave",
    "fallback": ["jupyter-book", "quarto"]
}

TOOL_JUPYTER_BOOK = {
    "name": "jupyter-book",
    "display_name": "交互式书籍出版",
    "description": "基于 Jupyter Notebook 和 Markdown 的书籍出版工具，支持交互式内容",
    "category": "排版PDF工具",
    "scenarios": ["交互式教材编写", "学术出版", "Jupyter文档整理", "在线教程制作"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["pweave", "quarto"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合包含代码和运行结果的教程类书籍创作",
    "github_stars": 6600,
    "open_source": True,
    "download_command": "pip install jupyter-book",
    "fallback": ["quarto", "pweave"]
}

TOOL_QUARTO = {
    "name": "quarto",
    "display_name": "多格式出版系统",
    "description": "新一代多格式出版系统，支持 Jupyter/R Markdown，输出 PDF/HTML/Word/Docx 等",
    "category": "排版PDF工具",
    "scenarios": ["学术出版", "技术文档", "数据报告", "幻灯片制作", "博客发布"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 4,
    "conflicts_with": ["jupyter-book", "pweave"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "功能比 Jupyter Book 更全面，支持 R/Python/Julia/Jupyter 等多种计算引擎",
    "github_stars": 4100,
    "open_source": True,
    "download_command": "pip install quarto",
    "fallback": ["jupyter-book", "pandoc"]
}

TOOL_RINOHTYPE = {
    "name": "rinohtype",
    "display_name": "Python原生排版",
    "description": "纯 Python 编写的文档排版系统，无需 TeX 依赖，从 rst/Markdown 生成 PDF",
    "category": "排版PDF工具",
    "scenarios": ["文档排版", "PDF生成", "简单出版流水线"],
    "accuracy": 3,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["LaTeX", "ReportLab"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "纯 Python 实现，无需外部依赖，适合简单文档排版场景",
    "github_stars": 200,
    "open_source": True,
    "download_command": "pip install rinohtype",
    "fallback": ["ReportLab", "LaTeX"]
}

TOOL_SVG2PDF = {
    "name": "svg2pdf",
    "display_name": "SVG转PDF",
    "description": "将 SVG 矢量图形文件转换为 PDF 格式，保留矢量特性",
    "category": "排版PDF工具",
    "scenarios": ["矢量图转PDF", "图标导出", "设计素材转换", "插图排版"],
    "accuracy": 4,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["img2pdf"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "推荐使用 cairosvg，转换质量高，支持复杂 SVG 特性",
    "github_stars": 300,
    "open_source": True,
    "download_command": "pip install svg2pdf",
    "fallback": ["img2pdf", "cairosvg"]
}

TOOL_IMG2PDF = {
    "name": "img2pdf",
    "display_name": "图片转PDF",
    "description": "将多张图片合并转换为 PDF 文件，支持无损压缩和高质量输出",
    "category": "排版PDF工具",
    "scenarios": ["图片批量转PDF", "扫描件合并", "相册制作", "电子书制作"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["svg2pdf"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持 JPEG/PNG/GIF/TIFF 等格式，非图片内容用 ReportLab",
    "github_stars": 2900,
    "open_source": True,
    "download_command": "pip install img2pdf",
    "fallback": ["ReportLab", "FPDF2"]
}

TOOL_PYPDF = {
    "name": "pypdf",
    "display_name": "PDF拆分合并",
    "description": "纯 Python PDF 操作库，支持拆分、合并、旋转、裁剪、提取文本和元数据",
    "category": "排版PDF工具",
    "scenarios": ["PDF拆分合并", "PDF页面操作", "PDF元数据编辑", "PDF提取"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pikepdf", "stapler"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "轻量级 PDF 操作首选，功能全面且无需额外依赖",
    "github_stars": 8300,
    "open_source": True,
    "download_command": "pip install pypdf",
    "fallback": ["pikepdf", "PyMuPDF"]
}

TOOL_PIKEPDF = {
    "name": "pikepdf",
    "display_name": "PDF加密解密",
    "description": "基于 QPDF 的 PDF 操作库，支持加密解密、压缩优化、元数据编辑、结构分析",
    "category": "排版PDF工具",
    "scenarios": ["PDF加密解密", "PDF压缩优化", "PDF结构分析", "PDF修复"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pypdf", "PyMuPDF"],
    "safety_level": "warning",
    "requires_network": False,
    "usage_tips": "处理加密 PDF 的首选工具，大文件压缩效果明显",
    "github_stars": 2300,
    "open_source": True,
    "download_command": "pip install pikepdf",
    "fallback": ["pypdf", "PyMuPDF"]
}

TOOL_PDF2IMAGE = {
    "name": "pdf2image",
    "display_name": "PDF转图片",
    "description": "将 PDF 页面转换为 PIL 图片对象，支持批量转换和自定义分辨率",
    "category": "排版PDF工具",
    "scenarios": ["PDF预览生成", "PDF缩略图", "文档数字化", "PDF页面截图"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["PyMuPDF"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需要安装 poppler，配合 OCR 工具可实现 PDF 文字识别流水线",
    "github_stars": 4100,
    "open_source": True,
    "download_command": "pip install pdf2image",
    "fallback": ["PyMuPDF"]
}

TOOL_CAMELOT = {
    "name": "camelot",
    "display_name": "PDF表格提取",
    "description": "专注 PDF 表格提取的库，基于 Lattice/Stream 两种模式，提取准确率高",
    "category": "排版PDF工具",
    "scenarios": ["PDF表格高精度提取", "财务报表数据提取", "研究数据采集", "PDF转DataFrame"],
    "accuracy": 5,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["tabula-py", "pdfplumber"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "对有线表格(Lattice)提取准确率极高，支持导出为 Excel/CSV/JSON",
    "github_stars": 2900,
    "open_source": True,
    "download_command": "pip install camelot-py",
    "fallback": ["tabula-py", "pdfplumber"]
}

TOOL_FITZ = {
    "name": "fitz",
    "display_name": "PyMuPDF(fitz)",
    "description": "PyMuPDF 的 fitz 模块接口，高效的 PDF/图像格式解析、渲染和文本提取",
    "category": "排版PDF工具",
    "scenarios": ["PDF渲染", "文本提取", "PDF注释", "图像提取", "PDF转图片"],
    "accuracy": 5,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["pdfminer", "pypdf"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "PyMuPDF 的核心接口，速度和功能兼优的 PDF 处理选择",
    "github_stars": 3600,
    "open_source": True,
    "download_command": "pip install PyMuPDF",
    "fallback": ["pypdf", "pdfminer"]
}

TOOL_BORB = {
    "name": "borb",
    "display_name": "PDF读写分析",
    "description": "纯 Python PDF 库，支持 PDF 创建、读取、分析和编辑，面向对象设计",
    "category": "排版PDF工具",
    "scenarios": ["PDF创建编辑", "PDF结构分析", "PDF表单填写", "PDF注释添加"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 3,
    "conflicts_with": ["ReportLab", "PyMuPDF"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "API 设计优雅，但速度不如 PyMuPDF，适合中小型项目",
    "github_stars": 1600,
    "open_source": True,
    "download_command": "pip install borb",
    "fallback": ["PyMuPDF", "ReportLab"]
}

TOOL_STAPLER = {
    "name": "stapler",
    "display_name": "PDF操作工具",
    "description": "命令行 PDF 操作工具，基于 pypdf，支持拆分、合并、旋转、裁剪等",
    "category": "排版PDF工具",
    "scenarios": ["PDF命令行操作", "PDF批量处理", "脚本化PDF操作"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["pypdf", "pikepdf"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "适合在命令行中快速操作 PDF，脚本自动化场景方便",
    "github_stars": 600,
    "open_source": True,
    "download_command": "pip install stapler",
    "fallback": ["pypdf", "pikepdf"]
}

TOOL_PDFMINER = {
    "name": "pdfminer",
    "display_name": "PDF文本解析",
    "description": "PDF 内容解析器，专注于文本提取和布局分析，支持复杂 PDF 解析",
    "category": "排版PDF工具",
    "scenarios": ["PDF文本深度解析", "PDF布局分析", "PDF内容提取", "PDF研究分析"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 2,
    "conflicts_with": ["PyMuPDF", "pypdf"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "解析能力强但速度慢，适合复杂 PDF 研究用，日常用 PyMuPDF 即可",
    "github_stars": 5600,
    "open_source": True,
    "download_command": "pip install pdfminer.six",
    "fallback": ["PyMuPDF", "pypdf"]
}

TOOL_PYLATEX_PDF = {
    "name": "pylatex",
    "display_name": "LaTeX代码生成",
    "description": "Python 生成 LaTeX 代码并编译为 PDF，支持数学公式、表格、图像、图表等",
    "category": "排版PDF工具",
    "scenarios": ["自动化LaTeX文档", "学术报告生成", "公式排版", "PDF流水线"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["LaTeX", "typst"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需要安装 LaTeX 发行版，适合需要高质量排版的自动化场景",
    "github_stars": 1500,
    "open_source": True,
    "download_command": "pip install pylatex",
    "fallback": ["LaTeX", "typst"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}