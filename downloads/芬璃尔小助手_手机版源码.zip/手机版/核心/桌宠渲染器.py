import sys
import json
import time
import threading
import socket
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from 桌宠引擎 import DeskPet, GameDetector, PetState, PetAction

class PetRenderer:
    """桌宠渲染调度器——管理宠物的状态并通过HTTP/WebSocket与UI通信"""
    
    def __init__(self, pet_name="芬璃尔"):
        self.pet = DeskPet(pet_name)
        self.detector = GameDetector(self.pet)
        self._thinking_thread = None
        self._running = False
        self._clients = []
    
    def start(self):
        self._running = True
        self.pet.start()
        
        # 游戏检测
        self.detector.start_monitoring()
        
        # 自动行为线程
        self._thinking_thread = threading.Thread(target=self._auto_loop, daemon=True)
        self._thinking_thread.start()
    
    def stop(self):
        self._running = False
        self.pet.stop()
        self.detector.stop_monitoring()
    
    def _auto_loop(self):
        while self._running:
            action = self.pet.auto_think()
            if action:
                self._broadcast(action)
            time.sleep(5)
    
    def _broadcast(self, data):
        msg = json.dumps(data, ensure_ascii=False)
        for client in self._clients[:]:
            try:
                client.send(msg.encode())
            except:
                self._clients.remove(client)
    
    def handle_event(self, event_type, data=None):
        if event_type == "click":
            result = self.pet.interact("click")
        elif event_type == "double_click":
            result = self.pet.interact("double_click")
        elif event_type == "drag":
            result = self.pet.move_to(data.get("x", 100), data.get("y", 100))
        elif event_type == "wander":
            result = self.pet.wander()
        elif event_type == "emotion":
            self.pet.emotion.set(data.get("emotion", "happy"))
            result = {"emotion": data.get("emotion")}
        elif event_type == "resize":
            self.pet.screen_size = data
            result = {"screen": data}
        else:
            result = None
        return result or self.pet.get_status()
    
    def get_status(self):
        return self.pet.get_status()
