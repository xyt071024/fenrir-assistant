TOOL_SLV = {
    "name": "snowleopard-vision",
    "display_name": "SnowLeopard Vision(SLV)",
    "description": "AI超分辨率与补帧工具，利用深度学习对视频/图片进行超分放大和帧率插值，支持实时处理和批量处理",
    "category": "GPU图形增强工具",
    "scenarios": ["视频AI超分辨率", "视频补帧(慢动作)", "老视频修复增强", "动漫/真人视频画质提升", "批量视频处理"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Video2X", "REAL-Video-Enhancer"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "GPU加速效果显著；支持CUDA/Vulkan后端；超分和补帧可组合使用达到最佳画质",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install slv",
    "fallback": ["Real-ESRGAN", "RIFE"]
}

TOOL_Real_ESRGAN_gpu = {
    "name": "Real-ESRGAN",
    "display_name": "Real-ESRGAN",
    "description": "通用超分辨率模型，基于增强型超分GAN，支持4倍/8倍放大，擅长真实世界图像降噪与增强",
    "category": "GPU图形增强工具",
    "scenarios": ["通用图像超分", "老照片修复", "模糊图像清晰化", "视频帧超分", "图像降噪"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["ESRGAN", "BasicSR"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "使用realesrgan-ncnn-vulkan版本可获更好GPU加速；tile模式避免OOM",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install real-esrgan",
    "fallback": ["ESRGAN", "BasicSR"]
}

TOOL_Waifu2x = {
    "name": "waifu2x",
    "display_name": "Waifu2x",
    "description": "动漫图片超分辨率放大工具，基于卷积神经网络，专门针对二次元/动漫风格图像进行2倍无损放大和降噪",
    "category": "GPU图形增强工具",
    "scenarios": ["动漫图片放大", "二次元图像降噪", "动漫视频帧增强", "游戏截图放大", "插画高清化"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Waifu2x-Extension", "Anime4K"],
    "safety_level": "safe",
    "requires_network": True,
    "fallback": ["Waifu2x-Extension", "Anime4K"],
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install waifu2x",
    "usage_tips": "动漫图片效果显著优于通用超分模型；支持CUDA加速；对真实照片效果一般"
}

TOOL_Video2X = {
    "name": "Video2X",
    "display_name": "Video2X",
    "description": "视频超分辨率放大框架，集成Waifu2x/ESRGAN/Real-ESRGAN等多种AI模型，自动对视频逐帧放大再合成",
    "category": "GPU图形增强工具",
    "scenarios": ["视频AI超分放大", "动漫视频画质提升", "低分辨率视频修复", "老视频高清化", "批量视频处理"],
    "accuracy": 5, "efficiency": 2, "speed": 2,
    "conflicts_with": ["Waifu2x-Extension", "REAL-Video-Enhancer"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "处理速度慢但效果极佳；建议配合GPU使用；支持选择不同AI模型作为引擎",
    "github_stars": 15000,
    "open_source": True,
    "download_command": "pip install video2x",
    "fallback": ["Waifu2x-Extension", "REAL-Video-Enhancer"]
}

TOOL_Waifu2x_Extension = {
    "name": "waifu2x-extension",
    "display_name": "Waifu2x-Extension",
    "description": "超分补帧全家桶，集成超分辨率、补帧、视频增强于一体的GUI工具，支持多种AI模型引擎切换",
    "category": "GPU图形增强工具",
    "scenarios": ["动漫/真人视频超分", "视频补帧制作慢动作", "视频综合画质增强", "老视频修复翻新", "批量图像处理"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["Video2X", "REAL-Video-Enhancer"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "支持Waifu2x/SRMDF/Real-ESRGAN等多种引擎；补帧支持RIFE/DAIN；推荐使用NVIDIA GPU",
    "github_stars": 16400,
    "open_source": True,
    "download_command": "pip install waifu2x-extension",
    "fallback": ["Video2X", "REAL-Video-Enhancer"]
}

TOOL_GFPGAN = {
    "name": "GFPGAN",
    "display_name": "GFPGAN",
    "description": "基于GAN的人脸修复模型，专门针对模糊/低质量/老化人脸进行修复增强，保留身份特征",
    "category": "GPU图形增强工具",
    "scenarios": ["老照片人脸修复", "模糊人脸清晰化", "人脸超分辨率", "旧照片翻新", "视频人脸增强"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["CodeFormer"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "与Real-ESRGAN配合使用效果更佳；支持全脸修复和背景增强分离处理",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install gfpgan",
    "fallback": ["CodeFormer", "Real-ESRGAN"]
}

TOOL_CodeFormer = {
    "name": "CodeFormer",
    "display_name": "CodeFormer",
    "description": "基于VQGAN+Transformer的人脸修复模型，通过码本预测实现人脸修复增强，支持可调节的保真度控制",
    "category": "GPU图形增强工具",
    "scenarios": ["人脸修复增强", "老照片人脸复原", "模糊人脸高清化", "人脸去马赛克", "人脸生成修复"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["GFPGAN"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "w参数控制保真度(0-1)，值越小越倾向于生成修复，越大越保持原图；推荐w=0.5平衡",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install codeformer",
    "fallback": ["GFPGAN", "Real-ESRGAN"]
}

TOOL_REAL_Video_Enhancer = {
    "name": "real-video-enhancer",
    "display_name": "REAL-Video-Enhancer",
    "description": "视频增强工具，集成超分辨率、补帧、色彩增强、去噪等功能的视频画质提升一体化方案",
    "category": "GPU图形增强工具",
    "scenarios": ["视频画质综合增强", "低分辨率视频超分", "视频色彩修复", "老视频去噪去划痕", "视频美化"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["Video2X", "Waifu2x-Extension"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "支持插件式模型扩展；建议先试用小片段调整参数再处理完整视频",
    "github_stars": 1300,
    "open_source": True,
    "download_command": "pip install real-video-enhancer",
    "fallback": ["Video2X", "Waifu2x-Extension"]
}

TOOL_Flowframes = {
    "name": "flowframes",
    "display_name": "Flowframes",
    "description": "AI视频补帧工具，基于深度学习光流法实现视频帧率提升，可将30fps补帧至60/120/240fps甚至更高",
    "category": "GPU图形增强工具",
    "scenarios": ["视频慢动作制作", "帧率提升(30→60/120fps)", "运动画面平滑化", "游戏录像补帧", "视频流畅度增强"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["RIFE", "DAIN"],
    "safety_level": "safe",
    "requires_network": True,
    "fallback": ["RIFE", "DAIN"],
    "github_stars": 1900,
    "open_source": True,
    "download_command": "pip install flowframes",
    "usage_tips": "支持RIFE和DAIN两种补帧引擎；RIFE速度快，DAIN效果更精细；补帧倍数越高越吃配置"
}

TOOL_Anime4K = {
    "name": "Anime4K",
    "display_name": "Anime4K",
    "description": "高性能动漫实时放大算法，基于GLSL着色器，可在播放器中实时将低分辨率动漫放大至4K分辨率",
    "category": "GPU图形增强工具",
    "scenarios": ["动漫实时放大播放", "低分辨率动漫4K化", "视频播放器滤镜", "直播画面增强", "实时渲染放大"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["Waifu2x", "Real-ESRGAN"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "可作为MPV/VLC等播放器的实时滤镜使用；计算量极低，集显也能流畅运行",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install anime4k",
    "fallback": ["Waifu2x", "Real-ESRGAN"]
}

TOOL_RIFE = {
    "name": "rife",
    "display_name": "RIFE",
    "description": "实时视频补帧算法(Real-Time Intermediate Flow Estimation)，基于光流的高效补帧模型，支持任意倍数插帧",
    "category": "GPU图形增强工具",
    "scenarios": ["实时视频补帧", "慢动作视频制作", "帧率提升", "视频流畅化", "游戏录像插帧"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["DAIN", "Flowframes"],
    "safety_level": "safe",
    "requires_network": True,
    "fallback": ["DAIN", "Flowframes"],
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install rife",
    "usage_tips": "速度快可实时处理，精度略低于DAIN；多倍数插帧时建议分阶段补帧以获得更好效果"
}

TOOL_DAIN = {
    "name": "dain",
    "display_name": "DAIN",
    "description": "深度补帧网络(Depth-Aware Video Frame Interpolation)，基于深度感知的补帧算法，精度高但速度较慢",
    "category": "GPU图形增强工具",
    "scenarios": ["高精度视频补帧", "慢动作精细制作", "电影级补帧", "运动模糊插值", "高质量帧率提升"],
    "accuracy": 5, "efficiency": 2, "speed": 2,
    "conflicts_with": ["RIFE", "Flowframes"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "精度高但速度慢，适合离线处理追求极致画质的场景；对显存要求较高",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install dain",
    "fallback": ["RIFE", "Flowframes"]
}

TOOL_enhance = {
    "name": "enhance",
    "display_name": "Enhance",
    "description": "图像增强工具集，提供对比度增强、直方图均衡化、锐化、去雾、色彩增强等多种图像质量提升算法",
    "category": "GPU图形增强工具",
    "scenarios": ["图像对比度增强", "低光照图像增强", "去雾处理", "图像锐化", "色彩校正"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "CLAHE算法适合低对比度图像增强；去雾算法对雾霾照片有明显改善效果",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install enhance",
    "fallback": ["opencv-python", "Pillow"]
}

TOOL_ncnn = {
    "name": "ncnn",
    "display_name": "ncnn",
    "description": "腾讯开发的轻量级神经网络推理框架，专为移动端优化，支持GPU加速(Vulkan)，可用于部署超分/补帧模型",
    "category": "GPU图形增强工具",
    "scenarios": ["移动端AI推理", "端侧超分模型部署", "实时视频处理", "嵌入式AI加速", "跨平台模型部署"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["vulkan-compute"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "支持Vulkan GPU加速；模型需转换为ncnn格式；非常适合移动端和边缘设备部署",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install ncnn",
    "fallback": ["vulkan-compute", "OpenCV"]
}

TOOL_vulkan_compute = {
    "name": "vulkan-compute",
    "display_name": "Vulkan-Compute",
    "description": "基于Vulkan的GPU通用计算框架，可用于图像处理、神经网络推理等并行计算任务，跨平台支持",
    "category": "GPU图形增强工具",
    "scenarios": ["GPU通用计算", "并行图像处理", "自定义着色器开发", "高性能计算", "跨平台GPU加速"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["ncnn"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需要Vulkan驱动的GPU；适合编写自定义GPU计算任务；与GLSL着色器语法类似",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install vulkan",
    "fallback": ["ncnn", "OpenCV"]
}

TOOL_SRGAN = {
    "name": "srgan",
    "display_name": "SRGAN",
    "description": "超分辨率生成对抗网络，基于GAN的图像超分模型，能够生成更真实的高频纹理细节",
    "category": "GPU图形增强工具",
    "scenarios": ["图像超分辨率", "纹理细节生成", "深度学习超分研究", "图像增强", "超分模型训练"],
    "accuracy": 4, "efficiency": 3, "speed": 3,
    "conflicts_with": ["ESRGAN", "EDSR"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "SRGAN是超分GAN的奠基工作；ESRGAN在其基础上改进；适合学术研究和实验",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install srgan",
    "fallback": ["ESRGAN", "EDSR"]
}

TOOL_EDSR = {
    "name": "edsr",
    "display_name": "EDSR",
    "description": "增强深度超分辨率网络，去除BN层的改进超分模型，在NTIRE2017超分挑战赛夺冠，PSNR指标优秀",
    "category": "GPU图形增强工具",
    "scenarios": ["高PSNR超分辨率", "图像精细放大", "超分模型基准测试", "高质量图像重建", "学术研究"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["SRGAN", "ESRGAN"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "追求PSNR指标的最佳选择；模型较大需要较多显存；适合对保真度要求高的场景",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install edsr",
    "fallback": ["SRGAN", "ESRGAN"]
}

TOOL_ESRGAN = {
    "name": "esrgan",
    "display_name": "ESRGAN",
    "description": "增强型超分辨率GAN(Enhanced SRGAN)，改进SRGAN的判别器和感知损失，生成更逼真的纹理细节",
    "category": "GPU图形增强工具",
    "scenarios": ["图像超分增强", "纹理细节重建", "图像质量提升", "超分模型研究", "Real-ESRGAN基础模型"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["SRGAN", "Real-ESRGAN"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "Real-ESRGAN是其改进版，更擅长处理真实图像；ESRGAN对合成退化图像效果更好",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install esrgan",
    "fallback": ["Real-ESRGAN", "SRGAN"]
}

TOOL_BasicSR = {
    "name": "basicsr",
    "display_name": "BasicSR",
    "description": "开源图像/视频超分辨率工具箱，集成ESRGAN/EDSR/RCAN等主流超分模型，支持训练和推理",
    "category": "GPU图形增强工具",
    "scenarios": ["超分模型训练", "超分模型推理", "多模型对比实验", "自定义超分模型开发", "视频超分处理"],
    "accuracy": 5, "efficiency": 3, "speed": 3,
    "conflicts_with": ["ESRGAN", "Real-ESRGAN"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "支持多种超分模型训练和推理；配置文件驱动；适合超分研究和定制化需求",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install basicsr",
    "fallback": ["Real-ESRGAN", "ESRGAN"]
}

TOOL_VapourSynth = {
    "name": "vapoursynth",
    "display_name": "VapourSynth",
    "description": "视频处理框架，支持滤镜链式处理，可用于视频超分/补帧/去噪/色彩校正等复杂处理管线的搭建",
    "category": "GPU图形增强工具",
    "scenarios": ["视频处理管线搭建", "超分补帧滤镜链", "视频去噪滤镜", "色彩空间校正", "专业视频后期"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["ffmpeg", "av"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "学习曲线较高但功能极其强大；支持Python脚本控制整个视频处理流程；可集成各种AI模型",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install vapoursynth",
    "fallback": ["ffmpeg", "av"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}