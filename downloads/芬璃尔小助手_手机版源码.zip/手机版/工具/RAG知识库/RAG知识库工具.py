TOOL_ChromaDB_本地向量数据库 = {
    "name": "chromadb", "display_name": "ChromaDB本地向量数据库", "description": "轻量级本地向量数据库，专为AI应用设计，支持嵌入式部署、内存模式和持久化模式，API简洁易用",
    "category": "RAG知识库", "scenarios": ["本地语义搜索", "小规模RAG", "原型开发"],
    "accuracy": 4, "efficiency": 4, "speed": 5,
    "conflicts_with": ["Qdrant"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "适合单机和小项目，零配置即可运行",
    "github_stars": 18000, "open_source": True,
    "download_command": "pip install chromadb", "fallback": ["faiss向量搜索库"]
}

TOOL_Qdrant_高性能向量搜索 = {
    "name": "qdrant", "display_name": "Qdrant高性能向量搜索", "description": "高性能向量搜索引擎，支持RESTful/gRPC API、过滤搜索、批量向量导入、水平扩展，Rust编写性能极佳",
    "category": "RAG知识库", "scenarios": ["高性能搜索", "生产级RAG", "推荐系统"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["ChromaDB"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "支持Docker部署，推荐生产环境使用",
    "github_stars": 25000, "open_source": True,
    "download_command": "pip install qdrant-client", "fallback": ["Milvus企业级向量"]
}

TOOL_Milvus_企业级向量 = {
    "name": "milvus", "display_name": "Milvus企业级向量数据库", "description": "云原生分布式向量数据库，支持万亿级向量规模、多索引类型、GPU加速、分布式部署，44K Star",
    "category": "RAG知识库", "scenarios": ["企业级RAG", "大规模向量检索", "推荐系统"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": ["Weaviate"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "适合大规模生产部署，支持Kubernetes",
    "github_stars": 44000, "open_source": True,
    "download_command": "pip install pymilvus", "fallback": ["Qdrant高性能向量搜索"]
}

TOOL_Weaviate_AI原生向量 = {
    "name": "weaviate", "display_name": "Weaviate AI原生向量数据库", "description": "AI原生向量数据库，内置向量化模块、GraphQL接口、混合搜索（向量+关键词），支持自动Schema推断",
    "category": "RAG知识库", "scenarios": ["AI原生应用", "语义搜索", "知识图谱"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["Milvus"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "内置OpenAI/Cohere等嵌入模型，开箱即用",
    "github_stars": 13000, "open_source": True,
    "download_command": "pip install weaviate-client", "fallback": ["pgvector PostgreSQL向量扩展"]
}

TOOL_pgvector_PostgreSQL向量扩展 = {
    "name": "pgvector", "display_name": "pgvector PostgreSQL向量扩展", "description": "PostgreSQL的向量相似搜索扩展，支持精确和近似最近邻搜索、IVFFlat和HNSW索引，与现有PG生态无缝集成",
    "category": "RAG知识库", "scenarios": ["已有PostgreSQL项目", "混合查询", "事务+向量"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": False, "usage_tips": "在已有PG数据库上直接扩展，无需额外服务",
    "github_stars": 13000, "open_source": True,
    "download_command": "pip install pgvector", "fallback": ["ChromaDB本地向量数据库"]
}

TOOL_LangChain_LLM框架 = {
    "name": "langchain", "display_name": "LangChain LLM框架", "description": "最流行的LLM应用开发框架，提供Chain、Agent、RAG、Tool等核心抽象，集成数百种模型和数据源",
    "category": "RAG知识库", "scenarios": ["LLM应用开发", "RAG流水线", "Agent开发"],
    "accuracy": 4, "efficiency": 4, "speed": 3,
    "conflicts_with": ["LlamaIndex"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "生态最丰富，适合复杂LLM应用编排",
    "github_stars": 105000, "open_source": True,
    "download_command": "pip install langchain", "fallback": ["LlamaIndex数据索引"]
}

TOOL_LlamaIndex_数据索引 = {
    "name": "llamaindex", "display_name": "LlamaIndex数据索引框架", "description": "专注于数据索引和RAG的LLM框架，提供数据连接器、索引结构、查询引擎，擅长处理多源异构数据",
    "category": "RAG知识库", "scenarios": ["文档RAG", "数据索引", "知识库构建"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["LangChain"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "RAG场景比LangChain更专注高效",
    "github_stars": 39000, "open_source": True,
    "download_command": "pip install llama-index", "fallback": ["LangChain LLM框架"]
}

TOOL_sentence_transformers_文本向量化 = {
    "name": "sentence-transformers", "display_name": "sentence-transformers文本向量化", "description": "最流行的文本嵌入模型库，提供大量预训练句子/文本嵌入模型，支持语义相似度计算、聚类、检索",
    "category": "RAG知识库", "scenarios": ["文本嵌入", "语义相似度", "向量化"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "推荐使用all-MiniLM-L6-v2，兼顾速度和质量",
    "github_stars": 18000, "open_source": True,
    "download_command": "pip install sentence-transformers", "fallback": []
}

TOOL_haystack_RAG框架 = {
    "name": "haystack", "display_name": "Haystack RAG框架", "description": "生产级RAG框架，提供完整的文档检索、问答管道、模型微调、评估和部署方案，支持多种检索器和Reader",
    "category": "RAG知识库", "scenarios": ["生产级RAG", "文档问答", "搜索系统"],
    "accuracy": 5, "efficiency": 4, "speed": 4,
    "conflicts_with": ["LangChain"], "safety_level": "safe",
    "requires_network": True, "usage_tips": "适合需要完整RAG管道的生产项目",
    "github_stars": 18000, "open_source": True,
    "download_command": "pip install haystack-ai", "fallback": ["LlamaIndex数据索引"]
}

TOOL_elasticsearch_搜索引擎 = {
    "name": "elasticsearch", "display_name": "Elasticsearch搜索引擎", "description": "分布式搜索和分析引擎，8.x版本支持向量搜索，结合全文搜索+向量搜索进行混合检索，企业级成熟方案",
    "category": "RAG知识库", "scenarios": ["全文搜索", "混合搜索", "日志分析"],
    "accuracy": 5, "efficiency": 5, "speed": 4,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "成熟稳定，适合已有ES基础设施的团队",
    "github_stars": 73000, "open_source": True,
    "download_command": "pip install elasticsearch", "fallback": ["redis-vector向量搜索"]
}

TOOL_redis_vector_向量搜索 = {
    "name": "redis-vector", "display_name": "Redis向量搜索", "description": "Redis的向量搜索模块(Redis Stack)，支持向量索引和相似搜索，与Redis缓存能力结合，延迟极低",
    "category": "RAG知识库", "scenarios": ["实时向量搜索", "缓存+向量", "低延迟场景"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": [], "safety_level": "safe",
    "requires_network": True, "usage_tips": "适合需要低延迟向量检索的场景",
    "github_stars": 0, "open_source": True,
    "download_command": "pip install redis", "fallback": ["ChromaDB本地向量数据库"]
}

TOOL_faiss_向量搜索库 = {
    "name": "faiss", "display_name": "FAISS向量搜索库", "description": "Meta开源的向量相似搜索库，支持多种索引结构（IVF、HNSW、PQ），CPU和GPU加速，极高检索性能",
    "category": "RAG知识库", "scenarios": ["大规模向量检索", "离线索引", "GPU加速"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["scann Google向量搜索"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "纯向量检索库，需自行管理存储和索引",
    "github_stars": 34000, "open_source": True,
    "download_command": "pip install faiss-cpu", "fallback": ["usearch紧凑向量搜索"]
}

TOOL_annoy_近似最近邻 = {
    "name": "annoy", "display_name": "Annoy近似最近邻搜索", "description": "Spotify开源的近似最近邻搜索库，使用随机投影树，内存占用小，支持静态文件索引，适合只读场景",
    "category": "RAG知识库", "scenarios": ["只读向量搜索", "内存敏感场景", "静态索引"],
    "accuracy": 3, "efficiency": 5, "speed": 5,
    "conflicts_with": ["FAISS"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "索引不可变，适合构建后不再修改的场景",
    "github_stars": 14000, "open_source": True,
    "download_command": "pip install annoy", "fallback": ["faiss向量搜索库"]
}

TOOL_scann_Google向量搜索 = {
    "name": "scann", "display_name": "ScaNN Google向量搜索", "description": "Google Research开源的向量相似搜索库，使用ScaNN算法（各向异性量化+重新排序），在大规模数据上速度极快",
    "category": "RAG知识库", "scenarios": ["超大规模检索", "高吞吐场景", "Google方案"],
    "accuracy": 5, "efficiency": 5, "speed": 5,
    "conflicts_with": ["faiss向量搜索库"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "对10M+级别的向量搜索表现优异",
    "github_stars": 4300, "open_source": True,
    "download_command": "pip install scann", "fallback": ["faiss向量搜索库"]
}

TOOL_usearch_紧凑向量搜索 = {
    "name": "usearch", "display_name": "USearch紧凑向量搜索", "description": "跨平台、零依赖的向量搜索引擎，支持C、C++、Python、JavaScript等多语言，单文件即可嵌入任何项目",
    "category": "RAG知识库", "scenarios": ["嵌入式设备", "跨平台应用", "轻量级搜索"],
    "accuracy": 4, "efficiency": 5, "speed": 5,
    "conflicts_with": ["FAISS"], "safety_level": "safe",
    "requires_network": False, "usage_tips": "零外部依赖，编译后仅几百KB，适合嵌入式",
    "github_stars": 3000, "open_source": True,
    "download_command": "pip install usearch", "fallback": ["faiss向量搜索库"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}