TOOL_TRANSLATORS = {
    "name": "translators",
    "display_name": "translators",
    "description": "聚合翻译引擎库，集成Google、Bing、DeepL、百度、有道等20+翻译API，统一接口调用",
    "category": "翻译工具",
    "scenarios": ["多引擎翻译", "翻译对比", "批量翻译", "跨语言沟通"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["deep-translator", "googletrans"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "支持自动检测源语言，可在不同引擎间切换比较翻译质量",
    "github_stars": 2400,
    "open_source": True,
    "download_command": "pip install translators",
    "fallback": ["deep-translator", "googletrans"]
}

TOOL_ARGOS_TRANSLATE = {
    "name": "argos_translate",
    "display_name": "Argos Translate",
    "description": "基于OpenNMT的离线翻译引擎，支持多种语言对，无需网络连接即可完成翻译",
    "category": "翻译工具",
    "scenarios": ["离线翻译", "隐私翻译", "本地化部署", "数据安全翻译"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["translators", "LibreTranslate"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "首次需下载语言包，后续完全离线使用",
    "github_stars": 5000,
    "open_source": True,
    "download_command": "pip install argostranslate",
    "fallback": ["LibreTranslate", "translate-python"]
}

TOOL_TRANSLATE_PYTHON = {
    "name": "translate_python",
    "display_name": "translate-python",
    "description": "轻量级翻译客户端，基于谷歌翻译API，支持100+语言，代码简洁易用",
    "category": "翻译工具",
    "scenarios": ["简单翻译", "快速集成", "命令行翻译", "轻量应用"],
    "accuracy": 3,
    "efficiency": 5,
    "speed": 5,
    "conflicts_with": ["googletrans", "translators"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "适合简单翻译场景，不支持批量翻译",
    "github_stars": 754,
    "open_source": True,
    "download_command": "pip install translate",
    "fallback": ["googletrans", "translators"]
}

TOOL_LIBRETRANSLATE = {
    "name": "libretranslate",
    "display_name": "LibreTranslate",
    "description": "自托管的开源翻译服务，可部署私有翻译服务器，支持API调用和Web界面",
    "category": "翻译工具",
    "scenarios": ["私有化部署", "企业翻译", "数据保密翻译", "自建翻译服务"],
    "accuracy": 3,
    "efficiency": 4,
    "speed": 3,
    "conflicts_with": ["argos_translate", "translators"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需自行部署服务端，支持Docker一键部署",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install libretranslate",
    "fallback": ["argos_translate", "translators"]
}

TOOL_DEEP_TRANSLATOR = {
    "name": "deep_translator",
    "display_name": "deep-translator",
    "description": "多引擎翻译库，支持Google、Bing、DeepL、Yandex、PONS、Libre等10+翻译服务",
    "category": "翻译工具",
    "scenarios": ["多引擎翻译", "翻译服务切换", "批量翻译", "翻译集成"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["translators", "googletrans"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "支持代理设置，适合需要切换不同翻译引擎的场景",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install deep-translator",
    "fallback": ["translators", "googletrans"]
}

TOOL_GOOGLETRANS = {
    "name": "googletrans",
    "display_name": "googletrans",
    "description": "谷歌翻译非官方API，支持100+语言的检测和翻译，使用简单但稳定性受限于免费接口限制",
    "category": "翻译工具",
    "scenarios": ["谷歌翻译", "语言检测", "简单翻译", "免费翻译"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["translate-python", "deep-translator"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "免费版有频率限制，建议添加延迟避免被封",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install googletrans==4.0.0-rc1",
    "fallback": ["translators", "translate-python"]
}

TOOL_BAIDU_TRANSLATE = {
    "name": "baidu_translate",
    "display_name": "百度翻译",
    "description": "百度翻译官方API，支持中英日韩等200+语言，中文翻译质量优秀，需注册百度开发者账号",
    "category": "翻译工具",
    "scenarios": ["百度翻译", "中文翻译", "中英互译", "商用翻译"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["googletrans", "youdao_translate"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需申请API Key和Secret Key，有免费额度",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install baidu-aip",
    "fallback": ["youdao_translate", "tencent-cloud-tts"]
}

TOOL_YOUDAO_TRANSLATE = {
    "name": "youdao_translate",
    "display_name": "有道翻译",
    "description": "有道翻译官方API，支持中英日韩法俄等100+语言，提供文本翻译和语音合成服务",
    "category": "翻译工具",
    "scenarios": ["有道翻译", "中英翻译", "语音翻译", "教育翻译"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["baidu_translate", "googletrans"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需注册有道智云获取API凭证",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install youdao-translate",
    "fallback": ["baidu_translate", "tencent-cloud-tts"]
}

TOOL_TENCENT_CLOUD_TTS = {
    "name": "tencent_cloud_tts",
    "display_name": "腾讯云翻译",
    "description": "腾讯云机器翻译服务，支持中英日韩法等20+语言，集成语音合成和自然语言处理能力",
    "category": "翻译工具",
    "scenarios": ["腾讯翻译", "语音合成翻译", "商业翻译", "多模态翻译"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["aliyun_nlp", "baidu_translate"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需开通腾讯云翻译服务并配置SecretId和SecretKey",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install tencentcloud-sdk-python",
    "fallback": ["aliyun_nlp", "baidu_translate"]
}

TOOL_ALIYUN_NLP = {
    "name": "aliyun_nlp",
    "display_name": "阿里云翻译",
    "description": "阿里云自然语言处理翻译服务，支持中英日韩德法等100+语言，集成分词、情感分析等NLP能力",
    "category": "翻译工具",
    "scenarios": ["阿里翻译", "NLP翻译", "商业翻译", "电商翻译"],
    "accuracy": 4,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["tencent_cloud_tts", "baidu_translate"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需注册阿里云并开通NLP翻译服务",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install aliyun-python-sdk-core",
    "fallback": ["tencent_cloud_tts", "baidu_translate"]
}

TOOL_DEEPL = {
    "name": "deepl",
    "display_name": "DeepL",
    "description": "DeepL官方翻译API，以翻译质量自然流畅著称，支持29种语言，特别擅长欧洲语言翻译",
    "category": "翻译工具",
    "scenarios": ["高质量翻译", "专业文档翻译", "欧洲语言翻译", "学术翻译"],
    "accuracy": 5,
    "efficiency": 4,
    "speed": 4,
    "conflicts_with": ["translators", "googletrans"],
    "safety_level": "safe",
    "requires_network": True,
    "usage_tips": "需注册DeepL API获取Auth Key，免费版有字符限制",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install deepl",
    "fallback": ["translators", "googletrans"]
}

TOOL_M2M100 = {
    "name": "m2m100",
    "display_name": "M2M-100",
    "description": "Meta发布的多语言翻译模型，支持100种语言之间的直接翻译，无需先转英文作为中间语言",
    "category": "翻译工具",
    "scenarios": ["多语言翻译", "低资源语言翻译", "学术研究", "小语种翻译"],
    "accuracy": 4,
    "efficiency": 2,
    "speed": 2,
    "conflicts_with": ["mbart", "nllb"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "模型较大(2.2GB)，推荐在GPU上使用",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install transformers",
    "fallback": ["nllb", "mbart"]
}

TOOL_MBART = {
    "name": "mbart",
    "display_name": "mBART",
    "description": "Meta发布的多语言去噪自编码器，支持50种语言的翻译和生成，特别适合多语言序列到序列任务",
    "category": "翻译工具",
    "scenarios": ["多语言翻译", "多语言生成", "跨语言迁移", "低资源翻译"],
    "accuracy": 4,
    "efficiency": 2,
    "speed": 2,
    "conflicts_with": ["m2m100", "nllb"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "需指定源语言和目标语言前缀标记",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install transformers",
    "fallback": ["m2m100", "nllb"]
}

TOOL_OPUS_MT = {
    "name": "opus_mt",
    "display_name": "OPUS-MT",
    "description": "赫尔辛基大学开发的OPUS翻译模型，覆盖1000+语言对，专注小语种和低资源语言的神经机器翻译",
    "category": "翻译工具",
    "scenarios": ["小语种翻译", "学术翻译", "低资源语言", "多语言对翻译"],
    "accuracy": 4,
    "efficiency": 3,
    "speed": 2,
    "conflicts_with": ["m2m100", "nllb"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "各语言对模型独立下载，大小因语言对而异",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install transformers",
    "fallback": ["m2m100", "nllb"]
}

TOOL_NLLB = {
    "name": "nllb",
    "display_name": "NLLB",
    "description": "Meta不落下任何语言(No Language Left Behind)项目，支持200种语言的翻译，特别覆盖非洲和亚洲低资源语言",
    "category": "翻译工具",
    "scenarios": ["低资源语言翻译", "稀有语言翻译", "跨语言研究", "普惠翻译"],
    "accuracy": 4,
    "efficiency": 2,
    "speed": 2,
    "conflicts_with": ["m2m100", "opus_mt"],
    "safety_level": "safe",
    "requires_network": False,
    "usage_tips": "有54B超大模型和蒸馏小模型可选，按需选择",
    "github_stars": 0,
    "open_source": True,
    "download_command": "pip install transformers",
    "fallback": ["m2m100", "opus_mt"]
}

_all_tools = {k: v for k, v in globals().items() if k.startswith("TOOL_")}
